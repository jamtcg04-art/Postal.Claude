# The Postal Trace: dialogue rework (pass 9)

Disco Elysium-style conversations, written once in plain-text scripts and played the same way in the
browser build and in Godot.

- `docs/WRITING_DIALOGUE.md`: how to write conversations (start here)
- `docs/DIALOGUE_SYSTEM.md`: what changed, how it fits together, test results, and how to put it into the port
- `dialogue/`: all 120 conversations as `.pt` scripts
- `godot/`: the Godot addon (`addons/pt_dialogue`), compiled data, a demo scene (open `godot/project.godot`), and tests
- `browser/index.html`: the browser build with the compiled conversations in place
- `build/`: compiler output: `report.md`, `graphs/*.svg` (one picture per conversation), Godot data, browser code
- `tools/`: the compiler and the test tools (Node 18+)
- `run_tests.sh`: compile and run every check
