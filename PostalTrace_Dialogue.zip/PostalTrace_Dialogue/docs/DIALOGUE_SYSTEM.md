# The Postal Trace dialogue system (pass 9)

## What changed

| | Before (browser artifact, and the Godot port through JsLite) | Now |
|---|---|---|
| Where conversations are written | `GRAPH[...] = {...}` objects inside the 27,000-line `index.html`, with JavaScript functions for every condition and changing line | `dialogue/*.pt`: 19 plain-text scripts, one per place |
| Conditions | 893 JavaScript functions | expressions (`not done.vane_scorn and coin >= 2`) compiled to a small tree both builds read |
| Godot | the browser's conversation screen redrawn through `bridge.gd`/`html.gd`, run by the JS interpreter | a native GDScript runner and a Disco-style scrolling log (`addons/pt_dialogue`) |
| Keeping builds the same | re-export the browser code | one compile step writes both builds' data; tests replay browser play in Godot |
| Checking | play it | a report of broken links, unknown names and unreachable nodes, and a picture of every conversation |

The game's rules did not change: same voices, thresholds, checks, modifiers, retries and memory keys
(`gseen_`, `gmet_`, `gu_`, `ck_` … in `S.done`), so existing saves load in either build.

## The parts

```
dialogue/*.pt  ──tools/compile.js──►  build/godot/data/dialogue/*.json   (Godot: PTDialogueDB)
                                 └──►  build/browser/pt_dialogue.gen.js    (browser: tools/patch_browser.js)
                                 └──►  build/report.md, build/graphs/*.dot|svg
```

- `tools/ptexpr.js`: the expression language: read, print, compile to JavaScript, evaluate.
- `tools/ptc.js`: reads and writes `.pt` scripts; writes the browser's GRAPH code.
- `tools/compile.js`: compiler, checker and graph pictures.
- `tools/extract.js`, `js2ast.js`, `normalize.js`: turned the browser's GRAPH into the scripts (done once; kept for reference).
- `godot/addons/pt_dialogue/`:
  - `pt_dialogue_runner.gd`: the conversation flow (hub, voices, branches, checks, retries, replays, returns).
  - `pt_cond.gd`: evaluates conditions with JavaScript's rules (so `undefined`, `null`, numbers and text compare as in the browser).
  - `pt_dialogue_db.gd`: loads the compiled conversations.
  - `pt_dialogue_host.gd`: what the runner asks of the game.
  - `pt_jslite_host.gd`: answers with the browser's own rule functions through JsLite (use this in the game now).
  - `pt_native_host.gd`: the same rules written in GDScript (skills, voices, modifiers, dice, effects, thoughts).
  - `ui/pt_dialogue_log.gd`: the dialogue column: one feed, voices coloured by attribute with *[Medium: Success]* tags,
    the dice line, beats revealed one at a time (Space), numbered choices (1–9) with odds, a hover card listing
    every modifier, and *[Leave.]*.
- `godot/demo/`: pick any of the 120 conversations, set skills, and play it on the native rules.

## Tests and what they showed (31 October 2026)

- **Round trip:** all 120 conversations written as `.pt` and read back are identical to the browser's data.
- **Same behaviour in the browser:** the 893 conditions and changing lines, compiled back to JavaScript, give the same
  answers and the same state changes as the originals over 150 random game states (133,950 calls, 0 differences).
- **The patched browser build** replays 294 of 295 recorded conversations exactly; the other one is the tavern dice game,
  which uses unseeded random numbers of its own.
- **Godot runner with the browser's rules** (`tests/parity_js.gd`): 295 recorded browser conversations, 2,012 screens,
  0 differences: same lines, same voices, same dice, same choices with the same states and odds.
- **Godot runner with the native rules** (`tests/parity.gd`): 277 of 295 runs identical. The 18 that differ are all in
  conversations that use `@js` fields or game queries the native rules don't have yet (market prices, the cellar,
  the dice game, the miller's petition, Karrow's mare).
- **Smoke:** every conversation walked with random choices on the native rules without a script error.

## Putting it into the Godot port

1. Copy `addons/pt_dialogue` and `data/dialogue` into the project.
2. Make a host on the game's JavaScript engine: `PTJsLiteHost.new(func(code): return <js_lite eval>(code))`.
3. Where the game opens a talk screen (the browser's `talk(ti)` → `graphShow`), open the runner instead:
   ```gdscript
   var runner := PTDialogueRunner.new(PTDialogueDB.new(), host)
   var log := PTDialogueLog.new()
   add_child(log); log.attach(runner)
   log.closed.connect(func(reason): pass)   # back to the 3D place
   runner.start(scene_id, {"id": talker_id, "name": name, "role": role, "mood": mood})
   ```
4. Run `tests/parity_js.gd` against the port's own engine instead of the test bridge.
5. Port game queries to `PTNativeHost.fns` one at a time; when a conversation has none left, it can run without JsLite.

I couldn't do steps 2–4 here: the port's project (PostalTrace_Godot.zip) wasn't in this session.

`browser/index.html` is the live artifact (version 1793303789-483f) with the conversations block added. The pass 7 and 8
browser changes are in PostalTrace_browser_index.html; to combine, run
`node tools/patch_browser.js PostalTrace_browser_index.html build/browser/pt_dialogue.gen.js out.html`.

## Keeping both builds the same, from now on

Write conversations in `dialogue/*.pt`, compile, patch the browser page, and copy the Godot data. Change rules
(voices, modifiers, effects) in the browser code as before; `PTJsLiteHost` picks them up at once, and
`tests/parity.gd` shows when `PTNativeHost` needs the same change.
