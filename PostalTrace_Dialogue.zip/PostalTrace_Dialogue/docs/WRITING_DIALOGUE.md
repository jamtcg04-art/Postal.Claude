# Writing dialogue for The Postal Trace

All conversations live in `dialogue/*.pt`, one file per place (`cross.pt`, `market.pt` …). They are plain
text: write them in any editor, keep them in git, and diff them. `tools/compile.js` turns them into the data
both builds read, so a line written once plays the same in the browser and in Godot.

```
node tools/compile.js --browser path/to/index.html --svg     # check and compile (see build/report.md)
node tools/patch_browser.js path/to/index.html build/browser/pt_dialogue.gen.js path/to/index.html
cp -r build/godot/data/dialogue  <godot project>/data/                # Godot reads data/dialogue/*.json
```

## The index card

```
=== cross:vane                   a conversation: <place>:<who>   (objects to look at: <place>:x_<thing>)
~ hub                            a node. Every conversation starts at "hub" (or "=== id hub=start")
Plain lines are what they say.   one paragraph per line
{done.vane_scorn} A line …       a line that only shows when the condition is true
{= mkPrice(2) + " coin"}         a line worked out when it is shown
@say {done.vane_soft}            variants: the first @say whose condition holds is used …
@say                             … and a bare @say is the fallback

@mood sad {done.x}               the portrait's mood (first match wins; a bare @mood is the fallback)
@by ledger                       the whole node is spoken by an inner voice
@flag vane_named                 set done.vane_named the first time you get here
@learn Vane has served.          a fact for the Learned list
@temp nerve 1 you let him talk   +1 Nerve on the next check (also @temp2)
@fx trust 1, hrs 1               change Valley trust, hours, coin, duty, health, stamina …
@give plea  / @take plea         items
@xp 2   @thought quiet   @tally loyal   @log text   @ban vane:0 (a banter key)   @fail text (a failed check's voice line)

> wits 1+ | text                 an inner voice that speaks when Wits ≥ 1 (a passive check)
> arms ..0 | text                speaks when Arms ≤ 0 (an "anti-passive": you failed to notice)
> ledger 1..3 {cond} | text      a voice by name, a range, and a condition
> ledger 1+ ask "“Struck through?”" -> v_ledger / "“His books are his business.”" | text
                                 a voice that opens its own branch (the / part is the refusal)
@argue {cond} min=battery:1      voices arguing among themselves, one per indented line:
  duty | He sits while …
  battery | He has the dry end …

* “Where did you serve?” -> serve #once          an option; #once greys it out after use
* {not done.vane_scorn} Square up. #once        an option that only shows when the condition holds
  @check nerve 8 -> stare_ok / stare_bad         a WHITE check: retry when your skill or knowledge changes
  @check nerve 9 -> ok / bad #red v=bluff        a RED check: one chance. v= picks the voice that rolls
  @check wits 8 -> ok / bad with=nerve/parade    a second skill helps with half its value
* Go back. -> <                  "<" returns to where a voice branch was opened (or the hub)
* Leave him to it.               no arrow: the conversation ends
* … #off  #think:quiet  #past:2  #tally:loyal  #side:duty    off the record · needs a thought ·
                                 needs Redoubt Nine memories · counts toward a courier type · Duty vs the hat
  @flag / @temp / @fx / @xp / @give / @learn under an option happen when it is first chosen
```

Conditions read the game state: `done.<flag>` for story flags, plain fields such as `coin`, `duty`, `trust`,
`hp`, `level`, and game queries like `has("hat")`, `pastN()`, `crossState()`. Write `not`, `and`, `or`,
`==`, `!=`, `<`, `>=` …, numbers and "text". Lines starting with `//` are notes for you.

Voices: `shoulder ramrod splinter` (Arms), `parade bluff battery` (Nerve), `ledger wire cipher` (Wits),
`longroad mud ringing` (Grit), and `duty`, `hat`, `trace`. A skill name (`wits`) means that skill's
plain voice (Ledger).

## How it plays (the Disco Elysium rules the runner follows)

- **Hub and spokes.** Every talk opens on the hub. Topics marked `#once` grey out when asked, but
  can be heard again; checks you passed can be replayed for their text. The hub always has a way out.
- **Passive checks.** Up to three inner voices speak on each screen, in the order written, if their value
  is in range. In Godot they show Disco's tag: `> wits 2+` shows *[Medium: Success]* (value + 6 against 8);
  `> arms ..0` shows *[Easy: Failure]*.
- **White checks** can be tried again once the skill goes up, you learn something new, or a thought
  sinks in. **Red checks** are one-shot; an internalised Tin Thought with that skill gives one more try.
  The odds and every named modifier show before you choose (hover the option in Godot).
- **Failure is content.** Write both branches. After a failure the voice that rolled says something,
  unless the fail node already gives that voice a line (or write your own with `@fail`).
- **Reactivity.** Tag memorable moments with a flag (`@flag`), then let later lines, options and check
  modifiers read it. Name flags by place and person: `vane_named`, `mk_cellar_known`.
- **Your character.** `#tally:` choices build the courier's type (three of a kind brings a Tin Thought);
  `#side:duty` / `#side:hat` weigh the Crown against the person in front of you.

## Things kept as JavaScript

A few fields are written as `@js` blocks holding the browser's own code: actions such as starting a fight,
buying, or selling a man to the press-gang (`@js run` under an option), and some market lines that use list
helpers. Both builds run them through the browser's code (Godot via JsLite). Rewrite one as conditions
and `{= …}` lines whenever you like; the compiler tells you how many are left.

## Checking your work

`build/report.md` lists errors (a `->` to a node that does not exist, an unknown voice, skill, item or
thought, a check with no fail branch) and warnings (a node nothing leads to, a hub with no way out, a
flag that is read but never set anywhere — usually a typo). `build/graphs/*.svg` draws each conversation:
the hub is a box, checks are diamonds (red ones red), voice branches are dotted.
