class_name PTDialogueHost
extends RefCounted
## What the dialogue runner needs from the game. The runner owns the conversation flow
## (which lines show, which options are open, white/red check memory, returns and replays);
## the host owns the game's rules and state (skills, the dice, effects, Tin Thoughts).
##
## Two hosts ship with the addon:
##   PTNativeHost   – the rules written in GDScript over a state Dictionary (same shape as the browser's S)
##   PTJsLiteHost   – hands every rule to the browser's own functions through the port's JsLite engine
## Override any method to plug the runner into another state store.

# ---------- state (conditions read and write through these) ----------
func get_path(_path: String):
	return PTCond.UNDEF

func set_path(_path: String, _value) -> void:
	pass

## A named game query from a condition or a computed line: has("hat"), pastN(), mkPrice(2) …
func call_fn(_name: String, _args: Array):
	return PTCond.UNDEF

## A field kept as JavaScript in the script (@js). `closure` holds the values it captured.
## `is_action` is true for an option's @js run (start a fight, open a shop …).
func run_js(_src: String, _closure: Dictionary, _is_action: bool):
	push_warning("PTDialogueHost: this host cannot run @js fields")
	return null

## An option's @js run (start a fight, open a shop, sell a man to the press-gang …).
## Return where the conversation goes next, if it goes on:
##   {"go": node, "chips": [...]}         arrive at a node (its effects apply), as the browser's mkGo
##   {"show": node, "chips": [...], "note": ""}   redraw a node, as mkRe
##   {"leave": true}                       back to the scene
##   {"ending": "death"}                   the run is over
##   {}                                    something else took over (a fight, a shop screen)
func run_action(src: String, closure: Dictionary, _runner) -> Dictionary:
	run_js(src, closure, true)
	return {}

func done(key: String):
	return get_path("done." + key)

func set_done(key: String, value) -> void:
	set_path("done." + key, value)

# ---------- voices and skills ----------
func voice_exists(_v: String) -> bool: return false
func voice_val(_v: String) -> int: return 0
func voice_name(v: String) -> String: return v
func voice_head(v: String) -> String: return voice_name(v)
## The voice that rolls a check for this skill, read from what the option says.
func voice_for(_sk: String, _text: String) -> String: return ""
func default_voice(sk: String) -> String: return sk
func skill_name(sk: String) -> String: return sk
## Text as a voice says it (the browser's addrOpen + meFill).
func voice_text(_v: String, text: String) -> String: return text
func muted_by(_v: String) -> bool: return false

# ---------- checks ----------
## The browser's modifiers(): { tot, dc, list: [String], v, vn }
func modifiers(_check: Dictionary) -> Dictionary: return {"tot": 0, "dc": int(_check.get("dc", 7)), "list": [], "v": "", "vn": ""}
## Two six-sided dice: { a, b, total, ok, crit }
func roll(_m: Dictionary) -> Dictionary: return {"a": 1, "b": 1, "total": 2, "ok": false, "crit": "lo"}
## skill + temporary bonuses + trained rank (the browser's ckTot): a white check can be retried once this goes up
func check_total(_sk: String, _v: String) -> int: return 0
func temp_labels() -> Array: return []
func clear_temp() -> void: pass
func thought_retry(_sk: String) -> String: return ""
func spend_thought_retry(_tid: String, _sk: String) -> void: pass
func thought_name(tid: String) -> String: return tid
func thought_done(_tid: String) -> bool: return false
func internal_count() -> int: return 0
func learned_count() -> int: return 0
func past_n() -> int: return 0
func perk(_p: String) -> bool: return false
func hardcore() -> bool: return false

# ---------- effects (each returns chips: short lines like "Nerve +1 on the next check") ----------
## fx, temp, temp2, give, take, xp, flag, log, learn, thought on a node or option
func apply_node(_src: Dictionary, _scene: String, _talker: Dictionary, _runner) -> Array: return []
func tally_add(_tag: String) -> Array: return []
func side_add(_side: String) -> Array: return []
## After a failed check: the rolling voice has its say (the browser's failVoice).
func fail_voice(_v: String, _node: Dictionary, _key: String, _runner) -> void: pass
## Lines queued by effects (pattern thoughts, reactions), drained each screen: [{v, text, beat}]
func drain_voices() -> Array: return []
## An ending the conversation has caused ("death", "late"), or "".
func check_end() -> String: return ""

# ---------- scene flavour ----------
func banter(_scene: String, _key: String) -> Array: return []
func manner(_scene: String, _talker: Dictionary) -> String: return ""
func companion_lines(_scene: String, _talker: Dictionary, _first_meet: bool) -> Array: return []
