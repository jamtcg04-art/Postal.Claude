class_name PTJsLiteHost
extends PTDialogueHost
## Runs the dialogue on the browser build's own rules, inside the port's JavaScript engine (scripts/js_lite.gd
## with data/lib.json). The flow (what shows, what is open, check memory) is native GDScript; every rule
## (skills, voices, modifiers, dice, effects, Tin Thoughts) and every @js field is the browser's code.
## Use this in the main game until a rule is ported to PTNativeHost; then both hosts give the same screens.
##
## Wiring: give it a Callable that evaluates a JavaScript expression in the game's scope and returns the
## value as Godot data (Dictionary/Array/String/float/bool/null). For the port that is a one-liner around JsLite:
##     var host := PTJsLiteHost.new(func(code): return js_lite.eval_expression(code))
## (Use whatever JsLite calls its evaluate method.)

var js: Callable


func _init(p_eval: Callable) -> void:
	js = p_eval


func _q(v) -> String:
	return JSON.stringify(v)


func _call(fn: String, args: Array):
	return js.call(fn + "(" + ", ".join(args.map(func(a): return _q(a))) + ")")


# ---------- state ----------
func get_path(path: String):
	# read the way the compiled browser code does: (S.a && S.a.b); a missing field comes back as undefined
	var v = js.call("(function (p) { var o = S; for (var i = 0; i < p.length; i++) { if (i >= 1 && !o) return o === undefined ? { __undef: 1 } : o; if (o === null || typeof o !== 'object' || !(p[i] in o)) return { __undef: 1 }; o = o[p[i]]; } return o === undefined ? { __undef: 1 } : o; })(" + _q(path.split(".")) + ")")
	return PTCond.UNDEF if v is Dictionary and v.has("__undef") and v.size() == 1 else v

func set_path(path: String, value) -> void:
	var parts := path.split(".")
	var code := "S"
	for i in parts.size() - 1:
		code += "[" + _q(parts[i]) + "]"
		js.call("(" + code + " = " + code + " || {}, 0)")
	js.call("(" + code + "[" + _q(parts[-1]) + "] = " + _q(value) + ", 0)")

func call_fn(name: String, args: Array):
	return _call(name, args)

## An action: the browser's own code runs; where it would have drawn the next screen is caught and handed back.
func run_action(src: String, closure: Dictionary, runner) -> Dictionary:
	var t: Dictionary = runner.talker
	var ti := _q(String(t.id).trim_prefix("x_")) if t.get("obj", false) else "0"
	var r = js.call("(function () {" +
		" CURG = { ti: " + ti + ", nodeId: " + _q(runner.node_id) + ", tid: " + _q(t.id) + " };" +
		" var out = {}, g0 = graphGo, s0 = graphShow, sc0 = scene, e0 = ending;" +
		" graphGo = function (ti, n, prev) { out = { go: n, chips: (prev && prev.chips) || [] }; };" +
		" graphShow = function (ti, n, ctx) { out = { show: n, chips: (ctx && ctx.chips) || [], note: (ctx && ctx.note) || '' }; };" +
		" scene = function () { out = { leave: true }; };" +
		" ending = function (e) { out = { ending: e }; };" +
		" try { (" + js_value({"__fn": src, "__closure": closure}) + ")(); } finally { graphGo = g0; graphShow = s0; scene = sc0; ending = e0; }" +
		" return out; })()")
	if not (r is Dictionary): return {}
	if r.has("chips"): r.chips = (r.chips as Array).map(func(h): return _strip(h))
	if r.has("note"): r.note = _strip(r.note)
	return r

## @js fields: rebuild the function with the values it captured, then call it
func run_js(src: String, closure: Dictionary, _is_action: bool):
	return js.call("(" + js_value({"__fn": src, "__closure": closure}) + ")()")

static func js_value(c) -> String:
	if c is Dictionary:
		if c.has("__undef"): return "undefined"
		if c.has("__fn"):
			var cl: Dictionary = c.get("__closure", {})
			if cl.is_empty(): return "(" + String(c.__fn) + ")"
			return "(function (" + ", ".join(cl.keys()) + ") { return " + String(c.__fn) + "; })(" + ", ".join(cl.values().map(func(x): return js_value(x))) + ")"
		return "{" + ", ".join(c.keys().map(func(k): return JSON.stringify(k) + ": " + js_value(c[k]))) + "}"
	if c is Array: return "[" + ", ".join(c.map(func(x): return js_value(x))) + "]"
	return JSON.stringify(c)

static func _strip(html) -> String:
	var re := RegEx.new(); re.compile("<[^>]+>")
	return re.sub(String(html), "", true).replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")

func _chips(code: String) -> Array:
	var a = js.call(code)
	return (a as Array).map(func(h): return _strip(h)) if a is Array else []


# ---------- voices and skills: the browser's own functions ----------
func voice_exists(v: String) -> bool: return js.call("!!VOICES[" + _q(v) + "]")
func voice_val(v: String) -> int: return int(_call("voiceVal", [v]))
func voice_name(v: String) -> String: return String(js.call("VOICES[" + _q(v) + "] ? VOICES[" + _q(v) + "].name : " + _q(v)))
func voice_head(v: String) -> String: return String(_call("voiceHead", [v]))
func voice_for(sk: String, text: String) -> String: return String(_call("voiceFor", [sk, text]))
func default_voice(sk: String) -> String: return String(js.call("DEF_VOICE[" + _q(sk) + "] || " + _q(sk)))
func skill_name(sk: String) -> String: return String(js.call("SKILLS[" + _q(sk) + "] || " + _q(sk)))
func voice_text(v: String, text: String) -> String: return String(js.call("meFill(addrOpen(" + _q(v) + ", " + _q(text) + "))"))
func muted_by(v: String) -> bool: return bool(_call("mutedBy", [v]))

# ---------- checks ----------
func modifiers(ch: Dictionary) -> Dictionary:
	return js.call("(function (m) { return { tot: m.tot, dc: m.dc, list: m.list, v: m.v || '', vn: m.vn || '' }; })(modifiers(" + _q(ch) + "))")
func roll(m: Dictionary) -> Dictionary: return _call("rollDice", [m])
func check_total(sk: String, v: String) -> int: return int(_call("ckTot", [sk, v]))
func temp_labels() -> Array: return js.call("S.temp.map(function (t) { return SKILLS[t.sk] + ' ' + (t.v > 0 ? '+' : '') + t.v + ' · ' + t.label; })")
func clear_temp() -> void: js.call("(S.temp = [], 0)")
func thought_retry(sk: String) -> String: var t = _call("thoughtRetry", [sk]); return String(t) if t else ""
func spend_thought_retry(tid: String, sk: String) -> void: js.call("(S.done['thr_' + " + _q(tid) + "] = true, S.done['thrsk_' + " + _q(sk) + "] = true, 0)")
func thought_name(tid: String) -> String: return String(js.call("THOUGHTS[" + _q(tid) + "] ? THOUGHTS[" + _q(tid) + "].name : " + _q(tid)))
func thought_done(tid: String) -> bool: return bool(_call("thoughtDone", [tid]))
func internal_count() -> int: return int(js.call("internalCount()"))
func learned_count() -> int: return int(js.call("S.learned.length"))
func past_n() -> int: return int(js.call("pastN()"))
func perk(p: String) -> bool: return bool(_call("perk", [p]))
func hardcore() -> bool: return bool(js.call("!!S.hard"))

# ---------- effects ----------
## Effects use the browser's applyNode on the original GRAPH node, so learn/thought texts and chips are exact.
func apply_node(src: Dictionary, scene: String, talker: Dictionary, runner) -> Array:
	var ref := _node_ref(src, runner)
	return _chips("applyNode(" + ref + ", def(" + _q(scene) + ") || { title: " + _q(scene) + " }, " + _q({"id": talker.get("id"), "name": talker.get("name", "")}) + ", [])")
func tally_add(tag: String) -> Array: return _chips("(function (c) { tallyAdd(" + _q(tag) + ", c); return c; })([])")
func side_add(side: String) -> Array: return _chips("(function (c) { sideAdd(" + _q(side) + ", c); return c; })([])")
func fail_voice(v: String, node: Dictionary, k: String, runner) -> void:
	js.call("(failVoice(" + _q(v) + ", " + _node_ref(node, runner) + ", " + _q(k) + "), 0)")
func drain_voices() -> Array:
	var q = js.call("(function () { var q = (S.vq || []).filter(function (x) { return x[0].charAt(0) !== '_'; }); S.vq = []; return q; })()")
	return (q as Array).map(func(x): return {"v": x[0], "text": x[1], "beat": x[3] if x.size() > 3 else ""}) if q is Array else []
func check_end() -> String: var e = js.call("checkEnd()"); return String(e) if e else ""

## The same node in the engine's GRAPH (falls back to the compiled one if the engine has no GRAPH entry)
func _node_ref(src: Dictionary, runner) -> String:
	if runner and runner.G.nodes.get(runner.node_id) == src:
		return "GRAPH[" + _q(runner.conv_id) + "].nodes[" + _q(runner.node_id) + "]"
	if runner:
		for nid in runner.G.nodes:
			if runner.G.nodes[nid] == src: return "GRAPH[" + _q(runner.conv_id) + "].nodes[" + _q(nid) + "]"
			var opts: Array = runner.G.nodes[nid].get("opts", [])
			for j in opts.size():
				if opts[j] == src: return "GRAPH[" + _q(runner.conv_id) + "].nodes[" + _q(nid) + "].opts[" + str(j) + "]"
	return _q(src)

# ---------- flavour ----------
func banter(scene: String, k: String) -> Array:
	var a = js.call("(BANTER[" + _q(scene) + "] || []).filter(function (b) { return b.on === " + _q(k) + "; }).reduce(function (o, b) { return o.concat(b.lines.map(function (l) { return { who: l[0] ? nameOf(" + _q(scene) + ", l[0]) : '', text: String(l[1]) }; })); }, [])")
	return a if a is Array else []
func manner(scene: String, talker: Dictionary) -> String:
	return _strip(js.call("mannerHtml(" + _q(scene) + ", { id: " + _q(talker.get("id")) + " })"))
