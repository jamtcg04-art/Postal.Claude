class_name PTNativeHost
extends PTDialogueHost
## The browser build's dialogue rules, written in GDScript, over a state Dictionary `S` with the browser's
## own shape (S.done, S.up, S.temp, S.thoughts, S.inv …), so saves and conditions read the same.
##
## Ported from index.html: skillParts / voiceVal / voiceFor / modifiers / okRoll / addTemp / applyFx /
## addXp / gain / tallyAdd / sideAdd / newThought / failVoice / thoughtRetry / addrOpen / meFill.
## Not ported here (the JsLite host covers them): companions (COMP), Duty reactions (dutyEvent),
## and the game-specific queries a few conditions call (crossState, mkPrice …); add those with `fns`.

const LIM := {"hp": [0, 10], "st": [0, 10], "pw": [0, 6], "ra": [0, 9], "hrs": [0, 99], "notice": [0, 5], "trust": [-3, 3], "coin": [0, 20], "duty": [-3, 3]}
const FX_KEYS := ["hp", "st", "pw", "ra", "hrs", "notice", "trust", "coin", "duty"]
const NAMES := {"hp": "Health", "st": "Stamina", "pw": "Powder", "ra": "Rations", "hrs": "Hours", "notice": "Notice", "trust": "Valley trust", "coin": "Coin", "duty": "Duty"}
const XP_PER_POINT := 7
const V_PTS := 2

var S: Dictionary
var R: Dictionary                  # rules.json
## extra game queries for conditions: name -> Callable(args: Array) -> value
var fns := {}
## where the dice come from: a Callable returning 1..6 (tests pass a seeded one)
var d6: Callable
var _rng := RandomNumberGenerator.new()
var _addr_last := {}
var _warned := {}
var _vre := []                     # V_RULES as [skill, voice, RegEx]


func _init(rules: Dictionary, state := {}) -> void:
	R = rules
	S = state if not state.is_empty() else fresh()
	_rng.randomize()
	d6 = func(): return _rng.randi_range(1, 6)
	for r in R.get("V_RULES", []):
		var re := RegEx.new()
		var src: String = r[2].__re
		re.compile(("(?i)" if String(r[2].get("flags", "")).contains("i") else "") + src)
		_vre.append([r[0], r[1], re])


## A new game's state, as the browser's fresh().
static func fresh() -> Dictionary:
	return {"trait": null, "hp": 6, "st": 8, "pw": 4, "ra": 4, "hrs": 0, "notice": 0, "trust": 0, "coin": 3, "duty": 0, "wet": false, "sealBroken": false,
		"read": false, "sold": false, "full": 0, "partial": 0, "withheld": 0, "delivered": [], "route": [], "idx": 0, "inv": ["case"], "copies": 4, "log": [],
		"up": {"arms": 0, "nerve": 0, "wits": 0, "grit": 0}, "xp": 0, "level": 1, "points": 0, "done": {}, "errands": 0, "relay": {}, "out": {}, "seen": 0,
		"temp": [], "talked": {}, "learned": [], "perc": {}, "worn": {}, "assessed": {}, "thoughts": [], "loose": [], "mull": {},
		"tally": {"loyal": 0, "merciful": 0, "cynical": 0, "frightened": 0}, "side": {"duty": 0, "hat": 0}, "past": {"n": 0, "view": null, "last": -9}, "holes": 2, "vq": []}


func _i(v) -> int:
	return int(PTCond.num(v)) if not (PTCond.is_undef(v) or v == null) else 0


# ---------- state ----------
func get_path(path: String):
	return PTCond.read_path(S, path)

func set_path(path: String, value) -> void:
	PTCond.write_path(S, path, value)

func call_fn(name: String, args: Array):
	match name:
		"has": return has(String(args[0]))
		"pastN": return past_n()
		"thoughtDone": return thought_done(String(args[0]))
		"vVal": return voice_val(String(args[0]))
		"voiceOn": return voice_exists(String(args[0])) and (String(args[0]) != "hat" or has("hat"))
		"compHere": return S.get("comp") if S.get("comp") else null
		"perk": return perk(String(args[0]))
	if fns.has(name):
		return fns[name].call(args)
	if not _warned.has(name):
		_warned[name] = true
		push_warning("PTNativeHost: no game query '%s' (add it to fns, or use the JsLite host)" % name)
	return PTCond.UNDEF

func run_js(src: String, _closure: Dictionary, is_action: bool):
	if not _warned.has(src):
		_warned[src] = true
		push_warning("PTNativeHost: @js %s kept as JavaScript; it needs the JsLite host: %s" % ["action" if is_action else "field", src.substr(0, 80)])
	return null

func has(id: String) -> bool:
	return (S.get("inv", []) as Array).has(id)


# ---------- skills and voices ----------
func skill_parts(sk: String) -> Array:
	var p := []
	if sk == "grit": p.append(["Veteran’s endurance", 1])
	var t = R.TRAITS.get(S.get("trait")) if S.get("trait") is String else null
	if t and t[0] == sk: p.append([t[1], 2])
	if S.get("worn", {}).get("hat"):
		if sk == "nerve": p.append(["Lieutenant Hale’s hat", 2])
		if sk == "wits": p.append(["Lieutenant Hale’s hat", -2])
	var up := _i(S.get("up", {}).get(sk, 0))
	if up: p.append(["Points you put in", up])
	for tid in S.get("thoughts", []):
		var th = R.THOUGHTS.get(tid)
		if not th: continue
		var mulling := _i(S.get("mull", {}).get(tid, 0)) > 0
		if th.has("bonus") and th.bonus.get(sk) and not mulling: p.append([th.name, _i(th.bonus[sk])])
		if th.has("cost") and th.cost.get(sk) and mulling: p.append([th.name + " (mulling)", _i(th.cost[sk])])
	return p

func skill_bonus(sk: String) -> int:
	var t := 0
	for x in skill_parts(sk): t += int(x[1])
	return t

func temp_total(sk: String) -> int:
	var t := 0
	for x in S.get("temp", []): if x.sk == sk: t += _i(x.v)
	return t

func v_rank(v: String) -> int:
	return _i(S.get("vr", {}).get(v, 0)) if S.get("vr") is Dictionary else 0

func vperk(k: String) -> bool:
	for v in R.VPERK:
		var lst: Array = R.VPERK[v]
		for i in lst.size():
			if lst[i][2] == k and v_rank(v) > i: return true
	return false

func voice_exists(v: String) -> bool:
	return R.VOICES.has(v)

func voice_val(v: String) -> int:
	var V = R.VOICES.get(v)
	if V == null: return -99
	if V.has("sk"): return skill_bonus(V.sk) + temp_total(V.sk) + v_rank(v)
	match v:
		"duty": return _i(S.get("duty", 0))
		"hat": return (2 if S.get("worn", {}).get("hat") else 1) if has("hat") else 0
		"trace": return _i(S.get("trust", 0))
	return 0

func voice_name(v: String) -> String:
	return String(R.VOICES[v].name) if R.VOICES.has(v) else v

func voice_head(v: String) -> String:
	var V = R.VOICES.get(v)
	if V == null: return v
	var pre := ""
	if V.has("sk"): pre = String(R.SKILLS[V.sk]) + " · "
	elif V.has("tag"): pre = String(V.tag) + " · "
	return pre + String(V.name)

func voice_for(sk: String, text: String) -> String:
	for r in _vre:
		if r[0] == sk and r[2].search(text) != null: return r[1]
	return String(R.DEF_VOICE.get(sk, sk))

func default_voice(sk: String) -> String:
	return String(R.DEF_VOICE.get(sk, sk))

func skill_name(sk: String) -> String:
	return String(R.SKILLS.get(sk, sk))

func me_word() -> String:
	var a = S.get("arch")
	return String(R.ADDR[a]) if a is String and R.get("ADDR") and R.ADDR.has(a) else "courier"

func voice_text(v: String, text: String) -> String:
	# addrOpen: the plain skill voices open about one line in three with your title
	var a = S.get("arch")
	if R.get("ADDR_V", {}).has(v) and a is String and R.get("ADDR") and R.ADDR.has(a) and not text.to_lower().contains("{me}"):
		var re := RegEx.new(); re.compile("(?i)\\b" + String(R.ADDR[a]) + "\\b")
		if re.search(text) == null:
			var h := 0
			for i in text.length(): h = (h * 31 + text.unicode_at(i)) & 0xFFFFFFFF
			var mark := str(_i(S.get("idx", 0))) + ":" + text
			if h % 3 == 0 and _addr_last.get(v) != mark:
				_addr_last[v] = mark
				text = "{Me}. " + text
	var w := me_word()
	return text.replace("{me}", w).replace("{Me}", w.substr(0, 1).to_upper() + w.substr(1))

func muted_by(v: String) -> bool:
	for tid in S.get("thoughts", []):
		var th = R.THOUGHTS.get(tid)
		if th and th.get("mute") == v and thought_done(tid): return true
	return false


# ---------- checks ----------
static func _signed(n: int) -> String:
	return ("+" if n >= 0 else "−") + str(abs(n))

func modifiers(ch: Dictionary) -> Dictionary:
	var m := []
	var tot := 0
	var sk: String = ch.skill
	var sb := skill_bonus(sk)
	var vv := ""
	if ch.get("v", "") != "" and R.VOICES.has(ch.v) and R.VOICES[ch.v].get("sk") == sk: vv = ch.v
	else: vv = voice_for(sk, String(ch.get("txt", "")))
	if not R.VOICES.has(vv): vv = ""
	var vr := v_rank(vv) if vv != "" else 0
	var vn := voice_name(vv) if vv != "" else String(R.SKILLS.get(sk, "No roll"))
	tot += sb + vr
	m.append(vn + " " + _signed(sb + vr) + ((" (" + skill_name(sk) + " " + _signed(sb) + ", trained " + _signed(vr) + ")") if vr else ""))
	if ch.has("with") and R.SKILLS.has(ch.with.sk):
		var w2: Dictionary = ch.with
		var h2 := skill_bonus(w2.sk) + (v_rank(w2.v) if w2.has("v") and R.VOICES.has(w2.v) else 0)
		var a2 := int(ceil(h2 / 2.0)) if h2 > 0 else 0
		var wn := voice_name(w2.v) if w2.has("v") and R.VOICES.has(w2.v) else skill_name(w2.sk)
		tot += a2
		m.append(wn + " helps " + _signed(a2) + " (half of " + skill_name(w2.sk) + " " + _signed(h2) + ")")
		vn = vn + " + " + wn
	if _i(S.hp) <= 4 and not vperk("no_wound_pen"): tot -= 1; m.append("wounds -1")
	if _i(S.st) <= 3: tot -= 1; m.append("exhaustion -1")
	if sk == "arms" and S.get("wet"):
		var wp := 1 if vperk("wet_half") else 2
		tot -= wp; m.append("wet powder -" + str(wp))
	for t in S.get("temp", []):
		if t.sk == sk:
			tot += _i(t.v); m.append(String(t.label) + " " + ("+" if _i(t.v) > 0 else "") + str(_i(t.v)))
	var dc := int(ch.dc)
	var route: Array = S.get("route", [])
	var idx := _i(S.get("idx", 0))
	var here = route[idx] if idx < route.size() else null
	var dn: Dictionary = S.done
	if here == "cross":
		if dn.get("vane_scorn") and sk == "nerve": tot -= 1; m.append("Vane has seen you flinch -1")
		if dn.get("vane_soft") and sk == "wits": tot += 1; m.append("Vane weighed your arithmetic +1")
		if dn.get("vane_wavers") and sk == "nerve": tot += 1; m.append("Vane is wavering +1")
	if _i(S.get("notice", 0)) >= 3: dc += 1; m.append("valley on alert, target +1")
	var stage := 2 if idx >= 11 else (1 if idx >= 6 else 0)
	if stage and here != "malice": dc += stage; m.append(("deep in the valley" if stage > 1 else "the war closing in") + ", target +" + str(stage))
	if dn.get("cp_pass") and (here == "oak" or here == "malice") and (sk == "nerve" or sk == "wits"): tot += 1; m.append("Lisle’s provost pass +1")
	if S.get("hard"): dc += 1; m.append("hardcore, target +1")
	var lvl := _i(S.get("level", 1))
	if ch.get("red", false) and lvl >= 4:
		var rr := 2 if lvl >= 6 else 1
		dc += rr; m.append("a red check at level " + str(lvl) + ", target +" + str(rr))
	if S.get("hard") and lvl >= 4: dc += 1; m.append("hardcore at level " + str(lvl) + ", target +1")
	if dn.get("fd_cart_good") and here == "oak": tot += 1; m.append("the garrison’s goodwill +1")
	if dn.get("wl_bet") and here == "oak": tot += 2; m.append("Bet walked you past the sentries +2")
	if dn.get("hs_done") and here == "ridge": tot += 2; m.append("the Ridge gun fires again +2")
	if dn.get("cp_report") and not dn.get("cp_report_stopped") and here == "malice": dc += 2; m.append("Lisle’s report is on Corvane’s desk, target +2")
	return {"tot": tot, "dc": dc, "list": m, "v": vv, "vn": vn}

static func ok_roll(a: int, b: int, tot: int, dc: int) -> bool:
	return (a == 6 and b == 6) or (not (a == 1 and b == 1) and a + b + tot >= dc)

func roll(m: Dictionary) -> Dictionary:
	var a: int = d6.call()
	var b: int = d6.call()
	return {"a": a, "b": b, "total": a + b + int(m.tot), "ok": ok_roll(a, b, int(m.tot), int(m.dc)), "crit": "hi" if a == 6 and b == 6 else ("lo" if a == 1 and b == 1 else "")}

func check_total(sk: String, v: String) -> int:
	return skill_bonus(sk) + temp_total(sk) + (v_rank(v) if v != "" else 0)

func temp_labels() -> Array:
	return S.get("temp", []).map(func(t): return skill_name(t.sk) + " " + ("+" if _i(t.v) > 0 else "") + str(_i(t.v)) + " · " + String(t.label))

func clear_temp() -> void:
	S.temp = []

func thought_done(tid: String) -> bool:
	return (S.get("thoughts", []) as Array).has(tid) and not (_i(S.get("mull", {}).get(tid, 0)) > 0)

func thought_name(tid: String) -> String:
	return String(R.THOUGHTS[tid].name) if R.THOUGHTS.has(tid) else tid

func thought_retry(sk: String) -> String:
	if PTCond.truthy(S.done.get("thrsk_" + sk)): return ""
	for tid in S.get("thoughts", []):
		var th = R.THOUGHTS.get(tid)
		if thought_done(tid) and th and th.has("bonus") and th.bonus.get(sk) and not PTCond.truthy(S.done.get("thr_" + tid)):
			return tid
	return ""

func spend_thought_retry(tid: String, sk: String) -> void:
	S.done["thr_" + tid] = true
	S.done["thrsk_" + sk] = true

func internal_count() -> int:
	return (S.get("thoughts", []) as Array).filter(func(t): return thought_done(t)).size()

func learned_count() -> int:
	return (S.get("learned", []) as Array).size()

func past_n() -> int:
	return _i(S.past.n) if S.get("past") is Dictionary else 0

func perk(p: String) -> bool:
	for tid in S.get("thoughts", []):
		var th = R.THOUGHTS.get(tid)
		if th and th.get("perk") == p and thought_done(tid): return true
	return vperk(p)

func hardcore() -> bool:
	return PTCond.truthy(S.get("hard"))


# ---------- effects ----------
func apply_fx(fx: Dictionary) -> Array:
	var chips := []
	for k in FX_KEYS:
		if fx.get(k):
			var before := _i(S.get(k, 0))
			var hi: int = LIM[k][1] + (1 if k == "pw" and vperk("pw_cap") else 0)
			S[k] = clampi(before + _i(fx[k]), LIM[k][0], hi)
			var diff: int = S[k] - before
			if diff: chips.append(NAMES[k] + " " + ("+" if diff > 0 else "") + str(diff))
	if fx.get("wet"): S.wet = true; chips.append("Powder soaked")
	if fx.get("crack") and not S.get("sealBroken"): S.sealBroken = true; chips.append("Seal cracked")
	return chips

func add_temp(t: Array) -> String:
	var cap := _i(R.get("TEMP_CAP", 3))
	var cur := temp_total(t[0])
	var nv := clampi(cur + _i(t[1]), -cap, cap)
	var d := nv - cur
	if not d: return ""
	S.temp.append({"sk": t[0], "v": d, "label": t[2]})
	return skill_name(t[0]) + " " + ("+" if d > 0 else "") + str(d) + " on the next check"

func add_xp(n: int) -> Array:
	var chips := ["XP +" + str(n)]
	S.xp = _i(S.xp) + n
	while S.xp >= XP_PER_POINT:
		S.xp -= XP_PER_POINT; S.level = _i(S.level) + 1; S.points = _i(S.points) + V_PTS
		chips.append("Level " + str(S.level) + ": " + str(V_PTS) + " skill points earned")
	return chips

func gain(id: String) -> bool:
	if has(id): return false
	S.inv.append(id)
	return true

func new_thought(tid: String, chips: Array) -> bool:
	var th = R.THOUGHTS.get(tid)
	if th == null or S.thoughts.has(tid) or S.loose.has(tid): return false
	S.loose.append(tid)
	chips.append("New thought: " + String(th.name) + ". Pin it in Tin Thoughts.")
	return true

func vq_push(v: String, text: String, kind := "", beat := "") -> void:
	if text == "" or not R.VOICES.has(v): return
	if v == "hat" and not has("hat"): return
	if kind != "force" and muted_by(v): return
	S.vq.append([v, text, kind, beat])

func apply_node(src: Dictionary, scene: String, talker: Dictionary, runner) -> Array:
	var chips := []
	if src.get("fx") is Dictionary: chips.append_array(apply_fx(src.fx))
	for k in ["temp", "temp2"]:
		if src.get(k) is Array:
			var c := add_temp(src[k])
			if c != "": chips.append(c)
	for g in src.get("give", []):
		if gain(g): chips.append(String(R.ITEMS.get(g, {}).get("kind", "Item")) + ": " + String(R.ITEMS.get(g, {}).get("name", g)))
	for g in src.get("take", []):
		if has(g): S.inv.erase(g); chips.append("Handed over: " + String(R.ITEMS.get(g, {}).get("name", g)))
	if src.get("xp"): chips.append_array(add_xp(_i(src.xp)))
	if src.get("flag") is String: S.done[src.flag] = true
	if src.get("log") is String: S.log.append({"title": scene, "text": src.log})
	var lrn = runner.val(src.get("learn")) if src.has("learn") else null
	if lrn is String and lrn != "":
		var known := false
		for l in S.learned: if l.text == lrn: known = true
		if not known:
			S.learned.append({"from": talker.get("name", ""), "where": scene, "text": lrn})
			chips.append("Learned: " + lrn)
			if vperk("learn_xp"): chips.append_array(add_xp(1))
	if src.get("thought") is String: new_thought(src.thought, chips)
	return chips

func tally_add(tag: String) -> Array:
	var chips := []
	if not R.TALLY_TAGS.has(tag): return chips
	S.tally[tag] = _i(S.tally.get(tag, 0)) + 1
	if S.tally[tag] == 3 and new_thought(String(R.PATTERN[tag]), chips):
		var pl: Array = R.PATTERN_LINE[tag]
		if pl[0] == "longroad" and has("hat"): vq_push("hat", "You keep stopping. I have started to like it.", "pat")
		else: vq_push(pl[0], pl[1], "pat")
	return chips

func side_add(v: String) -> Array:
	var chips := []
	if v != "duty" and v != "hat": return chips
	S.side[v] = _i(S.side.get(v, 0)) + 1
	if S.side[v] == 3 and new_thought(String(R.PATTERN[v]), chips):
		vq_push(R.PATTERN_LINE[v][0], R.PATTERN_LINE[v][1], "pat")
	return chips

## failRemark: the browser picks a line by a 32-bit hash of the key
func fail_remark(v: String, k: String) -> String:
	var L: Array = R.FAIL_REM.get(v, [])
	if L.is_empty(): return ""
	var h := 0
	for i in k.length():
		h = (h * 31 + k.unicode_at(i)) & 0xFFFFFFFF
	if h >= 0x80000000: h -= 0x100000000
	return L[abs(h) % L.size()]

func fail_voice(v: String, node: Dictionary, k: String, runner) -> void:
	if v == "" or not R.VOICES.has(v) or not R.FAIL_REM.has(v): return
	var sk = R.VOICES[v].get("sk")
	for e in node.get("voices", []):
		var w: String = runner.vid(e)
		if w == v: return
		if R.VOICES.has(w) and R.VOICES[w].get("sk") == sk and (not e.has("show") or runner._cond(e.show)) and runner.voice_on(w, e): return
	var line = node.get("failLine")
	vq_push(v, String(line) if line is String else fail_remark(v, k), "force")

func drain_voices() -> Array:
	var out := []
	for x in S.get("vq", []):
		if x[0] is String and x[0].begins_with("_"): continue
		out.append({"v": x[0], "text": x[1], "beat": x[3] if x.size() > 3 else ""})
	S.vq = []
	return out

func check_end() -> String:
	if _i(S.hp) <= 0: return "death"
	if _i(S.hrs) > (68 if S.get("hard") else 72): return "late"
	return ""


# ---------- flavour ----------
func talker_name(scene: String, id: String) -> String:
	for sc in [scene, scene.trim_prefix("back_").trim_prefix("fun_")]:
		var t = R.get("TALKERS", {}).get(sc, {}).get(id)
		if t: return String(t.name)
	return id

func talker_info(scene: String, id: String) -> Dictionary:
	for sc in [scene, scene.trim_prefix("back_").trim_prefix("fun_")]:
		var t = R.get("TALKERS", {}).get(sc, {}).get(id)
		if t: return {"id": id, "name": t.name, "role": t.get("role", ""), "mood": t.get("mood", "calm"), "hue": t.get("hue", "")}
		var o = R.get("OBJECTS", {}).get(sc, {}).get(id)
		if o: return {"id": id, "name": o.name, "role": o.get("role", ""), "mood": "think", "obj": true}
	return {"id": id, "name": id.capitalize(), "role": "", "mood": "calm", "obj": id.begins_with("x_")}

func banter(scene: String, k: String) -> Array:
	var out := []
	for b in R.get("BANTER", {}).get(scene, []):
		if b.get("on") != k: continue
		for l in b.lines:
			out.append({"who": talker_name(scene, l[0]) if l[0] != "" else "", "text": PTCond.jstr(l[1])})
	return out

func manner(scene: String, talker: Dictionary) -> String:
	var arr = R.get("MANNER", {}).get(scene + ":" + String(talker.id))
	if not (arr is Array) or arr.is_empty(): return ""
	var k := "v_" + scene + ":" + String(talker.id)
	var n := _i(S.done.get(k, 0))
	S.done[k] = n + 1
	return String(arr[n % arr.size()])
