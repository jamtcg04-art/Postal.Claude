extends Control
## Try any conversation on the native rules: pick one on the left, set your skills, and talk.

var db: PTDialogueDB
var host: PTNativeHost
var runner: PTDialogueRunner
var log_view: PTDialogueLog
var list: ItemList
var spins := {}
var hat: CheckBox
var status: Label


func _ready() -> void:
	db = PTDialogueDB.new("res://data/dialogue")
	var bg := ColorRect.new(); bg.color = Color("#1b1916"); bg.set_anchors_preset(Control.PRESET_FULL_RECT); add_child(bg)
	var row := HBoxContainer.new(); row.set_anchors_preset(Control.PRESET_FULL_RECT); add_child(row)
	var side := VBoxContainer.new(); side.custom_minimum_size.x = 300; row.add_child(side)
	var t := Label.new(); t.text = "  The Postal Trace: conversations"; side.add_child(t)
	list = ItemList.new(); list.size_flags_vertical = Control.SIZE_EXPAND_FILL; side.add_child(list)
	for id in db.ids(): list.add_item(id)
	list.item_activated.connect(func(i): _open(list.get_item_text(i)))
	list.item_selected.connect(func(i): _open(list.get_item_text(i)))
	var grid := GridContainer.new(); grid.columns = 2; side.add_child(grid)
	for sk in ["arms", "nerve", "wits", "grit"]:
		var l := Label.new(); l.text = "  " + sk.capitalize() + " points"; grid.add_child(l)
		var sp := SpinBox.new(); sp.min_value = -2; sp.max_value = 6; grid.add_child(sp); spins[sk] = sp
	hat = CheckBox.new(); hat.text = "Carry Lieutenant Hale’s hat"; side.add_child(hat)
	var again := Button.new(); again.text = "Start over with these skills"; side.add_child(again)
	again.pressed.connect(func(): if list.get_selected_items().size(): _open(list.get_item_text(list.get_selected_items()[0]), true))
	status = Label.new(); status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; side.add_child(status)
	var spacer := Control.new(); spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL; row.add_child(spacer)
	log_view = PTDialogueLog.new(); log_view.column_width = 560; row.add_child(log_view)
	log_view.closed.connect(func(reason): status.text = "Conversation over (%s). Pick another, or the same one to go back." % reason)
	_new_state()


func _new_state() -> void:
	host = PTNativeHost.new(db.rules)
	host.S.route = ["cross", "ford", "oak", "ridge", "malice"]
	for sk in spins: host.S.up[sk] = int(spins[sk].value)
	if hat.button_pressed: host.S.inv.append("hat")


func _open(id: String, fresh_state := false) -> void:
	if fresh_state: _new_state()
	var parts := id.split(":")
	runner = PTDialogueRunner.new(db, host)
	log_view.clear()
	log_view.attach(runner)
	host.S.idx = max(0, ["cross", "ford", "oak", "ridge", "malice"].find(parts[0].trim_prefix("back_").trim_prefix("fun_")))
	status.text = "Talking: " + id
	runner.start(parts[0], host.talker_info(parts[0], parts[1]))
