extends SceneTree
## Replays conversations recorded in the browser build (tools/parity_record.js) on the Godot runner
## with the same starting state, the same dice and the same choices, and checks every screen matches:
## the lines said, which inner voices spoke (and what they said), the dice, and every choice with its
## state (open, greyed, retry, hear-again) and its check (voice, difficulty, target, odds).
##   godot --headless -s res://tests/parity.gd [-- fixture.json]

var fails := 0
var screens := 0
var runs := 0
var report := []

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var path := args[0] if args.size() else "res://tests/fixtures/parity.json"
	var data = JSON.parse_string(FileAccess.get_file_as_string(path))
	var db := PTDialogueDB.new("res://data/dialogue")
	for run in data.runs:
		runs += 1
		_replay(db, run)
	print("parity: %d runs, %d screens compared, %d runs differ" % [runs, screens, fails])
	for r in report.slice(0, 25): print(r)
	quit(1 if fails else 0)


static func ints(v):
	if v is float and v == floor(v): return int(v)
	if v is Array: return v.map(func(x): return ints(x))
	if v is Dictionary:
		var o := {}
		for k in v: o[k] = ints(v[k])
		return o
	return v


func _replay(db: PTDialogueDB, run: Dictionary) -> void:
	var host := PTNativeHost.new(db.rules, ints(run.S0))
	var dice: Array = ints(run.dice)
	var di := [0]
	host.d6 = func():
		if di[0] >= dice.size(): push_error("ran out of recorded dice"); return 1
		di[0] += 1
		return dice[di[0] - 1]
	var r := PTDialogueRunner.new(db, host)
	var t: Dictionary = run.talker
	var who := {"id": t.id, "name": t.name, "role": t.role, "mood": t.mood, "hue": t.hue}
	if t.obj: who.obj = true
	var v := r.start(String(run.scene), who)
	var steps: Array = run.steps
	if not _same(run, 0, _snap(v), steps[0]): return
	for i in run.picks.size():
		v = r.choose(int(run.picks[i]))
		if not _same(run, i + 1, _snap(v), steps[i + 1]): return


func _snap(v: Dictionary) -> Dictionary:
	if v.ended: return {"ended": true}
	var say := []
	var voices := []
	var roll = null
	for e in v.entries:
		match String(e.t):
			"say", "look": say.append_array(e.lines)
			"voice": if not e.get("queued", false): voices.append([e.v, e.text])
			"argue": for l in e.lines: voices.append([l.v, l.text])
			"roll": roll = {"dice": [e.a, e.b], "ok": e.ok}
	var choices := []
	for c in v.choices:
		var ck := ""
		if c.has("check"):
			var k: Dictionary = c.check
			ck = ("Red · " if k.kind == "red" else "") + String(k.voice) + " · " + String(k.difficulty) + " " + str(k.dc) + " · " + str(k.odds) + "%" + (" · retry" if k.retry else "")
		choices.append({"text": c.text, "enabled": c.enabled, "retry": c.get("retry", false), "replay": c.get("replay", false), "kind": c.kind, "ck": ck})
	return {"ended": false, "say": say, "voices": voices, "roll": roll, "choices": choices}


func _same(run: Dictionary, i: int, got: Dictionary, want: Dictionary) -> bool:
	screens += 1
	var why := _diff(ints(want), got)
	if why == "": return true
	fails += 1
	report.append("%s (screen %d, after picks %s): %s" % [run.conv, i, str(run.picks.slice(0, i)), why])
	return false


func _diff(w, g, at := "") -> String:
	if w is Dictionary and g is Dictionary:
		for k in w:
			if not g.has(k): return at + "." + k + " missing"
			var d := _diff(w[k], g[k], at + "." + k)
			if d != "": return d
		return ""
	if w is Array and g is Array:
		for i in min(w.size(), g.size()):
			var d := _diff(w[i], g[i], at + "[" + str(i) + "]")
			if d != "": return d
		if w.size() != g.size(): return at + ": browser has %d, Godot %d: %s vs %s" % [w.size(), g.size(), str(w).left(300), str(g).left(300)]
		return ""
	if typeof(w) != typeof(g) and not (w == null and g == null):
		if (w is int or w is float) and (g is int or g is float) and float(w) == float(g): return ""
		return at + ": browser %s, Godot %s" % [str(w).left(200), str(g).left(200)]
	if w != g: return at + ": browser «%s», Godot «%s»" % [str(w).left(200), str(g).left(200)]
	return ""
