extends "res://tests/parity.gd"
## The same replay, with the browser's own rules behind PTJsLiteHost (served by tools/js_bridge_server.js).
## This is how the main game runs conversations; @js fields and game queries work here.
##   node tools/js_bridge_server.js index.html 8765 &   then   godot --headless -s res://tests/parity_js.gd -- fixture.json [onlyConvPrefix]

var http := HTTPClient.new()

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var path := args[0] if args.size() else "res://tests/fixtures/parity.json"
	var only := args[1] if args.size() > 1 else ""
	http.connect_to_host("127.0.0.1", 8765)
	while http.get_status() in [HTTPClient.STATUS_CONNECTING, HTTPClient.STATUS_RESOLVING]:
		http.poll(); OS.delay_msec(1)
	var data = JSON.parse_string(FileAccess.get_file_as_string(path))
	var db := PTDialogueDB.new("res://data/dialogue")
	for run in data.runs:
		if only != "" and not String(run.conv).begins_with(only): continue
		runs += 1
		_replay_js(db, run)
	print("parity (browser rules): %d runs, %d screens compared, %d runs differ" % [runs, screens, fails])
	for r in report.slice(0, 25): print(r)
	quit(1 if fails else 0)

func js_eval(code: String):
	http.request(HTTPClient.METHOD_POST, "/eval", ["Content-Type: text/plain"], code)
	while http.get_status() == HTTPClient.STATUS_REQUESTING:
		http.poll(); OS.delay_usec(200)
	var body := PackedByteArray()
	while http.get_status() == HTTPClient.STATUS_BODY:
		http.poll()
		var chunk := http.read_response_body_chunk()
		if chunk.size(): body.append_array(chunk)
		else: OS.delay_usec(200)
	var v = JSON.parse_string(body.get_string_from_utf8())
	if v is Dictionary and v.has("__error"): push_error("JS: " + v.__error + " in " + code.left(200))
	return ints(v)

func _replay_js(db: PTDialogueDB, run: Dictionary) -> void:
	js_eval("(S = " + JSON.stringify(run.S0) + ", S.route = [" + JSON.stringify(run.scene) + "], S.idx = 0, window.__DQ = " + JSON.stringify(run.dice) + ", d6 = function () { return window.__DQ.length ? window.__DQ.shift() : 1; }, addrLast = {}, 0)")
	var host := PTJsLiteHost.new(js_eval)
	var r := PTDialogueRunner.new(db, host)
	var t: Dictionary = run.talker
	var who := {"id": t.id, "name": t.name, "role": t.role, "mood": t.mood, "hue": t.hue}
	if t.obj: who.obj = true
	var v := r.start(String(run.scene), who)
	var steps: Array = run.steps
	if not _same(run, 0, _snap(v), steps[0]): return
	for i in run.picks.size():
		v = r.choose(int(run.picks[i]))
		if not _same(run, i + 1, _snap(v), steps[i + 1]): return
