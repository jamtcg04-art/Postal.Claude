extends SceneTree
## Opens a conversation in the demo, plays a few beats and choices, and saves a picture of the screen.
## xvfb-run godot --rendering-driver opengl3 -s res://tests/screenshot.gd -- <conv> <out.png> [choices…]
func _init() -> void:
	var args := OS.get_cmdline_user_args()
	var conv := args[0] if args.size() > 0 else "cross:vane"
	var out := args[1] if args.size() > 1 else "user://shot.png"
	var picks := args.slice(2)
	root.size = Vector2i(1280, 800)
	var demo = load("res://demo/demo.tscn").instantiate()
	root.add_child(demo)
	for i in 3: await process_frame
	for sk in ["nerve", "wits", "grit"]: demo.spins[sk].value = 2
	demo._open(conv, true)
	for p in picks:
		await _beats(demo)
		demo.runner.choose(int(p))
	await _beats(demo)
	for i in 10: await process_frame
	var img := root.get_texture().get_image()
	img.save_png(out)
	print("saved ", out)
	quit()

func _beats(demo) -> void:
	for i in 30:
		await process_frame
		if demo.log_view._cont.visible: demo.log_view._next_beat()
	for i in 5: await process_frame
