extends SceneTree
## Walks every conversation with random choices on the native host and reports crashes or dead ends.
func _init() -> void:
	var db := PTDialogueDB.new("res://data/dialogue")
	var steps := 0
	var convs := 0
	var rng := RandomNumberGenerator.new(); rng.seed = 7
	for id in db.ids():
		var host := PTNativeHost.new(db.rules)
		host.S.route = ["cross", "ford", "oak", "ridge", "malice"]
		var r := PTDialogueRunner.new(db, host)
		var parts: PackedStringArray = id.split(":")
		var v := r.start(parts[0], host.talker_info(parts[0], parts[1]))
		convs += 1
		for i in 40:
			if v.ended: break
			var open: Array = v.choices.filter(func(c): return c.enabled)
			if open.is_empty(): break
			v = r.choose(open[rng.randi_range(0, open.size() - 1)].index)
			steps += 1
	print("smoke: %d conversations, %d steps" % [convs, steps])
	quit()
