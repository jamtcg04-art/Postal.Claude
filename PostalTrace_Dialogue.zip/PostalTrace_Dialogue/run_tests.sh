#!/bin/sh
# Compile the dialogue and run every check. Needs Node 18+; the browser checks need Playwright + Chromium;
# the Godot checks need Godot 4.3+ on PATH as "godot" (or set GODOT=…).
# usage: ./run_tests.sh path/to/index.html
set -e
HTML=${1:?give the browser build index.html}
GODOT=${GODOT:-godot}
node tools/compile.js --browser "$HTML" --svg
node tools/roundtrip.js build/compiled_all.json
node tools/patch_browser.js "$HTML" build/browser/pt_dialogue.gen.js build/browser/index.html
rm -rf godot/data/dialogue && mkdir -p godot/data && cp -r build/godot/data/dialogue godot/data/
node tools/parity_record.js "$HTML" godot/tests/fixtures/parity.json 3 12
node tools/parity_record.js build/browser/index.html build/parity_patched.json 0 0 godot/tests/fixtures/parity.json
(cd godot && "$GODOT" --headless --import >/dev/null 2>&1; "$GODOT" --headless -s res://tests/smoke.gd; "$GODOT" --headless -s res://tests/parity.gd || true)
node tools/js_bridge_server.js "$HTML" 8765 & BR=$!; sleep 6
(cd godot && "$GODOT" --headless -s res://tests/parity_js.gd); kill $BR
