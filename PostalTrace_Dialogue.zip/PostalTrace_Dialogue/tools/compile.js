#!/usr/bin/env node
// Compile The Postal Trace's dialogue scripts.
//
//   node tools/compile.js [--src dialogue] [--out build] [--rules data/dialogue_rules.json] [--browser index.html]
//
// Writes:
//   <out>/godot/data/dialogue/<scene>.json   compiled conversations (Godot reads these)
//   <out>/godot/data/dialogue/index.json     conversation id -> file
//   <out>/browser/pt_dialogue.gen.js         the same conversations as GRAPH entries for the browser build
//   <out>/report.md                          validation report
//   <out>/graphs/<conv>.dot                  one Graphviz picture per conversation
// Exits 1 if there are errors (a jump to a node that does not exist, an unknown voice …).
'use strict';
const fs = require('fs'), path = require('path');
const P = require('./ptc'), E = require('./ptexpr');

const args = process.argv.slice(2), opt = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const SRC = opt('src', 'dialogue'), OUT = opt('out', 'build'), RULES = opt('rules', 'data/dialogue_rules.json'), BROWSER = opt('browser', null);

const rules = fs.existsSync(RULES) ? JSON.parse(fs.readFileSync(RULES, 'utf8')) : null;
const files = fs.readdirSync(SRC).filter(f => f.endsWith('.pt')).sort();
const all = {}, fileOf = {}, problems = [];
const err = (where, m) => problems.push({ level: 'error', where, m });
const warn = (where, m) => problems.push({ level: 'warn', where, m });

for (const f of files) {
  let convs;
  try { convs = P.parse(fs.readFileSync(path.join(SRC, f), 'utf8'), f); }
  catch (e) { err(f, e.message); continue; }
  for (const id in convs) {
    if (all[id]) err(f, 'conversation ' + id + ' is also in ' + fileOf[id]);
    all[id] = convs[id]; fileOf[id] = f;
  }
}

// ---------- validation ----------
const flagsRead = new Map(), flagsSet = new Set();
function scan(v, at) {
  JSON.stringify(v, (k, x) => {
    if (Array.isArray(x) && x[0] === 'v' && /^done\./.test(x[1])) { const fl = x[1].slice(5); if (!flagsRead.has(fl)) flagsRead.set(fl, at); }
    if (Array.isArray(x) && x[0] === 'set' && /^done\./.test(x[1])) flagsSet.add(x[1].slice(5));
    return x;
  });
}
const voices = rules ? new Set(Object.keys(rules.VOICES)) : null, skills = rules ? new Set(Object.keys(rules.SKILLS)) : null;
const thoughts = rules ? new Set(Object.keys(rules.THOUGHTS)) : null, items = rules ? new Set(Object.keys(rules.ITEMS)) : null;
let jsCount = 0, nodeCount = 0, optCount = 0, checkCount = 0, voiceCount = 0;
for (const id in all) {
  const G = all[id], W = fileOf[id] + ' ' + id;
  if (!G.nodes[G.hub]) err(W, 'the hub node "' + G.hub + '" does not exist');
  const edges = {};
  for (const nid in G.nodes) {
    const N = G.nodes[nid], at = W + ' ~ ' + nid; nodeCount++;
    edges[nid] = [];
    const jump = (t, what) => { if (t === undefined || t === null || t === '<') return; if (!G.nodes[t]) err(at, what + ' goes to "' + t + '", which is not a node here'); else edges[nid].push(t); };
    if (N.by && voices && !voices.has(N.by)) err(at, '@by ' + N.by + ' is not a voice');
    if (N.flag && typeof N.flag === 'string') flagsSet.add(N.flag);
    if (N.thought && thoughts && typeof N.thought === 'string' && !thoughts.has(N.thought)) err(at, '@thought ' + N.thought + ' is not a Tin Thought');
    (N.give || []).concat(N.take || []).forEach(g => { if (items && !items.has(g)) err(at, 'item ' + g + ' does not exist'); });
    [N.temp, N.temp2].forEach(t => { if (t && skills && !skills.has(t[0])) err(at, '@temp skill ' + t[0] + ' does not exist'); });
    (N.voices || []).forEach((e, i) => {
      voiceCount++;
      const v = e.v || (rules && rules.DEF_VOICE[e.sk]) || e.sk;
      if (voices && !voices.has(v)) err(at, 'voice ' + v + ' does not exist');
      if (e.go !== undefined) jump(e.go, 'voice "' + v + '"');
      if (e.go !== undefined && e.q === undefined) warn(at, 'voice "' + v + '" opens a branch but has no ask text (shows “Go on.”)');
    });
    (N.argue && (Array.isArray(N.argue) ? (Array.isArray(N.argue[0]) ? [{ lines: N.argue }] : N.argue) : [N.argue]) || []).forEach(a => a.lines.forEach(l => { if (voices && !voices.has(l[0])) err(at, 'argument voice ' + l[0] + ' does not exist'); }));
    N.opts.forEach((o, j) => {
      optCount++;
      if (o.check) {
        checkCount++;
        if (skills && !skills.has(o.check.sk)) err(at, 'check skill ' + o.check.sk + ' does not exist');
        if (o.check.v && voices && !voices.has(o.check.v)) err(at, 'check voice ' + o.check.v + ' does not exist');
        jump(o.check.pass, 'check pass'); jump(o.check.fail, 'check fail');
        if (o.to !== undefined) warn(at, 'option ' + (j + 1) + ' has both a check and "->"; the check wins');
      } else if ('to' in o) jump(o.to, 'option ' + (j + 1));
      if (o.flag) flagsSet.add(o.flag);
      if (o.think && thoughts && !thoughts.has(o.think)) err(at, '#think:' + o.think + ' is not a Tin Thought');
      if (o.tally && rules && !rules.TALLY_TAGS[o.tally]) err(at, '#tally:' + o.tally + ' is not one of ' + Object.keys(rules.TALLY_TAGS).join(', '));
      if (o.side && o.side !== 'duty' && o.side !== 'hat') err(at, '#side:' + o.side + ' must be duty or hat');
    });
    JSON.stringify(N, (k, x) => { if (x && typeof x === 'object' && 'js' in x && typeof x.js === 'string') jsCount++; return x; });
    scan(N, at);
  }
  // reachability: from the hub, and from any node a "<" return or the game itself can open (voice branches count)
  const seen = new Set([G.hub]), q = [G.hub];
  while (q.length) { const n = q.pop(); (edges[n] || []).forEach(t => { if (!seen.has(t)) { seen.add(t); q.push(t); } }); }
  for (const nid in G.nodes) if (!seen.has(nid)) warn(W + ' ~ ' + nid, 'no path leads here from ' + G.hub + ' (the game may open it directly)');
  // every hub should let you leave
  const H = G.nodes[G.hub];
  if (H && !H.opts.some(o => !('to' in o) || o.to === null || o.run) ) warn(W, 'the hub has no way out (an option with no "->")');
}
// flags read but never set anywhere (conversations or the browser's own code)
let browserSrc = BROWSER && fs.existsSync(BROWSER) ? fs.readFileSync(BROWSER, 'utf8') : '';
for (const [fl, at] of flagsRead) {
  if (flagsSet.has(fl)) continue;
  if (/^(gseen|gmet|gu|gox|ck|vgo|vno|gret)_/.test(fl)) continue;   // kept by the dialogue runner itself
  if (browserSrc && (browserSrc.indexOf('S.done.' + fl) >= 0 || browserSrc.indexOf("'" + fl + "'") >= 0 || browserSrc.indexOf("done['" + fl) >= 0)) continue;
  if (!browserSrc) continue;
  warn(at, 'reads done.' + fl + ', which nothing sets (a typo?)');
}

// ---------- outputs ----------
const godotDir = path.join(OUT, 'godot', 'data', 'dialogue');
fs.mkdirSync(godotDir, { recursive: true });
fs.mkdirSync(path.join(OUT, 'browser'), { recursive: true });
fs.mkdirSync(path.join(OUT, 'graphs'), { recursive: true });
const byFile = {};
for (const id in all) (byFile[fileOf[id]] = byFile[fileOf[id]] || {})[id] = all[id];
const index = {};
for (const f in byFile) {
  const name = f.replace(/\.pt$/, '.json');
  fs.writeFileSync(path.join(godotDir, name), JSON.stringify({ format: 'postal-trace-dialogue', v: 2, conversations: byFile[f] }));
  for (const id in byFile[f]) index[id] = name;
}
fs.writeFileSync(path.join(godotDir, 'index.json'), JSON.stringify({ format: 'postal-trace-dialogue-index', v: 2, conversations: index }, null, 1));
if (rules) fs.writeFileSync(path.join(godotDir, 'rules.json'), JSON.stringify(rules));
fs.writeFileSync(path.join(OUT, 'compiled_all.json'), JSON.stringify(all));
fs.writeFileSync(path.join(OUT, 'browser', 'pt_dialogue.gen.js'),
  '// Generated by tools/compile.js from dialogue/*.pt. Do not edit; edit the scripts and recompile.\n' +
  '// Paste inside the game script after the last GRAPH patch (or load it there), so it replaces those entries.\n' + P.emitJS(all) + '\n');

// pictures: hubs are boxes, checks diamonds (red ones red), voice branches dotted
for (const id in all) {
  const G = all[id]; const L = ['digraph "' + id + '" {', '  rankdir=LR; node [fontname="Helvetica" fontsize=10 shape=ellipse]; edge [fontsize=8 fontname="Helvetica"];'];
  const lab = s => JSON.stringify(String(s).slice(0, 40));
  for (const nid in G.nodes) {
    const N = G.nodes[nid];
    L.push('  ' + JSON.stringify(nid) + ' [' + (nid === G.hub ? 'shape=box style=bold ' : '') + (N.by ? 'style=dashed ' : '') + 'label=' + lab(nid + (N.by ? '\n(' + N.by + ')' : '')) + '];');
    (N.voices || []).forEach(e => { if (e.go) L.push('  ' + JSON.stringify(nid) + ' -> ' + JSON.stringify(e.go) + ' [style=dotted label=' + lab(e.v || e.sk) + '];'); });
    N.opts.forEach((o, j) => {
      const q = typeof o.q === 'string' ? o.q : '(computed)';
      if (o.check) {
        const c = JSON.stringify(nid + '#ck' + j);
        L.push('  ' + c + ' [shape=diamond ' + (o.check.red ? 'color=red ' : '') + 'label=' + lab(o.check.sk + ' ' + o.check.dc) + '];');
        L.push('  ' + JSON.stringify(nid) + ' -> ' + c + ' [label=' + lab(q) + '];');
        L.push('  ' + c + ' -> ' + JSON.stringify(o.check.pass) + ' [color=darkgreen label="pass"];');
        L.push('  ' + c + ' -> ' + JSON.stringify(o.check.fail) + ' [color=firebrick label="fail"];');
      } else if (o.to && o.to !== '<') L.push('  ' + JSON.stringify(nid) + ' -> ' + JSON.stringify(o.to) + ' [label=' + lab(q) + '];');
      else if (o.to === '<') L.push('  ' + JSON.stringify(nid) + ' -> "<back>" [style=dashed label=' + lab(q) + '];');
      else L.push('  ' + JSON.stringify(nid) + ' -> "<leave>" [style=dashed label=' + lab(q) + '];');
    });
  }
  L.push('}');
  fs.writeFileSync(path.join(OUT, 'graphs', id.replace(/[^\w-]/g, '_') + '.dot'), L.join('\n') + '\n');
}

// pictures as SVG too, when Graphviz is installed (--svg)
if (args.indexOf('--svg') >= 0) {
  const { execFileSync } = require('child_process');
  try {
    for (const f of fs.readdirSync(path.join(OUT, 'graphs')).filter(f => f.endsWith('.dot')))
      execFileSync('dot', ['-Tsvg', path.join(OUT, 'graphs', f), '-o', path.join(OUT, 'graphs', f.replace(/\.dot$/, '.svg'))]);
  } catch (e) { warn('graphs', 'could not run Graphviz (dot) for SVG pictures: ' + e.message.split('\n')[0]); }
}

const errors = problems.filter(p => p.level === 'error'), warns = problems.filter(p => p.level === 'warn');
const rep = ['# Dialogue compile report', '',
  '- ' + files.length + ' script files, ' + Object.keys(all).length + ' conversations, ' + nodeCount + ' nodes, ' + optCount + ' options, ' + checkCount + ' checks, ' + voiceCount + ' inner-voice lines',
  '- ' + jsCount + ' fields still written as JavaScript (@js): actions such as starting a fight or a sale, and a few lines that use list helpers',
  '- ' + errors.length + ' errors, ' + warns.length + ' warnings', ''];
if (errors.length) rep.push('## Errors', '', ...errors.map(p => '- **' + p.where + '**: ' + p.m), '');
if (warns.length) rep.push('## Warnings', '', ...warns.map(p => '- ' + p.where + ': ' + p.m), '');
fs.writeFileSync(path.join(OUT, 'report.md'), rep.join('\n') + '\n');
console.log(rep.slice(2, 5).join('\n'));
errors.slice(0, 20).forEach(p => console.log('ERROR ' + p.where + ': ' + p.m));
process.exit(errors.length ? 1 : 0);
