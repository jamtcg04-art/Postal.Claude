# The Postal Trace (Godot 4)

A Godot port of the browser RPG *The Postal Trace*. It has the whole written game and its core loop: dialogue with inner voices, skill checks, Tin Thoughts, items, the road between stops and its events, fights, the Redoubt Nine memories and the endings, and the 3D places you walk around in.

Open the folder in **Godot 4.3 or newer** (the standard build, not .NET). The first time you open it, Godot imports the audio, fonts and portraits, which takes a few seconds. Then press F5.

## Controls

- Mouse, or the arrow keys and Enter (works with a gamepad's d-pad too).
- Number keys 1–9 pick an option. Space or Enter shows the next line of a conversation.
- C character sheet, T Tin Thoughts, I satchel, J journal, Esc menu (save, load, sound).

## How the project is laid out

```
dialogue/<place>.pt   every conversation, as plain-text scripts (see "Writing conversations" below)
data/                 everything else you can write or rebalance, as JSON
  tables.json         skills, voices, thoughts, items, endings, perks, flavour text, intro pages...
  scenes/<id>.json    a stop or road meeting: its text, its choices, and who is there to talk to
  dialogue/<place>.json   the conversations, compiled from dialogue/*.pt (don't edit; recompile)
  lib.json            the browser build's own game logic (500 functions and their data): fights,
                      companions, the market, the gate, errands, horses, revolvers, road events...
  index.json          which scenes are the five main stops and which are road meetings
scripts/
  data.gd             loads data/ (autoload "Data")
  game.gd             the rules: state, checks, voices, thoughts, XP, saves (autoload "Game")
  main.gd             draws the screens and runs the flow between them
  dialogue_host.gd    connects the dialogue runner to the game's rules (Game, Data, the browser logic)
  bridge.gd           lets lib.json's logic draw its screens through Godot (autoload "Bridge")
  html.gd             reads the small HTML those screens are written in and turns it into widgets
  markup.gd           turns the text that fight and event logic builds into screen elements
  js_lite.gd          runs the logic inside the data (see below)
  world/              the 3D places: walking, people, the see-through holes, small effects (fx.gd),
                      place edits (place_edits.gd) and the place editor (place_editor.gd)
  sound.gd            effects, rain ambience and music (autoload "Sound")
addons/pt_dialogue/   the dialogue runner: hub, inner voices, white/red checks, retries, replays
assets/               audio, portraits and fonts
tests/                headless checks (see below)
tools/dialogue/       the dialogue compiler and its checks (Node 18+)
docs/                 WRITING_DIALOGUE.md, DIALOGUE_SYSTEM.md
```

## Editing the game

Conversations are in `dialogue/*.pt`; everything else a player reads is in `data/`. Change a line, save, press F5
(for a conversation, compile first).

### Writing conversations

A conversation script looks like this (trimmed; the full guide is `docs/WRITING_DIALOGUE.md`):

```
=== cross:vane
~ hub
@mood eyeroll {done.vane_scorn}
@mood skeptic
Vane looks up from the ledger without hurry.
> ledger 1+ ask "“Struck through?”" -> v_ledger / "“His books are his business.”" | The ledger has fallen open …
> arms ..0 | Your shoulder says: not today.
* “Where did you serve?” -> serve #once
* {not done.vane_scorn} Square up and stare him down. #once
  @check nerve 8 -> stare_ok / stare_bad
```

Then, from the project folder:

```
node tools/dialogue/compile.js --godot . --svg
```

It checks every script (a jump to a missing node, an unknown voice or item, a flag nothing sets …), writes
`data/dialogue/`, and leaves a report and a picture of each conversation in `.dialogue_build/` (hidden from Godot).
The same scripts build the browser version's conversations (`.dialogue_build/browser/pt_dialogue.gen.js`, put in
place with `tools/dialogue/patch_browser.js`), so both builds play the same lines with the same rules.

Conditions are written as expressions (`not done.vane_scorn and coin >= 2`, `has("hat")`, `pastN() >= 2`); the game's
queries (`has`, `pastN`, `crossState`, `mkPrice` …) are the browser logic's own functions. A few fields stay as
JavaScript in `@js` blocks (starting a fight, buying, selling); they run through `scripts/js_lite.gd` like the rest
of the browser logic.

### Logic inside the data

Other values in `data/` (scenes, tables, lib.json) can be small pieces of JavaScript kept from the original, for example:

```json
"show": {"$js": "function () { return !S.done.vane_scorn; }"}
```

`scripts/js_lite.gd` runs these against the live game state. `S` is the run state (`S.done.<flag>`, `S.hp`, `S.inv` ...) and helpers such as `has('hat')`, `pastN()` and `thoughtDone('quiet')` are available; the full list is at the bottom of `scripts/game.gd`. `$env` next to a `$js` holds values the function captured when it was exported. Leave it alone unless you are rewriting that function.

## 3D places

Every stop and road meeting has its 3D place again: all 36 of them, the inside rooms included (the taproom at Cross-Pillars, the halls and cells at Fort Malice, the mine drift...). When you arrive at a scene, the place fills the left of the window and the text sits on the right.

- **Walk:** click the ground, or use WASD or a gamepad stick. Hold Shift to run.
- **Talk or look:** click a person or a thing. The courier walks up to it and the conversation opens in the panel.
- **Doors:** click a door to go inside or back out.
- **Camera:** Q and E turn the view, and the mouse wheel zooms. When a building or tree stands between you and the camera, a stippled hole opens in it round the courier, as in the original.
- **Turn it off:** Menu > 3D places, if you want text only (on a slow handheld, say).

People are built on the one rigged body from the original, with its 39 movements (idle, talk, walk, jog, sit and so on) and each person's own outfit. They also say their passing lines when you come close.

### Editing a place

Each place is a scene in `places/` (for example `places/cross.tscn`). Open one in Godot's editor to move, add or delete props. Props are under `Props`, people's spots under `People`, things to look at under `Things`, and the areas you cannot walk through under `Solid`. To add a prop, drag a model from `assets/3d/models/` into `Props`. Your edits are what the game uses.

`tools/bake_places.gd` rebuilds a place from its layout in `data/places/`, which **overwrites your edits to that place**. Only run it to start a place over.

### Where the 3D came from

`tools/w3d_export.js` and `tools/places_export.js` converted the original's `w3d_*.js` files into what is in `assets/3d/`: 340 models as `.glb`, 171 textures, and the rigged person, which goes in `assets/3d/people/person.glb`. They also turned the original's layout code into `data/places/*.json`. The models keep the original's low-resolution look through `shaders/psx.gdshader`.

## Fights and the rest of the game's systems

Fights, companions, Linden Market, the Provost's Gate, going back to earlier places, errands, horses, the revolvers and the road events all run on the browser build's own logic, exported to `data/lib.json` and run by `scripts/js_lite.gd`. So a fight plays exactly as it does in the browser: the same moves, odds, enemy turns and morale. All nine fights are in (the ambush at the ford, the hunting party, the Quarter Cut's yard, Lisle at the gate, the provost's riders and the rest).

To change a fight or a system, edit its function in the browser version and re-export (see `tools/README.md`), so both builds stay the same. Small fixes can also be made straight in `data/lib.json`.

The 3D places have the browser's small effects too: smoke from the tavern chimney and a lantern swinging on its post at Cross-Pillars, the glint at the tavern window while Vane holds the road, tethered horses that breathe and toss their heads, flickering fires, Karrow's mare in the lane on the way back once she is out of the stall, Linden's townsfolk walking the streets (they stop to look at you, and sometimes speak), Goodwife Marl walking her stalls, old people's stoop, and night fog drifting round the Quarter Cut's yard (`scripts/world/fx.gd`).

## The opening, the signal hut, the clock, and Malice Gaol

- **Redoubt Nine** is now the first place on the road. The opening is three pages of clay; then you stand in the
  ruined redoubt in 3D and Lieutenant Ashworth walks out of the smoke to you (a short scene: `World.cut_walk`, the
  browser's `rdCut`; click, Space, Enter or Esc skips it) and hands over the case. His conversation has inner-voice
  branches; Orderly Fenn, the split gun, the ammunition crate and the cut signal pole can be looked at; the scene's
  three choices (relieved / resentful / numb) replace the old "How do you carry it?" screen. Leaving costs no hours:
  the 72-hour clock starts on the trace.
- **The Signal Hut at Hob's Cutting** comes next: Linesman Quill and the state of the lines (river line cut by hand,
  ridge line shelled, the Tanner line up and read by the provost). The Wire's passive check there lets the Wire
  hear Fort Malice calling. Choices: splice the line (the linesmen's pole road: the next two long marches take an
  hour less), wire ahead (Duty, but the provost reads it), cut the Tanner line (fewer reports reach the Crown), or go on.
- **Seven new Tin Thoughts**: Last of the Third, Iron Petals, A Clean Cut at Midnight, The Line Listens, Counting Poles, What the Tin Weighs, The Sky-Fire.
- **The sky-fire**: on the first night on the road (hours 13–40) a Carrington-style storm lights the valley red and green and the dead telegraph line talks with no battery. Listen at the pole (the Wire), walk on by its light (next long march an hour shorter) or sit with the farmer. The game never says what spoke on the line; the voices argue about it and about the rain. Quill tells you the night the redoubt fell was a storm night too, and that the hand-cut wires were filed as ATMOSPHERIC; he can give you a copy of his report for his brother, the chaplain at Fort Malice.
- **The clock**: the road shows hours left and stops to Fort Malice (red when you are behind), and offers to go round
  the next road meeting by the back lanes (Stamina −1; you miss whatever was there).
- **The courier's record**: every ending works out what the Crown heard (fights with the provost's men or the
  Quarter Cut, reports from the gate, informing, the case going to the rebels, kindnesses a Crown ear could have
  heard of, meetings gone round, a cut line) and where the courier stood (the Crown's / two masters / the valley's).
  It is shown on the ending screen, saved to `user://legacy.json`, and given as a `PTL1:` code that Malice Gaol in
  the browser accepts. Malice Gaol itself is not in the Godot build yet (it is a separate 200 KB game; porting it is
  the next big step).

## Phones, tablets and comfort

- **Touch:** tap to walk, tap twice to run, pinch to zoom, and twist two fingers to turn the view (trackpads: pinch, and a two-finger swipe to turn). A finger can scroll the story without choosing anything: a choice is taken when you let go where you pressed.
- **Phone layout:** on a phone, or any narrow or tall window, the story sits under the 3D view instead of beside it. The game is laid out in finger-sized points, so text and buttons stay readable, the top bar is compact, and the menu fills the screen.
- **The voice ring:** when one of your voices has something to say about a person or thing near you, a ring in its colour hangs over the courier (as in the browser version). Press **V**, click the ring, or on a touch screen tap the **voice button** at the bottom of the 3D view, and the line opens at the top of the view; tap it to put it away.
- **Settings** (Menu): text size (Small to Larger), colours (Usual, High contrast, Soft), button size (Auto makes them large on touch screens), and the voice button (Auto shows it on touch screens). **Controls…** lets you change every key; game pads walk with the stick, run with the right shoulder, turn with the left shoulder and hear the waiting voice with Y.
- New screens of text fade in, and the 3D view fades up when it comes back after text-only screens.

## Saves

Saves use the browser version's own format, so they move freely between the two builds:

- **Slots:** six slots plus an autosave at every scene, stop and road leg, as in the browser.
- **Save to a file / Choose a save file:** a small `postal-trace-….json` file that either build can open.
- **All saves in one file:** Save all saves to one file puts the autosave and every slot in one `postal-trace-all-saves.json`. Opening it with Choose a save file (in either build) puts each save back in its own slot; a slot that already holds a newer save keeps it. This is how saves kept with your Claude account come across: in the browser version, Save all saves to one file, then open the file here.
- **Save codes:** Copy save code puts the save on the clipboard as the same code the browser shows; paste it under Load game in either build.
- **Sync folder:** pick a folder that Dropbox, Google Drive, OneDrive or iCloud keeps in step, and every slot and the autosave are written there too, so they follow you to other computers. When a slot exists in both places, the newer copy loads (the browser does the same with its account copy).

The browser's account saves only work inside claude.ai, so the Godot build cannot reach them; move a save across with a file or a save code.

## Dev Mode and the place editor

Menu > Dev Mode turns on what the browser's Dev Mode does: the stat changes of each dialogue option before you choose it, the full breakdown on every check, and the **place editor**. With Dev Mode on, an **Edit place** button sits at the bottom left of the 3D view. It has the browser editor's four modes:

- **Props:** click to select, drag to move; turn, raise, resize, recolour (lighter, darker, warmer, cooler), change the material, copy, delete, or add any model in the game. Lanterns and fires bring their light; moving a prop takes its blockers and its light with it.
- **People:** drag anyone in the place, turn them, raise them onto a floor; choose how they stand about, what they wear, what they carry and their age (worked out by the browser's own clothing code).
- **Ground & roads:** move, stretch, turn, retexture and tint each patch; lay new roads and patches.
- **Blockers:** the invisible walls, drawn on the ground. Move and resize them, add boxes and rings, delete them, and move the edges of the walkable area.

Keys: arrows nudge, Q/E turn, R/F raise and lower, +/- size, Delete, Ctrl+Z undo, Esc to finish. Drag empty ground to look around; the wheel zooms.

Edits are a layer over each place in the browser editor's own format, kept in `user://place_edits.json`. **Save file** writes `postal-trace-place-edits.json`, which the browser's Load file reads, and the other way round, so the two builds can share one set of edits. To put edits in the game for everyone, save the file as `data/place_edits.json` (edits made on a machine take priority over it). The editor in Godot's own editor (opening `places/<id>.tscn`) is still there for bigger changes.

## Living dice

An optional rule picked in the creator (The dice: Ordinary / Living, with Snowball, Lock and Hard mode: blank dice),
the same as the browser's. Each throw, the face that lands gains a pip and the face across from it loses one.
The rules are in `living_dice/living_dice.gd` (the run state's `ld`, the browser's `S.ld`, so saves carry it);
`Game.roll_dice` and `Game.odds` use it for skill checks, scenes and conversations alike. Fights, the Wire's
perception check and sizing up a scene keep plain dice. A "Dice in hand" button above choices opens the panel (each
die unfolded; lock a pair with the Lock rule; choose which dice to hold once you have more than two; Dev Mode adds The
Blank and the Hangman's Die). `living_dice/dice_ring.gd` is Jory's dice ring for Malice Gaol, for when Malice moves
over. Check: `tests/ld_test.gd`.

## Handhelds and game pads

The game runs on a handheld such as the **Anbernic RG35XX Plus** (640×480, d-pad, no sticks) through PortMaster; see
`tools/portmaster/README.md` to install it and `tools/portmaster/package.sh` to build `build/postaltrace.zip`.

- **Layout** (Menu > Layout: Auto / Desktop / Handheld): the handheld layout draws at 640×480 (480 lines high on a
  wider screen), with the text on the right and the place on the left; when you walk, the place fills the screen.
  Auto picks it on a small screen, when the launcher sets `PT_HANDHELD=1`, or in the handheld export.
- **Game pad** (any pad, on any layout; `scripts/pad.gd`): the d-pad moves between options and A picks, B goes back,
  X walks in the place (the d-pad then walks, A talks to or looks at what is marked, L2/R2 mark the next thing,
  L1/R1 turn the view, hold B to run), Y hears the waiting voice, Start opens the menu, Select steps through the four
  pages, Select + L1/R1 zooms. Menu > Controls… lists it and can swap A and B.
- **Detail** (Menu > Detail: Full / Light): Light runs at 30 frames a second and checks what hides the courier less
  often. It is the default on a handheld.
- Redrawing a place keeps the people who are already dressed (it used to build every figure again), which took the
  market's redraw from about 0.39 s to 0.15 s on a desktop.
- With living dice on, Select also reaches the dice panel (after the Journal).
- Checks: `tests/pad_bot.gd` plays whole runs with pad buttons only; `tests/handheld_shots.gd` takes 640×480 pictures
  driven by the pad; `tests/handheld_perf.gd` times the slow steps.

## Not ported

- Saves kept with a Claude account can't be reached from Godot directly (they only exist inside claude.ai); bring them across with the browser's Save all saves to one file.

## Checks you can run

- `tests/dialogue_parity.gd`: conversations recorded in the browser build, replayed here with the same state, dice and choices; every screen must match (320 of 321 runs, Redoubt Nine and the signal hut included: the other is the tavern dice game, whose loaded dice use the browser's own unseeded random numbers).
- `tests/talk_record.gd -- out.json`: plays every conversation with seeded states and choices and writes each screen; run it before and after a change and compare.
- `tests/v100_test.gd`: the redoubt scene, the signal hut, going round a meeting, the courier's record, the sky-fire (34/34).
- `tests/balance.gd ... hurry`: a bot that watches the clock (goes round meetings, takes the pole road).

From the project folder, with Godot on your PATH:

```
godot --headless -s res://tests/parse_all.gd          # every logic snippet in data/ parses
godot --headless -s res://tests/bot.gd -- 7 2000 rush  # a bot plays a full run with random choices
godot --headless -s res://tests/systems_test.gd       # fights, companions, market, gate, errands, going back
godot --headless -s res://tests/places_test.gd        # every 3D place loads and its people can be reached
godot --headless -s res://tests/world_click_test.gd   # conversations open from clicks in 3D
godot --headless -s res://tests/saves_test.gd         # slots, files, save codes, sync folder, a browser save
godot --headless -s res://tests/horses_test.gd        # the horses at Cross-Pillars follow the story
godot --headless -s res://tests/edits_test.gd         # place edits: keyed as the browser keys them, and applied
godot --headless -s res://tests/editor_test.gd        # the place editor, driven like a person would
godot --headless -s res://tests/walkers_test.gd       # Linden's walking townsfolk, Marl's rounds, the stoop
godot --headless -s res://tests/touch_test.gd         # voice ring and button, pinch and twist, settings, remapping keys
godot -s res://tests/ui_shots.gd -- <dir> <name>       # screenshots (add --resolution 390x844 for a phone)
```

### The balance report

`tests/balance.gd` plays a whole run and records every check, the supplies at each place, the fights and the ending; `tools/balance_report.py` turns a folder of those runs into a report:

```
godot --headless -s res://tests/balance.gd -- <seed> 2500 <random|careful> runs/<name>.json
python3 tools/balance_report.py runs > report.md
```

`tests/equiv.gd` compares the logic's results against the browser version (`tests/equiv_node.json` was recorded from it).

## Credits

Writing, systems, portraits and audio are from the original game; see Credits in the game's menu. Fonts: Caladea (Apache 2.0) and Liberation Mono (SIL OFL 1.1), licence texts in `assets/fonts`.
