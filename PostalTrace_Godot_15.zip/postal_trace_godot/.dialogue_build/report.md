# Dialogue compile report

- 22 script files, 146 conversations, 1233 nodes, 2156 options, 177 checks, 2086 inner-voice lines
- 78 fields still written as JavaScript (@js): actions such as starting a fight or a sale, and a few lines that use list helpers
- 0 errors, 2 warnings

## Warnings

- back_oak.pt back_oak:surgeon ~ hub: reads done.lead_tried, which nothing sets (a typo?)
- chapel.pt chapel:ines ~ hub: reads done.ines_lamp, which nothing sets (a typo?)

