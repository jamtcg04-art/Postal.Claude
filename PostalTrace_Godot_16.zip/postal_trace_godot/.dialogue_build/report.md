# Dialogue compile report

- 22 script files, 150 conversations, 1249 nodes, 2183 options, 178 checks, 2119 inner-voice lines
- 78 fields still written as JavaScript (@js): actions such as starting a fight or a sale, and a few lines that use list helpers
- 0 errors, 2 warnings

## Warnings

- back_oak.pt back_oak:surgeon ~ hub: reads done.lead_tried, which nothing sets (a typo?)
- chapel.pt chapel:ines ~ hub: reads done.ines_lamp, which nothing sets (a typo?)

