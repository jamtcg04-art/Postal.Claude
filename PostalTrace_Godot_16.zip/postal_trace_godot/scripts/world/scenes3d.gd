class_name Scenes3D
extends Node
## Two moments of the story played out in the place behind the text:
## - the quick draw at Cross-Pillars ("Clear the road with iron and powder"): a breath of standoff, then the draw;
##   Vane drops and his two run for the spruce, or the ball goes wide, the woodcutter lunges with the axe,
##   the fowling piece flashes, and the three of them give way at last;
## - the Oakhaven surgery (the walking lead): the courier lies on a cot under the canvas and the surgeon works;
##   the probe goes in; then the ball held up in the forceps, or a shake of the head.

var world: Node3D
var t := 0.0
var queue: Array = []          # [{at: float, fn: Callable}]
var made: Array = []           # what a scene put in the place, taken away when it is over
var _place: Node = null

func _at(dt: float, fn: Callable) -> void:
	queue.append({ "at": t + dt, "fn": fn })

func _fig(id: String) -> Figure:
	return world.figures.get(id) if world and world.figures.has(id) else null

func _face(f: Node3D, to: Vector3) -> void:
	var p: Vector3 = f.global_position
	f.global_rotation.y = atan2(to.x - p.x, to.z - p.z)

func _flash(p: Vector3, big := false) -> void:
	if world.stage:
		world.stage._flash(p, big)

func _snd(k: String, v: float) -> void:
	var S := world.get_tree().root.get_node_or_null("Sound")
	if S:
		S.play(k, v)

func _clean() -> void:
	for n in made:
		if is_instance_valid(n):
			n.queue_free()
	made.clear()
	queue.clear()

# ---------------------------------------------------------------- the quick draw

## The build-up before the time stop (the browser's TS_STAGE): the courier walks out to four paces from Vane, they square up,
## the camera comes in between them, and the pistol comes up. `then` opens the stopped moment.
var _so: Dictionary = {}
var _cam_back: Variant = null      # the zoom to go back to when a scene is over
func can_standoff(key: String) -> bool:
	return key == "cross:0" and world != null and _fig("vane") != null

func standoff(_key: String, then: Callable) -> void:
	var vane := _fig("vane")
	if world == null or vane == null:
		then.call()
		return
	_clean()
	_place = world.place
	var vp: Vector3 = vane.global_position
	vp.y = 0.0
	var d := Vector3(world.pl.x - vp.x, 0, world.pl.z - vp.z)
	var L := d.length()
	var to: Vector3 = world.pl if L < 0.01 else vp + d / L * minf(L, 4.0)
	world.input_locked = true
	world.goal = null
	_face(vane, to)
	vane.play_once("pidle", 1.0, 9999.0)
	for id in ["axeman", "fowler"]:
		var f := _fig(id)
		if f:
			_face(f, to)
			f.play_once("paim" if id == "fowler" else "idle", 1.0, 9999.0)
	_cam_back = world.zoom
	_so = { "to": to, "vane": vane, "then": then, "t0": t, "arr": -1.0, "z0": float(world.zoom), "aimed": false }

func _standoff_tick() -> void:
	var vane: Figure = _so.vane
	if not is_instance_valid(vane):
		_so = {}
		return
	var me: Figure = world.player
	var to: Vector3 = _so.to
	world.look_here = (world.pl + Vector3(vane.global_position.x, 0, vane.global_position.z)) * 0.5
	world.zoom = lerpf(float(_so.z0), float(_so.z0) * 0.62, minf(1.0, (t - float(_so.t0)) / 1.4))
	# walk out to the mark (moved here, not by the world's path-finding, so it plays the same in every build)
	if float(_so.arr) < 0.0:
		var g := Vector3(to.x - world.pl.x, 0, to.z - world.pl.z)
		if g.length() > 0.05:
			world.pl += g.normalized() * minf(g.length(), 3.0 * get_process_delta_time())
			world.face = atan2(g.x, g.z)
			me.play("walk")
	if float(_so.arr) < 0.0 and (Vector2(world.pl.x - to.x, world.pl.z - to.z).length() < 0.06 or t - float(_so.t0) > 6.0):
		_so.arr = t
		world.goal = null
		world.pl = to
		_face(me, vane.global_position)
		world.face = me.rotation.y
		me.play_once("pidle", 1.0, 9999.0)
	if float(_so.arr) >= 0.0:
		world.face = atan2(vane.global_position.x - world.pl.x, vane.global_position.z - world.pl.z)
		if t > float(_so.arr) + 1.3 and not _so.aimed:
			_so.aimed = true
			me.play_once("paim", 1.0, 9999.0)
		if t > float(_so.arr) + 2.1:
			var th: Callable = _so.then
			_so = {}
			th.call()

## The shot (straight after the stopped moment): Vane drops and his two run for the spruce; or the ball goes wide, the
## woodcutter comes in with the axe, the fowling piece flashes, and the three of them give way at last.
## Returns how long it plays, so the story can stay out of the way that long.
func quickdraw(ok: bool) -> float:
	var vane := _fig("vane")
	if world == null or vane == null:
		return 0.0
	_clean()
	_place = world.place
	var axe := _fig("axeman")
	var fowl := _fig("fowler")
	var me: Figure = world.player
	var vp: Vector3 = vane.global_position
	_face(me, vp)
	world.face = me.rotation.y
	if _cam_back == null:
		_cam_back = world.zoom
	world.look_here = (world.pl + Vector3(vp.x, 0, vp.z)) * 0.5
	world.input_locked = true
	me.play_once("paim", 1.0, 0.3)
	_at(0.25, func():
		me.play_once("pshoot", 1.6, 0.8)
		_flash(world.pl + Vector3(sin(world.face), 0, cos(world.face)) * 0.7)
		_snd("pistol", 0.55))
	var dur := 3.4
	if ok:
		_at(0.4, func(): vane.play_once("death", 1.0, 9999.0))
		for f in [axe, fowl]:
			if f:
				var ff: Figure = f
				_at(0.9, func(): _run(ff, ff.global_position + (ff.global_position - world.pl).normalized() * 14.0))
	else:
		dur = 4.2
		_at(0.4, func(): vane.play_once("crouch", 1.6, 0.6))
		if axe:
			_at(0.7, func():
				_face(axe, world.pl)
				axe.play_once("chop", 1.3, 0.7)
				me.play_once("hith", 1.0, 0.6))
		if fowl:
			_at(1.1, func():
				_face(fowl, world.pl)
				fowl.play_once("pshoot", 1.0, 0.6)
				_flash(fowl.global_position + Vector3(0, 0, 0))
				_snd("pistol", 0.4)
				me.play_once("hitc", 1.0, 0.6))
		_at(1.8, func(): me.play_once("punch", 1.2, 0.6))
		for f in [vane, axe, fowl]:
			if f:
				var ff2: Figure = f
				_at(2.6, func(): _run(ff2, ff2.global_position + (ff2.global_position - world.pl).normalized() * 14.0))
	_at(dur, func():
		world.input_locked = false
		world.look_here = null
		if _cam_back != null:
			world.zoom = _cam_back
		_cam_back = null)
	return dur

## Run off, out of the place (they do not come back this visit).
func _run(f: Figure, to: Vector3) -> void:
	f.set_meta("run_to", to)

# ---------------------------------------------------------------- the surgery under the canvas

var cot: Node3D

func surgery(step: String) -> void:
	var sg := _fig("surgeon")
	if world == null or sg == null:
		return
	if step == "lie":
		_clean()
		_place = world.place
		var sp: Vector3 = sg.global_position
		cot = PlaceBuilder._prop({ "m": "r_cot", "x": sp.x - 1.3, "z": sp.z - 0.6, "h": 0.5, "r": PI / 2 }, PlaceBuilder.models().get("sizes", {}))
		world.place.add_child(cot)
		made.append(cot)
		var c := PropMotion.spot(cot)
		# the courier lies on his back along the cot
		var me: Figure = world.player
		world.input_locked = true
		world.pl = Vector3(c.x, 0, c.z)
		me.set_meta("lying", Vector3(c.x, 0.52, c.z))
		me.play_once("death", 4.0, 9999.0)
		_at(0.6, func():
			if me.anim:
				me.anim.seek(me.anim.current_animation_length, true))
		_face(sg, c)
		sg.play("interact")
	elif step == "probe":
		sg.play_once("interact", 1.4, 2.0)
		_at(0.5, func(): _flash(world.player.global_position + Vector3(0, 0.4, 0)))
	elif step == "out":
		sg.play_once("yes", 1.0, 2.5)
	elif step == "fail":
		sg.play_once("no", 1.0, 2.5)
	elif step == "up":
		var me2: Figure = world.player
		me2.remove_meta("lying")
		me2.rotation = Vector3(0, me2.rotation.y, 0)
		me2._hold_until = 0
		me2.play("idle")
		world.input_locked = false
		_clean()

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	t += dt
	if world == null:
		return
	if _place != null and world.place != _place:
		_clean()
		_place = null
		if world.player and world.player.has_meta("lying"):
			world.player.remove_meta("lying")
	if not _so.is_empty():
		_standoff_tick()
	var due: Array = []
	var rest: Array = []
	for q in queue:
		(due if t >= float(q.at) else rest).append(q)
	queue = rest
	for q in due:
		q.fn.call()
	for id in world.figures:
		var f: Figure = world.figures[id]
		if is_instance_valid(f) and f.has_meta("run_to"):
			var to: Vector3 = f.get_meta("run_to")
			var d: Vector3 = to - f.global_position
			d.y = 0.0
			if d.length() < 0.2:
				f.visible = false
				f.remove_meta("run_to")
			else:
				f.global_position += d.normalized() * minf(d.length(), 4.6 * dt)
				f.global_rotation.y = atan2(d.x, d.z)
				f.play("sprint")
	var me: Figure = world.player
	if me and me.has_meta("lying"):
		me.global_position = me.get_meta("lying")
