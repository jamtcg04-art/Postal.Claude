## World: the 3D place you are in. Walking, the camera, and clicking people and things.
##
## main.gd puts this inside a low-resolution SubViewport behind the text panel. Click the
## ground to walk there, click a person or a thing to walk up to it and start talking or
## looking; WASD or a gamepad stick walks, Q/E turn the view, the mouse wheel zooms.
class_name World
extends Node3D

signal interact(kind: String, id: String)   # "person", "thing" or "door"
signal area_changed(file: String)

const SPEED := 4.2
const RUN := 7.6

var place: Node3D
var file = ""
var cam: Camera3D
var player: Figure
var label: Label3D
var bark_label: Label3D
var env: WorldEnvironment

var pl = Vector3.ZERO
var face = PI
var moving = false
var goal: Variant = null            # {x, z, then: Callable, wp: Array}
var yaw = PI / 4
var pitch = 0.62
var zoom = 7.5
var cam_target = Vector3.ZERO
var bounds = Rect2(-20, -20, 40, 40)
var solids: Array = []              # {x, z, r} or {x0, x1, z0, z1}
var lifts: Array = []               # raised floors you can walk on (a porch, its stair, a bridge deck): see lift_at()
var lift_top := 0.0                 # the highest of them, for picking a spot on it with the mouse
var picks: Array = []               # interactables: {kind, id, node, pos, hy, ax, az, pr}
var figures: Dictionary = {}        # person id -> Figure
var hover: Variant = null
var nav: Dictionary = {}
var barks: Dictionary = {}
var bark_seen: Dictionary = {}
var bark_t = 0.0
var active = false
var fx: PlaceFX
var editing = false                # the place editor has the view (see place_editor.gd)
var edit_cam: Variant = null        # where the camera looks while editing
var edits: PlaceEdits
var input_locked = false
# game pad walking (scripts/pad.gd): the d-pad moves, A goes to the highlighted person or thing
var pad_on := false
var pad_mv := Vector2.ZERO
var pad_run := false
var pad_turn := 0.0
var pad_target: Variant = null      # a pick, or null
var _pad_manual_at: Variant = null  # where the courier stood when L2/R2 chose the target by hand
var _pad_t := 0.0
var see_through_every := 0.08       # seconds between checks for what hides the courier (Settings > Detail)

func _ready() -> void:
	stage = FightStage.new()
	stage.name = "FightStage"
	add_child(stage)
	stage.call_deferred("setup", self)
	scenes = Scenes3D.new()
	scenes.name = "Scenes"
	scenes.world = self
	add_child(scenes)
	stage.bearers = BearersScene.new()
	stage.bearers.name = "Bearers"
	stage.bearers.world = self
	stage.bearers.stage = stage
	add_child(stage.bearers)
	cam = Camera3D.new()
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.near = 1.0
	cam.far = 140.0
	add_child(cam)
	player = Figure.new()
	player.name = "Courier"
	add_child(player)
	label = Label3D.new()
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.fixed_size = true
	label.pixel_size = 0.0022
	label.font_size = 28
	label.outline_size = 8
	label.modulate = Color(0.95, 0.9, 0.78)
	label.visible = false
	add_child(label)
	bark_label = label.duplicate()
	bark_label.modulate = Color(0.85, 0.85, 0.8)
	bark_label.font_size = 24
	bark_label.width = 420
	bark_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(bark_label)
	env = WorldEnvironment.new()
	env.environment = Environment.new()
	env.environment.background_mode = Environment.BG_COLOR
	add_child(env)

## Does this place have a 3D layout?
static func has_place(file: String) -> bool:
	return FileAccess.file_exists("res://data/places/%s.json" % file)

## Go into a place. file: "cross", or "malice__hall" for an inside area.
func enter(new_file: String, at: Variant = null, at_face: Variant = null) -> void:
	if place and file == new_file:
		active = true
		return
	road = null
	if stage:
		stage.cast.clear()
	if place:
		_save_pos()
		place.queue_free()
		place = null
	_faded.clear()
	file = new_file
	var baked = "res://places/%s.tscn" % file
	if ResourceLoader.exists(baked):
		place = load(baked).instantiate()
		PlaceBuilder.restyle_all(place)
	else:
		place = PlaceBuilder.build(file)
	add_child(place)
	edits = PlaceEdits.attach(place, file)
	fx = PlaceFX.attach(place, file)
	var L = PlaceBuilder.layout(file)
	barks = Data._norm(L.get("barks", {})) if L.get("barks") is Dictionary else {}
	bark_seen.clear()
	var b: Variant = _meta(place, "bounds")
	if b is Array and b.size() == 4:
		bounds = Rect2(float(b[0]), float(b[1]), float(b[2]) - float(b[0]), float(b[3]) - float(b[1]))
	else:
		bounds = Rect2(-20, -20, 40, 40)
	zoom = float(place.get_meta("zoom", 7.5)) if _meta(place, "zoom") != null else 7.5
	var lf: Variant = _meta(place, "lifts")
	lifts = lf if lf is Array else []
	lift_top = float(_meta(place, "liftTop")) if _meta(place, "liftTop") != null else 0.0
	_set_area(new_file)
	_read_solids()
	_spawn_people()
	_read_picks()
	nav.clear()
	var from_road: bool = Game.S.get("_from_road", false) == true
	Game.S.erase("_from_road")
	var st: Variant = place.get_meta("start", [0, 10])
	var saved: Variant = Game.S.done.get("wpos_" + file)
	if at is Array:
		pl = Vector3(float(at[0]), 0, float(at[1]))
	elif saved is Array:
		pl = Vector3(float(saved[0]), 0, float(saved[1]))
	else:
		pl = Vector3(float(st[0]), 0, float(st[1]))
	face = float(at_face) if at_face != null else float(place.get_meta("face", PI) if _meta(place, "face") != null else PI)
	pl.y = lift_at(pl.x, pl.z)
	goal = null
	cam_target = pl
	var fog: Variant = place.get_meta("fog", [0.12, 0.15, 0.17])
	var fr: Variant = place.get_meta("fogR", [11, 24])
	var lt: Variant = place.get_meta("light", [0.4, 0.85, 0.3])
	var fc = Color(float(fog[0]), float(fog[1]), float(fog[2]))
	env.environment.background_color = fc
	RenderingServer.global_shader_parameter_set("pt_fog", Vector3(fc.r, fc.g, fc.b))
	RenderingServer.global_shader_parameter_set("pt_fog_range", Vector2(float(fr[0]), float(fr[1])))
	RenderingServer.global_shader_parameter_set("pt_light", Vector3(float(lt[0]), float(lt[1]), float(lt[2])))
	player.dress(Figure.courier_look())
	_spawn_my_horse(from_road)
	active = true
	_place_camera(1.0)
	area_changed.emit(file)

# ================================================================ the road between stops (road_view.gd)

var road: RoadView = null
var scenes: Scenes3D             # the quick draw at Cross-Pillars, the Oakhaven surgery (scenes3d.gd)
var stage: FightStage            # fights in 3D (fight_stage.gd): the browser's W.stage events
const ROAD_FOG := Vector3(0.13, 0.15, 0.17)
const ROAD_LIGHT := Vector3(0.4, 0.85, 0.3)
const NIGHT_FOG := Vector3(0.045, 0.05, 0.07)
const NIGHT_LIGHT := Vector3(-0.3, 0.12, -0.6)   # the light from low behind: faces go dim
var _night_k := 0.0

## Put the road up as the place: the courier walks in place and the country goes by.
func enter_road(seed_i: int, with_horse: bool) -> void:
	if road != null and place == road:
		active = true
		return
	if place:
		_save_pos()
		place.queue_free()
		place = null
	_faded.clear()
	file = "@road"
	road = RoadView.build(seed_i, with_horse)
	place = road
	add_child(place)
	fx = null
	solids.clear()
	picks.clear()
	figures.clear()
	barks = {}
	bounds = Rect2(-30, -30, 60, 60)
	pl = Vector3.ZERO
	face = PI / 2
	goal = null
	yaw = 0.0
	pitch = 0.5
	zoom = 5.6
	cam_target = Vector3(0.8, 0, -1.2)
	_night_k = 0.0
	_road_light(0.0)
	player.dress(Figure.courier_look())
	input_locked = true
	active = true
	area_changed.emit(file)

func road_set(mode: String, info := {}) -> void:
	if road:
		road.set_mode(mode, info)

func _road_light(k: float) -> void:
	var f := ROAD_FOG.lerp(NIGHT_FOG, k)
	env.environment.background_color = Color(f.x, f.y, f.z)
	RenderingServer.global_shader_parameter_set("pt_fog", f)
	RenderingServer.global_shader_parameter_set("pt_fog_range", Vector2(11, 24).lerp(Vector2(3.5, 12.0), k))
	RenderingServer.global_shader_parameter_set("pt_light", ROAD_LIGHT.lerp(NIGHT_LIGHT, k))

func _road_tick(dt: float) -> void:
	var camping: bool = not road.camp.is_empty()
	# with a horse the courier rides the road, and gets down to make camp
	if road.horse and not camping and player.riding == null:
		player.mount(road.horse)
	elif (camping or road.horse == null) and player.riding != null:
		player.dismount()
	if player.riding != null:
		var cam_t: Vector3 = Vector3(0.6, 1.1, -1.0)
		cam_target = cam_target.lerp(cam_t, minf(1.0, dt * 1.5))
		var dir0 = Vector3(cos(pitch) * sin(yaw), sin(pitch), cos(pitch) * cos(yaw))
		cam.size = zoom * 2.0
		cam.position = cam_target + dir0 * 40.0
		cam.look_at(cam_target, Vector3.UP)
		var k0: float = 1.0 if road.night else 0.0
		if absf(_night_k - k0) > 0.001:
			_night_k = move_toward(_night_k, k0, dt * 0.6)
			_road_light(_night_k)
		return
	pl = road.camp_player_spot() if camping else Vector3.ZERO
	face = (atan2(-1.0, -0.4) if road.player_anim == "sit" else PI) if camping else PI / 2   # sitting: turned to the fire
	player.position = pl
	player.rotation.y = face
	var walk: bool = road.player_anim == "walk"
	player.play(road.player_anim if (not walk or road.speed > 0.2) else "idle", clampf(road.speed / RoadView.SPEED, 0.5, 1.2) if walk else 1.0)
	var k: float = 1.0 if road.night else 0.0
	if absf(_night_k - k) > 0.001:
		_night_k = move_toward(_night_k, k, dt * 0.6)
		_road_light(_night_k)
	var tgt: Vector3 = Vector3(0.6, 0.6, -3.0) if camping else Vector3(0.8, 0.6, -1.0)
	cam_target = cam_target.lerp(tgt, minf(1.0, dt * 1.5))
	var dir = Vector3(cos(pitch) * sin(yaw), sin(pitch), cos(pitch) * cos(yaw))
	cam.size = zoom * 2.0
	cam.position = cam_target + dir * 40.0
	cam.look_at(cam_target, Vector3.UP)
	RenderingServer.global_shader_parameter_set("pt_cam", cam_target)

# ================================================================ the courier's horse in places

var my_horse: Node3D = null
const HORSE_LOOK := { "grey": ["cp_horse_grey", [1.0, 1.0, 1.0]], "black": ["cp_horse", [0.25, 0.23, 0.24]], "bess": ["cp_horse", [1.0, 1.0, 1.0]],
	"cob": ["cp_horse", [0.82, 0.72, 0.6]], "mare": ["cp_horse_grey", [0.92, 0.86, 0.78]] }
const RIDE_SPEED := 5.0
const RIDE_RUN := 9.0

func _horse_owned() -> Variant:
	var h: Variant = Game.S.get("horse")
	return h if h is Dictionary and h.get("id") != null and Bridge.has_js("horseOk") and Data.truthy(Bridge.call_js("horseOk")) else null

## Outdoors, the courier's horse is with him: in the saddle if he rode in from the road, standing by if he came
## out of a door.
func _spawn_my_horse(from_road: bool) -> void:
	my_horse = null
	var h: Variant = _horse_owned()
	if h == null or file.contains("__") or road != null:
		if player and player.riding:
			player.dismount()
		return
	var lk: Array = HORSE_LOOK.get(str(h.id), HORSE_LOOK.grey)
	my_horse = PlaceBuilder._prop({ "m": lk[0], "x": pl.x + 1.2, "z": pl.z, "h": 1.9, "r": face, "tint": lk[1] }, PlaceBuilder.models().get("sizes", {}))
	my_horse.name = "MyHorse"
	place.add_child(my_horse)
	if not PropMotion.rig_horse(my_horse, 11):
		my_horse.queue_free()
		my_horse = null
		return
	_horse_pick()
	if from_road:
		_horse_at(pl, face)
		player.mount(my_horse)
	elif player.riding:
		player.dismount()

func _horse_pick() -> void:
	if my_horse == null or not is_instance_valid(my_horse):
		return
	for k in picks:
		if k.kind == "horse":
			return
	var nm := str(Bridge.call_js("horseName")) if Bridge.has_js("horseName") else "your horse"
	picks.append({ "kind": "horse", "id": "my_horse", "node": my_horse, "name": nm.capitalize(), "hy": 1.7, "ax": null, "az": null, "pr": 1.4, "to": null, "at": null, "note": "Get up in the saddle" })

func _horse_at(p: Vector3, f: float) -> void:
	if my_horse == null:
		return
	my_horse.rotation.y = f
	var c := PropMotion.spot(my_horse)
	my_horse.position += Vector3(p.x - c.x, 0, p.z - c.z)

func mounted() -> bool:
	return my_horse != null and player != null and player.riding == my_horse

## Get down beside the horse (to talk, look closer or go through a door); she stays where she stands.
func dismount_here() -> void:
	if not mounted():
		return
	player.dismount()
	var side := Vector3(cos(face), 0, -sin(face)) * 0.9
	_move_to(pl.x + side.x, pl.z + side.z)

func mount_up() -> void:
	if my_horse == null or mounted():
		return
	var c := PropMotion.spot(my_horse)
	pl = Vector3(c.x, 0, c.z)
	face = my_horse.rotation.y
	player.mount(my_horse)

func leave() -> void:
	_save_pos()
	active = false

func _save_pos() -> void:
	if file != "" and not file.begins_with("@"):
		Game.S.done["wpos_" + file] = [snappedf(pl.x, 0.1), snappedf(pl.z, 0.1)]

func _read_solids() -> void:
	solids.clear()
	var holder = place.get_node_or_null("Solid")
	if holder == null:
		return
	for m in holder.get_children():
		if m.get_meta("off", false) or (fx and fx.cleared(m.position.x, m.position.z)):
			continue
		if m.has_meta("r"):
			solids.append({ "x": m.position.x, "z": m.position.z, "r": float(m.get_meta("r")) })
		elif m.has_meta("half"):
			var h: Vector2 = m.get_meta("half")
			solids.append({ "x0": m.position.x - h.x, "x1": m.position.x + h.x, "z0": m.position.z - h.y, "z1": m.position.z + h.y })

func _spawn_people() -> void:
	if _cut != null:
		var c: Dictionary = _cut
		_cut = null
		zoom = c.zoom
		input_locked = c.lock
	figures.clear()
	var here: Array = []
	for t in Game.talkers():
		here.append(str(t.id))
	for group in ["People", "Bystanders"]:
		var holder = place.get_node_or_null(group)
		if holder == null:
			continue
		for m in holder.get_children():
			if m.get_meta("kind", "") == "person" and not here.has(str(m.get_meta("id", ""))):
				m.visible = false
				continue
			m.visible = true
			var lk: Variant = _meta(m, "look")
			var o: Dictionary = lk.o if lk is Dictionary and lk.get("o") is Dictionary else { "c": m.get_meta("coat", [0.3, 0.28, 0.26]) }
			var want: String = str(lk.get("want", "idle")) if lk is Dictionary and lk.get("o") is Dictionary else "idle"
			# keep a figure that is already dressed the same: building one is the slow part of redrawing a
			# scene (a tenth of a second at the market on a desktop, about a second on a handheld)
			var f: Figure = null
			for c in m.get_children():
				if c is Figure and not c.is_queued_for_deletion():
					if f == null and c.look.hash() == o.hash():
						f = c
					else:
						c.queue_free()
			if f == null:
				f = Figure.new()
				m.add_child(f)
				f.dress(o)
			f.play(want)
			if m.get_meta("kind", "") == "person":
				figures[str(m.get_meta("id"))] = f
				solids.append({ "x": m.global_position.x, "z": m.global_position.z, "r": 0.35 })

func _read_picks() -> void:
	picks.clear()
	for group in ["People", "Things"]:
		var holder = place.get_node_or_null(group)
		if holder == null:
			continue
		for m in holder.get_children():
			if not m.visible:
				continue
			var kind = str(m.get_meta("kind", "thing"))
			var id = str(m.get_meta("id", ""))
			if kind == "thing" and not _thing_here(id):
				continue
			picks.append({ "kind": kind, "id": id, "node": m, "name": str(m.get_meta("name", id)),
				"hy": float(m.get_meta("hy", 1.6 if kind == "person" else 0.6)), "ax": _meta(m, "ax"), "az": _meta(m, "az"),
				"pr": float(m.get_meta("pr", 1.1)), "to": _meta(m, "to"), "at": _meta(m, "at") })
	_horse_pick()

func _thing_here(oid: String) -> bool:
	for o in Game.objects():
		if str(o.id) == oid:
			return true
	return false

## Build the place again from its layout and edits, keeping where you stand (the editor's undo, reset...).
func rebuild() -> void:
	if place == null:
		return
	var f = file
	var at = [pl.x, pl.z]
	var fc = face
	place.free()
	place = null
	file = ""
	enter(f, at, fc)
	refresh()

## Recheck who is here and what can be looked at (after a conversation changes things).
func refresh() -> void:
	if place == null:
		return
	if fx:
		fx.apply_state()
	_read_solids()
	_spawn_people()
	_read_picks()
	nav.clear()

# ================================================================ moving

func _blocked(x: float, z: float, pad: float) -> bool:
	if x < bounds.position.x or x > bounds.end.x or z < bounds.position.y or z > bounds.end.y:
		return true
	for s in solids:
		if s.has("r"):
			if Vector2(x - s.x, z - s.z).length() < float(s.r) + pad:
				return true
		elif x > s.x0 - pad and x < s.x1 + pad and z > s.z0 - pad and z < s.z1 + pad:
			return true
	return false

func _move_to(x: float, z: float) -> void:
	x = clampf(x, bounds.position.x, bounds.end.x)
	z = clampf(z, bounds.position.y, bounds.end.y)
	for s in solids:
		if s.has("r"):
			var d = Vector2(x - s.x, z - s.z)
			var l = d.length()
			if l < float(s.r):
				var n = d / (l if l > 0.0 else 1.0)
				x = float(s.x) + n.x * float(s.r)
				z = float(s.z) + n.y * float(s.r)
		elif x > s.x0 and x < s.x1 and z > s.z0 and z < s.z1:
			var e = [x - float(s.x0), float(s.x1) - x, z - float(s.z0), float(s.z1) - z]
			var m: float = e.min()
			if m == e[0]: x = float(s.x0)
			elif m == e[1]: x = float(s.x1)
			elif m == e[2]: z = float(s.z0)
			else: z = float(s.z1)
	pl.x = x
	pl.z = z
	pl.y = lift_at(x, z)

## Raised floors, the same list and rule as the browser's liftAt(): flat {x0,x1,z0,z1,y}; a slope with ramp
## "z-" | "z+" | "x-" | "x+" (rising toward that side to y); a hump with edge and along (y in the middle, falling
## to nothing over `edge` at both ends). The highest one under (x, z) wins.
func lift_at(x: float, z: float) -> float:
	var y := 0.0
	for q in lifts:
		if not (x > float(q.x0) and x < float(q.x1) and z > float(q.z0) and z < float(q.z1)):
			continue
		var h := float(q.y)
		if q.get("ramp") != null:
			var r := str(q.ramp)
			var f := (float(q.z1) - z) / (float(q.z1) - float(q.z0)) if r == "z-" else ((z - float(q.z0)) / (float(q.z1) - float(q.z0)) if r == "z+" else ((float(q.x1) - x) / (float(q.x1) - float(q.x0)) if r == "x-" else (x - float(q.x0)) / (float(q.x1) - float(q.x0))))
			h = float(q.y) * clampf(f, 0.0, 1.0)
		elif q.get("edge") != null:
			var e := minf(x - float(q.x0), float(q.x1) - x) if str(q.get("along", "z")) == "x" else minf(z - float(q.z0), float(q.z1) - z)
			h = float(q.y) * minf(1.0, e / float(q.edge))
		y = maxf(y, h)
	return y

## Which room of a place you are in, for the game's own checks (W.areas, as in the browser: OBJECTS' show,
## TALK's when ...): "ford__ferryhouse" puts W.areas.ford = "ferryhouse"; outside, the place has no entry.
func _set_area(f: String) -> void:
	var Wd: Variant = Data.js.globals.vars.get("W") if Data.js else null
	if not (Wd is Dictionary):
		return
	var areas: Dictionary = Wd.get("areas", {}) if Wd.get("areas") is Dictionary else {}
	areas.clear()
	var i := f.find("__")
	if i > 0:
		areas[f.substr(0, i)] = f.substr(i + 2)
	Wd["areas"] = areas

func _clear_line(a: Vector2, b: Vector2, pad: float) -> bool:
	var d = a.distance_to(b)
	var n = maxi(1, int(ceil(d / 0.15)))
	for i in range(1, n + 1):
		var p = a.lerp(b, float(i) / n)
		if _blocked(p.x, p.y, pad):
			return false
	return true

## A* on a coarse grid around what is solid, then the corners pulled straight.
func _path(from: Vector2, to: Vector2) -> Array:
	var PAD = 0.12
	if not _blocked(to.x, to.y, PAD) and _clear_line(from, to, PAD):
		return [to]
	var C = 0.35
	var nx = int(bounds.size.x / C) + 1
	var nz = int(bounds.size.y / C) + 1
	if nx * nz > 90000:
		return [to]
	if nav.is_empty():
		var g = PackedByteArray()
		g.resize(nx * nz)
		for j in nz:
			for i in nx:
				g[j * nx + i] = 1 if _blocked(bounds.position.x + i * C, bounds.position.y + j * C, 0.2) else 0
		nav = { "g": g }
	var G: PackedByteArray = nav.g
	var cell = func(p: Vector2) -> Vector2i:
		return Vector2i(clampi(int(round((p.x - bounds.position.x) / C)), 0, nx - 1), clampi(int(round((p.y - bounds.position.y) / C)), 0, nz - 1))
	var near_free = func(c: Vector2i) -> Variant:
		if G[c.y * nx + c.x] == 0:
			return c
		for r in range(1, 14):
			var best: Variant = null
			var bd = 1e9
			for dj in range(-r, r + 1):
				for di in range(-r, r + 1):
					if maxi(absi(di), absi(dj)) != r:
						continue
					var i: int = c.x + di
					var j: int = c.y + dj
					if i < 0 or j < 0 or i >= nx or j >= nz or G[j * nx + i] != 0:
						continue
					var dd = di * di + dj * dj
					if dd < bd:
						bd = dd
						best = Vector2i(i, j)
			if best != null:
				return best
		return null
	var s: Variant = near_free.call(cell.call(from))
	var t: Variant = near_free.call(cell.call(to))
	if s == null or t == null:
		return [to]
	var N = nx * nz
	var gs = PackedFloat32Array(); gs.resize(N); gs.fill(1e9)
	var src = PackedInt32Array(); src.resize(N); src.fill(-1)
	var closed = PackedByteArray(); closed.resize(N)
	var si: int = s.y * nx + s.x
	var ti: int = t.y * nx + t.x
	gs[si] = 0
	var open: Array = [[0.0, si]]
	var NB = [[1, 0, 1.0], [-1, 0, 1.0], [0, 1, 1.0], [0, -1, 1.0], [1, 1, 1.414], [1, -1, 1.414], [-1, 1, 1.414], [-1, -1, 1.414]]
	var found = false
	var iter = 0
	while open.size() and iter < 60000:
		iter += 1
		var best_k = 0
		for k in open.size():
			if open[k][0] < open[best_k][0]:
				best_k = k
		var cur: int = open[best_k][1]
		open.remove_at(best_k)
		if closed[cur]:
			continue
		closed[cur] = 1
		if cur == ti:
			found = true
			break
		var ci = cur % nx
		var cj = cur / nx
		for nb in NB:
			var ni: int = ci + nb[0]
			var nj: int = cj + nb[1]
			if ni < 0 or nj < 0 or ni >= nx or nj >= nz:
				continue
			var nn = nj * nx + ni
			if G[nn] != 0 or closed[nn]:
				continue
			if nb[0] != 0 and nb[1] != 0 and (G[cj * nx + ni] != 0 or G[nj * nx + ci] != 0):
				continue
			var ng: float = gs[cur] + nb[2]
			if ng < gs[nn]:
				gs[nn] = ng
				src[nn] = cur
				open.append([ng + Vector2(ni - t.x, nj - t.y).length(), nn])
	if not found:
		return [to]
	var pts: Array = []
	var c2 = ti
	while c2 != -1:
		pts.push_front(Vector2(bounds.position.x + (c2 % nx) * C, bounds.position.y + (c2 / nx) * C))
		c2 = src[c2]
	pts.append(to)
	# pull the string: skip every corner you can see past
	var out: Array = []
	var a = from
	var i2 = 0
	while i2 < pts.size():
		var j2 = pts.size() - 1
		while j2 > i2 and not _clear_line(a, pts[j2], PAD):
			j2 -= 1
		out.append(pts[j2])
		a = pts[j2]
		i2 = j2 + 1
	return out

## A short scripted scene: one person walks from `from` to where they stand, the camera closes in
## and the courier turns to watch; `then` runs at the end (a click or Space skips it).
var _cut: Variant = null
func cut_walk(pid: String, from: Vector2, speed: float, then: Callable) -> void:
	var f: Figure = figures.get(pid)
	if f == null:
		then.call()
		return
	var m: Node3D = f.get_parent()
	var to := Vector2(m.position.x, m.position.z)
	m.position = Vector3(from.x, m.position.y, from.y)
	_cut = { "m": m, "f": f, "to": to, "speed": speed, "then": then, "t": 0.0, "zoom": zoom, "lock": input_locked }
	input_locked = true
	goal = null
	zoom = maxf(4.2, zoom * 0.7)

func in_cut() -> bool:
	return _cut != null

func cut_skip() -> void:
	if _cut == null:
		return
	var c: Dictionary = _cut
	if not is_instance_valid(c.m):
		_cut_end()
		return
	c.m.position = Vector3(c.to.x, c.m.position.y, c.to.y)
	_cut_end()

func _cut_end() -> void:
	var c: Dictionary = _cut
	_cut = null
	if is_instance_valid(c.f):
		c.f.play("idle")
	if is_instance_valid(c.m):
		c.m.rotation.y = atan2(pl.x - c.m.position.x, pl.z - c.m.position.z)
	zoom = c.zoom
	input_locked = c.lock
	c.then.call()

func _cut_tick(dt: float) -> void:
	var c: Dictionary = _cut
	if not is_instance_valid(c.m) or not is_instance_valid(c.f) or place == null:
		# the place was rebuilt under the scene (another screen came up): drop it quietly
		_cut = null
		zoom = c.zoom
		input_locked = c.lock
		return
	c.t += dt
	var m: Node3D = c.m
	if c.t > 0.8:
		var d := Vector2(c.to.x - m.position.x, c.to.y - m.position.z)
		var st: float = c.speed * dt
		if d.length() <= maxf(st, 0.03):
			m.position = Vector3(c.to.x, m.position.y, c.to.y)
			c.f.play("idle")
			if c.t > 1.6 and c.get("arrived", false):
				_cut_end()
				return
			c.arrived = true
		else:
			var n := d.normalized()
			m.position += Vector3(n.x, 0, n.y) * st
			m.rotation.y = atan2(n.x, n.y)
			c.f.play("walk", 1.0)
	if c.t > 10.0:
		cut_skip()
		return
	face = atan2(m.position.x - pl.x, m.position.z - pl.z)
	cam_target = cam_target.lerp(pl.lerp(m.position, 0.45), minf(1.0, dt * 3.0))

func walk_to(x: float, z: float, then: Callable = Callable()) -> void:
	goal = { "x": x, "z": z, "then": then, "wp": _path(Vector2(pl.x, pl.z), Vector2(x, z)) }

func _process(dt: float) -> void:
	if not active or place == null:
		return
	dt = minf(dt, 0.05)
	if road != null and place == road:
		_road_tick(dt)
		return
	if _cut != null:
		_cut_tick(dt)
		if _cut != null:
			player.position = pl
			player.rotation.y = face
			player.play("idle", 1.0)
			var dir = Vector3(cos(pitch) * sin(yaw), sin(pitch), cos(pitch) * cos(yaw))
			cam.size = zoom * 2.0
			cam.position = cam_target + dir * 40.0
			cam.look_at(cam_target, Vector3.UP)
			return
	if editing:
		player.position = pl
		player.play("idle", 1.0)
		_place_camera(dt)
		return
	var mv = Vector2.ZERO
	if not input_locked:
		if Input.is_action_pressed("walk_up"): mv.y -= 1
		if Input.is_action_pressed("walk_down"): mv.y += 1
		if Input.is_action_pressed("walk_left"): mv.x -= 1
		if Input.is_action_pressed("walk_right"): mv.x += 1
		var joy = Vector2(Input.get_joy_axis(0, JOY_AXIS_LEFT_X), Input.get_joy_axis(0, JOY_AXIS_LEFT_Y))
		if joy.length() > 0.3:
			mv += joy
		if Input.is_action_pressed("turn_left"): yaw += dt * 1.6
		if Input.is_action_pressed("turn_right"): yaw -= dt * 1.6
		if Input.is_action_pressed("zoom_in"): zoom = clampf(zoom / (1.0 + dt * 1.5), 3.5, 14.0)
		if Input.is_action_pressed("zoom_out"): zoom = clampf(zoom * (1.0 + dt * 1.5), 3.5, 14.0)
		if pad_on:
			mv += pad_mv
			yaw += dt * 1.6 * pad_turn
	var run = Input.is_action_pressed("run") or (pad_on and pad_run) or (goal != null and goal.get("run", false))
	var speed = RUN if run else SPEED
	if mounted():
		speed = RIDE_RUN if run else RIDE_SPEED
	moving = false
	if mv.length() > 0.01:
		mv = mv.limit_length(1.0)
		var fwx = -sin(yaw); var fz := -cos(yaw); var rx := cos(yaw); var rz := -sin(yaw)
		var v = Vector2(rx * mv.x - fwx * mv.y, rz * mv.x - fz * mv.y)
		if v.length() > 0.0:
			v = v.normalized()
			_move_to(pl.x + v.x * speed * dt, pl.z + v.y * speed * dt)
			face = atan2(v.x, v.y)
			moving = true
			goal = null
	elif goal != null:
		var wp: Vector2 = goal.wp[0] if goal.wp.size() else Vector2(goal.x, goal.z)
		var last: bool = goal.wp.size() <= 1
		var d = Vector2(wp.x - pl.x, wp.y - pl.z)
		if not last and d.length() < 0.25:
			goal.wp.pop_front()
		elif last and d.length() < 0.15:
			var g: Dictionary = goal
			goal = null
			if g.then.is_valid():
				g.then.call()
		else:
			var st = minf(d.length(), speed * dt)
			var n = d.normalized()
			var ox = pl
			_move_to(pl.x + n.x * st, pl.z + n.y * st)
			face = atan2(n.x, n.y)
			moving = true
			if Vector2(pl.x - ox.x, pl.z - ox.z).length() < st * 0.2:
				goal.stuck = float(goal.get("stuck", 0.0)) + dt
				if goal.stuck > 0.6:
					var g2: Dictionary = goal
					goal = null
					if g2.then.is_valid():
						g2.then.call()
	if mounted():
		_horse_at(pl, face)
		PropMotion.horse_play(my_horse, (("gallop" if run else "trot") if moving else "idle"), 1.0)
	else:
		player.position = pl
		player.rotation.y = face
		player.play(("jog" if run else "walk") if moving else "idle", 1.0)
	_place_camera(dt)
	_update_hover()
	_update_barks(dt)
	_people_tick(dt)
	_update_see_through(dt)

# ================================================================ seeing the courier through buildings

## Small street things never turn to stipple; buildings, trees and walls do (as in the original).
const NOFADE := "^(mm_|stall$|f_stall|e_markettent|tent$|barrel|f_barrel|pt_barrel|mk_crate|crates$|f_crate|f_box|pt_box|pt_chest|sacks|mk_wagon|b_cart|pt_cart|cart$|banner|b_lamp|pt_lamp|signpost|well$|fountain|block$|d_bench|f_bench|f_table|f_stool|f_shelf|keg$|lantern|coffin|mn_cart)"
var _nofade_re: RegEx
var _occ_t = 0.0
var _faded: Array = []                # props currently stippled
var _fade_twin: Dictionary = {}       # material -> its stippled copy

func _prop_box(prop: Node3D) -> Variant:
	if prop.has_meta("_box"):
		return prop.get_meta("_box")
	var box: Variant = null
	var inv = prop.global_transform.affine_inverse()
	for mi in prop.find_children("*", "MeshInstance3D", true, false):
		if mi.mesh == null:
			continue
		var a: AABB = (inv * mi.global_transform) * mi.mesh.get_aabb()
		box = a if box == null else box.merge(a)
	prop.set_meta("_box", box)
	return box

func _occludes(prop: Node3D, dir: Vector3) -> bool:
	var box: Variant = _prop_box(prop)
	if box == null:
		return false
	var b: AABB = box
	var sc = prop.global_transform.basis.get_scale()
	if b.size.y * sc.y < 1.15 or b.size.x * sc.x > 60 or b.size.z * sc.z > 60:
		return false
	var inv = prop.global_transform.affine_inverse()
	var ld = (inv.basis * dir)
	for h in [0.25, 0.9, 1.55]:
		var lo = inv * (pl + Vector3(0, h, 0))
		if b.intersects_ray(lo, ld) != null:
			return true
	return false

func _set_fade(prop: Node3D, on: bool) -> void:
	for mi in prop.find_children("*", "MeshInstance3D", true, false):
		if mi.material_override is ShaderMaterial:
			mi.material_override = _twin(mi.material_override, on)
		elif mi.mesh:
			for i in mi.mesh.get_surface_count():
				var m = mi.get_surface_override_material(i)
				if m is ShaderMaterial:
					mi.set_surface_override_material(i, _twin(m, on))

func _twin(m: ShaderMaterial, on: bool) -> ShaderMaterial:
	if on:
		if m.get_meta("faded", false):
			return m
		if not _fade_twin.has(m):
			var t: ShaderMaterial = m.duplicate()
			t.set_shader_parameter("fade", true)
			t.set_meta("faded", true)
			t.set_meta("plain", m)
			_fade_twin[m] = t
		return _fade_twin[m]
	return m.get_meta("plain", m)

func _update_see_through(dt: float) -> void:
	RenderingServer.global_shader_parameter_set("pt_hole", Vector4(pl.x, pl.y + 0.9, pl.z, 1.4))
	_occ_t -= dt
	if _occ_t > 0.0:
		return
	_occ_t = see_through_every
	if _nofade_re == null:
		_nofade_re = RegEx.create_from_string(NOFADE)
	var props = place.get_node_or_null("Props")
	if props == null:
		return
	var dir = cam.global_transform.basis.z.normalized()   # towards the camera
	var now: Array = []
	for p in props.get_children():
		if not (p is Node3D):
			continue
		var m = str(p.get_meta("model", p.name))
		if _nofade_re.search(m) != null:
			continue
		if _occludes(p, dir):
			now.append(p)
	for p in _faded:
		if is_instance_valid(p) and not now.has(p):
			_set_fade(p, false)
	for p in now:
		if not _faded.has(p):
			_set_fade(p, true)
	_faded = now

var look_here: Variant = null       # a scene that wants the camera somewhere (the bearers' ambush); null = on the courier
func _place_camera(dt: float) -> void:
	if editing and edit_cam is Vector3:
		cam_target = edit_cam
	elif look_here is Vector3:
		cam_target = cam_target.lerp(look_here, minf(1.0, dt * 2.0))
	else:
		cam_target = cam_target.lerp(pl, minf(1.0, dt * 4.0))
	var dir = Vector3(cos(pitch) * sin(yaw), sin(pitch), cos(pitch) * cos(yaw))
	cam.size = zoom * 2.0
	cam.position = cam_target + dir * 40.0
	cam.look_at(cam_target, Vector3.UP)
	RenderingServer.global_shader_parameter_set("pt_cam", cam_target)

# ================================================================ pointing and clicking

var _mouse = Vector2(-1, -1)
var _last_click := 0
var _touches: Dictionary = {}    # finger index -> position, for pinch and two-finger turn
var _pinch: Variant = null       # {d, a} at the last step of a two-finger gesture

## Called by main.gd with the mouse position in this world's viewport.
func pointer(ev: InputEvent, pos: Vector2) -> void:
	if not active:
		return
	if _cut != null:
		if (ev is InputEventMouseButton or ev is InputEventScreenTouch) and ev.pressed:
			cut_skip()
		return
	if _gesture(ev):
		return
	if input_locked:
		return
	_mouse = pos
	if ev is InputEventMouseButton and ev.pressed:
		match ev.button_index:
			MOUSE_BUTTON_WHEEL_UP: zoom = clampf(zoom / 1.12, 3.5, 14.0)
			MOUSE_BUTTON_WHEEL_DOWN: zoom = clampf(zoom * 1.12, 3.5, 14.0)
			MOUSE_BUTTON_LEFT: _click(pos)

## Two fingers: pinch to zoom, twist to turn the view. Trackpads: pinch to zoom, two-finger swipe to turn.
## Works while you talk too (the view stays still otherwise). True when the event was used.
func _gesture(ev: InputEvent) -> bool:
	if ev is InputEventScreenTouch:
		if ev.pressed:
			_touches[ev.index] = ev.position
		else:
			_touches.erase(ev.index)
		_pinch = null
		if _touches.size() >= 2:
			goal = null          # the first finger's tap is not a walk
		return _touches.size() >= 2
	if ev is InputEventScreenDrag:
		if not _touches.has(ev.index):
			return false
		_touches[ev.index] = ev.position
		if _touches.size() < 2:
			return false
		var k = _touches.keys()
		var a: Vector2 = _touches[k[0]]
		var b: Vector2 = _touches[k[1]]
		var d = maxf(a.distance_to(b), 1.0)
		var ang = (b - a).angle()
		if _pinch != null:
			zoom = clampf(zoom * float(_pinch.d) / d, 3.5, 14.0)
			yaw += wrapf(ang - float(_pinch.a), -PI, PI)
		_pinch = { "d": d, "a": ang }
		return true
	if ev is InputEventMagnifyGesture:
		zoom = clampf(zoom / ev.factor, 3.5, 14.0)
		return true
	if ev is InputEventPanGesture:
		yaw -= ev.delta.x * 0.04
		return true
	return false

func _click(pos: Vector2) -> void:
	_update_hover()
	if hover != null:
		approach(hover)
		return
	var o = cam.project_ray_origin(pos)
	var d = cam.project_ray_normal(pos)
	if absf(d.y) < 0.0001:
		return
	var t = -o.y / d.y
	var p = o + d * t
	# a raised floor (the porch, its stair) is hit before the ground under it, as in the browser's wGroundAt
	if lifts.size() and lift_top > 0.0:
		var tt = (lift_top - o.y) / d.y
		var pt = o + d * tt
		if lift_at(pt.x, pt.z) > lift_top - 0.05:
			p = pt
		else:
			for _i in 3:
				var hh := lift_at(p.x, p.z)
				p = o + d * ((hh - o.y) / d.y)
	# a second click or tap soon after the first runs there (the browser's double-click)
	var now = Time.get_ticks_msec()
	var fast = now - _last_click < 320
	_last_click = now
	walk_to(p.x, p.z)
	if fast and goal != null:
		goal["run"] = true

func _update_hover() -> void:
	if pad_on:
		_pad_update()
		hover = pad_target
		if hover != null:
			label.text = str(hover.name) + _note(hover)
			label.position = hover.node.global_position + Vector3(0, float(hover.hy) + 0.6, 0)
			label.visible = true
		else:
			label.visible = false
		return
	hover = null
	if _mouse.x < 0:
		label.visible = false
		return
	var best = 26.0
	for k in picks:
		var n: Node3D = k.node
		var at = n.global_position + Vector3(0, float(k.hy) * 0.6, 0)
		if cam.is_position_behind(at):
			continue
		var sp = cam.unproject_position(at)
		var dd = sp.distance_to(_mouse)
		if dd < best:
			best = dd
			hover = k
	if hover != null:
		label.text = str(hover.name) + _note(hover)
		label.position = hover.node.global_position + Vector3(0, float(hover.hy) + 0.6, 0)
		label.visible = true
	else:
		label.visible = false

# ================================================================ choosing with a game pad

## What the pad can reach: everything on view, nearest first.
func pad_list() -> Array:
	var out: Array = []
	for k in picks:
		var n: Node3D = k.node
		if not is_instance_valid(n) or not n.is_visible_in_tree():
			continue
		var at = n.global_position + Vector3(0, float(k.hy) * 0.6, 0)
		if cam.is_position_behind(at):
			continue
		var sp = cam.unproject_position(at)
		var vs = Vector2(get_viewport().size)
		if sp.x < -8 or sp.y < -8 or sp.x > vs.x + 8 or sp.y > vs.y + 8:
			continue
		out.append(k)
	out.sort_custom(func(a, b): return _pad_d(a) < _pad_d(b))
	return out

func _pad_d(k: Dictionary) -> float:
	var p: Vector3 = k.node.global_position
	return Vector2(p.x - pl.x, p.z - pl.z).length()

## The nearest thing in reach is highlighted by itself, unless L2/R2 chose one (until the courier walks off).
func _pad_update() -> void:
	if pad_target != null and (not is_instance_valid(pad_target.node) or not picks.has(pad_target)):
		pad_target = null
	if _pad_manual_at is Vector3 and pl.distance_to(_pad_manual_at) > 2.5:
		_pad_manual_at = null
	if _pad_manual_at != null and pad_target != null:
		return
	_pad_t -= get_process_delta_time()
	if _pad_t > 0.0 and pad_target != null:
		return
	_pad_t = 0.15
	var best: Variant = null
	var bd = 4.5
	var fwd = Vector2(sin(face), cos(face))
	for k in picks:
		var p: Vector3 = k.node.global_position
		var d = Vector2(p.x - pl.x, p.z - pl.z)
		# things ahead of the courier count as nearer than things behind
		var score = d.length() - (0.8 * fwd.dot(d.normalized()) if d.length() > 0.01 else 0.0)
		if score < bd:
			bd = score
			best = k
	pad_target = best

## L2/R2: the next or previous thing on view, by distance.
func pad_cycle(dir: int) -> void:
	var list = pad_list()
	if list.is_empty():
		pad_target = null
		return
	var i = list.find(pad_target)
	i = (i + dir) % list.size() if i >= 0 else (0 if dir > 0 else list.size() - 1)
	if i < 0:
		i += list.size()
	pad_target = list[i]
	_pad_manual_at = pl
	Sound.play("blip", 0.15)

func _note(k: Dictionary) -> String:
	if k.kind == "door":
		return "\n" + str(k.node.get_meta("note", ""))
	return ""

## Walk up to a person or a thing, then talk, look, or go through.
func approach(k: Dictionary) -> void:
	var n: Node3D = k.node
	var tp = Vector2(n.global_position.x, n.global_position.z)
	var stand: Vector2
	if k.ax != null and k.az != null:
		stand = Vector2(float(k.ax), float(k.az))
	else:
		var away = Vector2(pl.x, pl.z) - tp
		stand = tp + (away.normalized() if away.length() > 0.01 else Vector2(0, 1)) * minf(float(k.pr), 1.1)
	if k.kind == "horse":
		var near := Vector2(pl.x, pl.z).distance_to(tp) <= 2.2
		if near:
			mount_up()
		else:
			walk_to(tp.x + 0.9, tp.y, func(): mount_up())
		return
	var done = func():
		dismount_here()
		face = atan2(tp.x - pl.x, tp.y - pl.z)
		if k.kind == "door":
			_through(k)
		else:
			if k.kind == "thing" and player and not mounted():
				player.play_once(look_move(float(k.get("hy", 0.6))))
			interact.emit(k.kind, k.id)
	if Vector2(pl.x, pl.z).distance_to(tp) <= float(k.pr) + 0.7:
		done.call()
	else:
		walk_to(stand.x, stand.y, done)

## Looking at a thing: how high it is says how the courier looks (the browser's lookMove: LOOK_LOW, LOOK_HIGH).
const LOOK_LOW := 0.75
const LOOK_HIGH := 1.7
static func look_move(hy: float) -> String:
	return "reachhigh" if hy >= LOOK_HIGH else ("search" if hy <= LOOK_LOW else "interact")

## Going through a doorway: the courier reaches for the door; a door that is its own model swings open
## first (prop_motion.gd), then the next place loads and its door shuts behind.
var _door_busy := false
func _through(k: Dictionary) -> void:
	if _door_busy:
		return
	var wait := 0.0
	if fx and fx.motion and not editing:
		wait = fx.motion.open_door(k.node.position, pl)
	if wait <= 0.0:
		Sound.play("door_open", 0.3)
	if player:
		player.play_once("interact" if wait > 0.0 else "push", 1.6, maxf(wait, 0.3) + 0.05)
	if DisplayServer.get_name() == "headless" and OS.get_environment("PT_CUT") == "":
		return _through_now(k)
	_door_busy = true
	input_locked = true
	get_tree().create_timer(maxf(wait, 0.3)).timeout.connect(func():
		_door_busy = false
		input_locked = false
		_through_now(k))

func _through_now(k: Dictionary) -> void:
	var base = file.split("__")[0]
	var to: Variant = k.get("to")
	var target = base if to == null else base + "__" + str(to)
	if not has_place(target):
		return
	var at: Variant = k.get("at")
	var tf: Variant = _meta(k.node, "toFace")
	Game.S.done.erase("wpos_" + target)
	enter(target, at, tf)
	if fx and fx.motion:
		fx.motion.shut_behind(pl, pl - Vector3(sin(face), 0, cos(face)))

## Look at a person (when a conversation opens), or let the camera rest.
func focus(kind: String, id: String) -> void:
	for k in picks:
		if k.kind == kind and k.id == id:
			var tp: Vector3 = k.node.global_position
			face = atan2(tp.x - pl.x, tp.z - pl.z)
			if kind == "person" and figures.has(id) and not k.node.get_meta("noTurn", false):
				var f: Figure = figures[id]
				f.get_parent().rotation.y = atan2(pl.x - tp.x, pl.z - tp.z)
				f.play("talk")

# ================================================================ people about their business
## Two standing close together, facing each other: one talks, the other listens, and every PAIR_TURN seconds they
## swap (the browser's pairWant: the same phases from the same seed). The Provost Marshal stamps his ledger now and then.
const PAIR_TURN := 4.5
const STAMP_EVERY := 9.0
var _stamp_t := 0.0
func _people_tick(dt: float) -> void:
	if place == null or _cut != null:
		return
	var holder = place.get_node_or_null("Bystanders")
	var now := Time.get_ticks_msec() / 1000.0
	if holder:
		for m in holder.get_children():
			var pr: Variant = _meta(m, "pair")
			if not (pr is Dictionary) or not m.visible:
				continue
			var f: Figure = null
			for c in m.get_children():
				if c is Figure:
					f = c
			if f == null:
				continue
			var ph := int(floor((now + float(pr.get("seed", 0.0))) / PAIR_TURN))
			var talking: bool = ((ph % 2) == 0) == bool(pr.get("lead", false))
			var last := int(m.get_meta("pair_ph", -1))
			if last != ph:
				m.set_meta("pair_ph", ph)
				if last >= 0 and not talking and ph % 3 == 0:
					f.base_want = "listen"
					f.play_once("laugh" if ph % 2 else "shrug")
					continue
			f.play(("talkgest" if ph % 4 < 2 else "talk") if talking else "listen")
	_stamp_t += dt
	if _stamp_t > STAMP_EVERY:
		_stamp_t = 0.0
		for id in figures:
			var fg: Figure = figures[id]
			if fg.current == "writesit":
				fg.play_once("stamp")

# ================================================================ things said as you pass

func _update_barks(dt: float) -> void:
	bark_t -= dt
	if bark_t > 0.0:
		return
	bark_label.visible = false
	for k in picks:
		var n: Node3D = k.node
		var d = Vector2(n.global_position.x - pl.x, n.global_position.z - pl.z).length()
		var key: String = k.id if k.kind == "person" else "x_" + str(k.id)
		if d > 3.2 or bark_seen.has(key) or not barks.has(key):
			continue
		bark_seen[key] = true
		var lines: Variant = Data.val(barks[key])
		if not (lines is Array):
			continue
		for l in lines:
			if not (l is Dictionary) or not l.get("text"):
				continue
			var v = str(l.get("v", ""))
			if v != "" and not Game.voice_on(v, l):
				continue
			if v != "":
				# a voice with something to say about this person or thing waits in the ring over you (V, or the button)
				ring_push(v, Game.me_fill(str(Data.val(l.text))), file + "|" + str(Data.val(l.text)))
				return
			bark_label.text = Game.me_fill(str(Data.val(l.text)))
			bark_label.position = n.global_position + Vector3(0, float(k.hy) + 1.3, 0)
			bark_label.modulate = Color(0.85, 0.85, 0.8) if v == "" else Color(0.95, 0.82, 0.55)
			bark_label.visible = true
			bark_t = 4.0
			return

# ================================================================ the voice ring
# When one of the voices in your head has something to say, a ring in its colour hangs over you until
# you ask (V, a click on the ring, or the voice button on a touch screen). The browser's wRing.

signal ring_changed
var vq: Array = []            # [{v, text}]
var vseen: Dictionary = {}

func ring_push(v: String, text: String, key := "") -> void:
	if not Data.T.VOICES.has(v) or text == "":
		return
	if key != "":
		if vseen.has(key):
			return
		vseen[key] = true
	vq.append({ "v": v, "text": text })
	while vq.size() > 6:
		vq.pop_front()
	ring_changed.emit()

## Take the next line off the ring (null if none).
func ring_open() -> Variant:
	if vq.is_empty():
		return null
	var it = vq.pop_front()
	ring_changed.emit()
	# the voice's own sound plays as its line opens (an offer to talk sounds when the conversation does)
	if not it.has("inner") and not Sound.line_seen("ring|" + str(it.v) + "|" + str(it.text)):
		Sound.voice_now(str(it.v))
	return it

## Where the ring hangs: over the courier's head, in this view's pixels.
func ring_point() -> Vector2:
	return cam.unproject_position(pl + Vector3(0, 2.3, 0))

static func _meta(n: Object, k: String) -> Variant:
	return n.get_meta(k) if n.has_meta(k) else null
