# Dialogue compile report

- 22 script files, 160 conversations, 1270 nodes, 2217 options, 179 checks, 2157 inner-voice lines
- 78 fields still written as JavaScript (@js): actions such as starting a fight or a sale, and a few lines that use list helpers
- 0 errors, 4 warnings

## Warnings

- back_oak.pt back_oak:surgeon ~ hub: reads done.lead_tried, which nothing sets (a typo?)
- chapel.pt chapel:ines ~ hub: reads done.ines_lamp, which nothing sets (a typo?)
- cross.pt cross:netta ~ hub: reads done.inn_cup_over, which nothing sets (a typo?)
- cross.pt cross:netta ~ hub: reads done.inn_cup_righted, which nothing sets (a typo?)

