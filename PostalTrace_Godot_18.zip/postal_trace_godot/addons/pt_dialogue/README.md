# pt_dialogue: The Postal Trace's dialogue for Godot 4.3+

Conversations compiled from `dialogue/*.pt` (see docs/WRITING_DIALOGUE.md) into `res://data/dialogue/`.

```gdscript
var db := PTDialogueDB.new()                         # res://data/dialogue
var host := PTJsLiteHost.new(func(code): return js_lite_eval(code))   # the browser's rules, in the game
# or: var host := PTNativeHost.new(db.rules, save_state)            # the same rules in GDScript
var runner := PTDialogueRunner.new(db, host)
var log := PTDialogueLog.new()
add_child(log)
log.attach(runner)
log.closed.connect(_back_to_the_place)
runner.start("cross", {"id": "vane", "name": "Vane", "role": "Toll-taker, ex-sergeant", "mood": "skeptic"})
```

Without the log, drive it yourself: `start()` and `choose(i)` return a view
`{speaker, mood, entries: [...], choices: [{text, enabled, check: {voice, difficulty, dc, odds, mods}}]}`.

Tests: `godot --headless -s res://tests/smoke.gd`, `res://tests/parity.gd` (native rules vs recorded browser play),
`res://tests/parity_js.gd` (browser rules; start `node tools/js_bridge_server.js index.html` first).
