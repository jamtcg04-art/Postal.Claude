class_name PTCond
extends RefCounted
## Walks the dialogue expression ASTs compiled by tools/compile.js, with JavaScript's rules,
## so a condition gives the same answer here as in the browser build.
##
## AST nodes are arrays: ["v", "done.x"], ["call", "has", [args]], ["&&", a, b], ["?:", c, a, b] … (see tools/ptexpr.js)
## The host answers state reads (get_path), writes (set_path) and named game queries (call_fn).

## JavaScript's `undefined`: a state field that is not there. Kept apart from null, as in the browser.
class Undef extends RefCounted:
	func _to_string() -> String:
		return "undefined"

static var UNDEF := Undef.new()


static func is_undef(v) -> bool:
	return typeof(v) == TYPE_OBJECT and v is Undef


static func truthy(v) -> bool:
	match typeof(v):
		TYPE_NIL: return false
		TYPE_BOOL: return v
		TYPE_INT: return v != 0
		TYPE_FLOAT: return v != 0.0 and not is_nan(v)
		TYPE_STRING, TYPE_STRING_NAME: return String(v) != ""
		TYPE_OBJECT: return v != null and not (v is Undef)
	return true


## JavaScript's ToNumber, for < > + - with numbers.
static func num(v) -> float:
	match typeof(v):
		TYPE_NIL: return 0.0
		TYPE_BOOL: return 1.0 if v else 0.0
		TYPE_INT, TYPE_FLOAT: return float(v)
		TYPE_STRING, TYPE_STRING_NAME:
			var s := String(v).strip_edges()
			if s == "": return 0.0
			return s.to_float() if s.is_valid_float() else NAN
	return NAN


## JavaScript's String(v), for "text " + value.
static func jstr(v) -> String:
	match typeof(v):
		TYPE_NIL: return "null"
		TYPE_BOOL: return "true" if v else "false"
		TYPE_INT: return str(v)
		TYPE_FLOAT:
			if is_nan(v): return "NaN"
			if v == floor(v) and abs(v) < 1e15: return str(int(v))
			return str(v)
		TYPE_STRING, TYPE_STRING_NAME: return String(v)
		TYPE_ARRAY: return ",".join((v as Array).map(func(x): return "" if x == null or is_undef(x) else jstr(x)))
		TYPE_OBJECT: return "undefined" if is_undef(v) else str(v)
	return str(v)


## === between two values (numbers compare as numbers, whatever Godot stored them as).
static func same(a, b) -> bool:
	var ta := typeof(a)
	var tb := typeof(b)
	var na := ta == TYPE_INT or ta == TYPE_FLOAT
	var nb := tb == TYPE_INT or tb == TYPE_FLOAT
	if na and nb: return float(a) == float(b)
	if is_undef(a) or is_undef(b): return is_undef(a) and is_undef(b)
	var sa := ta == TYPE_STRING or ta == TYPE_STRING_NAME
	var sb := tb == TYPE_STRING or tb == TYPE_STRING_NAME
	if sa and sb: return String(a) == String(b)
	if ta != tb: return false
	if ta == TYPE_NIL: return true
	if ta == TYPE_ARRAY or ta == TYPE_DICTIONARY or ta == TYPE_OBJECT: return is_same(a, b)
	return a == b


static func _is_null_lit(n) -> bool:
	return n is Array and n.size() == 1 and n[0] == "null"


static func _rel(op: String, a, b) -> bool:
	var sa := typeof(a) == TYPE_STRING or typeof(a) == TYPE_STRING_NAME
	var sb := typeof(b) == TYPE_STRING or typeof(b) == TYPE_STRING_NAME
	if sa and sb:
		var x := String(a)
		var y := String(b)
		match op:
			"<": return x < y
			"<=": return x <= y
			">": return x > y
			">=": return x >= y
	var p := num(a)
	var q := num(b)
	if is_nan(p) or is_nan(q): return false
	match op:
		"<": return p < q
		"<=": return p <= q
		">": return p > q
		">=": return p >= q
	return false


static func eval(n, host):
	if n == null:
		return true
	match String(n[0]):
		"n", "s", "b":
			return n[1]
		"null":
			return null
		"v":
			return host.get_path(String(n[1]))
		"call":
			var args := []
			for x in n[2]:
				args.append(eval(x, host))
			return host.call_fn(String(n[1]), args)
		"arr":
			var out := []
			for i in range(1, n.size()):
				out.append(eval(n[i], host))
			return out
		"cat":
			var l = eval(n[1], host)
			var r = eval(n[2], host)
			var out := []
			if l is Array: out.append_array(l)
			else: out.append(l)
			if r is Array: out.append_array(r)
			else: out.append(r)
			return out
		"do":
			for s in n[1]:
				if s[3] == null or truthy(eval(s[3], host)):
					host.set_path(String(s[1]), eval(s[2], host))
			return eval(n[2], host)
		"!":
			return not truthy(eval(n[1], host))
		"neg":
			return -num(eval(n[1], host))
		"&&":
			var l = eval(n[1], host)
			return eval(n[2], host) if truthy(l) else l
		"||":
			var l = eval(n[1], host)
			return l if truthy(l) else eval(n[2], host)
		"?:":
			return eval(n[2], host) if truthy(eval(n[1], host)) else eval(n[3], host)
		"==", "!=":
			var a = eval(n[1], host)
			var b = eval(n[2], host)
			var eq: bool
			if _is_null_lit(n[1]) or _is_null_lit(n[2]):   # compiled as JS loose == null: null and undefined match
				eq = (a == null or is_undef(a)) and (b == null or is_undef(b))
			else:
				eq = same(a, b)
			return eq if n[0] == "==" else not eq
		"<", "<=", ">", ">=":
			return _rel(String(n[0]), eval(n[1], host), eval(n[2], host))
		"+":
			var a = eval(n[1], host)
			var b = eval(n[2], host)
			if typeof(a) == TYPE_STRING or typeof(b) == TYPE_STRING or a is Array or b is Array:
				return jstr(a) + jstr(b)
			return _numout(num(a) + num(b))
		"-": return _numout(num(eval(n[1], host)) - num(eval(n[2], host)))
		"*": return _numout(num(eval(n[1], host)) * num(eval(n[2], host)))
		"/": return num(eval(n[1], host)) / num(eval(n[2], host))
		"%": return fmod(num(eval(n[1], host)), num(eval(n[2], host)))
	push_error("PTCond: unknown expression node %s" % [n[0]])
	return false


static func _numout(f: float):
	return int(f) if f == floor(f) and abs(f) < 1e15 else f


## Read a dotted path from a Dictionary the way the compiled browser code does (S.a && S.a.b).
static func read_path(root: Dictionary, path: String):
	var parts := path.split(".")
	var cur = root
	for i in parts.size():
		# S.a.b.c is read as (S.a && S.a.b && S.a.b.c): a falsy step is the answer
		if i >= 1 and not truthy(cur):
			return cur
		if cur is Dictionary:
			cur = (cur as Dictionary).get(parts[i], UNDEF)
		elif cur is Array and parts[i].is_valid_int() and parts[i].to_int() < (cur as Array).size():
			cur = cur[parts[i].to_int()]
		else:
			return UNDEF
	return cur


static func write_path(root: Dictionary, path: String, value) -> void:
	var parts := path.split(".")
	var cur: Dictionary = root
	for i in parts.size() - 1:
		if not (cur.get(parts[i]) is Dictionary):
			cur[parts[i]] = {}
		cur = cur[parts[i]]
	cur[parts[parts.size() - 1]] = value


## The same expression as JavaScript source (what tools/ptexpr.js js() writes), for engines that run JS
## (the port's JsLite still reads conversations through the browser logic's GRAPH table).
static func to_js(n) -> String:
	var id_re := RegEx.create_from_string("^[A-Za-z_$][\\w$]*$")
	match String(n[0]):
		"n": return PTCond.jstr(n[1])
		"s": return JSON.stringify(n[1])
		"b": return "true" if n[1] else "false"
		"null": return "null"
		"v":
			var parts := String(n[1]).split(".")
			var out := "S"
			var acc := []
			for p in parts:
				out += ("." + p) if id_re.search(p) else "[" + JSON.stringify(p) + "]"
				acc.append(out)
			if parts.size() == 1 or (parts.size() == 2 and parts[0] == "done"): return out
			return "(" + " && ".join(acc) + ")"
		"call": return String(n[1]) + "(" + ", ".join((n[2] as Array).map(func(x): return to_js(x))) + ")"
		"arr": return "[" + ", ".join(n.slice(1).map(func(x): return to_js(x))) + "]"
		"cat": return "(" + to_js(n[1]) + ").concat(" + to_js(n[2]) + ")"
		"do":
			var parts2 := []
			for s in n[1]:
				var tgt := "S"
				for p in String(s[1]).split("."): tgt += ("." + p) if id_re.search(p) else "[" + JSON.stringify(p) + "]"
				parts2.append(("(" + to_js(s[3]) + ") && " if s[3] != null else "") + "(" + tgt + " = " + to_js(s[2]) + ")")
			return "(" + ", ".join(parts2) + ", " + to_js(n[2]) + ")"
		"!": return "!(" + to_js(n[1]) + ")"
		"neg": return "-(" + to_js(n[1]) + ")"
		"?:": return "(" + to_js(n[1]) + " ? " + to_js(n[2]) + " : " + to_js(n[3]) + ")"
		"==", "!=":
			var loose: bool = _is_null_lit(n[1]) or _is_null_lit(n[2])
			var op := ("==" if loose else "===") if n[0] == "==" else ("!=" if loose else "!==")
			return "(" + to_js(n[1]) + " " + op + " " + to_js(n[2]) + ")"
	return "(" + to_js(n[1]) + " " + String(n[0]) + " " + to_js(n[2]) + ")"
