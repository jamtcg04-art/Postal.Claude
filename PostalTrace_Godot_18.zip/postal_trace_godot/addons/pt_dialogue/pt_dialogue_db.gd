class_name PTDialogueDB
extends RefCounted
## Loads the compiled conversations (data/dialogue/*.json, written by tools/compile.js).
## Files load the first time one of their conversations is asked for.

var dir := "res://data/dialogue"
var index := {}          # conversation id -> file name
var _files := {}         # file name -> conversations
var rules := {}          # voices, skills, thoughts, items, banter … (rules.json)


func _init(p_dir := "res://data/dialogue") -> void:
	dir = p_dir
	var idx = _read(dir + "/index.json")
	if idx is Dictionary:
		index = idx.get("conversations", {})
	else:
		push_error("PTDialogueDB: no index.json in " + dir + " (run tools/compile.js)")
	var r = _read(dir + "/rules.json")
	if r is Dictionary:
		rules = r


func _read(path: String):
	if not FileAccess.file_exists(path):
		return null
	return JSON.parse_string(FileAccess.get_file_as_string(path))


func has(conv_id: String) -> bool:
	return index.has(conv_id)


func conversation(conv_id: String) -> Dictionary:
	var f: String = index.get(conv_id, "")
	if f == "":
		return {}
	if not _files.has(f):
		var d = _read(dir + "/" + f)
		_files[f] = d.get("conversations", {}) if d is Dictionary else {}
	return _files[f].get(conv_id, {})


func ids() -> Array:
	var a := index.keys()
	a.sort()
	return a
