class_name PTDialogueRunner
extends RefCounted
## Runs one conversation from the compiled dialogue data, the way the browser build's graphShow/graphGo do:
## a hub of topics, inner voices that cut in when their skill is high (or low) enough, voices that open
## their own branches, white checks you can retry when something changes, red checks you get once,
## lines you can hear again, and "<" returns to where a voice branch was opened.
##
## Usage:
##   var r := PTDialogueRunner.new(db, host)
##   var view := r.start("cross", {"id": "vane", "name": "Vane", "role": "Toll-taker", "mood": "skeptic"})
##   while not view.ended: view = r.choose(view.choices[i].index)
## Each view is a plain Dictionary the UI draws (see PTDialogueLog): speaker, mood, entries, choices.
## All memory is kept in the game state's done table under the browser's own keys (gseen_, gmet_, gu_, ck_ …),
## so saves move between the builds.

signal view_changed(view: Dictionary)
signal ended(reason: String)

const GO_ON := "“Go on.”"

var db: PTDialogueDB
var host: PTDialogueHost
var scene_id := ""
var talker := {}
var conv_id := ""
var G: Dictionary = {}
var key := ""          # the browser's graphKey: scene + "_" + talker id
var node_id := ""
var view := {}
var _asks: Array = []
var _opts: Array = []
## the conversation so far, oldest first (each screen's entries); the UI shows it above the new lines
var history: Array = []
var _shows := 0


func _init(p_db: PTDialogueDB, p_host: PTDialogueHost) -> void:
	db = p_db
	host = p_host


## Open a conversation. `who` is the talker: {id, name, role, mood, hue} (an object to look at has "obj": true
## and its id is "x_" + object id). Returns the first view.
func start(p_scene: String, who: Dictionary, note := "") -> Dictionary:
	if not open(p_scene, who):
		return _end("missing")
	return show(String(G.hub), {"note": note} if note != "" else {})


## Point the runner at a conversation without showing anything (the game then calls show() or go()).
## Returns false if there is no such conversation.
func open(p_scene: String, who: Dictionary) -> bool:
	var cid := p_scene + ":" + String(who.id)
	if cid != conv_id:
		history = []
	scene_id = p_scene
	talker = who
	conv_id = cid
	G = db.conversation(conv_id)
	key = scene_id + "_" + String(who.id)
	if G.is_empty():
		push_error("PTDialogueRunner: no conversation " + conv_id)
		return false
	return true


## The value of a field that may be computed ({x: AST}) or kept as JavaScript ({js: …}).
func val(v):
	if v is Dictionary:
		if v.has("x"):
			return PTCond.eval(v.x, host)
		if v.has("js"):
			return host.run_js(String(v.js), v.get("closure", {}), false)
	return v


func _cond(v) -> bool:
	return v == null or PTCond.truthy(val(v))


func _nodes() -> Dictionary:
	return G.nodes


# ---------- which options and voices are open ----------
func opt_visible(o: Dictionary) -> bool:
	if o.has("show") and not _cond(o.show): return false
	if o.get("off", false) and not PTCond.truthy(host.done("cock_" + scene_id)): return false
	if o.has("think") and not host.thought_done(String(o.think)): return false
	if o.has("past") and host.past_n() < int(o.past): return false
	return true


func ck_key(nid: String, j: int) -> String:
	return "ck_" + key + "_" + nid + "_" + str(j)


func ck_voice(o: Dictionary) -> String:
	var c: Dictionary = o.check
	if c.has("v") and host.voice_exists(String(c.v)):
		return String(c.v)
	return host.voice_for(String(c.sk), String(o.q) if o.q is String else "")


## The browser's optState: used (greyed), replay (hear it again), retry (a failed white check is open again), hint.
func opt_state(nid: String, o: Dictionary, j: int) -> Dictionary:
	if o.has("check"):
		var rec = host.done(ck_key(nid, j))
		if not (rec is Dictionary):
			if PTCond.truthy(host.done("gu_" + key + "_" + nid + "_" + str(j))):
				return {"used": true, "hint": "Already tried."}
			return {"used": false}
		if rec.get("r") == "p":
			return {"used": true, "hint": "Passed."} if o.has("run") else {"used": true, "replay": true, "hint": "Passed · hear it again"}
		var sk := String(o.check.sk)
		if o.check.get("red", false):
			var thr := "" if PTCond.truthy(rec.get("thr", false)) else host.thought_retry(sk)
			if thr != "":
				return {"used": false, "retry": true, "hint": "“" + host.thought_name(thr) + "” gives you one more try at this."}
			return {"used": true, "hint": "Failed. That chance is gone."}
		if host.hardcore():
			return {"used": true, "hint": "Failed. Hardcore: no second tries."}
		if host.check_total(sk, ck_voice(o)) > int(rec.get("tot", 0)) or host.learned_count() > int(rec.get("ln", 0)) or host.internal_count() > int(rec.get("th", 0)):
			return {"used": false, "retry": true, "hint": "You failed this before. Something has changed. Try again."}
		return {"used": true, "hint": "Failed. You can try again once your " + host.skill_name(sk) + " improves or you learn something new."}
	if o.get("once", false) and PTCond.truthy(host.done("gu_" + key + "_" + nid + "_" + str(j))):
		return {"used": true, "hint": "Already said."} if o.has("run") else {"used": true, "replay": true, "hint": "Already said · hear it again"}
	return {"used": false}


func voice_on(v: String, e) -> bool:
	if not host.voice_exists(v): return false
	if v == "hat" and not PTCond.truthy(host.call_fn("has", ["hat"])): return false
	if e is Dictionary:
		if e.has("show") and not _cond(e.show): return false
		var value := host.voice_val(v)
		if e.has("min") and value < int(e.min): return false
		if e.has("max") and value > int(e.max): return false
	return true


func vid(e: Dictionary) -> String:
	if e.has("v"): return String(e.v)
	return host.default_voice(String(e.sk))


func _arg_list(a) -> Array:
	if a == null: return []
	if a is Dictionary: return [a]
	if a is Array and a.size() and a[0] is Array: return [{"lines": a}]
	return a


func _argue_ok(a: Dictionary) -> bool:
	if not a.has("lines") or a.lines.is_empty(): return false
	if a.has("show") and not _cond(a.show): return false
	for l in a.lines:
		if not voice_on(String(l[0]), null): return false
	if a.has("min"):
		for v in a.min:
			if host.voice_val(String(v)) < int(a.min[v]): return false
	return true


## odds of a check in percent, counted over the 36 throws (double six always passes, double one always fails)
static func odds(m: Dictionary) -> int:
	var n := 0
	for a in range(1, 7):
		for b in range(1, 7):
			if (a == 6 and b == 6) or (not (a == 1 and b == 1) and a + b + int(m.tot) >= int(m.dc)):
				n += 1
	return int(round(n / 36.0 * 100.0))


static func diff_name(dc: int) -> String:
	for p in [[6, "Trivial"], [7, "Easy"], [8, "Medium"], [9, "Challenging"], [10, "Formidable"], [11, "Legendary"], [12, "Heroic"]]:
		if dc <= p[0]: return p[1]
	return "Impossible"


# ---------- a screen ----------
## The browser's graphShow: build the view for node `nid`. ctx: {you, roll, chips, thought, note}
func show(nid: String, ctx := {}) -> Dictionary:
	_shows += 1
	node_id = nid
	var node: Dictionary = _nodes()[nid]
	var is_obj: bool = talker.get("obj", false)
	var is_hub := nid == String(G.hub)
	var first_meet := is_hub and not PTCond.truthy(host.done("gmet_" + key))
	var say = val(node.get("say", []))
	if not (say is Array): say = [] if say == null or PTCond.is_undef(say) else [say]
	var mood = val(node.get("mood")) if node.has("mood") else null
	if not PTCond.truthy(mood): mood = talker.get("mood", "calm")
	if not is_obj:
		host.set_done("pmood_" + scene_id + "_" + String(talker.id), mood)
	var entries: Array = []
	if ctx.has("you"): entries.append({"t": "you", "text": ctx.you})
	if ctx.has("roll"): entries.append(ctx.roll)
	var by := String(node.get("by", "")) if node.get("by") is String else ""
	if by != "" and host.voice_exists(by):
		for p in say: entries.append({"t": "voice", "v": by, "head": host.voice_head(by), "text": host.voice_text(by, PTCond.jstr(p)), "big": true})
	elif is_obj:
		entries.append({"t": "look", "lines": say.map(func(p): return PTCond.jstr(p))})
	elif say.size():
		entries.append({"t": "say", "who": talker.get("name", ""), "lines": say.map(func(p): return PTCond.jstr(p))})
	if not is_obj and is_hub and not ctx.has("you") and not first_meet:
		var mn := host.manner(scene_id, talker)
		if mn != "": entries.append({"t": "beat", "text": mn})
	if not is_obj and first_meet:
		_banter(entries, "meet:" + String(talker.id))
		entries.append_array(host.companion_meet(scene_id, talker))
	var ban = node.get("ban")
	if ban is String and not (first_meet and ban == "meet:" + String(talker.id)):
		_banter(entries, ban)
	if by == "":
		entries.append_array(host.companion_chime(scene_id, talker, key, nid, ctx, first_meet))
	for a in _arg_list(node.get("argue")):
		if _argue_ok(a):
			entries.append({"t": "argue", "lines": a.lines.map(func(l): return {"v": String(l[0]), "head": host.voice_head(String(l[0])), "text": host.voice_text(String(l[0]), PTCond.jstr(val(l[1])))})})
	# inner voices: at most three speak; one may open a branch of its own
	var shown := 0
	_asks = []
	var vs: Array = node.get("voices", [])
	for vi in vs.size():
		if shown >= 3: break
		var e: Dictionary = vs[vi]
		var v := vid(e)
		if not voice_on(v, e): continue
		var vk := key + "_" + nid + "_" + str(vi)
		var rp: bool = e.has("go") and PTCond.truthy(host.done("vgo_" + vk)) and _nodes().has(String(e.go))
		if e.has("go") and not rp and (PTCond.truthy(host.done("vno_" + vk)) or not _nodes().has(String(e.go))): continue
		shown += 1
		var ve := {"t": "voice", "v": v, "head": host.voice_head(v), "text": host.voice_text(v, PTCond.jstr(val(e.text))), "ask": e.has("go"), "value": host.voice_val(v)}
		# Disco-style passive tag: a line that needs value ≥ min passed a check of min + 6; one that needs value ≤ max failed one of max + 7
		if e.has("min") and int(e.min) > -9: ve.passive = diff_name(int(e.min) + 6) + ": Success"
		elif e.has("max"): ve.passive = diff_name(int(e.max) + 7) + ": Failure"
		entries.append(ve)
		if e.has("go"): _asks.append({"e": e, "v": v, "vk": vk, "rp": rp})
	if ctx.get("thought"):
		entries.append({"t": "thought", "id": ctx.thought, "name": host.thought_name(String(ctx.thought))})
	var chips: Array = ctx.get("chips", [])
	if chips.size(): entries.append({"t": "chips", "list": chips})
	if ctx.get("note", "") != "": entries.append({"t": "note", "text": ctx.note})
	for q in host.drain_voices():
		if q.has("t"): entries.append(q)   # the game drew it already (an HTML fragment, a thought card)
		else: entries.append({"t": "voice", "v": q.v, "head": host.voice_head(q.v), "text": host.voice_text(q.v, q.text), "beat": q.get("beat", ""), "queued": true})
	var temps := host.temp_line()
	if temps.size(): entries.append({"t": "temp", "list": temps})

	var choices: Array = []
	for ai in _asks.size():
		var a: Dictionary = _asks[ai]
		choices.append({"kind": "ask", "index": choices.size(), "ai": ai, "v": a.v, "voice": host.voice_name(a.v), "text": String(a.e.get("q", GO_ON)), "enabled": true, "replay": a.rp, "hint": "Already asked · hear it again" if a.rp else ""})
		if a.e.has("no") and not a.rp:
			choices.append({"kind": "no", "index": choices.size(), "ai": ai, "v": a.v, "voice": host.voice_name(a.v), "text": String(a.e.no), "enabled": true})
	_opts = node.get("opts", [])
	for j in _opts.size():
		var o: Dictionary = _opts[j]
		if not opt_visible(o): continue
		var st := opt_state(nid, o, j)
		var c := {"kind": "opt", "index": choices.size(), "j": j, "text": PTCond.jstr(val(o.get("q", ""))),
			"enabled": not (st.get("used", false) and not st.get("replay", false)), "replay": st.get("replay", false),
			"retry": st.get("retry", false), "hint": st.get("hint", ""), "tags": []}
		if o.has("check"):
			var m := host.modifiers(_check_arg(o))
			c.check = {"kind": "red" if o.check.get("red", false) else "white", "skill": String(o.check.sk), "voice": String(m.get("vn", "")),
				"dc": int(m.dc), "tot": int(m.tot), "odds": host.check_odds(m) if host.has_method("check_odds") else odds(m), "difficulty": diff_name(int(m.dc)), "mods": m.get("list", []), "retry": st.get("retry", false)}
		if o.get("off", false): c.tags.append("Off the record")
		if o.has("think"): c.tags.append("Thought: " + host.thought_name(String(o.think)))
		if o.has("past"): c.tags.append("Redoubt Nine")
		choices.append(c)
	view = {"ended": false, "conv": conv_id, "node": nid, "speaker": talker.get("name", ""), "role": talker.get("role", ""),
		"mood": mood, "hue": talker.get("hue", ""), "obj": is_obj, "by": by, "entries": entries, "choices": choices,
		"prompt": "What do you do?" if is_obj else "What do you say?"}
	if is_hub:
		host.set_done("gmet_" + key, true)
	history.append(entries)
	view_changed.emit(view)
	return view


func _banter(entries: Array, k: String) -> void:
	for block in host.banter(scene_id, k):   # one entry per exchange: [{who, text}, …]
		if block.size(): entries.append({"t": "banter", "lines": block})


func _check_arg(o: Dictionary) -> Dictionary:
	var c: Dictionary = o.check
	var d := {"skill": String(c.sk), "dc": int(c.dc), "v": ck_voice(o), "red": c.get("red", false)}
	if c.has("with"): d.with = c.with
	return d


# ---------- moving on ----------
## The browser's graphGo: arrive at a node (its effects happen the first time only), then show it.
func go(nid: String, prev := {}) -> Dictionary:
	var node: Dictionary = _nodes()[nid]
	var chips: Array = prev.get("chips", []).duplicate()
	var seen := "gseen_" + key + "_" + nid
	var first := not PTCond.truthy(host.done(seen))
	if first:
		chips.append_array(host.apply_node(node, scene_id, talker, self))
		if node.has("tally"): chips.append_array(host.tally_add(String(node.tally)))
		if node.has("side"): chips.append_array(host.side_add(String(node.side)))
	host.set_done(seen, true)
	var e := host.check_end()
	if e != "": return _end(e)
	var ctx := {"chips": chips}
	if prev.has("q"): ctx.you = prev.q
	if prev.has("roll"):
		ctx.roll = prev.roll
		ctx.ok = prev.roll.ok
		ctx.ck = prev.roll.skill
	if prev.has("tally"): ctx.tally = prev.tally
	if first and node.has("thought"): ctx.thought = node.thought
	return show(nid, ctx)


## Pick a choice by its index in view.choices.
func choose(index: int) -> Dictionary:
	var c: Dictionary = view.choices[index]
	if not c.enabled: return view
	var node: Dictionary = _nodes()[node_id]
	match String(c.kind):
		"ask":
			var a: Dictionary = _asks[c.ai]
			host.set_done("vgo_" + a.vk, true)
			var tgt := String(a.e.go)
			if _nodes()[tgt].has("by") and not node.has("by"):
				host.set_done("gret_" + key, node_id)
			return go(tgt, {"q": String(a.e.get("q", GO_ON)), "chips": []})
		"no":
			host.set_done("vno_" + _asks[c.ai].vk, true)
			return show(node_id, {})
	var j: int = c.j
	var o: Dictionary = _opts[j]
	if c.replay:   # hear it again: nothing is rolled or gained a second time
		var rn = o.check.pass if o.has("check") else o.get("to")
		if rn == "<": rn = _back()
		if rn == null or not _nodes().has(String(rn)): return view
		if _nodes()[rn].has("by") and not node.has("by"):
			host.set_done("gret_" + key, node_id)
		return go(String(rn), {"q": c.text, "chips": []})
	if not talker.get("obj", false):
		host.set_path("talked." + conv_id + ":g", true)
	if o.get("once", false) and not o.has("check"):
		host.set_done("gu_" + key + "_" + node_id + "_" + str(j), true)
	var prev := {"q": c.text, "chips": []}
	if o.has("tally"): prev.tally = o.tally
	var nxt = o.get("to")
	var ox := "gox_" + key + "_" + node_id + "_" + str(j)
	if not PTCond.truthy(host.done(ox)):
		host.set_done(ox, true)
		prev.chips = host.apply_node(o, scene_id, talker, self)
		if o.has("tally"): prev.chips.append_array(host.tally_add(String(o.tally)))
		if o.has("side"): prev.chips.append_array(host.side_add(String(o.side)))
	if o.has("run"):   # the browser drops this option's own chips and lets the action decide what comes next
		var shows_before := _shows
		var nx := host.run_action(String(o.run.js), o.run.get("closure", {}), self)
		if nx.is_empty() and _shows != shows_before and not view.get("ended", false):
			return view   # the action itself went back into the conversation
		if nx.has("go") and _nodes().has(String(nx.go)): return go(String(nx.go), {"chips": nx.get("chips", [])})
		if nx.has("show") and _nodes().has(String(nx.show)): return show(String(nx.show), {"chips": nx.get("chips", []), "note": nx.get("note", "")})
		if nx.has("leave"): return _end("leave")
		if nx.has("ending"): return _end(String(nx.ending))
		return _end("action")
	if o.has("check"):
		var ch: Dictionary = o.check
		var m := host.modifiers(_check_arg(o))
		var r := host.roll(m)
		var ck := ck_key(node_id, j)
		var before = host.done(ck)
		var tot := host.check_total(String(ch.sk), ck_voice(o))
		var red: bool = ch.get("red", false)
		prev.roll = {"t": "roll", "skill": String(ch.sk), "voice": String(m.get("vn", "")), "a": r.a, "b": r.b, "tot": int(m.tot), "total": r.total, "dc": int(m.dc), "ok": r.ok, "crit": r.get("crit", ""), "red": red, "r": r, "m": m}
		var temps := host.temp_labels()
		if temps.size():
			prev.chips.append(host.chip("Spent: " + ", ".join(temps), ""))
			host.clear_temp()
		var failed_before: bool = before is Dictionary and before.get("r") == "f"
		if r.ok:
			host.set_done(ck, {"r": "p"})
			if failed_before:
				var fnode = _nodes().get(String(ch.fail))
				if fnode is Dictionary and fnode.has("flag"): host.set_done(String(fnode.flag), false)
				prev.chips.append(host.chip("Retry passed", "up"))
			if host.perk("xp"): prev.chips.append_array(host.apply_node({"xp": 1}, scene_id, talker, self))
		else:
			host.set_done(ck, {"r": "f", "tot": tot, "ln": host.learned_count(), "th": host.internal_count(), "thr": failed_before and red})
		if failed_before and red:
			var tu := host.thought_retry(String(ch.sk))
			if tu != "":
				host.spend_thought_retry(tu, String(ch.sk))
				prev.chips.append(host.chip("“" + host.thought_name(tu) + "” spent", "info"))
		nxt = ch.pass if r.ok else ch.fail
		if not r.ok:
			host.fail_voice(String(m.get("v", "")), _nodes().get(String(nxt), {}), key + ":" + String(nxt), self)
	if nxt == "<": nxt = _back()
	if nxt == null or String(nxt) == "": return _end("leave")
	if _nodes()[nxt].has("by") and not node.has("by"):
		host.set_done("gret_" + key, node_id)
	return go(String(nxt), prev)


## Where "<" leads: the node a voice branch was opened from, else the hub.
func _back() -> String:
	var g = host.done("gret_" + key)
	return String(g) if PTCond.truthy(g) else String(G.hub)


## Leave the conversation (the browser's "Back to the scene").
func leave() -> Dictionary:
	return _end("leave")


func _end(reason: String) -> Dictionary:
	view = {"ended": true, "reason": reason, "conv": conv_id}
	ended.emit(reason)
	return view


## How many hub topics are still unasked (the browser's graphLeft), for "2 things to ask" on a talk button.
func topics_left(p_scene: String, who: Dictionary) -> int:
	var g := db.conversation(p_scene + ":" + String(who.id))
	if g.is_empty(): return 0
	var save_scene := scene_id; var save_key := key; var save_g := G
	scene_id = p_scene; key = p_scene + "_" + String(who.id); G = g
	var n := 0
	var opts: Array = g.nodes[g.hub].get("opts", [])
	for j in opts.size():
		var o: Dictionary = opts[j]
		if o.get("once", false) and opt_visible(o) and not opt_state(String(g.hub), o, j).get("used", false): n += 1
	scene_id = save_scene; key = save_key; G = save_g
	return n
