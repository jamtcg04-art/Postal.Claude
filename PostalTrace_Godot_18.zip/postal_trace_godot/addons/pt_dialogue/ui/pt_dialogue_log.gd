class_name PTDialogueLog
extends PanelContainer
## A Disco Elysium-style dialogue column: one scrolling feed where the person you talk to, your own words,
## the inner voices and the dice all stack up in order; older lines dim, new lines come one beat at a time
## (Continue, Space or Enter), and numbered choices sit at the bottom (keys 1–9).
##
##   var log := PTDialogueLog.new()
##   add_child(log)
##   log.attach(runner)            # then runner.start(...) – the log follows the runner's views
##   log.closed.connect(...)       # the conversation ended (leave, action, ending)

signal closed(reason: String)
signal choice_made(choice: Dictionary)

## colours by attribute, as the browser build's sk-* classes; other voices by name
const SKILL_COL := {"arms": Color("#d9705f"), "nerve": Color("#a98be0"), "wits": Color("#6fb7dd"), "grit": Color("#d9b85c")}
const VOICE_COL := {"duty": Color("#e0c068"), "hat": Color("#9fc28a"), "trace": Color("#7fbf9f")}
const NPC_COL := Color("#efe6d2")
const YOU_COL := Color("#c9c0ad")
const DIM := Color(1, 1, 1, 0.5)

@export var column_width := 520.0
@export var beat_by_beat := true

var runner: PTDialogueRunner
var _feed: VBoxContainer
var _scroll: ScrollContainer
var _choices: VBoxContainer
var _name: Label
var _role: Label
var _portrait: ColorRect
var _mood: Label
var _cont: Button
var _queue: Array = []
var _view := {}
var _tip: PanelContainer
var _tip_text: RichTextLabel


func _ready() -> void:
	custom_minimum_size.x = column_width
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.07, 0.065, 0.06, 0.96)
	bg.content_margin_left = 22; bg.content_margin_right = 22; bg.content_margin_top = 18; bg.content_margin_bottom = 18
	add_theme_stylebox_override("panel", bg)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 10)
	add_child(col)
	# who you are talking to
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	col.add_child(head)
	_portrait = ColorRect.new()
	_portrait.custom_minimum_size = Vector2(64, 64)
	_portrait.color = Color("#3a332b")
	head.add_child(_portrait)
	_mood = Label.new()
	_mood.set_anchors_preset(Control.PRESET_FULL_RECT)
	_mood.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_mood.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_mood.add_theme_font_size_override("font_size", 11)
	_mood.add_theme_color_override("font_color", Color(1, 1, 1, 0.6))
	_portrait.add_child(_mood)
	var names := VBoxContainer.new()
	head.add_child(names)
	_name = Label.new()
	_name.add_theme_font_size_override("font_size", 20)
	_name.add_theme_color_override("font_color", NPC_COL)
	names.add_child(_name)
	_role = Label.new()
	_role.add_theme_color_override("font_color", Color(1, 1, 1, 0.45))
	names.add_child(_role)
	# the feed
	_scroll = ScrollContainer.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	col.add_child(_scroll)
	_feed = VBoxContainer.new()
	_feed.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_feed.add_theme_constant_override("separation", 12)
	_scroll.add_child(_feed)
	_cont = Button.new()
	_cont.text = "Continue  ▸   [Space]"
	_cont.flat = true
	_cont.alignment = HORIZONTAL_ALIGNMENT_LEFT
	_cont.add_theme_color_override("font_color", Color("#e0c068"))
	_cont.pressed.connect(_next_beat)
	_cont.hide()
	col.add_child(_cont)
	_choices = VBoxContainer.new()
	_choices.add_theme_constant_override("separation", 4)
	col.add_child(_choices)
	# check tooltip
	_tip = PanelContainer.new()
	var tb := StyleBoxFlat.new(); tb.bg_color = Color(0.12, 0.11, 0.1, 0.98); tb.set_content_margin_all(10); tb.border_color = Color("#5a5040"); tb.set_border_width_all(1)
	_tip.add_theme_stylebox_override("panel", tb)
	_tip.top_level = true
	_tip.custom_minimum_size.x = 320
	_tip_text = RichTextLabel.new(); _tip_text.bbcode_enabled = true; _tip_text.fit_content = true; _tip_text.custom_minimum_size.x = 300
	_tip.add_child(_tip_text)
	_tip.hide()
	add_child(_tip)


func attach(r: PTDialogueRunner) -> void:
	if runner and runner.view_changed.is_connected(_on_view):
		runner.view_changed.disconnect(_on_view)
		runner.ended.disconnect(_on_ended)
	runner = r
	runner.view_changed.connect(_on_view)
	runner.ended.connect(_on_ended)


func clear() -> void:
	for c in _feed.get_children(): c.queue_free()
	for c in _choices.get_children(): c.queue_free()
	_queue = []


func _on_ended(reason: String) -> void:
	for c in _choices.get_children(): c.queue_free()
	_cont.hide()
	closed.emit(reason)


func _on_view(v: Dictionary) -> void:
	_view = v
	_name.text = String(v.speaker).to_upper()
	_role.text = String(v.role)
	_mood.text = String(v.mood)
	_portrait.color = Color("#2f3a44") if v.obj else Color("#3a332b")
	for c in _feed.get_children(): c.modulate = DIM
	for c in _choices.get_children(): c.queue_free()
	_queue = []
	for e in v.entries:
		var w := _entry(e)
		if w: _queue.append(w)
	if beat_by_beat:
		_next_beat()
	else:
		while _queue.size(): _feed.add_child(_queue.pop_front())
		_show_choices()


func _next_beat() -> void:
	if _queue.size():
		var w: Control = _queue.pop_front()
		w.modulate.a = 0.0
		_feed.add_child(w)
		create_tween().tween_property(w, "modulate:a", 1.0, 0.25)
	_scroll_down()
	if _queue.size():
		_cont.show(); _cont.grab_focus()
	else:
		_cont.hide(); _show_choices()


func _scroll_down() -> void:
	await get_tree().process_frame
	_scroll.scroll_vertical = int(_scroll.get_v_scroll_bar().max_value)


func _unhandled_key_input(ev: InputEvent) -> void:
	if not visible or not (ev is InputEventKey) or not ev.pressed: return
	if (ev.keycode == KEY_SPACE or ev.keycode == KEY_ENTER) and _cont.visible:
		_next_beat(); get_viewport().set_input_as_handled(); return
	var n: int = ev.keycode - KEY_1
	if n >= 0 and n < 9 and not _cont.visible:
		var bs := _choices.get_children().filter(func(b): return b is Button)
		if n < bs.size() and not bs[n].disabled: bs[n].emit_signal("pressed"); get_viewport().set_input_as_handled()


static func voice_color(v: String, sk: String) -> Color:
	if SKILL_COL.has(sk): return SKILL_COL[sk]
	return VOICE_COL.get(v, Color("#b8b0a0"))


func _voice_sk(v: String) -> String:
	if runner and runner.host is PTNativeHost:
		var V = (runner.host as PTNativeHost).R.VOICES.get(v, {})
		return String(V.get("sk", ""))
	return ""


func _rt(bb: String) -> RichTextLabel:
	var rt := RichTextLabel.new()
	rt.bbcode_enabled = true
	rt.fit_content = true
	rt.scroll_active = false
	rt.selection_enabled = true
	rt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rt.text = bb
	return rt


static func _e(s) -> String:
	return String(s).replace("[", "[lb]")


func _speaker(name: String, col: Color, text: String, tag := "") -> String:
	return "[b][color=#%s]%s[/color][/b]%s — %s" % [col.to_html(false), _e(name.to_upper()), tag, _e(text)]


func _entry(e: Dictionary) -> Control:
	match String(e.t):
		"you":
			return _rt(_speaker("You", YOU_COL, String(e.text)))
		"say":
			var box := VBoxContainer.new()
			var first := true
			for p in e.lines:
				box.add_child(_rt(_speaker(String(e.who), NPC_COL, p) if first else "[color=#%s]%s[/color]" % [NPC_COL.to_html(false), _e(p)]))
				first = false
			return box
		"look":
			return _rt("[i]%s[/i]" % _e("\n\n".join(e.lines)))
		"voice":
			var sk := _voice_sk(String(e.v))
			var col := voice_color(String(e.v), sk)
			var tag := ""
			if e.has("passive"):
				tag = " [color=#7a7266][lb]%s[rb][/color]" % _e(e.passive)
			var s := ("[i][color=#8a8274]%s[/color][/i]\n" % _e(e.beat) if String(e.get("beat", "")) != "" else "") + _speaker(String(e.head), col, String(e.text), tag)
			var rt := _rt(s)
			if e.get("big", false): rt.add_theme_font_size_override("normal_font_size", 17)
			return rt
		"argue":
			var box := VBoxContainer.new()
			for l in e.lines:
				box.add_child(_rt(_speaker(String(l.head), voice_color(String(l.v), _voice_sk(String(l.v))), String(l.text))))
			return box
		"roll":
			var col := "c94f4f" if e.red else "d8d0bf"
			var verdict := "Double six: success" if e.crit == "hi" else ("Double one: setback" if e.crit == "lo" else ("Success" if e.ok else "Setback"))
			var face := func(n: int) -> String: return String.chr(0x2680 + clampi(n, 1, 6) - 1) if n >= 1 else "–"
			return _rt("[color=#%s][b][lb]%s%s · %s %d[rb][/b][/color]  %s %d  %s %d  %+d = %d   [b][color=#%s]%s[/color][/b]" % [col, "Red · " if e.red else "", _e(e.voice), PTDialogueRunner.diff_name(int(e.dc)), int(e.dc), face.call(int(e.a)), int(e.a), face.call(int(e.b)), int(e.b), int(e.tot), int(e.total), "8fc27a" if e.ok else "c96a5a", verdict])
		"beat":
			return _rt("[i][color=#8a8274]%s[/color][/i]" % _e(e.text))
		"banter":
			var box := VBoxContainer.new()
			for l in e.lines:
				box.add_child(_rt(("[i][color=#8a8274]%s[/color][/i]" % _e(l.text)) if String(l.who) == "" else _speaker(String(l.who), Color("#cfc4ad"), String(l.text))))
			return box
		"thought":
			return _rt("[color=#e0c068]◆ New thought: [b]%s[/b][/color]" % _e(e.name))
		"chips", "temp":
			return _rt("[font_size=12][color=#8f8778]%s[/color][/font_size]" % _e("  ·  ".join(e.list)))
		"note":
			return _rt("[i][color=#c9a050]%s[/color][/i]" % _e(e.text))
	return null


func _show_choices() -> void:
	for c in _choices.get_children(): c.queue_free()
	var n := 0
	for c in _view.get("choices", []):
		n += 1
		var b := Button.new()
		b.flat = true
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		b.custom_minimum_size.x = column_width - 60
		var label := "%d. " % n
		var col := Color("#e8dcc0")
		if c.kind == "ask" or c.kind == "no":
			col = voice_color(String(c.v), _voice_sk(String(c.v)))
			label += "[%s] " % c.voice
		if c.has("check"):
			var ck: Dictionary = c.check
			label += "[%s%s · %s %d · %d%%%s] " % ["Red · " if ck.kind == "red" else "", ck.voice, ck.difficulty, ck.dc, ck.odds, " · retry" if ck.retry else ""]
			if ck.kind == "red": col = Color("#e07a6a")
		label += String(c.text)
		for t in c.get("tags", []): label += "  (%s)" % t
		if c.get("replay", false): label += "   · hear it again"
		b.text = label
		b.add_theme_color_override("font_color", col)
		b.add_theme_color_override("font_hover_color", col.lightened(0.3))
		b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.28))
		if c.get("replay", false): b.modulate = Color(1, 1, 1, 0.65)
		b.disabled = not c.enabled
		b.tooltip_text = String(c.get("hint", ""))
		if c.has("check"):
			b.mouse_entered.connect(_show_tip.bind(b, c))
			b.mouse_exited.connect(func(): _tip.hide())
		var choice: Dictionary = c
		b.pressed.connect(func():
			_tip.hide()
			choice_made.emit(choice)
			runner.choose(choice.index))
		_choices.add_child(b)
	var leave := Button.new()
	leave.flat = true
	leave.alignment = HORIZONTAL_ALIGNMENT_LEFT
	leave.text = "%d. [Leave.]" % (n + 1)
	leave.add_theme_color_override("font_color", Color(1, 1, 1, 0.5))
	leave.pressed.connect(func(): runner.leave())
	_choices.add_child(leave)
	_scroll_down()


func _show_tip(b: Button, c: Dictionary) -> void:
	var ck: Dictionary = c.check
	var how := "[b]Red check.[/b] One chance. There is no retry." if ck.kind == "red" else "[b]White check.[/b] If you fail, you can try again once your %s improves or you learn something new." % _e(ck.voice)
	_tip_text.text = "[b]%s (%s) · %s (%d)[/b]\nRoll 2d6 and add %+d. You need %d or more.\n%s\n[i]Double six always succeeds. Double one always fails.[/i]\n%s" % [
		_e(ck.voice), _e(runner.host.skill_name(ck.skill)), ck.difficulty, ck.dc, ck.tot, ck.dc, _e("\n".join(ck.mods)), how]
	_tip.show()
	_tip.global_position = b.global_position + Vector2(-_tip.size.x - 12, 0)
	if _tip.global_position.x < 0: _tip.global_position.x = b.global_position.x + 40
