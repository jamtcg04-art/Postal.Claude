# The Postal Trace dialogue system (pass 9)

## What changed

| | Before (browser artifact, and the Godot port through JsLite) | Now |
|---|---|---|
| Where conversations are written | `GRAPH[...] = {...}` objects inside the 27,000-line `index.html`, with JavaScript functions for every condition and changing line | `dialogue/*.pt`: 21 plain-text scripts, one per place (128 conversations, Redoubt Nine and the signal hut included) |
| Conditions | 893 JavaScript functions | expressions (`not done.vane_scorn and coin >= 2`) compiled to a small tree both builds read |
| Godot | the browser's conversation screen redrawn through `bridge.gd`/`html.gd`, run by the JS interpreter | a native GDScript runner and a Disco-style scrolling log (`addons/pt_dialogue`) |
| Keeping builds the same | re-export the browser code | one compile step writes both builds' data; tests replay browser play in Godot |
| Checking | play it | a report of broken links, unknown names and unreachable nodes, and a picture of every conversation |

The game's rules did not change: same voices, thresholds, checks, modifiers, retries and memory keys
(`gseen_`, `gmet_`, `gu_`, `ck_` … in `S.done`), so existing saves load in either build.

## The parts

```
dialogue/*.pt  ──tools/dialogue/compile.js──►  data/dialogue/*.json   (Godot: PTDialogueDB, and Data's GRAPH)
                                          └──►  .dialogue_build/browser/pt_dialogue.gen.js   (browser: patch_browser.js)
                                          └──►  .dialogue_build/report.md, .dialogue_build/graphs/*.dot|svg
```

- `tools/dialogue/ptexpr.js`: the expression language: read, print, compile to JavaScript, evaluate.
- `tools/dialogue/ptc.js`: reads and writes `.pt` scripts; writes the browser's GRAPH code.
- `tools/dialogue/compile.js`: compiler, checker and graph pictures.
- `tools/dialogue/extract.js`, `port_import.js`, `js2ast.js`, `normalize.js`: turned the browser's GRAPH and the port's data/graphs into the scripts (done once; kept for reference).
- `addons/pt_dialogue/`:
  - `pt_dialogue_runner.gd`: the conversation flow (hub, voices, branches, checks, retries, replays, returns).
  - `pt_cond.gd`: evaluates conditions with JavaScript's rules (so `undefined`, `null`, numbers and text compare as in the browser).
  - `pt_dialogue_db.gd`: loads the compiled conversations.
  - `pt_dialogue_host.gd`: what the runner asks of the game.
  - `pt_jslite_host.gd`: answers with the browser's own rule functions through JsLite (use this in the game now).
  - `pt_native_host.gd`: the same rules written in GDScript (skills, voices, modifiers, dice, effects, thoughts).
  - `ui/pt_dialogue_log.gd`: the dialogue column: one feed, voices coloured by attribute with *[Medium: Success]* tags,
    the dice line, beats revealed one at a time (Space), numbered choices (1–9) with odds, a hover card listing
    every modifier, and *[Leave.]*.

## Tests and what they showed (31 October 2026)

- **Round trip:** all 120 conversations written as `.pt` and read back are identical to the browser's data.
- **Same behaviour in the browser:** the 893 conditions and changing lines, compiled back to JavaScript, give the same
  answers and the same state changes as the originals over 150 random game states (133,950 calls, 0 differences).
- **The patched browser build** replays 294 of 295 recorded conversations exactly; the other one is the tavern dice game,
  which uses unseeded random numbers of its own.
- **Godot runner with the browser's rules** (`tests/parity_js.gd`): 295 recorded browser conversations, 2,012 screens,
  0 differences: same lines, same voices, same dice, same choices with the same states and odds.
- **Godot runner with the native rules** (`tests/parity.gd`): 277 of 295 runs identical. The 18 that differ are all in
  conversations that use `@js` fields or game queries the native rules don't have yet (market prices, the cellar,
  the dice game, the miller's petition, Karrow's mare).
- **Smoke:** every conversation walked with random choices on the native rules without a script error.

## In the Godot game (pass 9, 1 November 2026)

- `scripts/main.gd` no longer has its own copy of the conversation flow: `graph_show`, `_graph_go` and the option
  clicks go through `PTDialogueRunner`, and main.gd draws the runner's views with the game's own widgets (portraits,
  voices, chips, the staged reveal, touch sizes, palettes). The browser logic's `graphShow`/`graphGo` calls land in
  the same place.
- `scripts/dialogue_host.gd` (`PTGameHost`) answers the runner from `Game`, `Data` and the browser logic in lib.json,
  so companions, Duty reactions, the market and fights react as before.
- `data/dialogue/*.json` replaces `data/graphs/`; `Data` still gives the browser logic its `GRAPH` table, made from
  the same compiled data (expressions turned back into JavaScript for JsLite).
- New on screen: Disco-style passive tags on inner voices (*‹Medium: Success›*), and every modifier on hover over a
  check.
- Fixed by the change (the port differed from the browser here): an option that buys, sells or throws dice now
  stays in the conversation instead of dropping you back to the scene; an option that starts a fight (the Quarter
  Cut's yard) now starts it; leaving through an action draws the scene once (it was drawn twice, which could
  swallow the arrival lines); companions' pass/fail asides after a check can fire.
- Checks: recordings from the published browser build (pass 11) replayed in the game 320/321 (the tavern dice game uses unseeded random numbers); the scripts match the published browser's 128 conversations exactly, and its 913 conditions over 100 random states;
  the old and new Godot flows give identical screens in 205 of 214 seeded runs, and the other 9 are the fixes above;
  the port's own tests unchanged (systems 11, v100 34/34, saves 16/16, touch 15/15, walkers 9/9, horses 11/11,
  edits 11/11, editor 18/18, places 38, clicks 2/2, bots reach endings).
- The checker found one bug in the original writing: Ines's "You came back" greeting (chapel.pt) waits for
  `done.ines_lamp`, which nothing sets (the scene gives the Tin Thought `ines_lamp` and the flag `ines_hopeful`).

## Keeping both builds the same, from now on

Write conversations in `dialogue/*.pt`, run `node tools/dialogue/compile.js --godot .`, and patch the browser page. Change rules
(voices, modifiers, effects) in the browser code as before; `PTJsLiteHost` picks them up at once, and
`tests/parity.gd` shows when `PTNativeHost` needs the same change.
