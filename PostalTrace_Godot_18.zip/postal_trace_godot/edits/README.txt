Drop edits files from the browser's place editor here.

In the browser game: Dev Mode > Edit place > Save file writes postal-trace-place-edits.json.
Put that file (or several) in this folder and the Godot game takes the edits the next time a
place is built. Each place is taken when the file is newer than the edits already made for that
place on this machine. Files here go into every export of the game.

Other folders the game also reads (for files you do not want built into the game):
  user://edits/            the game's data folder (Place editor > Open edits folder)
  <game folder>/edits/     next to an exported game, for example the handheld port's folder
