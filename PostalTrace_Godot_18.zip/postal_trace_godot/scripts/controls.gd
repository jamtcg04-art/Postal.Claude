class_name Controls
extends RefCounted
## Remappable controls (Menu > Controls). Each action has its keys (first key is the one shown and the
## one you change) and pad buttons; changes are kept in user://settings.cfg.

const CFG := "user://settings.cfg"

## [action, label, default keys, pad buttons]
const ACTIONS := [
	["walk_up", "Walk forward", [KEY_W, KEY_UP], []],
	["walk_down", "Walk back", [KEY_S, KEY_DOWN], []],
	["walk_left", "Walk left", [KEY_A, KEY_LEFT], []],
	["walk_right", "Walk right", [KEY_D, KEY_RIGHT], []],
	["run", "Run (hold)", [KEY_SHIFT], [JOY_BUTTON_RIGHT_SHOULDER]],
	["turn_left", "Turn the view left", [KEY_Q], [JOY_BUTTON_LEFT_SHOULDER]],
	["turn_right", "Turn the view right", [KEY_E], []],
	["zoom_in", "Zoom in", [KEY_PERIOD], []],
	["zoom_out", "Zoom out", [KEY_COMMA], []],
	["voice", "Hear the waiting voice", [KEY_V], [JOY_BUTTON_Y]],
	["character", "Character", [KEY_C], []],
	["thoughts", "Tin Thoughts", [KEY_T], []],
	["satchel", "Satchel", [KEY_I], []],
	["journal", "Journal", [KEY_J], []],
]

## Set up the actions with the saved keys (or the defaults).
static func setup() -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	for a in ACTIONS:
		var name: String = a[0]
		if not InputMap.has_action(name):
			InputMap.add_action(name, 0.2)
		InputMap.action_erase_events(name)
		var keys: Array = a[2].duplicate()
		if c.has_section_key("controls", name):
			keys[0] = int(c.get_value("controls", name))
		for k in keys:
			if int(k) == 0:
				continue
			var ev = InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(name, ev)
		for b in a[3]:
			var jb = InputEventJoypadButton.new()
			jb.button_index = b
			InputMap.action_add_event(name, jb)

static func key_of(name: String) -> int:
	for ev in InputMap.action_get_events(name):
		if ev is InputEventKey:
			return ev.physical_keycode
	return 0

static func key_name(name: String) -> String:
	var k = key_of(name)
	return OS.get_keycode_string(k) if k != 0 else "(none)"

## Change an action's main key; the key comes off any other action that had it as its main key.
static func set_key(name: String, keycode: int) -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	for a in ACTIONS:
		if a[0] != name and key_of(a[0]) == keycode:
			c.set_value("controls", a[0], 0)
	c.set_value("controls", name, keycode)
	c.save(CFG)
	setup()

static func reset() -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	if c.has_section("controls"):
		c.erase_section("controls")
	c.save(CFG)
	setup()
