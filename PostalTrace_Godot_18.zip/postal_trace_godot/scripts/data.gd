## Data: loads every table, scene and conversation from res://data.
##
## Layout (all plain JSON, edit freely):
##   data/tables.json          skills, voices, thoughts, items, endings, flavour text...
##   data/scenes/<id>.json     a stop or road meeting: text, choices, who is there to talk to
##   data/dialogue/<scene>.json  the conversations, compiled from dialogue/*.pt by tools/dialogue/compile.js
##                             (read by the dialogue runner, addons/pt_dialogue); older builds used data/graphs/
##   data/lib.json             the browser version's own logic for companions, the market, the gate,
##                             errands, fights, road events and more (run by JsLite)
##   data/index.json           which scenes are main stops and which are road meetings
##
## Any value written as {"$js": "function () { ... }"} is a small piece of game logic
## (a condition, a line that changes with the state, an outcome). It is run by JsLite.
extends Node

var js := JsLite.new()
var T: Dictionary = {}          # tables.json
var scenes: Dictionary = {}     # id -> scene
var graphs: Dictionary = {}     # "scene:who" -> graph, as the browser logic sees it (JsLite functions)
var dialogue: PTDialogueDB      # the compiled conversations, as the dialogue runner reads them
var index: Dictionary = {}

func _ready() -> void:
	load_all()

func load_all() -> void:
	T = _norm(_read("res://data/tables.json"))
	index = _norm(_read("res://data/index.json"))
	scenes.clear()
	graphs.clear()
	var sd := DirAccess.open("res://data/scenes")
	if sd:
		for f in sd.get_files():
			if f.ends_with(".json"):
				scenes[f.get_basename()] = _norm(_read("res://data/scenes/" + f))
	dialogue = PTDialogueDB.new("res://data/dialogue")
	for cid in dialogue.ids():
		graphs[cid] = _norm(_for_js(dialogue.conversation(cid)))
	var gd := DirAccess.open("res://data/graphs") if graphs.is_empty() else null
	if gd:
		for s in gd.get_directories():
			var d2 := DirAccess.open("res://data/graphs/" + s)
			for f in d2.get_files():
				if f.ends_with(".json"):
					graphs[s + ":" + f.get_basename()] = _norm(_read("res://data/graphs/" + s + "/" + f))
	for k in T:
		js.set_global(k, T[k])
	_load_lib()

## A compiled conversation in the form the browser logic reads (GRAPH): computed fields become JavaScript
## functions again ({x: expression} -> {$js}), kept JavaScript keeps its captured values ($env).
func _for_js(v: Variant) -> Variant:
	if v is Dictionary:
		if v.size() == 1 and v.get("x") is Array:
			return {"$js": "function () { return " + PTCond.to_js(v.x) + "; }"}
		if v.has("js") and v.get("js") is String and (v.size() == 1 or (v.size() == 2 and v.has("closure"))):
			return {"$js": v.js, "$env": PTGameHost.port_env(v.get("closure", {}))}
		var out := {}
		for k in v: out[k] = _for_js(v[k])
		return out
	if v is Array:
		return v.map(func(x): return _for_js(x))
	return v

func dialogue_ids() -> Array:
	return dialogue.ids() if dialogue else graphs.keys()

func _read(path: String) -> Variant:
	var txt := FileAccess.get_file_as_string(path)
	if txt == "":
		push_error("Data: could not read " + path)
		return {}
	var v: Variant = JSON.parse_string(txt)
	if v == null:
		push_error("Data: bad JSON in " + path)
		return {}
	return v

## JSON numbers arrive as floats; whole numbers become ints so text reads "+2", not "+2.0".
## {"$js"} values become JsLite functions (parsed on first use).
func _norm(v: Variant) -> Variant:
	if v is Dictionary:
		if v.has("$js"):
			return js.make_fn(v)
		if v.has("$re"):
			return js.make_regex(str(v["$re"]), str(v.get("flags", "")))
		var out: Dictionary = {}
		for k in v:
			out[k] = _norm(v[k])
		return out
	if v is Array:
		var a: Array = []
		for x in v:
			a.append(_norm(x))
		return a
	if typeof(v) == TYPE_FLOAT and v == floor(v) and abs(v) < 1e12:
		return int(v)
	return v

# ---------------------------------------------------------------- access helpers

## A field that may be a function of the state: return its current value.
func val(v: Variant) -> Variant:
	return js.val(v)

## Read o[k], running getters and functions the way the original nodeVal() did.
func g(o: Variant, k: Variant) -> Variant:
	return js.get_prop(o, k)

## Read o[k] and evaluate it if it is a function.
func gv(o: Variant, k: Variant) -> Variant:
	return js.val(js.get_prop(o, k))

func call_fn(f: Variant, args: Array = []) -> Variant:
	return js.call_fn(f, args)

func truthy(v: Variant) -> bool:
	return JsLite.truthy(v)

func scene_def(id: String) -> Variant:
	return scenes.get(id)

func graph(scene_id: String, who: String) -> Variant:
	return graphs.get(scene_id + ":" + who)

## data/lib.json: the browser version's own functions and the tables they use, run as they are.
## The tables already loaded above stay the ones in use; the same objects serve both sides.
func _load_lib() -> void:
	var main_sc := {}
	var road_sc := {}
	var talk := {}
	for id in scenes:
		(main_sc if scenes[id].get("kind") == "main" else road_sc)[id] = scenes[id]
		talk[id] = scenes[id].get("talk", [])
	js.set_global("SCENES", main_sc)
	js.set_global("ENC", road_sc)
	js.set_global("TALK", talk)
	js.set_global("GRAPH", graphs)
	if not FileAccess.file_exists("res://data/lib.json"):
		return
	var lib: Dictionary = _norm(_read("res://data/lib.json"))
	for k in lib.get("data", {}):
		if not js.globals.vars.has(k):
			js.set_global(k, lib.data[k])
	for k in lib.get("functions", {}):
		var f: Variant = lib.functions[k]
		if f is JsLite.JsFn and f.src.find("[native code]") >= 0:
			continue   # stand-ins for the page in the export, not game logic
		js.set_global(k, f)
