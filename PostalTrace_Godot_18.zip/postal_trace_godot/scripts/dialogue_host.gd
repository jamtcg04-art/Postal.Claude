class_name PTGameHost
extends PTDialogueHost
## The dialogue runner's link to this game: the rules in game.gd (Game), the tables (Data), the browser
## logic in lib.json (through JsLite and the Bridge) and main.gd's own helpers, so a conversation reacts
## exactly as the rest of the game does (companions, Duty reactions, the market, fights …).

var main   # main.gd: chips, XP and Tin Thoughts go through its helpers, which route through the browser logic
var _fns := {}   # @js source + captured values -> JsLite function


func _init(p_main) -> void:
	main = p_main


# ---------- state ----------
func get_path(path: String):
	return PTCond.read_path(Game.S, path)

func set_path(path: String, value) -> void:
	PTCond.write_path(Game.S, path, value)

func call_fn(name: String, args: Array):
	var e: JsLite.Env = Data.js.globals.lookup(name)
	if e == null:
		if Data.js.fallback.is_valid():
			var fb = Data.js.fallback.call(name)
			if fb != null: return Data.call_fn(fb, args)
		push_warning("PTGameHost: no game query '%s'" % name)
		return PTCond.UNDEF
	var r = Data.call_fn(e.vars[name], args)
	return r

func run_js(src: String, closure: Dictionary, _is_action: bool):
	return Data.call_fn(js_fn(src, closure))

## the @js field as a JsLite function (made once)
func js_fn(src: String, closure: Dictionary) -> JsLite.JsFn:
	var k := src + JSON.stringify(closure)
	if not _fns.has(k):
		_fns[k] = Data.js.make_fn({"$js": src, "$env": PTGameHost.port_env(closure)})
	return _fns[k]

## captured values, from the compiled form ({__fn, __closure}, {__undef}) to the port's ({$js, $env}, null)
static func port_env(c):
	if c is Dictionary:
		if c.has("__undef"): return null
		if c.has("__fn"): return {"$js": c.__fn, "$env": port_env(c.get("__closure", {}))}
		if c.has("__re"): return {"$re": c.__re, "flags": c.get("flags", "")}
		var o := {}
		for k in c: o[k] = port_env(c[k])
		return o
	if c is Array: return c.map(func(x): return port_env(x))
	if c is float and c == floor(c): return int(c)
	return c

## An action (buy, sell, start a fight …) runs the browser logic. Where it would draw the next screen is caught:
## back into this conversation, out to the scene, or an ending. Anything else (a fight, a road screen) it asked
## for through Game.pending is carried out afterwards by main.
func run_action(src: String, closure: Dictionary, runner) -> Dictionary:
	var g: Dictionary = Data.js.globals.vars
	var saved := {}
	var out := {}
	for n in ["graphGo", "graphShow", "scene", "ending"]: saved[n] = g.get(n)
	g["graphGo"] = func(a): out.merge({"go": str(a[1]), "chips": (a[2].get("chips", []) if a.size() > 2 and a[2] is Dictionary else [])}, true); return null
	g["graphShow"] = func(a): out.merge({"show": str(a[1]), "chips": (a[2].get("chips", []) if a.size() > 2 and a[2] is Dictionary else []), "note": (a[2].get("note", "") if a.size() > 2 and a[2] is Dictionary else "")}, true); return null
	g["scene"] = func(_a): out["leave"] = true; return null
	g["ending"] = func(a): out["ending"] = str(a[0]); return null
	# the browser logic finds its way back into the conversation through CURG (mkTi, mkGo, mkRe)
	var t: Dictionary = runner.talker
	var ti: Variant = str(t.id).trim_prefix("x_") if t.get("obj", false) else 0
	if not t.get("obj", false):
		var ts: Array = Game.talkers()
		for i in ts.size():
			if str(ts[i].id) == str(t.id): ti = i
	Data.js.set_global("CURG", {"ti": ti, "nodeId": runner.node_id, "tid": ti if typeof(ti) == TYPE_STRING else t.id})
	Game.pending = []
	Data.call_fn(js_fn(src, closure))
	for n in saved: g[n] = saved[n]
	if out.is_empty() and not Game.pending.is_empty():
		out["pending"] = true
	return out


# ---------- voices and skills (game.gd) ----------
func voice_exists(v: String) -> bool: return Data.T.VOICES.has(v)
func voice_val(v: String) -> int: return Game.voice_val(v)
func voice_name(v: String) -> String: return str(Data.T.VOICES[v].name) if Data.T.VOICES.has(v) else v
func voice_head(v: String) -> String: return Game.voice_head(v)
func voice_for(sk: String, text: String) -> String: return Game.voice_for(sk, text)
func default_voice(sk: String) -> String: return str(Data.T.DEF_VOICE.get(sk, sk))
func skill_name(sk: String) -> String: return str(Data.T.SKILLS.get(sk, sk))
## main._voice() fills in the title and {me} as it draws the line, so the text passes through untouched here
func voice_text(_v: String, text: String) -> String: return text
func muted_by(v: String) -> bool: return Game.muted_by(v)

# ---------- checks ----------
func modifiers(ch: Dictionary) -> Dictionary:
	return Game.modifiers({"skill": ch.skill, "dc": ch.dc, "v": ch.get("v", ""), "with": ch.get("with"), "red": ch.get("red", false)})
func roll(m: Dictionary) -> Dictionary: return Game.roll_dice(m)
func check_odds(m: Dictionary) -> int: return Game.odds(m)
func check_total(sk: String, v: String) -> int: return Game.skill_bonus(sk) + Game.temp_total(sk) + (Game.v_rank(v) if v != "" else 0)
func temp_labels() -> Array: return Game.S.temp.map(func(x): return str(x.label))
func temp_line() -> Array: return Game.S.temp.duplicate()   # main._temp_line() draws them
func clear_temp() -> void: Game.S.temp = []
func thought_retry(sk: String) -> String:
	var t = Game.thought_retry(sk)
	return str(t) if t else ""
func spend_thought_retry(tid: String, sk: String) -> void:
	Game.S.done["thr_" + tid] = true
	Game.S.done["thrsk_" + sk] = true
func thought_name(tid: String) -> String: return str(Data.T.THOUGHTS[tid].name) if Data.T.THOUGHTS.has(tid) else tid
func thought_done(tid: String) -> bool: return Game.thought_done(tid)
func internal_count() -> int: return Game.internal_count()
func learned_count() -> int: return Game.S.learned.size()
func past_n() -> int: return Game.past_n()
func perk(p: String) -> bool: return Game.perk(p)
func hardcore() -> bool: return bool(Game.S.get("hard", false))
func chip(text: String, kind: String) -> Variant: return Game.chip(text, kind)

# ---------- effects ----------
func apply_node(src: Dictionary, scene: String, talker: Dictionary, runner) -> Array:
	var S := Game.S
	var sc: Variant = Game.def(scene)
	var title: String = str(sc.title) if sc is Dictionary else scene
	var chips: Array = []
	if src.get("fx") is Dictionary:
		chips.append_array(main._fx(src.fx))
	for key in ["temp", "temp2"]:
		if src.get(key) is Array:
			var c: Variant = Game.add_temp(src[key])
			if c: chips.append(c)
	for g in src.get("give", []):
		if Game.gain(g): chips.append(Game.chip(Data.T.ITEMS[g].kind + ": " + Data.T.ITEMS[g].name, "info"))
	for g in src.get("take", []):
		if Game.has(g):
			Game.lose(g)
			chips.append(Game.chip("Handed over: " + Data.T.ITEMS[g].name))
	if src.get("xp"): chips.append_array(main._xp(int(src.xp)))
	if src.get("flag") is String: S.done[src.flag] = true
	if src.get("log") is String: S.log.append({"title": title, "text": src.log})
	var lrn = runner.val(src.get("learn")) if src.has("learn") else null
	if lrn is String and lrn != "" and not S.learned.any(func(l): return l.text == lrn):
		S.learned.append({"from": talker.get("name", ""), "where": title, "text": lrn})
		chips.append(Game.chip("Learned: " + lrn, "info"))
		if Game.vperk("learn_xp"): chips.append_array(main._xp(1))
	if src.get("thought") is String: main._thought(src.thought, chips)
	return chips

func tally_add(tag: String) -> Array:
	var c: Array = []
	main._tally(tag, c)
	return c

func side_add(side: String) -> Array:
	var c: Array = []
	main._side_add(side, c)
	return c

## after a failed check the voice that rolled says something, unless the next node already gives it a line
func fail_voice(v: String, node: Dictionary, k: String, runner) -> void:
	var FR: Dictionary = Data.T.FAIL_REM
	if v == "" or not Data.T.VOICES.has(v) or not FR.has(v): return
	var sk: String = Data.T.VOICES[v].get("sk", "")
	for e in node.get("voices", []):
		var w: String = runner.vid(e)
		if w == v or (Data.T.VOICES.has(w) and Data.T.VOICES[w].get("sk") == sk and (not e.has("show") or runner._cond(e.show)) and runner.voice_on(w, e)):
			return
	var line: String = str(node.failLine) if node.get("failLine") is String else ""
	if line == "":
		var L: Array = FR[v]
		var h := 0
		for c in k: h = (h * 31 + c.unicode_at(0)) & 0xFFFFFFFF
		if h >= 0x80000000: h -= 0x100000000
		line = L[abs(h) % L.size()]
	Game.vq_push(v, line, "force")

func drain_voices() -> Array:
	if Bridge.has_js("drainVoices"):
		var h := str(Bridge.call_js("drainVoices"))
		return [{"t": "html", "html": h}] if h != "" else []
	var out := []
	for x in Game.drain():
		if x[0] == "_th": out.append({"t": "thought_done", "id": x[1]})
		else: out.append({"v": x[0], "text": x[1], "beat": str(x[3]) if x.size() > 3 else ""})
	return out

func check_end() -> String: return Game.check_end()

# ---------- flavour ----------
func banter(scene: String, k: String) -> Array:
	var out := []
	var list: Variant = Data.T.BANTER.get(scene)
	if not (list is Array): return out
	for b in list:
		if b.get("on") != k: continue
		var lines := []
		for l in b.lines: lines.append({"who": main._name_of(scene, l[0]) if l[0] else "", "text": str(l[1])})
		out.append(lines)
	return out

func manner(scene: String, talker: Dictionary) -> String:
	var arr: Variant = Data.T.MANNER.get(scene + ":" + str(talker.id))
	if not (arr is Array) or arr.is_empty(): return ""
	var k := "v_" + scene + ":" + str(talker.id)
	var n := int(Game.S.done.get(k, 0))
	Game.S.done[k] = n + 1
	return str(arr[n % arr.size()])

func companion_meet(scene: String, talker: Dictionary) -> Array:
	if not Bridge.has_js("compMeetLine"): return []
	return [{"t": "html", "html": str(Bridge.call_js("compMeetLine", [scene, talker]))}]

func companion_chime(scene: String, talker: Dictionary, k: String, node_id: String, ctx: Dictionary, first_meet: bool) -> Array:
	if not Bridge.has_js("compChime"): return []
	return [{"t": "html", "html": str(Bridge.call_js("compChime", [scene, talker, k, node_id, ctx, first_meet]))}]
