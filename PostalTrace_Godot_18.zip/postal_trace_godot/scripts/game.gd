## Game: the rules of The Postal Trace, ported from the browser version.
##
## The run state lives in the dictionary S, with the same keys as the original
## (S.hp, S.done, S.inv, S.thoughts ...), so the logic in the data files keeps working.
## This script holds the rules; scripts/main.gd draws the screens and calls into it.
extends Node

signal ledger_changed

const SAVE_SLOTS := 6

var S: Dictionary = {}
var pending: Array = []     # requests made by data logic: ["scene"], ["ending", kind], ["resolve", ch, idx, forced],
                            # ["fight", cfg], ["event", eyebrow, title, body, opts, after], ["html", html], ["road"]
var dom: Dictionary = {}    # button id -> handler, for screens built with show()
var cur_scx: String = ""    # unused for now (revisits); kept for parity with the original
var addr_last: Dictionary = {}
var rng = RandomNumberGenerator.new()

var _vrules: Array = []     # [skill, voice, RegEx]

func _ready() -> void:
	rng.randomize()
	S = new_state()
	_build_vrules()
	_register_helpers()
	_init_sync()

func T(k: String) -> Variant:
	return Data.T.get(k)

# ================================================================ state

func new_state() -> Dictionary:
	return { "trait": null, "hp": 6, "st": 8, "pw": 4, "ra": 4, "hrs": 0, "notice": 0, "trust": 0, "coin": 3, "duty": 0,
		"wet": false, "sealBroken": false, "read": false, "sold": false, "full": 0, "partial": 0, "withheld": 0,
		"delivered": [], "route": [], "idx": 0, "inv": ["case"], "copies": 4, "log": [],
		"up": { "arms": 0, "nerve": 0, "wits": 0, "grit": 0 }, "xp": 0, "level": 1, "points": 0, "done": {},
		"errands": 0, "relay": {}, "out": {}, "seen": 0, "temp": [], "talked": {}, "learned": [], "perc": {},
		"worn": {}, "assessed": {}, "thoughts": [], "loose": [], "mull": {},
		"tally": { "loyal": 0, "merciful": 0, "cynical": 0, "frightened": 0 }, "side": { "duty": 0, "hat": 0 },
		"past": { "n": 0, "view": null, "last": -9 }, "holes": 2, "vq": [], "vr": {}, "vcap": {} }

func set_state(s: Dictionary) -> void:
	S = s
	Data.js.set_global("S", S)
	ledger_changed.emit()

func begin_run(cc: Dictionary) -> void:
	var s = new_state()
	s["trait"] = cc.get("trait", "steady")
	s["up"] = cc.get("up", { "arms": 1, "nerve": 1, "wits": 1, "grit": 1 }).duplicate()
	s["points"] = int(cc.get("left", 0))
	s["arch"] = cc.get("arch")
	s["hard"] = bool(cc.get("hard", false))
	s["vary"] = bool(cc.get("vary", false))
	s["runId"] = Time.get_unix_time_from_system()
	# living dice (living_dice/living_dice.gd, the browser's S.ld): null when the run uses ordinary dice
	s["ld"] = LivingDice.postal_start(cc.get("ld", {}))
	cp = null
	set_state(s)

func dline() -> int:
	if jsf("dLine") != null:
		return int(JsLite.to_num(Data.call_fn(jsf("dLine"))))
	return 68 if S.get("hard", false) else int(T("DEADLINE"))

func done(k: String) -> Variant:
	return S["done"].get(k)

func is_done(k: String) -> bool:
	return Data.truthy(S["done"].get(k))

# ================================================================ chips (the small result tags)

static func chip(text: String, kind: String = "") -> Dictionary:
	return { "t": text, "k": kind }

func signed(n: Variant) -> String:
	var x = int(n)
	return ("+" if x >= 0 else "−") + str(abs(x))

# ================================================================ resources

func clamp_k(k: String) -> void:
	var lim: Array = T("LIM")[k]
	var hi: int = int(lim[1]) + (1 if k == "pw" and vperk("pw_cap") else 0)
	S[k] = clampi(int(S[k]), int(lim[0]), hi)

func apply_fx(fx: Variant) -> Array:
	var chips: Array = []
	if not (fx is Dictionary):
		return chips
	for k in ["hp", "st", "pw", "ra", "hrs", "notice", "trust", "coin", "duty"]:
		if fx.has(k) and Data.truthy(fx[k]):
			var before = int(S[k])
			S[k] = int(S[k]) + int(fx[k])
			clamp_k(k)
			var diff = int(S[k]) - before
			if diff != 0:
				var bad: bool = diff > 0 if (k == "notice" or k == "hrs") else diff < 0
				chips.append(chip(T("NAMES")[k] + " " + ("+" if diff > 0 else "") + str(diff), "down" if bad else "up"))
				if k == "duty":
					duty_event(diff)
	if Data.truthy(fx.get("wet")):
		S["wet"] = true
		chips.append(chip("Powder soaked", "down"))
	if Data.truthy(fx.get("crack")) and not S["sealBroken"]:
		S["sealBroken"] = true
		chips.append(chip("Seal cracked", "down"))
	ledger_changed.emit()
	return chips

func has(id: String) -> bool:
	return S.get("inv", []).has(id)

func gain(id: String) -> bool:
	if jsf("gain") != null:
		var r: Variant = Data.call_fn(jsf("gain"), [id])
		ledger_changed.emit()
		return Data.truthy(r)
	if has(id):
		return false
	S["inv"].append(id)
	if id == "hat" and not is_done("hat_met"):
		S["done"]["hat_met"] = true
		var hl: Dictionary = T("HAT_LINES")
		vq_push("hat", hl["meet"][1], "force", hl["meet"][0])
		vq_push("duty", hl["meetDuty"], "force")
		vq_push("hat", hl["meetBack"], "force")
	ledger_changed.emit()
	return true

func lose(id: String) -> void:
	if jsf("lose") != null:
		Data.call_fn(jsf("lose"), [id])
		ledger_changed.emit()
		return
	S["inv"].erase(id)
	ledger_changed.emit()

# ================================================================ skills and voices

## A function of the browser logic (data/lib.json), or null.
func jsf(name: String) -> Variant:
	return Data.js.globals.vars.get(name)

func skill_parts(sk: String) -> Array:
	# the browser's skillParts, with everything later versions added to it (coat, companions...)
	if jsf("skillParts") != null:
		var r: Variant = Data.call_fn(jsf("skillParts"), [sk])
		if r is Array:
			return r
	var p: Array = []
	if sk == "grit":
		p.append(["Veteran’s endurance", 1])
	var tr: Variant = T("TRAITS").get(str(S.get("trait")))
	if tr != null and tr[0] == sk:
		p.append([tr[1], 2])
	if S.get("worn", {}).get("hat"):
		if sk == "nerve":
			p.append(["Lieutenant Hale’s hat", 2])
		if sk == "wits":
			p.append(["Lieutenant Hale’s hat", -2])
	var up = int(S["up"].get(sk, 0))
	if up:
		p.append(["Points you put in", up])
	for tid in S.get("thoughts", []):
		var th: Variant = T("THOUGHTS").get(tid)
		if th == null:
			continue
		var mulling: bool = int(S["mull"].get(tid, 0)) > 0
		if th.get("bonus") is Dictionary and th["bonus"].get(sk) and not mulling:
			p.append([th["name"], int(th["bonus"][sk])])
		if th.get("cost") is Dictionary and th["cost"].get(sk) and mulling:
			p.append([th["name"] + " (mulling)", int(th["cost"][sk])])
	return p

func skill_bonus(sk: String) -> int:
	var t = 0
	for x in skill_parts(sk):
		t += int(x[1])
	return t

func _build_vrules() -> void:
	_vrules.clear()
	for r in T("V_RULES"):
		var re: Variant = r[2]
		_vrules.append([r[0], r[1], re])

func voice_for(sk: String, txt: String) -> String:
	for r in _vrules:
		if r[0] == sk and r[2] is JsLite.JsRegex and r[2].re.search(txt) != null:
			return r[1]
	return str(T("DEF_VOICE").get(sk, sk))

func v_rank(v: String) -> int:
	return int(S.get("vr", {}).get(v, 0))

func innate(sk: String) -> int:
	var tr: Variant = T("TRAITS").get(str(S.get("trait")))
	return int(S["up"].get(sk, 0)) + (1 if sk == "grit" else 0) + (2 if tr != null and tr[0] == sk else 0)

func v_cap(sk: String) -> int:
	return max(0, innate(sk)) + int(S.get("vcap", {}).get(sk, 0))

func v_val(v: String) -> int:
	return skill_bonus(str(T("VOICES")[v]["sk"])) + v_rank(v)

func vperk(key: String) -> bool:
	var vp: Dictionary = T("VPERK")
	for v in vp:
		var list: Array = vp[v]
		for i in list.size():
			if list[i][2] == key and v_rank(v) > i:
				return true
	return false

func thought_done(tid: String) -> bool:
	return S.get("thoughts", []).has(tid) and not int(S.get("mull", {}).get(tid, 0)) > 0

func internal_count() -> int:
	var n = 0
	for tid in S.get("thoughts", []):
		if thought_done(tid):
			n += 1
	return n

func muted_by(v: String) -> bool:
	for tid in S.get("thoughts", []):
		var th: Variant = T("THOUGHTS").get(tid)
		if th and th.get("mute") == v and thought_done(tid):
			return true
	return false

func perk(p: String) -> bool:
	for tid in S.get("thoughts", []):
		var th: Variant = T("THOUGHTS").get(tid)
		if th and th.get("perk") == p and thought_done(tid):
			return true
	return vperk(p)

func temp_total(sk: String) -> int:
	var t = 0
	for x in S["temp"]:
		if x["sk"] == sk:
			t += int(x["v"])
	return t

func add_temp(tp: Array) -> Variant:
	var sk: String = tp[0]
	var cur = temp_total(sk)
	var cap = int(T("TEMP_CAP"))
	var nv = clampi(cur + int(tp[1]), -cap, cap)
	var d = nv - cur
	if d == 0:
		return null
	S["temp"].append({ "sk": sk, "v": d, "label": tp[2] })
	return chip(T("SKILLS")[sk] + " " + ("+" if d > 0 else "") + str(d) + " on the next check", "up" if d > 0 else "down")

func voice_val(v: String) -> int:
	var V: Variant = T("VOICES").get(v)
	if V == null:
		return -99
	if V.get("sk"):
		return skill_bonus(V["sk"]) + temp_total(V["sk"]) + v_rank(v)
	if v == "duty":
		return int(S["duty"])
	if v == "hat":
		return (2 if S.get("worn", {}).get("hat") else 1) if has("hat") else 0
	if v == "trace":
		return int(S["trust"])
	return 0

func voice_on(v: String, e: Variant) -> bool:
	if not T("VOICES").has(v):
		return false
	if v == "hat" and not has("hat"):
		return false
	if e is Dictionary:
		if e.has("show") and e["show"] != null and not Data.truthy(Data.call_fn(e["show"])):
			return false
		var val = voice_val(v)
		if e.get("min") != null and val < int(e["min"]):
			return false
		if e.get("max") != null and val > int(e["max"]):
			return false
	return true

func vid(e: Dictionary) -> String:
	if e.get("v"):
		return e["v"]
	var dv: Variant = T("DEF_VOICE").get(str(e.get("sk")))
	return str(dv) if dv != null else str(e.get("sk"))

func voice_head(v: String) -> String:
	var V: Dictionary = T("VOICES")[v]
	if V.get("sk"):
		return T("SKILLS")[V["sk"]] + " · " + V["name"]
	if V.get("tag"):
		return V["tag"] + " · " + V["name"]
	return V["name"]

## The skill a voice belongs to, or the voice id for the special voices (duty, hat, trace).
func voice_kind(v: String) -> String:
	var V: Variant = T("VOICES").get(v)
	if V and V.get("sk"):
		return V["sk"]
	return v

func me_word() -> String:
	var a: Variant = S.get("arch")
	if a != null and T("ADDR").has(a):
		return T("ADDR")[a]
	return "courier"

func me_fill(t: String) -> String:
	var w = me_word()
	return t.replace("{me}", w).replace("{Me}", w.capitalize())

func addr_open(v: String, text: String) -> String:
	if not T("ADDR_V").has(v) or S.get("arch") == null or not T("ADDR").has(S["arch"]):
		return text
	if text.to_lower().find("{me}") >= 0:
		return text
	var w: String = T("ADDR")[S["arch"]]
	var re = RegEx.new()
	re.compile("(?i)\\b" + w + "\\b")
	if re.search(text) != null:
		return text
	var h = 0
	for i in text.length():
		h = (h * 31 + text.unicode_at(i)) & 0xFFFFFFFF
	var key = str(S["idx"]) + ":" + text
	if h % 3 != 0 or addr_last.get(v) == key:
		return text
	addr_last[v] = key
	return "{Me}. " + text

## Final text for a voice line, with the player's title filled in.
func voice_text(v: String, text: Variant) -> String:
	var t := str(Data.val(text))
	if jsf("echoText") != null:
		t = str(Data.call_fn(jsf("echoText"), [v, t]))
	return me_fill(addr_open(v, t))

# ================================================================ checks

func modifiers(ch: Dictionary) -> Dictionary:
	var m: Array = []
	var tot = 0
	var skill: String = str(ch.get("skill", ""))
	var sb = skill_bonus(skill)
	var vv: Variant = null
	var cv: Variant = ch.get("v")
	if cv != null and T("VOICES").has(cv) and T("VOICES")[cv].get("sk") == skill:
		vv = cv
	else:
		var txt: String = str(ch.get("txt", "")) if ch.get("txt") else str(Data.val(ch.get("title", ""))) + " " + (str(ch.get("hint")) if typeof(ch.get("hint")) == TYPE_STRING else "")
		vv = voice_for(skill, txt)
	if not T("VOICES").has(str(vv)):
		vv = null
	var vr = v_rank(vv) if vv != null else 0
	var vn: String = T("VOICES")[vv]["name"] if vv != null else str(T("SKILLS").get(skill, "No roll"))
	tot += sb + vr
	m.append(vn + " " + signed(sb + vr) + ((" (" + T("SKILLS")[skill] + " " + signed(sb) + ", trained " + signed(vr) + ")") if vr else ""))
	var w2: Variant = ch.get("with")
	if w2 is Dictionary and T("SKILLS").has(w2.get("sk")):
		var h2: int = skill_bonus(w2["sk"]) + (v_rank(w2["v"]) if w2.get("v") and T("VOICES").has(w2["v"]) else 0)
		var a2: int = int(ceil(h2 / 2.0)) if h2 > 0 else 0
		var wn: String = T("VOICES")[w2["v"]]["name"] if w2.get("v") and T("VOICES").has(w2["v"]) else T("SKILLS")[w2["sk"]]
		tot += a2
		m.append(wn + " helps " + signed(a2) + " (half of " + T("SKILLS")[w2["sk"]] + " " + signed(h2) + ")")
		vn = vn + " + " + wn
	if int(S["hp"]) <= 4 and not vperk("no_wound_pen"):
		tot -= 1; m.append("wounds -1")
	if int(S["st"]) <= 3:
		tot -= 1; m.append("exhaustion -1")
	if skill == "arms" and S["wet"]:
		var wp = 1 if vperk("wet_half") else 2
		tot -= wp; m.append("wet powder -" + str(wp))
	for t in S["temp"]:
		if t["sk"] == skill:
			tot += int(t["v"]); m.append(str(t["label"]) + " " + ("+" if int(t["v"]) > 0 else "") + str(t["v"]))
	if ch.get("bonus") != null:
		var bn: Variant = Data.call_fn(ch["bonus"])
		if bn is Dictionary and Data.truthy(bn.get("v")):
			tot += int(bn["v"]); m.append(str(bn.get("label", "")) + " " + ("+" if int(bn["v"]) > 0 else "") + str(bn["v"]))
	var dc = int(ch.get("dc", 0))
	if ch.get("dcAdj") != null:
		var da: Variant = Data.call_fn(ch["dcAdj"])
		if da is Dictionary and Data.truthy(da.get("v")):
			dc += int(da["v"]); m.append(str(da.get("label", "")) + " " + ("+" if int(da["v"]) > 0 else "") + str(da["v"]))
	var here: String = cur_id()
	if here == "cross":
		if is_done("vane_scorn") and skill == "nerve":
			tot -= 1; m.append("Vane has seen you flinch -1")
		if is_done("vane_soft") and skill == "wits":
			tot += 1; m.append("Vane weighed your arithmetic +1")
		if is_done("vane_wavers") and skill == "nerve":
			tot += 1; m.append("Vane is wavering +1")
	if int(S["notice"]) >= 3:
		dc += 1; m.append("valley on alert, target +1")
	var idx = int(S["idx"])
	var stage = 2 if idx >= 11 else (1 if idx >= 6 else 0)
	if stage and here != "malice":
		dc += stage; m.append(("deep in the valley" if stage > 1 else "the war closing in") + ", target +" + str(stage))
	if is_done("cp_pass") and (here == "oak" or here == "malice") and (skill == "nerve" or skill == "wits"):
		tot += 1; m.append("Lisle’s provost pass +1")
	if S.get("hard", false):
		dc += 1; m.append("hardcore, target +1")
	if ch.get("red") and int(S["level"]) >= 4:
		var rr = 2 if int(S["level"]) >= 6 else 1
		dc += rr; m.append("a red check at level " + str(S["level"]) + ", target +" + str(rr))
	if S.get("hard", false) and int(S["level"]) >= 4:
		dc += 1; m.append("hardcore at level " + str(S["level"]) + ", target +1")
	if is_done("fd_cart_good") and here == "oak":
		tot += 1; m.append("the garrison’s goodwill +1")
	if is_done("wl_bet") and here == "oak":
		tot += 2; m.append("Bet walked you past the sentries +2")
	if is_done("hs_done") and here == "ridge":
		tot += 2; m.append("the Ridge gun fires again +2")
	if is_done("cp_report") and not is_done("cp_report_stopped") and here == "malice":
		dc += 2; m.append("Lisle’s report is on Corvane’s desk, target +2")
	return { "tot": tot, "dc": dc, "list": m, "v": vv, "vn": vn }

var dice_queue: Array = []   # tests: dice to throw before the random ones (recorded browser runs)

func d6() -> int:
	if not dice_queue.is_empty():
		return int(dice_queue.pop_front())
	return rng.randi_range(1, 6)

static func ok_roll(a: int, b: int, tot: int, dc: int) -> bool:
	return (a == 6 and b == 6) or (not (a == 1 and b == 1) and a + b + tot >= dc)

func roll_dice(m: Dictionary) -> Dictionary:
	if LivingDice.is_on(S.get("ld")) and dice_queue.is_empty():
		var lr: Dictionary = LivingDice.roll(S.ld, { "tot": int(m["tot"]), "dc": int(m["dc"]) }, int(S.hp))
		lr["fxnote"] = _ld_fx(lr.get("fx", {}))
		if on_roll.is_valid():
			on_roll.call(m, lr)
		return lr
	var a = d6()
	var b = d6()
	var crit = "hi" if a == 6 and b == 6 else ("lo" if a == 1 and b == 1 else "")
	var r = { "a": a, "b": b, "total": a + b + int(m["tot"]), "ok": ok_roll(a, b, int(m["tot"]), int(m["dc"])), "crit": crit }
	if on_roll.is_valid():
		on_roll.call(m, r)
	return r

## Called with (modifiers, result) after every check: the balance report listens here.
var on_roll: Callable

## Overwhelming success / catastrophe with living dice: apply what the roll says and describe it.
func _ld_fx(fx: Dictionary) -> String:
	var bits: PackedStringArray = []
	if fx.has("st"):
		S.st = int(S.st) + int(fx.st); clamp_k("st"); bits.append("Stamina %s" % signed(int(fx.st)))
	if fx.has("hp"):
		S.hp = int(S.hp) + int(fx.hp); clamp_k("hp"); bits.append("Health %s" % signed(int(fx.hp)))
	if fx.has("xp"):
		add_xp(int(fx.xp)); bits.append("+%d XP" % int(fx.xp))
	if bits.size():
		ledger_changed.emit()
	return ", ".join(bits)

func odds(m: Dictionary) -> int:
	if LivingDice.is_on(S.get("ld")):
		return LivingDice.odds(S.ld, { "tot": int(m["tot"]), "dc": int(m["dc"]) })
	var n = 0
	for a in range(1, 7):
		for b in range(1, 7):
			if ok_roll(a, b, int(m["tot"]), int(m["dc"])):
				n += 1
	return int(round(n / 36.0 * 100.0))

func diff_name(dc: int) -> String:
	for d in T("DIFFN"):
		if dc <= int(d[0]):
			return d[1]
	return "Impossible"

# ================================================================ xp, thoughts, tallies

func add_xp(n: int) -> Array:
	var chips: Array = [chip("XP +" + str(n), "info")]
	S["xp"] = int(S["xp"]) + n
	var per = int(T("XP_PER_POINT"))
	var pts = int(T("V_PTS"))
	while int(S["xp"]) >= per:
		S["xp"] = int(S["xp"]) - per
		S["level"] = int(S["level"]) + 1
		S["points"] = int(S["points"]) + pts
		chips.append(chip("Level " + str(S["level"]) + ": " + (str(pts) + " skill points" if pts > 1 else "skill point") + " earned", "info"))
		if S["level"] == 4 or S["level"] == 8:
			chips.append(chip("A new pigeonhole in the tin case", "info"))
	ledger_changed.emit()
	return chips

func new_thought(tid: String, chips: Variant = null) -> bool:
	var th: Variant = T("THOUGHTS").get(tid)
	if th == null or S["thoughts"].has(tid) or S["loose"].has(tid):
		return false
	S["loose"].append(tid)
	Sound.play("thought", 0.55, 0.3)
	if chips is Array:
		chips.append(chip("New thought: " + th["name"] + ". Pin it in Tin Thoughts.", "info"))
	ledger_changed.emit()
	return true

func tally_add(tag: String, chips: Variant = null) -> void:
	if not T("TALLY_TAGS").has(tag):
		return
	S["tally"][tag] = int(S["tally"].get(tag, 0)) + 1
	if S["tally"][tag] == 3 and new_thought(T("PATTERN")[tag], chips):
		var pl: Array = T("PATTERN_LINE")[tag]
		if pl[0] == "longroad" and has("hat"):
			vq_push("hat", "You keep stopping. I have started to like it.", "pat")
		else:
			vq_push(pl[0], pl[1], "pat")

func side_add(v: String, chips: Variant = null) -> void:
	if v != "duty" and v != "hat":
		return
	S["side"][v] = int(S["side"].get(v, 0)) + 1
	if S["side"][v] == 3 and new_thought(T("PATTERN")[v], chips):
		vq_push(T("PATTERN_LINE")[v][0], T("PATTERN_LINE")[v][1], "pat")

func tally_voices(tag: String) -> void:
	if not T("DUTY_TALLY").has(tag):
		return
	var duty_said = false
	for x in S["vq"]:
		if x[0] == "duty":
			duty_said = true
	if not duty_said:
		vq_push("duty", pick_line("dt" + tag, T("DUTY_TALLY")[tag]), "gen")
	if has("hat"):
		vq_push("hat", pick_line("ht" + tag, T("HAT_TALLY")[tag]), "gen")

func duty_event(diff: int) -> void:
	if diff == 0:
		return
	var lvl = int(S["duty"])
	var up = diff > 0
	var band: String
	if up:
		band = "hi" if lvl >= 2 else ("mid" if lvl >= 0 else "lo")
	else:
		band = "hi" if lvl >= 1 else ("mid" if lvl >= -1 else "lo")
	vq_push("duty", pick_line("du" + ("u" if up else "d") + band, T("DUTY_REACT")["up" if up else "down"][band]), "gen")
	if has("hat") and rng.randf() < 0.75:
		vq_push("hat", pick_line("hd" + ("u" if up else "d"), T("HAT_DUTY")["up" if up else "down"]), "gen")

func pick_line(key: String, arr: Variant) -> String:
	if not (arr is Array) or arr.is_empty():
		return ""
	var n = int(S["done"].get("rot_" + key, 0))
	S["done"]["rot_" + key] = n + 1
	return str(arr[n % arr.size()])

static func ok_pick(x: Variant, ok: bool) -> Variant:
	if x is Array:
		return x[0] if ok else (x[1] if x.size() > 1 and x[1] else x[0])
	return x

## Queue a voice line to show with the next screen.
func vq_push(v: String, text: Variant, kind: String = "", beat: String = "") -> void:
	if text == null or str(text) == "" or not T("VOICES").has(v):
		return
	if v == "hat" and not has("hat"):
		return
	if kind != "force" and muted_by(v):
		return
	S["vq"].append([v, str(text), kind, beat])

func vq_drop_generic() -> void:
	var keep: Array = []
	for x in S["vq"]:
		if x[2] != "gen":
			keep.append(x)
	S["vq"] = keep

## Take the queued voice lines (and thought notices) for display.
func drain() -> Array:
	var out: Array = S["vq"].duplicate()
	S["vq"] = []
	return out

# ================================================================ the tin case

func case_slots() -> int:
	return min(int(T("MAX_HOLES")), int(S.get("holes", 2)) + (1 if int(S["level"]) >= 4 else 0) + (1 if int(S["level"]) >= 8 else 0) + (1 if vperk("hole") else 0))

func case_free() -> bool:
	return S["thoughts"].size() < case_slots()

func pin_thought(tid: String) -> void:
	if not case_free() or not S["loose"].has(tid):
		return
	S["loose"].erase(tid)
	S["thoughts"].append(tid)
	S["mull"][tid] = int(T("THOUGHTS")[tid].get("mull", 2))
	ledger_changed.emit()

func unpin_thought(tid: String) -> void:
	S["thoughts"].erase(tid)
	S["mull"].erase(tid)
	S["loose"].append(tid)
	ledger_changed.emit()

func cut_hole() -> void:
	if int(S["points"]) < 1 or case_slots() >= int(T("MAX_HOLES")):
		return
	S["points"] = int(S["points"]) - 1
	S["holes"] = int(S.get("holes", 2)) + 1
	ledger_changed.emit()

func mull_tick() -> void:
	var finished: Array = []
	for tid in S["mull"].keys():
		if int(S["mull"][tid]) > 0:
			S["mull"][tid] = int(S["mull"][tid]) - (2 if vperk("mull_fast") else 1)
			if int(S["mull"][tid]) <= 0:
				S["mull"].erase(tid)
				finished.append(tid)
	if finished.size():
		var names: PackedStringArray = []
		for tid in finished:
			names.append(T("THOUGHTS")[tid]["name"])
			S["vq"].append(["_th", tid, "force", ""])
		S["caseNote"] = "A thought has sunk in: " + ", ".join(names) + "."

func thought_retry(sk: String) -> Variant:
	if is_done("thrsk_" + sk):
		return null
	for tid in S.get("thoughts", []):
		var th: Variant = T("THOUGHTS").get(tid)
		if thought_done(tid) and th and th.get("bonus") is Dictionary and th["bonus"].get(sk) and not is_done("thr_" + tid):
			return tid
	return null

## Spend a skill point: "v:<voice>" trains a voice, "cap:<skill>" raises a skill's training cap.
func train(k: String) -> void:
	if int(S["points"]) < 1:
		return
	if k.begins_with("v:"):
		var v = k.substr(2)
		if not T("VOICES").has(v) or v_rank(v) >= v_cap(T("VOICES")[v]["sk"]):
			return
		S["vr"][v] = v_rank(v) + 1
	elif k.begins_with("cap:"):
		var c = k.substr(4)
		S["vcap"][c] = int(S["vcap"].get(c, 0)) + 1
	else:
		return
	S["points"] = int(S["points"]) - 1
	clamp_k("pw")
	ledger_changed.emit()

func toggle_wear(id: String) -> void:
	S["worn"][id] = not Data.truthy(S["worn"].get(id))
	if id == "hat":
		var hl: Dictionary = T("HAT_LINES")
		if S["worn"]["hat"]:
			vq_push("hat", hl.get("wear"), "force")
			if not muted_by("duty"):
				vq_push("duty", hl.get("wearDuty"), "force")
		else:
			vq_push("hat", hl.get("off"), "force")
	ledger_changed.emit()

func use_item(id: String) -> Array:
	var it: Dictionary = T("ITEMS")[id]
	if not it.get("use"):
		return []
	lose(id)
	S["done"]["used_" + id] = true
	var chips = apply_fx(Data.g(it["use"], "fx"))
	chips.push_front(chip("Used: " + it["name"], "info"))
	return chips

# ================================================================ where we are

func cur_id() -> String:
	if jsf("curId") != null:
		var r: Variant = Data.call_fn(jsf("curId"))
		return str(r) if r != null else ""
	var r: Array = S.get("route", [])
	var i = int(S.get("idx", 0))
	return str(r[i]) if i < r.size() else ""

func def(id: String) -> Variant:
	if jsf("def") != null:
		return Data.call_fn(jsf("def"), [id])
	return Data.scenes.get(id)

func is_main(id: String) -> bool:
	var sc: Variant = def(id)
	return sc != null and sc.get("kind") == "main"

func talkers() -> Array:
	if jsf("talkers") != null:
		var r: Variant = Data.call_fn(jsf("talkers"))
		return r if r is Array else []
	var id = cur_id()
	var sc: Variant = def(id)
	var out: Array = []
	if sc == null:
		return out
	for t in sc.get("talk", []):
		if t.get("when") != null and not Data.truthy(Data.call_fn(t["when"])):
			continue
		if Data.graph(id, t["id"]) == null:
			continue
		out.append(t)
	return out

func has_talked(id: String) -> bool:
	for k in S["talked"]:
		if str(k).begins_with(id + ":") and not str(k).ends_with(":met"):
			return true
	return false

## Things to look at in the current place that have something to say.
func objects() -> Array:
	var id = cur_id()
	var out: Array = []
	for o in T("OBJECTS").get(id, []):
		if Data.graph(id, "x_" + str(o["id"])) == null:
			continue
		if o.get("show") != null and not Data.truthy(Data.call_fn(o["show"])):
			continue
		out.append(o)
	return out

func build_route() -> Array:
	if jsf("buildRoute") != null:
		var r: Variant = Data.call_fn(jsf("buildRoute"))
		if r is Array:
			return r
	var skip = ["checkpoint", "cp_rider", "market"]   # these need systems not yet ported (see README)
	var pool: Array = []
	for k in Data.index.get("road", []):
		if not skip.has(k) and Data.scenes.has(k):
			pool.append(k)
	pool.shuffle()
	if S.get("vary", false):
		pool = pool.slice(0, max(4, pool.size() - 2))
	var legs: Array = [[], [], [], []]
	for i in pool.size():
		var leg: int = (i >> 1) if i < 8 else rng.randi_range(0, 3)
		legs[leg].append(pool[i])
	var r: Array = ["cross"]
	var mains = ["ford", "oak", "ridge", "malice"]
	for i in 4:
		var l: Array = legs[i]
		l.shuffle()
		r.append_array(l)
		r.append(mains[i])
	return r

func check_end() -> String:
	if jsf("checkEnd") != null:
		var r: Variant = Data.call_fn(jsf("checkEnd"))
		return str(r) if r != null else ""
	if int(S["hp"]) <= 0:
		return "death"
	if int(S["hrs"]) > dline():
		return "late"
	return ""

func past_n() -> int:
	return int(S.get("past", {}).get("n", 0))

func courier_type() -> Array:
	var t: Dictionary = S.get("tally", {})
	var order = ["loyal", "merciful", "cynical", "frightened"]
	var s = order.duplicate()
	# most-used tag first; ties keep the original order
	s.sort_custom(func(x, y): return int(t.get(x, 0)) > int(t.get(y, 0)) or (int(t.get(x, 0)) == int(t.get(y, 0)) and order.find(x) < order.find(y)))
	var a = int(t.get(s[0], 0))
	var b = int(t.get(s[1], 0))
	var C: Dictionary = T("COURIER")
	if a < 2:
		return C["grey"]
	if b >= 2 and b >= a - 1:
		var pair = [s[0], s[1]]
		pair.sort_custom(func(x, y): return order.find(x) < order.find(y))
		var key: String = pair[0] + "+" + pair[1]
		if C.has(key):
			return C[key]
	return C[s[0]]

func past_end() -> String:
	var p: Dictionary = S.get("past", { "n": 0 })
	if p.get("view"):
		for v in T("MEM")["views"]:
			if v["id"] == p["view"]:
				return v["end"]
	if int(p.get("n", 0)) >= 1:
		return "Something happened at Redoubt Nine. The ringing never quite stopped, and you never quite let it finish."
	return "Something happened at Redoubt Nine. You never let the ringing tell you what."

func road_voice() -> Array:
	var ok: Array = []
	for r in T("ROADV"):
		if Data.truthy(Data.call_fn(r[0])) and voice_on(r[1], null) and not muted_by(r[1]):
			ok.append(r)
	if ok.is_empty():
		return []
	var specific: Array = ok.filter(func(r): return r.size() < 4 or not r[3])
	var pool: Array = specific if specific.size() and rng.randf() < 0.7 else ok
	var n = int(S["done"].get("rvn", 0)) + 1
	S["done"]["rvn"] = n
	var r: Array = pool[n % pool.size()]
	if S["done"].get("rvlast") == r[2] and pool.size() > 1:
		r = pool[(n + 1) % pool.size()]
	S["done"]["rvlast"] = r[2]
	return [r[1], r[2]]

# ---------------------------------------------------------------- place-specific helpers used by the data

func cross_state() -> String:
	var o: Variant = S["out"].get("cross")
	if o == null:
		return "plain"
	var i = int(o["i"])
	var okv: bool = Data.truthy(o["ok"])
	if i == 0 and okv: return "dead"
	if i == 3 and okv: return "held"
	if i == 3 and not okv: return "burned"
	if i == 2 and not okv: return "roof"
	if i == 4: return "plain"
	return "vane"

func mare_know() -> String:
	if is_done("gseen_back_cross_karrow_horse"): return "name"
	if is_done("gseen_cross_keeper_karrow") or is_done("gseen_cross_keeper_harness"): return "told"
	if is_done("cross_harness") and is_done("cross_mare_seen"): return "self"
	if voice_val("ledger") >= 2 and is_done("cross_mare_seen"): return "skill"
	return "none"

func deliver_adj() -> Variant:
	var v = 0
	var bits: PackedStringArray = []
	for id in ["ford", "oak", "ridge"]:
		var r: Variant = S["relay"].get(id)
		var title: String = def(id)["title"]
		if r == "full":
			continue
		if r == "partial":
			v += 1; bits.append(title + " in part")
		elif r == "withheld":
			v += 2; bits.append(title + " kept back")
		else:
			v += 1; bits.append(title + " never delivered")
	if S["sealBroken"]: v += 2; bits.append("the seal is cut")
	if S["sold"]: v += 1; bits.append("one copy sold")
	if is_done("bury"): v -= 1; bits.append("the Ridge lamps signalled ahead for you")
	if is_done("colours_given"): v -= 1; bits.append("the Ridge colours in his drawer")
	if done("kw_fort") == "vouch": v -= 1; bits.append("Master Karrow spoke for you")
	if is_done("mk_hall_fort"): v -= 1; bits.append("Linden’s books in the Provost Marshal’s hands")
	if vperk("corvane"): v -= 1; bits.append("you know the orders by heart")
	if int(S["duty"]) >= 2:
		v -= 1; bits.append("your Duty speaks for you")
	elif int(S["duty"]) <= -2:
		v += 1; bits.append("your Duty is in doubt")
	v = min(v, 4)
	if v == 0:
		return null
	return { "v": v, "label": "Corvane’s questions (" + ", ".join(bits) + "), target" }

func deliver_ok() -> String:
	var full = 0
	for id in ["ford", "oak", "ridge"]:
		if S["relay"].get(id) == "full":
			full += 1
	if full == 3:
		return "You hand over the tin and give him the list without being asked: Greywater Ford, Oakhaven, the Ridge, each copy into the right hand, time and place. Corvane checks it against his own ledger and finds nothing to say. For the first time since Redoubt Nine, someone in authority looks at you as if you had done exactly what you were told."
	return "You hand over the tin. Corvane breaks what is left of the wax, reads quickly, asks after the other copies, and writes down what you tell him. He gives you a look you cannot place."

func truth_bonus() -> Dictionary:
	var v = 0
	var bits: PackedStringArray = []
	if int(S["trust"]) >= 2: v += 1; bits.append("the valley’s word")
	if is_done("ch_reg3"): v += 1; bits.append("the register read on the parade")
	if done("kw_fort") == "truth": v += 1; bits.append("Karrow’s Ashford story at the cookfires")
	return { "v": v, "label": ", ".join(bits) }

## The "pick" and "chk" builders some scenes use to add choices on the fly.
func make_pick(a: Array) -> Dictionary:
	var c = { "title": a[0], "hint": a[1], "skill": "wits", "dc": 0, "auto": func(_x): return true,
		"ok": { "text": a[2], "fx": a[3] if a.size() > 3 and a[3] != null else {}, "flags": a[4] if a.size() > 4 else null }, "bad": { "text": "", "fx": {} } }
	if a.size() > 5 and a[5] is Dictionary:
		for k in a[5]:
			c[k] = a[5][k]
	return c

func make_chk(a: Array) -> Dictionary:
	var c = { "title": a[0], "hint": a[1], "skill": a[2], "dc": a[3], "ok": { "text": a[4], "fx": a[5] }, "bad": { "text": a[6], "fx": a[7] } }
	if a.size() > 8 and a[8] is Dictionary:
		for k in a[8]:
			c[k] = a[8][k]
	return c

# ================================================================ saves
# Saves are written in the browser build's own format ({v, cp, at, where}), so a save file or a
# save code moves freely between the browser and Godot. A sync folder (Dropbox, Google Drive,
# OneDrive, iCloud...) carries the slots between devices: each slot is also written there, and
# the newer of the two copies wins when you load, as the browser does with its account copy.

var cp: Variant = null                  # the browser's CP: the checkpoint a save brings you back to
var sync_dir := ""
const SYNC_CFG := "user://sync.cfg"

func _init_sync() -> void:
	var c = ConfigFile.new()
	if c.load(SYNC_CFG) == OK:
		sync_dir = str(c.get_value("sync", "dir", ""))

func set_sync_dir(d: String) -> void:
	sync_dir = d
	var c = ConfigFile.new()
	c.set_value("sync", "dir", d)
	c.save(SYNC_CFG)
	if d != "":
		# put what is here into the folder too, so the other device sees it
		for i in range(0, SAVE_SLOTS + 1):
			var loc: Variant = _read_file(_local_path(i))
			var far: Variant = _read_file(_sync_path(i))
			if loc is Dictionary and _newest(loc, far) == loc:
				_write_file(_sync_path(i), JSON.stringify(loc))

## The browser's snap(kind): remember where a loaded save should pick up.
func snap(kind: String) -> void:
	var scx: Variant = Data.js.globals.vars.get("SCX")
	if Data.truthy(scx):
		kind = "revisit"
	var legs: Variant = Data.js.globals.vars.get("backLegs")
	cp = { "kind": kind, "s": JSON.stringify(S), "rv": Data.js.globals.vars.get("curRevisit"), "legs": legs if legs != null else 0 }
	# the game saves itself at every scene, stop and road leg (the browser's autoSave)
	var txt = JSON.stringify(cp)
	if txt != _auto_last and S.get("route", []).size() and not Data.truthy(S.get("practice")):
		_auto_last = txt
		save_slot(0)

var _auto_last := ""

func where_label() -> String:
	if not (cp is Dictionary):
		return ""
	var s: Variant = JSON.parse_string(str(cp.s))
	if not (s is Dictionary):
		return ""
	var r: Array = s.get("route", [])
	var i = int(s.get("idx", 0))
	var d: Variant = def(str(r[i])) if i < r.size() else null
	return (str(d.title) if d is Dictionary else "") + " · hour " + str(int(s.get("hrs", 0))) + " · Lv " + str(int(s.get("level", 1))) + (" · Hardcore" if Data.truthy(s.get("hard")) else "")

## The browser's packSave().
func pack_save() -> String:
	if not (cp is Dictionary):
		snap("scene")
	return JSON.stringify({ "v": 1, "cp": cp, "at": int(Time.get_unix_time_from_system() * 1000.0), "where": where_label() })

## A save code is the save itself in base64, the same as the browser's.
func save_code() -> String:
	return Marshalls.utf8_to_base64(pack_save())

## Read a save file's text or a save code into a pack ({v, cp, at, where}); null if it is not one.
func read_pack(txt: String) -> Variant:
	var j = txt.strip_edges()
	if not j.begins_with("{"):
		j = Marshalls.base64_to_utf8(j.replace("\n", "").replace(" ", ""))
	var p: Variant = JSON.parse_string(j)
	if not (p is Dictionary):
		return null
	if p.get("s") is Dictionary and not p.has("cp"):
		# an older Godot save
		return { "v": 1, "cp": { "kind": "scene", "s": JSON.stringify(p.s), "rv": null, "legs": 0 }, "at": 0, "where": str(p.get("where", "")) }
	if not (p.get("cp") is Dictionary) or typeof(p.cp.get("s")) != TYPE_STRING:
		return null
	return p

## The browser's loadPack, minus the screen: puts the save's state in place and returns its cp.
func apply_pack(p: Variant) -> Variant:
	if not (p is Dictionary):
		return null
	var s: Variant = JSON.parse_string(str(p.cp.s))
	if not (s is Dictionary) or not (s.get("route") is Array) or not (typeof(s.get("hp")) in [TYPE_INT, TYPE_FLOAT]):
		return null
	s = _ints(s)
	var fresh = new_state()
	for k in ["temp", "talked", "learned", "perc", "worn", "assessed", "thoughts", "loose", "mull", "tally", "side", "past", "vq"]:
		if s.get(k) == null and fresh.has(k):
			s[k] = fresh[k]
	if s.get("holes") == null:
		var lv = int(s.get("level", 1))
		s["holes"] = 2 + (1 if lv >= 3 else 0) + (1 if lv >= 5 else 0)
	set_state(s)
	cp = p.cp.duplicate()
	cp.s = JSON.stringify(S)
	if typeof(cp.get("legs")) in [TYPE_INT, TYPE_FLOAT]:
		Data.js.set_global("backLegs", int(cp.legs))
	return cp

func _local_path(slot: int) -> String:
	return "user://save_%d.json" % slot

func _sync_path(slot: int) -> String:
	return sync_dir.path_join("postal-trace-" + ("auto" if slot == 0 else "slot%d" % slot) + ".json")

func _read_file(path: String) -> Variant:
	if path == "" or not FileAccess.file_exists(path):
		return null
	return read_pack(FileAccess.get_file_as_string(path))

func _write_file(path: String, txt: String) -> bool:
	var f = FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(txt)
	return true

static func _newest(a: Variant, b: Variant) -> Variant:
	if not (a is Dictionary):
		return b if b is Dictionary else null
	if not (b is Dictionary):
		return a
	return b if float(b.get("at", 0)) > float(a.get("at", 0)) else a

func save_slot(slot: int, _where := "") -> bool:
	var txt = pack_save()
	var ok = _write_file(_local_path(slot), txt)
	if sync_dir != "":
		ok = _write_file(_sync_path(slot), txt) or ok
	return ok

## The newer of the slot here and its copy in the sync folder.
func read_slot(slot: int) -> Variant:
	var p: Variant = _newest(_read_file(_local_path(slot)), _read_file(_sync_path(slot)) if sync_dir != "" else null)
	if p is Dictionary:
		p["when"] = when_label(float(p.get("at", 0)))
	return p

func load_slot(slot: int) -> Variant:
	return apply_pack(read_slot(slot))

# ---------------------------------------------------------------- every save in one file
# The browser's "Save all saves to one file": the autosave and every slot together, to carry them to
# another device or between the browser and Godot in one go. Opening it under Load game puts each save
# back in its own slot; a slot that already holds a newer save keeps it.

func pack_all() -> Dictionary:
	var o = { "game": "The Postal Trace", "kind": "saves", "v": 1, "at": int(Time.get_unix_time_from_system() * 1000.0), "saves": {} }
	for i in range(0, SAVE_SLOTS + 1):
		var p: Variant = read_slot(i)
		if p is Dictionary:
			p = p.duplicate()
			p.erase("when")
			o.saves["auto" if i == 0 else str(i)] = p
	return o

func save_all_file(path: String) -> int:
	var o = pack_all()
	if o.saves.is_empty() or not _write_file(path, JSON.stringify(o)):
		return 0
	return o.saves.size()

## null when the text is not an all-saves file; else {put, kept}.
func load_all_text(txt: String) -> Variant:
	var j: Variant = JSON.parse_string(txt)
	if not (j is Dictionary) or str(j.get("kind", "")) != "saves" or not (j.get("saves") is Dictionary):
		return null
	var put = 0
	var kept = 0
	for k in j.saves:
		var n = 0 if str(k) == "auto" else (int(k) if str(k).is_valid_int() else -1)
		if n < 0 or n > SAVE_SLOTS:
			continue
		var p: Variant = j.saves[k]
		if not (p is Dictionary) or not (p.get("cp") is Dictionary) or typeof(p.cp.get("s")) != TYPE_STRING:
			continue
		var cur: Variant = read_slot(n)
		if cur is Dictionary and float(cur.get("at", 0)) >= float(p.get("at", 0)):
			kept += 1
			continue
		var t = JSON.stringify(p)
		var ok = _write_file(_local_path(n), t)
		if sync_dir != "":
			ok = _write_file(_sync_path(n), t) or ok
		if ok:
			put += 1
	return { "put": put, "kept": kept }

func save_file(path: String) -> bool:
	return _write_file(path, pack_save())

func file_name() -> String:
	var w = where_label() if where_label() != "" else "save"
	var re = RegEx.create_from_string("[^A-Za-z0-9]+")
	w = re.sub(w, "-", true).trim_prefix("-").trim_suffix("-").to_lower().left(40)
	return "postal-trace-" + w + ".json"

static func when_label(ms: float) -> String:
	if ms <= 0:
		return ""
	var bias = Time.get_time_zone_from_system().get("bias", 0)
	var d = Time.get_datetime_dict_from_unix_time(int(ms / 1000.0) + int(bias) * 60)
	return "%d/%d/%d %02d:%02d" % [d.month, d.day, d.year, d.hour, d.minute]

func _ints(v: Variant) -> Variant:
	if v is Dictionary:
		for k in v.keys():
			v[k] = _ints(v[k])
	elif v is Array:
		for i in v.size():
			v[i] = _ints(v[i])
	elif typeof(v) == TYPE_FLOAT and v == floor(v) and abs(v) < 1e12:
		return int(v)
	return v

# ================================================================ helpers the data logic can call

func _register_helpers() -> void:
	# The game's own functions come from data/lib.json (see data.gd). Here are only the state
	# object and the parts of JavaScript itself that the logic uses.
	var j: JsLite = Data.js
	j.set_global("S", S)
	j.set_global("parseInt", func(a): return int(JsLite.to_num(str(a[0]).to_int() if typeof(a[0]) == TYPE_STRING else a[0])))
	j.set_global("parseFloat", func(a): return float(JsLite.to_num(a[0])))
	j.set_global("isFinite", func(a): return is_finite(float(JsLite.to_num(a[0]))))
	j.set_global("isNaN", func(a): return is_nan(float(JsLite.to_num(a[0]))))
	j.set_global("String", func(a): return JsLite.to_str(a[0]) if a.size() else "")
	j.set_global("Number", func(a): return JsLite.to_num(a[0]) if a.size() else 0)
	j.set_global("Boolean", func(a): return a.size() > 0 and JsLite.truthy(a[0]))
	j.set_global("encodeURIComponent", func(a): return str(a[0]).uri_encode())
	j.set_global("Math", {
		"min": func(a): return _js_min(a),
		"max": func(a): return _js_max(a),
		"floor": func(a): return int(floor(float(JsLite.to_num(a[0])))),
		"ceil": func(a): return int(ceil(float(JsLite.to_num(a[0])))),
		"round": func(a): return int(floor(float(JsLite.to_num(a[0])) + 0.5)),
		"abs": func(a): return abs(JsLite.to_num(a[0])),
		"sign": func(a): return sign(JsLite.to_num(a[0])),
		"sqrt": func(a): return sqrt(float(JsLite.to_num(a[0]))),
		"pow": func(a): return pow(float(JsLite.to_num(a[0])), float(JsLite.to_num(a[1]))),
		"random": func(_a): return rng.randf(),
		"PI": PI,
	})
	j.set_global("Object", { "keys": func(a): return a[0].keys() if a[0] is Dictionary else [],
		"values": func(a): return a[0].values() if a[0] is Dictionary else [],
		"assign": func(a):
			var t: Variant = a[0]
			for i in range(1, a.size()):
				if a[i] is Dictionary and t is Dictionary:
					t.merge(a[i], true)
			return t,
		"defineProperty": func(a):
			var d: Variant = a[2] if a.size() > 2 else {}
			if a[0] is Dictionary and d is Dictionary:
				if d.get("get") is JsLite.JsFn:
					var g: JsLite.JsFn = d.get
					g.getter = true
					a[0][str(a[1])] = g
				elif d.has("value"):
					a[0][str(a[1])] = d.value
			return a[0] })
	j.set_global("Array", { "isArray": func(a): return a[0] is Array, "from": func(a): return (a[0] as Array).duplicate() if a[0] is Array else [] })
	j.set_global("JSON", { "parse": func(a): return _ints(JSON.parse_string(str(a[0]))), "stringify": func(a): return JSON.stringify(_plain(a[0])) })
	j.set_global("Date", { "now": func(_a): return int(Time.get_unix_time_from_system() * 1000) })
	j.set_global("console", { "log": func(a): print("[js] ", a); return null, "warn": func(a): print("[js] ", a); return null, "error": func(a): push_warning("[js] " + str(a)); return null })

## JSON-safe copy (drops functions).
static func _plain(v: Variant) -> Variant:
	if v is Dictionary:
		var d := {}
		for k in v:
			if not (v[k] is Callable or v[k] is Object):
				d[k] = _plain(v[k])
		return d
	if v is Array:
		var a := []
		for x in v:
			a.append(null if x is Callable or x is Object else _plain(x))
		return a
	return v

static func _js_min(a: Array) -> Variant:
	var m: Variant = INF
	for x in a:
		m = min(m, JsLite.to_num(x))
	return m

static func _js_max(a: Array) -> Variant:
	var m: Variant = -INF
	for x in a:
		m = max(m, JsLite.to_num(x))
	return m
