## Html: a very small stand-in for the browser page, so the browser version's own screen
## code can run in Godot unchanged.
##
## The game logic builds screens as HTML strings and then wires them up with
## screen.querySelectorAll(...) and addEventListener('click', ...). Html.parse() turns the
## string into Element objects that answer those calls; main.gd draws them as Godot widgets
## and runs the listeners when a button is pressed.
class_name Html
extends RefCounted

const VOID := ["br", "img", "input", "hr", "meta", "link", "source", "wbr"]
const INLINE := ["span", "b", "strong", "i", "em", "small", "kbd", "a", "code", "label", "u", "s", "sup", "sub", "#text", "img", "br"]

class Element extends RefCounted:
	var tag := ""
	var attrs: Dictionary = {}
	var children: Array = []
	var text := ""                 # for #text nodes
	var _parent: WeakRef = null
	var listeners: Dictionary = {} # type -> [fn]
	var props: Dictionary = {}     # anything the logic sets on it (style, value, hidden...)
	var widget: Control = null     # what main.gd drew for it

	func parent() -> Element:
		return _parent.get_ref() if _parent else null

	func classes() -> PackedStringArray:
		return str(attrs.get("class", "")).split(" ", false)

	func has_class(c: String) -> bool:
		return c in classes()

	func text_content() -> String:
		if tag == "#text":
			return text
		var out := ""
		for c in children:
			out += c.text_content()
		return out

	func each(fn: Callable) -> void:
		for c in children:
			if c.tag != "#text":
				fn.call(c)
				c.each(fn)

	# ---- the part the JavaScript sees
	func js_get(key: String) -> Variant:
		match key:
			"getAttribute": return func(a): return attrs.get(str(a[0]))
			"setAttribute": return func(a): attrs[str(a[0])] = str(a[1]); return null
			"hasAttribute": return func(a): return attrs.has(str(a[0]))
			"removeAttribute": return func(a): attrs.erase(str(a[0])); return null
			"addEventListener": return func(a):
				var t := str(a[0])
				if not listeners.has(t):
					listeners[t] = []
				listeners[t].append(a[1])
				return null
			"removeEventListener", "focus", "blur", "scrollIntoView", "insertBefore", "appendChild", "removeChild", "remove", "setPointerCapture":
				return func(_a): return null
			"click": return func(_a): fire("click"); return null
			"querySelector": return func(a): var l := Html.query(self, str(a[0])); return l[0] if l.size() else null
			"querySelectorAll": return func(a): return Html.query(self, str(a[0]))
			"closest": return func(a):
				var e: Element = self
				while e:
					if Html.matches(e, str(a[0])):
						return e
					e = e.parent()
				return null
			"cloneNode": return func(_a): return self
			"classList": return { "contains": func(a): return has_class(str(a[0])),
				"add": func(a): _class_set(str(a[0]), true); return null,
				"remove": func(a): _class_set(str(a[0]), false); return null,
				"toggle": func(a): _class_set(str(a[0]), not has_class(str(a[0])) if a.size() < 2 else JsLite.truthy(a[1])); return null }
			"textContent", "innerText": return text_content()
			"tagName", "nodeName": return tag.to_upper()
			"id": return attrs.get("id", "")
			"className": return attrs.get("class", "")
			"disabled": return attrs.has("disabled")
			"hidden": return props.get("hidden", attrs.has("hidden"))
			"value": return props.get("value", attrs.get("value", ""))
			"checked": return props.get("checked", attrs.has("checked"))
			"children": return children.filter(func(c): return c.tag != "#text")
			"firstChild", "firstElementChild": return children[0] if children.size() else null
			"parentNode", "parentElement": return parent()
			"dataset":
				var d := {}
				for k in attrs:
					if str(k).begins_with("data-"):
						d[str(k).substr(5)] = attrs[k]
				return d
			"style":
				if not props.has("style"):
					props.style = {}
				return props.style
			"offsetWidth", "offsetHeight", "scrollTop", "scrollHeight", "clientHeight": return 0
			"getBoundingClientRect": return func(_a): return { "left": 0, "top": 0, "width": 0, "height": 0, "right": 0, "bottom": 0 }
		return props.get(key)

	func js_set(key: String, v: Variant) -> void:
		match key:
			"disabled":
				if JsLite.truthy(v): attrs["disabled"] = ""
				else: attrs.erase("disabled")
			"className":
				attrs["class"] = str(v)
			"textContent", "innerText":
				var t := Element.new()
				t.tag = "#text"
				t.text = str(v)
				children = [t]
			_:
				props[key] = v

	func _class_set(c: String, on: bool) -> void:
		var l := classes()
		if on and not c in l:
			l.append(c)
		elif not on:
			var i := l.find(c)
			if i >= 0:
				l.remove_at(i)
		attrs["class"] = " ".join(l)

	## Run this element's listeners (a click on its widget).
	func fire(type: String) -> void:
		var ev := { "target": self, "currentTarget": self, "type": type,
			"preventDefault": func(_a): return null, "stopPropagation": func(_a): return null }
		var data: Node = (Engine.get_main_loop() as SceneTree).root.get_node("Data")
		for fn in listeners.get(type, []).duplicate():
			data.js.call_fn(fn, [ev], self)

# ================================================================ parsing

static func unescape(t: String) -> String:
	if t.find("&") < 0:
		return t
	return t.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ").replace("&mdash;", "—").replace("&ndash;", "–").replace("&amp;", "&")

static func escape(t: String) -> String:
	return t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

static func parse(src: String) -> Element:
	var root := Element.new()
	root.tag = "root"
	var stack: Array = [root]
	var re := RegEx.create_from_string("<!--[\\s\\S]*?-->|<(/?)([a-zA-Z][a-zA-Z0-9]*)((?:\\s+[^\\s=>/]+(?:\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[^\\s>]+))?)*)\\s*(/?)>")
	var are := RegEx.create_from_string("([^\\s=>/]+)(?:\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+)))?")
	var pos := 0
	for m in re.search_all(src):
		if m.get_start() > pos:
			_text(stack.back(), src.substr(pos, m.get_start() - pos))
		pos = m.get_end()
		if m.get_string(2) == "":
			continue   # a comment
		var tag := m.get_string(2).to_lower()
		if m.get_string(1) == "/":
			for i in range(stack.size() - 1, 0, -1):
				if stack[i].tag == tag:
					stack.resize(i)
					break
			continue
		var el := Element.new()
		el.tag = tag
		for a in are.search_all(m.get_string(3)):
			var v := a.get_string(2) if a.get_string(2) != "" else (a.get_string(3) if a.get_string(3) != "" else a.get_string(4))
			el.attrs[a.get_string(1).to_lower()] = unescape(v)
		var top: Element = stack.back()
		el._parent = weakref(top)
		top.children.append(el)
		if not (tag in VOID) and m.get_string(4) != "/":
			stack.append(el)
	if pos < src.length():
		_text(stack.back(), src.substr(pos))
	return root

static func _text(parent: Element, t: String) -> void:
	if t == "":
		return
	var e := Element.new()
	e.tag = "#text"
	e.text = unescape(t)
	e._parent = weakref(parent)
	parent.children.append(e)

# ================================================================ selectors

## Elements under root matching a CSS selector (tag, #id, .class, [attr], [attr="v"],
## :not(...), descendant and child combinators, comma lists).
static func query(root: Element, sel: String) -> Array:
	var out: Array = []
	var parts := sel.split(",")
	root.each(func(e):
		for p in parts:
			if matches(e, p.strip_edges()):
				out.append(e)
				break)
	return out

static func matches(e: Element, sel: String) -> bool:
	var steps := _split_steps(sel)
	if steps.is_empty():
		return false
	if not _simple(e, steps[steps.size() - 1]):
		return false
	var cur: Element = e.parent()
	var i := steps.size() - 2
	while i >= 0:
		var found := false
		while cur and cur.tag != "root":
			if _simple(cur, steps[i]):
				found = true
				cur = cur.parent()
				break
			cur = cur.parent()
		if not found:
			return false
		i -= 1
	return true

static func _split_steps(sel: String) -> PackedStringArray:
	var out: PackedStringArray = []
	var cur := ""
	var depth := 0
	for ch in sel.replace(">", " "):
		if ch == "[" or ch == "(":
			depth += 1
		elif ch == "]" or ch == ")":
			depth -= 1
		if ch == " " and depth == 0:
			if cur != "":
				out.append(cur)
			cur = ""
		else:
			cur += ch
	if cur != "":
		out.append(cur)
	return out

static func _simple(e: Element, s: String) -> bool:
	if e.tag == "#text":
		return false
	var re := RegEx.create_from_string("^([a-zA-Z][a-zA-Z0-9]*|\\*)|#([\\w-]+)|\\.([\\w-]+)|\\[([\\w-]+)(?:([\\^$*~]?=)\"?([^\"\\]]*)\"?)?\\]|:not\\(((?:[^()]|\\([^()]*\\))*)\\)|:([\\w-]+)")
	var pos := 0
	for m in re.search_all(s):
		if m.get_start() != pos:
			return false
		pos = m.get_end()
		if m.get_string(1) != "":
			var t := m.get_string(1).to_lower()
			if t != "*" and t != e.tag:
				return false
		elif m.get_string(2) != "":
			if str(e.attrs.get("id", "")) != m.get_string(2):
				return false
		elif m.get_string(3) != "":
			if not e.has_class(m.get_string(3)):
				return false
		elif m.get_string(4) != "":
			var a := m.get_string(4)
			if not e.attrs.has(a):
				return false
			var op := m.get_string(5)
			var want := m.get_string(6)
			var have := str(e.attrs[a])
			match op:
				"=": if have != want: return false
				"^=": if not have.begins_with(want): return false
				"$=": if not have.ends_with(want): return false
				"*=": if have.find(want) < 0: return false
				"~=": if not want in have.split(" "): return false
		elif m.get_start(7) >= 0 and m.get_end(7) >= m.get_start(7) and s.substr(m.get_start(), 5) == ":not(":
			if _simple(e, m.get_string(7)):
				return false
		# other pseudo-classes (:first-child...) are ignored
	return pos == s.length()
