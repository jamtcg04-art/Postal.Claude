## JsLite: a small interpreter for the JavaScript snippets kept in the game data.
##
## The original game stores conditions and effects as JavaScript functions, e.g.
##   "show": {"$js": "function () { return !S.done.vane_scorn; }"}
## This class parses and runs that subset (expressions, var, if, return, blocks,
## simple loops, object and array literals, nested functions) against the live
## game state. Unknown helper names evaluate to null and are reported once.
class_name JsLite
extends RefCounted

# ---------------------------------------------------------------- values

class JsFn extends RefCounted:
	var name: String = ""
	var params: Array = []
	var body: Array = []          # list of statements
	var env: Env = null           # closure
	var src: String = ""          # original source, for editing / debugging
	var getter := false
	var parsed := false
	var raw_env: Dictionary = {}  # captured closure values from the export

class Env extends RefCounted:
	var vars: Dictionary = {}
	var parent: Env = null
	func _init(p: Env = null) -> void:
		parent = p
	func lookup(n: String) -> Env:
		var e: Env = self
		while e != null:
			if e.vars.has(n):
				return e
			e = e.parent
		return null

class JsRegex extends RefCounted:
	var re: RegEx
	var source: String
	var flags: String

const RET := 1
const BRK := 2
const CONT := 3

var globals: Env = Env.new()
var warned: Dictionary = {}
var _ret: Variant = null
var _cache: Dictionary = {}   # src -> [params, body, name]
var fallback: Callable          # name -> value, for names nothing defines (set by Bridge)

# ---------------------------------------------------------------- public API

## Wrap a {"$js": src, "$env": {...}} dictionary from the data files.
func make_fn(d: Dictionary) -> JsFn:
	var f := JsFn.new()
	f.src = str(d.get("$js", ""))
	f.getter = bool(d.get("$get", false))
	f.raw_env = d.get("$env", {}) if d.get("$env") is Dictionary else {}
	f.env = globals
	return f

## Call a function value (JsFn or Callable) with arguments.
func call_fn(f: Variant, args: Array = [], this_val: Variant = null) -> Variant:
	if f is JsFn:
		return _invoke(f, args, this_val)
	if f is Callable:
		return (f as Callable).call(args)
	return null

## Evaluate a value the way the game's nodeVal() does: call it if it is a function.
func val(v: Variant) -> Variant:
	if v is JsFn:
		return _invoke(v, [], null)
	return v

func set_global(n: String, v: Variant) -> void:
	globals.vars[n] = v

## Parse a source string without running it. Returns "" on success, else the error.
func check(src: String) -> String:
	var p := _Parser.new(src)
	p.parse_function_source()
	return p.error

# ---------------------------------------------------------------- invoke

func _ensure_parsed(f: JsFn) -> bool:
	if f.parsed:
		return true
	if _cache.has(f.src):
		var c: Array = _cache[f.src]
		f.params = c[0]; f.body = c[1]; f.name = c[2]
	else:
		var p := _Parser.new(f.src)
		var r: Array = p.parse_function_source()
		if p.error != "":
			_warn("parse:" + f.src.substr(0, 60), "JsLite parse error: " + p.error + " in: " + f.src.substr(0, 120))
			return false
		f.params = r[0]; f.body = r[1]; f.name = r[2]
		_cache[f.src] = [f.params, f.body, f.name]
	if not f.raw_env.is_empty():
		var e := Env.new(f.env)
		for k in f.raw_env:
			e.vars[k] = _wrap_data(f.raw_env[k])
		f.env = e
	f.parsed = true
	return true

## Captured values become live: functions and patterns nested inside captured objects too (the market's
## "walk out" choice keeps its auto() inside an object, and read as a plain object it never counted as no-roll).
func _wrap_data(v: Variant) -> Variant:
	if v is Dictionary:
		if v.has("$js"):
			return make_fn(v)
		if v.has("$re"):
			return make_regex(str(v["$re"]), str(v.get("flags", "")))
		if _has_fn(v):
			var out: Dictionary = {}
			for k in v:
				out[k] = _wrap_data(v[k])
			return out
	elif v is Array and _has_fn(v):
		return v.map(func(x): return _wrap_data(x))
	return v

func _has_fn(v: Variant) -> bool:
	if v is Dictionary:
		if v.has("$js") or v.has("$re"):
			return true
		for k in v:
			if _has_fn(v[k]):
				return true
	elif v is Array:
		for x in v:
			if _has_fn(x):
				return true
	return false

func _invoke(f: JsFn, args: Array, this_val: Variant) -> Variant:
	if not _ensure_parsed(f):
		return null
	var e := Env.new(f.env)
	for i in f.params.size():
		e.vars[f.params[i]] = args[i] if i < args.size() else null
	e.vars["this"] = this_val
	e.vars["arguments"] = args
	if f.name != "" and not e.vars.has(f.name):
		e.vars[f.name] = f
	_ret = null
	var code := _exec_list(f.body, e)
	var out: Variant = _ret if code == RET else null
	_ret = null
	return out

# ---------------------------------------------------------------- statements

func _exec_list(list: Array, e: Env) -> int:
	# hoist nested function declarations
	for s in list:
		if s[0] == "fndecl":
			var fn := _closure(s[2], e)
			e.vars[s[1]] = fn
	for s in list:
		var c := _exec(s, e)
		if c != 0:
			return c
	return 0

func _exec(s: Array, e: Env) -> int:
	match s[0]:
		"exp":
			_eval(s[1], e)
		"var":
			for d in s[1]:
				e.vars[d[0]] = _eval(d[1], e) if d[1] != null else null
		"ret":
			_ret = _eval(s[1], e) if s[1] != null else null
			return RET
		"if":
			if truthy(_eval(s[1], e)):
				return _exec(s[2], e)
			elif s[3] != null:
				return _exec(s[3], e)
		"blk":
			return _exec_list(s[1], e)
		"for":
			if s[1] != null:
				if s[1][0] in ["var", "exp"]:
					_exec(s[1], e)
			var guard := 0
			while s[2] == null or truthy(_eval(s[2], e)):
				var c := _exec(s[4], e)
				if c == RET:
					return RET
				if c == BRK:
					break
				if s[3] != null:
					_eval(s[3], e)
				guard += 1
				if guard > 100000:
					break
		"forin":
			var obj: Variant = _eval(s[2], e)
			var keys: Array = []
			if obj is Dictionary:
				keys = obj.keys()
			elif obj is Array:
				for i in obj.size():
					keys.append(str(i))
			for k in keys:
				_assign_name(s[1], k, e, true)
				var c := _exec(s[3], e)
				if c == RET:
					return RET
				if c == BRK:
					break
		"while":
			var guard := 0
			while truthy(_eval(s[1], e)):
				var c := _exec(s[2], e)
				if c == RET:
					return RET
				if c == BRK:
					break
				guard += 1
				if guard > 100000:
					break
		"brk":
			return BRK
		"cont":
			return CONT
		"try":
			var c := _exec(s[1], e)
			if c != 0:
				return c
		"fndecl", "nop", "throw":
			pass
	return 0

# ---------------------------------------------------------------- expressions

func _closure(node: Array, e: Env) -> JsFn:
	var f := JsFn.new()
	f.name = node[1]
	f.params = node[2]
	f.body = node[3]
	f.env = e
	f.parsed = true
	return f

func _eval(n: Variant, e: Env) -> Variant:
	if n == null:
		return null
	match n[0]:
		"num", "str", "lit":
			return n[1]
		"id":
			var nm: String = n[1]
			if nm == "undefined":
				return null
			var where := e.lookup(nm)
			if where != null:
				return where.vars[nm]
			if fallback.is_valid():
				var fb: Variant = fallback.call(nm)
				if fb != null:
					return fb
			_warn("id:" + nm, "JsLite: unknown name '" + nm + "' (treated as null)")
			return null
		"re":
			return make_regex(n[1], n[2])
		"arr":
			var out: Array = []
			for x in n[1]:
				out.append(_eval(x, e))
			return out
		"obj":
			var d: Dictionary = {}
			for kv in n[1]:
				d[kv[0]] = _eval(kv[1], e)
			return d
		"fn":
			return _closure(n, e)
		"mem":
			var o: Variant = _eval(n[1], e)
			var key: Variant = _eval(n[2], e) if n[3] else n[2]
			return get_prop(o, key)
		"call":
			return _eval_call(n, e)
		"new":
			return _new(n, e)
		"un":
			return _unary(n[1], n[2], e)
		"upd":
			var old_v := to_num(_eval(n[3], e))
			var nv: Variant = old_v + (1 if n[1] == "++" else -1)
			_assign_to(n[3], nv, e)
			return nv if n[2] else old_v
		"bin":
			return binop(n[1], _eval(n[2], e), _eval(n[3], e))
		"log":
			var a: Variant = _eval(n[2], e)
			match n[1]:
				"&&":
					return _eval(n[3], e) if truthy(a) else a
				"||":
					return a if truthy(a) else _eval(n[3], e)
				"??":
					return a if a != null else _eval(n[3], e)
		"cond":
			return _eval(n[2], e) if truthy(_eval(n[1], e)) else _eval(n[3], e)
		"asg":
			var v: Variant = _eval(n[3], e)
			if n[1] != "=":
				v = binop(n[1].substr(0, n[1].length() - 1), _eval(n[2], e), v)
			_assign_to(n[2], v, e)
			return v
		"seq":
			var last: Variant = null
			for x in n[1]:
				last = _eval(x, e)
			return last
	return null

## The few constructors the game uses.
func _new(n: Array, e: Env) -> Variant:
	var args: Array = []
	for a in n[2]:
		args.append(_eval(a, e))
	var nm: String = n[1][1] if n[1][0] == "id" else ""
	match nm:
		"RegExp":
			var src: Variant = args[0] if args.size() else ""
			if src is JsRegex:
				return make_regex(src.source, str(args[1]) if args.size() > 1 else src.flags)
			return make_regex(to_str(src), str(args[1]) if args.size() > 1 and args[1] != null else "")
		"Date":
			var ms := int(Time.get_unix_time_from_system() * 1000)
			return { "getTime": func(_a): return ms, "valueOf": func(_a): return ms }
		"Error":
			return { "message": to_str(args[0]) if args.size() else "" }
		"Array":
			var arr: Array = []
			if args.size() == 1 and _is_num(args[0]):
				arr.resize(int(args[0]))
			else:
				arr = args
			return arr
		"Object":
			return {}
		"Set":
			return _make_set(args[0] if args.size() and args[0] is Array else [])
	var f: Variant = _eval(n[1], e)
	if f is JsFn:
		var obj := {}
		var r: Variant = _invoke(f, args, obj)
		return r if r is Dictionary else obj
	return {}

func _make_set(init: Array) -> Dictionary:
	var items: Dictionary = {}
	for x in init:
		items[x] = true
	var d := { "_set": items }
	d["has"] = func(a): return items.has(a[0])
	d["add"] = func(a): items[a[0]] = true; return null
	d["delete"] = func(a): return items.erase(a[0])
	return d

func _unary(op: String, x: Array, e: Env) -> Variant:
	match op:
		"!":
			return not truthy(_eval(x, e))
		"-":
			return -to_num(_eval(x, e))
		"+":
			return to_num(_eval(x, e))
		"typeof":
			var v: Variant
			if x[0] == "id" and e.lookup(x[1]) == null:
				return "undefined"
			v = _eval(x, e)
			return type_of(v)
		"void":
			_eval(x, e)
			return null
		"delete":
			if x[0] == "mem":
				var o: Variant = _eval(x[1], e)
				var key: Variant = _eval(x[2], e) if x[3] else x[2]
				if o is Dictionary:
					o.erase(_key(key))
			return true
	return null

func _assign_to(target: Array, v: Variant, e: Env) -> void:
	if target[0] == "id":
		_assign_name(target[1], v, e, false)
	elif target[0] == "mem":
		var o: Variant = _eval(target[1], e)
		var key: Variant = _eval(target[2], e) if target[3] else target[2]
		set_prop(o, key, v)

func _assign_name(nm: String, v: Variant, e: Env, local: bool) -> void:
	var where := e.lookup(nm)
	if where == null or local and where != e:
		where = e if local else globals
	where.vars[nm] = v

func _eval_call(n: Array, e: Env) -> Variant:
	var callee: Array = n[1]
	var args: Array = []
	for a in n[2]:
		args.append(_eval(a, e))
	if callee[0] == "mem":
		var o: Variant = _eval(callee[1], e)
		var key: Variant = _eval(callee[2], e) if callee[3] else callee[2]
		var r: Array = _builtin_method(o, str(key), args)
		if r.size() > 0:
			return r[0]
		var f: Variant = get_prop(o, key)
		if f == null:
			_warn("m:" + str(key), "JsLite: no method '" + str(key) + "' (treated as null)")
			return null
		return call_fn(f, args, o)
	var fv: Variant = _eval(callee, e)
	if fv == null:
		if callee[0] == "id":
			_warn("f:" + str(callee[1]), "JsLite: no helper '" + str(callee[1]) + "()' (returns null)")
		return null
	return call_fn(fv, args, null)

# ---------------------------------------------------------------- semantics

static func truthy(v: Variant) -> bool:
	if v == null:
		return false
	match typeof(v):
		TYPE_BOOL:
			return v
		TYPE_INT:
			return v != 0
		TYPE_FLOAT:
			return v != 0.0 and not is_nan(v)
		TYPE_STRING, TYPE_STRING_NAME:
			return str(v) != ""
	return true

static func to_num(v: Variant) -> Variant:
	match typeof(v):
		TYPE_INT, TYPE_FLOAT:
			return v
		TYPE_BOOL:
			return 1 if v else 0
		TYPE_NIL:
			return 0
		TYPE_STRING, TYPE_STRING_NAME:
			var s := str(v).strip_edges()
			if s == "":
				return 0
			if s.is_valid_int():
				return s.to_int()
			if s.is_valid_float():
				return s.to_float()
			return NAN
	return NAN

static func num_str(v: Variant) -> String:
	if typeof(v) == TYPE_FLOAT:
		if is_nan(v):
			return "NaN"
		if v == floor(v) and abs(v) < 1e15:
			return str(int(v))
	return str(v)

static func to_str(v: Variant) -> String:
	match typeof(v):
		TYPE_NIL:
			return "undefined"
		TYPE_BOOL:
			return "true" if v else "false"
		TYPE_INT, TYPE_FLOAT:
			return num_str(v)
		TYPE_ARRAY:
			var parts: PackedStringArray = []
			for x in v:
				parts.append("" if x == null else to_str(x))
			return ",".join(parts)
		TYPE_DICTIONARY:
			return "[object Object]"
	return str(v)

static func type_of(v: Variant) -> String:
	match typeof(v):
		TYPE_NIL:
			return "undefined"
		TYPE_BOOL:
			return "boolean"
		TYPE_INT, TYPE_FLOAT:
			return "number"
		TYPE_STRING, TYPE_STRING_NAME:
			return "string"
		TYPE_CALLABLE:
			return "function"
	if v is JsFn:
		return "function"
	return "object"

static func _is_num(v: Variant) -> bool:
	return typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT

static func strict_eq(a: Variant, b: Variant) -> bool:
	if _is_num(a) and _is_num(b):
		return float(a) == float(b)
	if typeof(a) == TYPE_STRING_NAME:
		a = str(a)
	if typeof(b) == TYPE_STRING_NAME:
		b = str(b)
	if typeof(a) != typeof(b):
		return false
	if a is Array or a is Dictionary or a is Object:
		return is_same(a, b)
	return a == b

static func loose_eq(a: Variant, b: Variant) -> bool:
	if a == null and b == null:
		return true
	if a == null or b == null:
		return false
	if (_is_num(a) or typeof(a) == TYPE_BOOL) and (typeof(b) in [TYPE_STRING, TYPE_BOOL] or _is_num(b)) \
			or (_is_num(b) or typeof(b) == TYPE_BOOL) and typeof(a) == TYPE_STRING:
		if typeof(a) != typeof(b):
			return float(to_num(a)) == float(to_num(b))
	return strict_eq(a, b)

static func _arith(v: Variant) -> Variant:
	var n: Variant = to_num(v)
	return n

static func binop(op: String, a: Variant, b: Variant) -> Variant:
	match op:
		"+":
			if typeof(a) in [TYPE_STRING, TYPE_STRING_NAME] or typeof(b) in [TYPE_STRING, TYPE_STRING_NAME] \
					or a is Array or b is Array or a is Dictionary or b is Dictionary:
				return to_str(a) + to_str(b)
			var x: Variant = to_num(a)
			var y: Variant = to_num(b)
			return x + y
		"-":
			return to_num(a) - to_num(b)
		"*":
			return to_num(a) * to_num(b)
		"/":
			var d: Variant = to_num(b)
			if float(d) == 0.0:
				return INF if float(to_num(a)) > 0 else (-INF if float(to_num(a)) < 0 else NAN)
			var q: float = float(to_num(a)) / float(d)
			return int(q) if q == floor(q) and abs(q) < 1e15 else q
		"%":
			var m: Variant = to_num(b)
			if float(m) == 0.0:
				return NAN
			if typeof(a) == TYPE_INT and typeof(m) == TYPE_INT:
				return a % m
			return fmod(float(to_num(a)), float(m))
		"===":
			return strict_eq(a, b)
		"!==":
			return not strict_eq(a, b)
		"==":
			return loose_eq(a, b)
		"!=":
			return not loose_eq(a, b)
		"<", ">", "<=", ">=":
			if typeof(a) == TYPE_STRING and typeof(b) == TYPE_STRING:
				match op:
					"<": return a < b
					">": return a > b
					"<=": return a <= b
					">=": return a >= b
			var x: float = float(to_num(a))
			var y: float = float(to_num(b))
			if is_nan(x) or is_nan(y):
				return false
			match op:
				"<": return x < y
				">": return x > y
				"<=": return x <= y
				">=": return x >= y
		"in":
			if b is Dictionary:
				return b.has(_key(a))
			if b is Array:
				var i: Variant = to_num(a)
				return _is_num(i) and int(i) >= 0 and int(i) < b.size()
			return false
		"instanceof":
			return false
		"|":
			return _i32(_i32(a) | _i32(b))
		"&":
			return _i32(_i32(a) & _i32(b))
		"^":
			return _i32(_i32(a) ^ _i32(b))
		"<<":
			return _i32(_i32(a) << (_i32(b) & 31))
		">>":
			return _i32(a) >> (_i32(b) & 31)
		">>>":
			return (_i32(a) & 0xFFFFFFFF) >> (_i32(b) & 31)
	return null

## JavaScript's ToInt32: bit operations work on 32-bit signed integers and wrap round.
static func _i32(v: Variant) -> int:
	var x: Variant = to_num(v) if typeof(v) != TYPE_INT else v
	if typeof(x) == TYPE_FLOAT:
		if is_nan(x) or is_inf(x):
			return 0
		x = int(fmod(float(x) if absf(x) < 9.2e18 else fmod(x, 4294967296.0), 4294967296.0)) if absf(x) >= 2147483648.0 else int(x)
	var n = int(x) & 0xFFFFFFFF
	return n - 0x100000000 if n >= 0x80000000 else n

static func _key(k: Variant) -> String:
	if _is_num(k):
		return num_str(k)
	return to_str(k) if typeof(k) != TYPE_STRING else k

func get_prop(o: Variant, key: Variant) -> Variant:
	if o == null:
		return null
	if o is Object and not (o is JsFn) and not (o is JsRegex) and o.has_method("js_get"):
		return o.js_get(_key(key))
	if o is Dictionary:
		var k := _key(key)
		var v: Variant = o.get(k)
		if v is Dictionary and (v.has("$js") or v.has("$re")):
			v = _wrap_data(v)
			o[k] = v
		if v is JsFn and v.getter:
			return _invoke(v, [], o)
		return v
	if o is Array:
		if typeof(key) == TYPE_STRING and key == "length":
			return o.size()
		var i: Variant = to_num(key)
		if _is_num(i) and int(i) >= 0 and int(i) < o.size():
			var v: Variant = o[int(i)]
			if v is Dictionary and (v.has("$js") or v.has("$re")):
				v = _wrap_data(v)
				o[int(i)] = v
			return v
		return null
	if typeof(o) in [TYPE_STRING, TYPE_STRING_NAME]:
		var s := str(o)
		if typeof(key) == TYPE_STRING and key == "length":
			return s.length()
		var i: Variant = to_num(key)
		if _is_num(i) and int(i) >= 0 and int(i) < s.length():
			return s[int(i)]
		return null
	if o is JsRegex:
		if str(key) == "source":
			return o.source
	if o is JsFn:
		if str(key) == "length":
			_ensure_parsed(o)
			return o.params.size()
	return null

func set_prop(o: Variant, key: Variant, v: Variant) -> void:
	if o is Object and o.has_method("js_set"):
		o.js_set(_key(key), v)
		return
	if o is Dictionary:
		o[_key(key)] = v
	elif o is Array:
		if typeof(key) == TYPE_STRING and key == "length":
			o.resize(int(to_num(v)))
			return
		var i := int(to_num(key))
		if i >= 0:
			if i >= o.size():
				o.resize(i + 1)
			o[i] = v

# ---------------------------------------------------------------- builtins

func make_regex(src: String, flags: String) -> JsRegex:
	var r := JsRegex.new()
	r.source = src
	r.flags = flags
	r.re = RegEx.new()
	var pre := ""
	if "i" in flags:
		pre += "(?i)"
	if "m" in flags:
		pre += "(?m)"
	if "s" in flags:
		pre += "(?s)"
	if r.re.compile(pre + src) != OK:
		_warn("re:" + src, "JsLite: regex did not compile: " + src)
	return r

## Returns [result] when (o, name) is a built-in method, else [].
func _builtin_method(o: Variant, name: String, a: Array) -> Array:
	var a0: Variant = a[0] if a.size() > 0 else null
	var a1: Variant = a[1] if a.size() > 1 else null
	if o is Array:
		match name:
			"indexOf":
				for i in o.size():
					if strict_eq(o[i], a0):
						return [i]
				return [-1]
			"includes":
				for x in o:
					if strict_eq(x, a0):
						return [true]
				return [false]
			"push":
				for x in a:
					o.append(x)
				return [o.size()]
			"pop":
				return [o.pop_back() if o.size() else null]
			"shift":
				return [o.pop_front() if o.size() else null]
			"unshift":
				for i in range(a.size() - 1, -1, -1):
					o.push_front(a[i])
				return [o.size()]
			"slice":
				var n: int = o.size()
				var s := int(to_num(a0)) if a0 != null else 0
				var en := int(to_num(a1)) if a1 != null else n
				if s < 0: s = max(0, n + s)
				if en < 0: en = max(0, n + en)
				s = min(s, n); en = min(en, n)
				return [o.slice(s, en) if en > s else []]
			"splice":
				var n: int = o.size()
				var s := int(to_num(a0))
				if s < 0: s = max(0, n + s)
				s = min(s, n)
				var cnt := n - s if a.size() < 2 else clampi(int(to_num(a1)), 0, n - s)
				var removed: Array = o.slice(s, s + cnt)
				for i in cnt:
					o.remove_at(s)
				for i in range(2, a.size()):
					o.insert(s + i - 2, a[i])
				return [removed]
			"concat":
				var out: Array = o.duplicate()
				for x in a:
					if x is Array:
						out.append_array(x)
					else:
						out.append(x)
				return [out]
			"join":
				var sep := "," if a0 == null else to_str(a0)
				var parts: PackedStringArray = []
				for x in o:
					parts.append("" if x == null else to_str(x))
				return [sep.join(parts)]
			"some":
				for i in o.size():
					if truthy(call_fn(a0, [o[i], i, o])):
						return [true]
				return [false]
			"every":
				for i in o.size():
					if not truthy(call_fn(a0, [o[i], i, o])):
						return [false]
				return [true]
			"filter":
				var out: Array = []
				for i in o.size():
					if truthy(call_fn(a0, [o[i], i, o])):
						out.append(o[i])
				return [out]
			"map":
				var out: Array = []
				for i in o.size():
					out.append(call_fn(a0, [o[i], i, o]))
				return [out]
			"forEach":
				for i in o.size():
					call_fn(a0, [o[i], i, o])
				return [null]
			"find":
				for i in o.size():
					if truthy(call_fn(a0, [o[i], i, o])):
						return [o[i]]
				return [null]
			"findIndex":
				for i in o.size():
					if truthy(call_fn(a0, [o[i], i, o])):
						return [i]
				return [-1]
			"reduce":
				var i0 := 0
				var acc: Variant = a1
				if a.size() < 2:
					if o.is_empty():
						return [null]
					acc = o[0]; i0 = 1
				for i in range(i0, o.size()):
					acc = call_fn(a0, [acc, o[i], i, o])
				return [acc]
			"reverse":
				o.reverse()
				return [o]
			"lastIndexOf":
				for i in range(o.size() - 1, -1, -1):
					if strict_eq(o[i], a0):
						return [i]
				return [-1]
			"sort":
				if a0 == null:
					o.sort_custom(func(x, y): return to_str(x) < to_str(y))
				else:
					var cmp: Variant = a0
					o.sort_custom(func(x, y): return float(to_num(call_fn(cmp, [x, y]))) < 0)
				return [o]
	elif typeof(o) in [TYPE_STRING, TYPE_STRING_NAME]:
		var s := str(o)
		match name:
			"indexOf":
				return [s.find(to_str(a0))]
			"includes":
				return [s.find(to_str(a0)) >= 0]
			"toLowerCase":
				return [s.to_lower()]
			"toUpperCase":
				return [s.to_upper()]
			"trim":
				return [s.strip_edges()]
			"charAt":
				var i := int(to_num(a0))
				return [s[i] if i >= 0 and i < s.length() else ""]
			"charCodeAt":
				var i := int(to_num(a0)) if a0 != null else 0
				return [s.unicode_at(i) if i >= 0 and i < s.length() else NAN]
			"split":
				if a0 is JsRegex:
					return [_re_split(a0, s)]
				var sep := to_str(a0)
				var out: Array = []
				if sep == "":
					for ch in s:
						out.append(ch)
				else:
					for p in s.split(sep):
						out.append(p)
				return [out]
			"slice", "substring":
				var n := s.length()
				var st := int(to_num(a0)) if a0 != null else 0
				var en := int(to_num(a1)) if a1 != null else n
				if name == "slice":
					if st < 0: st = max(0, n + st)
					if en < 0: en = max(0, n + en)
				st = clampi(st, 0, n); en = clampi(en, 0, n)
				if name == "substring" and st > en:
					var t := st; st = en; en = t
				return [s.substr(st, max(0, en - st))]
			"replace":
				if a0 is JsRegex:
					var rep := to_str(a1)
					if "g" in a0.flags:
						return [a0.re.sub(s, rep.replace("$&", "$0"), true)]
					return [a0.re.sub(s, rep.replace("$&", "$0"), false)]
				var f := s.find(to_str(a0))
				if f < 0:
					return [s]
				return [s.substr(0, f) + to_str(a1) + s.substr(f + to_str(a0).length())]
			"match":
				if a0 is JsRegex:
					var m: RegExMatch = a0.re.search(s)
					if m == null:
						return [null]
					return [Array(m.strings)]
			"startsWith":
				return [s.begins_with(to_str(a0))]
			"endsWith":
				return [s.ends_with(to_str(a0))]
			"repeat":
				return [s.repeat(int(to_num(a0)))]
			"lastIndexOf":
				return [s.rfind(to_str(a0))]
			"toString":
				return [s]
			"localeCompare":
				var t := to_str(a0)
				return [-1 if s < t else (1 if s > t else 0)]
	elif o is JsRegex:
		match name:
			"test":
				return [o.re.search(to_str(a0)) != null]
			"exec":
				var m: RegExMatch = o.re.search(to_str(a0))
				return [null if m == null else Array(m.strings)]
	elif o is JsFn or o is Callable:
		match name:
			"call":
				return [call_fn(o, a.slice(1), a0)]
			"apply":
				return [call_fn(o, a1 if a1 is Array else [], a0)]
	return []

func _re_split(r: JsRegex, s: String) -> Array:
	var out: Array = []
	var pos := 0
	for m in r.re.search_all(s):
		out.append(s.substr(pos, m.get_start() - pos))
		pos = m.get_end()
	out.append(s.substr(pos))
	return out

func _warn(key: String, msg: String) -> void:
	if warned.has(key):
		return
	warned[key] = true
	push_warning(msg)

# ================================================================ parser

class _Parser extends RefCounted:
	var toks: Array = []      # [type, value, regex_ok_after]
	var i := 0
	var error := ""
	var src := ""

	const PUNCT := ["===", "!==", ">>>", "...", "**=", "<<=", ">>=", "==", "!=", "<=", ">=", "&&", "||", "??", "?.",
		"++", "--", "+=", "-=", "*=", "/=", "%=", "|=", "&=", "^=", "=>", "**", "<<", ">>",
		"{", "}", "(", ")", "[", "]", ";", ",", "<", ">", "+", "-", "*", "/", "%", "&", "|", "^",
		"!", "~", "?", ":", "=", "."]
	const KEYWORDS := ["var", "let", "const", "function", "return", "if", "else", "for", "while", "do", "break",
		"continue", "new", "typeof", "void", "delete", "in", "instanceof", "this", "true", "false", "null",
		"try", "catch", "finally", "throw", "of"]

	func _init(s: String) -> void:
		src = s
		_tokenize()

	func _fail(msg: String) -> void:
		if error == "":
			error = msg + " near token " + str(i) + " (" + (str(toks[i][1]) if i < toks.size() else "end") + ")"

	# ---------------- tokenizer
	func _tokenize() -> void:
		var p := 0
		var n := src.length()
		var prev_type := ""
		var prev_val := ""
		while p < n:
			var c := src[p]
			if c == " " or c == "\t" or c == "\n" or c == "\r" or c == " " or c == "﻿":
				p += 1
				continue
			if c == "/" and p + 1 < n and src[p + 1] == "/":
				while p < n and src[p] != "\n":
					p += 1
				continue
			if c == "/" and p + 1 < n and src[p + 1] == "*":
				var e := src.find("*/", p + 2)
				p = n if e < 0 else e + 2
				continue
			# regex literal: allowed where an operand is expected
			if c == "/" and _regex_allowed(prev_type, prev_val):
				var q := p + 1
				var in_class := false
				var body := ""
				while q < n:
					var d := src[q]
					if d == "\\" and q + 1 < n:
						body += d + src[q + 1]
						q += 2
						continue
					if d == "[":
						in_class = true
					elif d == "]":
						in_class = false
					elif d == "/" and not in_class:
						break
					body += d
					q += 1
				q += 1
				var fl := ""
				while q < n and _is_ident_char(src[q]):
					fl += src[q]
					q += 1
				toks.append(["re", [body, fl]])
				prev_type = "re"; prev_val = ""
				p = q
				continue
			if c == "'" or c == "\"" or c == "`":
				var q := p + 1
				var out := ""
				while q < n and src[q] != c:
					var d := src[q]
					if d == "\\" and q + 1 < n:
						var e2 := src[q + 1]
						match e2:
							"n": out += "\n"
							"t": out += "\t"
							"r": out += "\r"
							"b": out += "\b"
							"0": out += char(0)
							"u":
								out += char(src.substr(q + 2, 4).hex_to_int())
								q += 4
							"x":
								out += char(src.substr(q + 2, 2).hex_to_int())
								q += 2
							"\n": pass
							_: out += e2
						q += 2
						continue
					out += d
					q += 1
				toks.append(["str", out])
				prev_type = "str"; prev_val = ""
				p = q + 1
				continue
			if c.is_valid_int() or (c == "." and p + 1 < n and src[p + 1].is_valid_int()):
				var q := p
				if c == "0" and p + 1 < n and (src[p + 1] == "x" or src[p + 1] == "X"):
					q = p + 2
					while q < n and src[q].is_valid_hex_number():
						q += 1
					toks.append(["num", src.substr(p + 2, q - p - 2).hex_to_int()])
				else:
					while q < n and (src[q].is_valid_int() or src[q] == "." or src[q] == "e" or src[q] == "E" \
							or ((src[q] == "+" or src[q] == "-") and (src[q - 1] == "e" or src[q - 1] == "E"))):
						q += 1
					var t := src.substr(p, q - p)
					if t.is_valid_int():
						toks.append(["num", t.to_int()])
					else:
						toks.append(["num", t.to_float()])
				prev_type = "num"; prev_val = ""
				p = q
				continue
			if _is_ident_start(c):
				var q := p
				while q < n and _is_ident_char(src[q]):
					q += 1
				var w := src.substr(p, q - p)
				toks.append(["name", w])
				prev_type = "name"; prev_val = w
				p = q
				continue
			var matched := ""
			for pu in PUNCT:
				if src.substr(p, pu.length()) == pu:
					matched = pu
					break
			if matched == "":
				error = "unexpected character '" + c + "'"
				return
			toks.append(["p", matched])
			prev_type = "p"; prev_val = matched
			p += matched.length()
		toks.append(["eof", null])

	func _regex_allowed(pt: String, pv: String) -> bool:
		if pt == "" :
			return true
		if pt == "num" or pt == "str" or pt == "re":
			return false
		if pt == "name":
			return pv in ["return", "typeof", "case", "in", "of", "new", "delete", "void", "instanceof", "else", "do"]
		return not (pv in [")", "]", "}"])

	static func _is_ident_start(c: String) -> bool:
		var u := c.unicode_at(0)
		return (u >= 65 and u <= 90) or (u >= 97 and u <= 122) or c == "_" or c == "$" or u > 127

	static func _is_ident_char(c: String) -> bool:
		return _is_ident_start(c) or c.is_valid_int()

	# ---------------- helpers
	func peek() -> Array:
		return toks[i]
	func is_p(v: String) -> bool:
		return toks[i][0] == "p" and toks[i][1] == v
	func is_kw(v: String) -> bool:
		return toks[i][0] == "name" and toks[i][1] == v
	func eat_p(v: String) -> bool:
		if is_p(v):
			i += 1
			return true
		return false
	func expect_p(v: String) -> void:
		if not eat_p(v):
			_fail("expected '" + v + "'")
			i = toks.size() - 1
	func ident() -> String:
		if toks[i][0] == "name":
			i += 1
			return toks[i - 1][1]
		_fail("expected a name")
		i = toks.size() - 1
		return ""

	# ---------------- entry: "function name(a, b) { ... }"  or a bare expression
	func parse_function_source() -> Array:
		if error != "":
			return [[], [], ""]
		if is_p("("):
			# wrapped like "(function () {...})"
			var save := i
			i += 1
			if is_kw("function"):
				var r := parse_function_source()
				eat_p(")")
				return r
			i = save
		if is_kw("function"):
			i += 1
			var nm := ""
			if toks[i][0] == "name":
				nm = ident()
			var params := _params()
			var body := _block_body()
			return [params, body, nm]
		# arrow function or a bare expression: treat as "return <expr>"
		var e: Variant = expr()
		if e != null and e[0] == "fn":
			return [e[2], e[3], e[1]]
		return [[], [["ret", e]], ""]

	func _params() -> Array:
		var ps: Array = []
		expect_p("(")
		while not is_p(")") and error == "":
			ps.append(ident())
			if is_p("="):
				# default values are rare; skip the expression
				i += 1
				assign()
			if not eat_p(","):
				break
		expect_p(")")
		return ps

	func _block_body() -> Array:
		expect_p("{")
		var out: Array = []
		while not is_p("}") and peek()[0] != "eof" and error == "":
			out.append(statement())
		expect_p("}")
		return out

	# ---------------- statements
	func statement() -> Array:
		var t := peek()
		if t[0] == "p":
			if t[1] == "{":
				return ["blk", _block_body()]
			if t[1] == ";":
				i += 1
				return ["nop"]
		if t[0] == "name":
			match t[1]:
				"var", "let", "const":
					var d := _var_decl()
					eat_p(";")
					return d
				"return":
					i += 1
					if is_p(";") or is_p("}"):
						eat_p(";")
						return ["ret", null]
					var e: Variant = expr()
					eat_p(";")
					return ["ret", e]
				"if":
					i += 1
					expect_p("(")
					var c: Variant = expr()
					expect_p(")")
					var a := statement()
					var b: Variant = null
					if is_kw("else"):
						i += 1
						b = statement()
					return ["if", c, a, b]
				"for":
					return _for()
				"while":
					i += 1
					expect_p("(")
					var c: Variant = expr()
					expect_p(")")
					return ["while", c, statement()]
				"break":
					i += 1
					eat_p(";")
					return ["brk"]
				"continue":
					i += 1
					eat_p(";")
					return ["cont"]
				"function":
					i += 1
					var nm := ident()
					var params := _params()
					var body := _block_body()
					return ["fndecl", nm, ["fn", nm, params, body]]
				"try":
					i += 1
					var tb := ["blk", _block_body()]
					if is_kw("catch"):
						i += 1
						if eat_p("("):
							ident()
							expect_p(")")
						_block_body()
					if is_kw("finally"):
						i += 1
						_block_body()
					return ["try", tb]
				"throw":
					i += 1
					expr()
					eat_p(";")
					return ["throw"]
		var e2: Variant = expr()
		eat_p(";")
		return ["exp", e2]

	func _var_decl() -> Array:
		i += 1
		var ds: Array = []
		while error == "":
			var nm := ident()
			var init: Variant = null
			if eat_p("="):
				init = assign()
			ds.append([nm, init])
			if not eat_p(","):
				break
		return ["var", ds]

	func _for() -> Array:
		i += 1
		expect_p("(")
		# for (var k in obj)
		var save := i
		if is_kw("var") or is_kw("let") or is_kw("const"):
			i += 1
		if toks[i][0] == "name" and toks[i + 1][0] == "name" and (toks[i + 1][1] == "in" or toks[i + 1][1] == "of"):
			var nm := ident()
			i += 1
			var obj: Variant = expr()
			expect_p(")")
			return ["forin", nm, obj, statement()]
		i = save
		var init: Variant = null
		if not is_p(";"):
			if is_kw("var") or is_kw("let") or is_kw("const"):
				init = _var_decl()
			else:
				init = ["exp", expr()]
		expect_p(";")
		var test: Variant = null if is_p(";") else expr()
		expect_p(";")
		var upd: Variant = null if is_p(")") else expr()
		expect_p(")")
		return ["for", init, test, upd, statement()]

	# ---------------- expressions
	func expr() -> Variant:
		var e: Variant = assign()
		if is_p(","):
			var list: Array = [e]
			while eat_p(","):
				list.append(assign())
			return ["seq", list]
		return e

	func assign() -> Variant:
		# arrow function: (a, b) => ...  or  a => ...
		var arrow: Variant = _try_arrow()
		if arrow != null:
			return arrow
		var left: Variant = conditional()
		var t := peek()
		if t[0] == "p" and t[1] in ["=", "+=", "-=", "*=", "/=", "%=", "|=", "&=", "^="]:
			i += 1
			var right: Variant = assign()
			return ["asg", t[1], left, right]
		return left

	func _try_arrow() -> Variant:
		if toks[i][0] == "name" and toks[i + 1][0] == "p" and toks[i + 1][1] == "=>":
			var nm: String = toks[i][1]
			i += 2
			return _arrow_body([nm])
		if is_p("("):
			# scan for matching ) followed by =>
			var depth := 0
			var j := i
			while j < toks.size():
				if toks[j][0] == "p":
					if toks[j][1] == "(":
						depth += 1
					elif toks[j][1] == ")":
						depth -= 1
						if depth == 0:
							break
				j += 1
			if j + 1 < toks.size() and toks[j + 1][0] == "p" and toks[j + 1][1] == "=>":
				var ps := _params()
				i += 1  # =>
				return _arrow_body(ps)
		return null

	func _arrow_body(ps: Array) -> Array:
		if is_p("{"):
			return ["fn", "", ps, _block_body()]
		return ["fn", "", ps, [["ret", assign()]]]

	func conditional() -> Variant:
		var c: Variant = nullish()
		if eat_p("?"):
			var a: Variant = assign()
			expect_p(":")
			var b: Variant = assign()
			return ["cond", c, a, b]
		return c

	func nullish() -> Variant:
		var l: Variant = logor()
		while is_p("??"):
			i += 1
			l = ["log", "??", l, logor()]
		return l

	func logor() -> Variant:
		var l: Variant = logand()
		while is_p("||"):
			i += 1
			l = ["log", "||", l, logand()]
		return l

	func logand() -> Variant:
		var l: Variant = bitor()
		while is_p("&&"):
			i += 1
			l = ["log", "&&", l, bitor()]
		return l

	func bitor() -> Variant:
		var l: Variant = bitxor()
		while is_p("|"):
			i += 1
			l = ["bin", "|", l, bitxor()]
		return l

	func bitxor() -> Variant:
		var l: Variant = bitand()
		while is_p("^"):
			i += 1
			l = ["bin", "^", l, bitand()]
		return l

	func bitand() -> Variant:
		var l: Variant = equality()
		while is_p("&"):
			i += 1
			l = ["bin", "&", l, equality()]
		return l

	func equality() -> Variant:
		var l: Variant = relational()
		while peek()[0] == "p" and peek()[1] in ["===", "!==", "==", "!="]:
			var op: String = peek()[1]
			i += 1
			l = ["bin", op, l, relational()]
		return l

	func relational() -> Variant:
		var l: Variant = shift()
		while (peek()[0] == "p" and peek()[1] in ["<", ">", "<=", ">="]) or is_kw("in") or is_kw("instanceof"):
			var op: String = peek()[1]
			i += 1
			l = ["bin", op, l, shift()]
		return l

	func shift() -> Variant:
		var l: Variant = additive()
		while peek()[0] == "p" and peek()[1] in ["<<", ">>", ">>>"]:
			var op: String = peek()[1]
			i += 1
			l = ["bin", op, l, additive()]
		return l

	func additive() -> Variant:
		var l: Variant = multiplicative()
		while peek()[0] == "p" and peek()[1] in ["+", "-"]:
			var op: String = peek()[1]
			i += 1
			l = ["bin", op, l, multiplicative()]
		return l

	func multiplicative() -> Variant:
		var l: Variant = unary()
		while peek()[0] == "p" and peek()[1] in ["*", "/", "%"]:
			var op: String = peek()[1]
			i += 1
			l = ["bin", op, l, unary()]
		return l

	func unary() -> Variant:
		var t := peek()
		if t[0] == "p" and t[1] in ["!", "-", "+", "~"]:
			i += 1
			return ["un", t[1], unary()]
		if t[0] == "p" and t[1] in ["++", "--"]:
			i += 1
			return ["upd", t[1], true, unary()]
		if t[0] == "name" and t[1] in ["typeof", "void", "delete"]:
			i += 1
			return ["un", t[1], unary()]
		var e: Variant = postfix()
		if peek()[0] == "p" and peek()[1] in ["++", "--"]:
			var op: String = peek()[1]
			i += 1
			return ["upd", op, false, e]
		return e

	func postfix() -> Variant:
		var e: Variant
		if is_kw("new"):
			i += 1
			var callee: Variant = primary()
			var args: Array = []
			if is_p("("):
				args = _args()
			e = ["new", callee, args]
		else:
			e = primary()
		while error == "":
			if eat_p("."):
				e = ["mem", e, ident(), false]
			elif is_p("?."):
				i += 1
				if is_p("("):
					e = ["call", e, _args()]
				elif eat_p("["):
					var k: Variant = expr()
					expect_p("]")
					e = ["mem", e, k, true]
				else:
					e = ["mem", e, ident(), false]
			elif eat_p("["):
				var k2: Variant = expr()
				expect_p("]")
				e = ["mem", e, k2, true]
			elif is_p("("):
				e = ["call", e, _args()]
			else:
				break
		return e

	func _args() -> Array:
		var out: Array = []
		expect_p("(")
		while not is_p(")") and error == "":
			out.append(assign())
			if not eat_p(","):
				break
		expect_p(")")
		return out

	func primary() -> Variant:
		var t := peek()
		match t[0]:
			"num":
				i += 1
				return ["num", t[1]]
			"str":
				i += 1
				return ["str", t[1]]
			"re":
				i += 1
				return ["re", t[1][0], t[1][1]]
			"name":
				match t[1]:
					"true":
						i += 1
						return ["lit", true]
					"false":
						i += 1
						return ["lit", false]
					"null":
						i += 1
						return ["lit", null]
					"function":
						i += 1
						var nm := ""
						if toks[i][0] == "name":
							nm = ident()
						var ps := _params()
						return ["fn", nm, ps, _block_body()]
				i += 1
				return ["id", t[1]]
			"p":
				match t[1]:
					"(":
						i += 1
						var e: Variant = expr()
						expect_p(")")
						return e
					"[":
						i += 1
						var items: Array = []
						while not is_p("]") and error == "":
							items.append(assign())
							if not eat_p(","):
								break
						expect_p("]")
						return ["arr", items]
					"{":
						i += 1
						var props: Array = []
						while not is_p("}") and error == "":
							var k: String
							var kt := peek()
							if kt[0] == "str" or kt[0] == "name":
								k = str(kt[1])
								i += 1
							elif kt[0] == "num":
								k = JsLite.num_str(kt[1])
								i += 1
							else:
								_fail("bad object key")
								break
							if eat_p(":"):
								props.append([k, assign()])
							elif is_p("("):
								var ps := _params()
								props.append([k, ["fn", k, ps, _block_body()]])
							else:
								props.append([k, ["id", k]])
							if not eat_p(","):
								break
						expect_p("}")
						return ["obj", props]
		_fail("unexpected token")
		i = toks.size() - 1
		return ["lit", null]
