## Markup: the small text format that data logic uses to build screens.
##
## The browser version built HTML strings. Logic in data/fights.json still does
## (e.g. '<div class="prose">' + paras(text) + '</div>' + evVoice('duty', line)),
## so paras() and voice lines become tagged segments and any leftover HTML is
## reduced to plain styled text.
class_name Markup
extends RefCounted

const SUMMARY := "\u0001F\u0003"

static func paras(t: Variant) -> String:
	return "\u0001P" + str(t) + "\u0003"

static func voice(v: String, t: Variant, cls: String = "") -> String:
	return "\u0001V" + v + ("|" + cls if cls != "" else "") + "\u0002" + str(t) + "\u0003"

static func portrait(mood: String, hue: Variant) -> String:
	return "\u0001I" + mood + "|" + (str(hue) if hue != null else "") + "\u0003"

static func roll(i: int) -> String:
	return "\u0001R" + str(i) + "\u0003"

## Like parse(), for text that is already BBCode: ["t", bb] parts are passed through as they are.
static func parse_bb(s: String) -> Array:
	var out: Array = []
	var re := RegEx.create_from_string("\u0001([PVFIR])([^\u0003]*)\u0003")
	var pos := 0
	for m in re.search_all(s):
		var before := s.substr(pos, m.get_start() - pos)
		if before.strip_edges() != "":
			out.append(["t", before.strip_edges()])
		out.append(_seg(m))
		pos = m.get_end()
	var rest := s.substr(pos)
	if rest.strip_edges() != "":
		out.append(["t", rest.strip_edges()])
	return out

static func _seg(m: RegExMatch) -> Array:
	match m.get_string(1):
		"P":
			return ["p", m.get_string(2)]
		"V":
			var parts := m.get_string(2).split("\u0002", true, 1)
			var head := parts[0].split("|", true, 1)
			return ["v", head[0], parts[1] if parts.size() > 1 else "", head[1] if head.size() > 1 else ""]
		"I":
			var pi := m.get_string(2).split("|", true, 1)
			return ["i", pi[0], pi[1] if pi.size() > 1 else ""]
		"R":
			return ["r", int(m.get_string(2))]
	return ["f"]

## Split marked-up text into segments: ["p", text], ["v", voice, text], ["f"] (the last
## fight's summary) and ["t", bbcode] for anything else.
static func parse(s: String) -> Array:
	var out: Array = []
	var re := RegEx.create_from_string("\u0001([PVFIR])([^\u0003]*)\u0003")
	var pos := 0
	for m in re.search_all(s):
		_plain(s.substr(pos, m.get_start() - pos), out)
		out.append(_seg(m))
		pos = m.get_end()
	_plain(s.substr(pos), out)
	return out

static func _plain(h: String, out: Array) -> void:
	var bb := to_bb(h)
	if bb.strip_edges() != "":
		out.append(["t", bb.strip_edges()])

## HTML fragment to RichTextLabel BBCode (only the few tags the game uses).
static func to_bb(h: String) -> String:
	var t := h.replace("[", "[lb]")
	t = RegEx.create_from_string("<span class=\"fhurt\">(.*?)</span>").sub(t, "[color=#d9695f]$1[/color]", true)
	t = RegEx.create_from_string("<span class=\"(fgood|chip up)\">(.*?)</span>").sub(t, "[color=#8bb871]$2[/color]", true)
	t = RegEx.create_from_string("</p>\\s*<p[^>]*>").sub(t, "\n\n", true)
	t = RegEx.create_from_string("<br\\s*/?>").sub(t, "\n", true)
	t = RegEx.create_from_string("<(b|strong)>").sub(t, "[b]", true)
	t = RegEx.create_from_string("</(b|strong)>").sub(t, "[/b]", true)
	t = RegEx.create_from_string("<(i|em)>").sub(t, "[i]", true)
	t = RegEx.create_from_string("</(i|em)>").sub(t, "[/i]", true)
	t = RegEx.create_from_string("<[^>]+>").sub(t, "", true)
	return t.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")

## Pull the parts of a whole screen of HTML (as show() received it).
static func screen(h: String) -> Dictionary:
	var d := { "eyebrow": "", "title": "", "buttons": [], "body": "" }
	var m := RegEx.create_from_string("<div class=\"eyebrow\">(.*?)</div>").search(h)
	if m:
		d.eyebrow = to_bb(m.get_string(1))
		h = h.replace(m.get_string(0), "")
	m = RegEx.create_from_string("<h2>(.*?)</h2>").search(h)
	if m:
		d.title = to_bb(m.get_string(1))
		h = h.replace(m.get_string(0), "")
	for b in RegEx.create_from_string("<button[^>]*id=\"([^\"]+)\"[^>]*>(.*?)</button>").search_all(h):
		d.buttons.append([b.get_string(1), to_bb(b.get_string(2))])
		h = h.replace(b.get_string(0), "")
	d.body = h
	return d
