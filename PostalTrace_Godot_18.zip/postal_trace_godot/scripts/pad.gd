class_name Pad
extends Node
## Game pad control, built for handhelds with a d-pad and no sticks (the Anbernic RG35XX Plus), and the same
## on any pad on a computer. The browser build's pad code (padTick in index.html) uses the same buttons.
##
## Two modes:
##   "panel": the d-pad moves between options, A picks, B goes back, L1/R1 scroll the text.
##   "walk":  the d-pad walks the courier, A talks to or looks at the highlighted person or thing,
##            L2/R2 change what is highlighted, L1/R1 turn the view, hold B to run, tap B (or X) for the text.
## X switches between them where there is a place to walk in. Y hears the waiting voice. Start opens the menu,
## Select steps through Character, Tin Thoughts, Satchel and Journal. Select + L1/R1 zooms the view.

const CFG := "user://settings.cfg"
const REPEAT_DELAY := 0.36
const REPEAT_RATE := 0.11

## The pad's commands and the buttons they start on. A binding is a button index (int) or an axis as
## "a<axis><+|->" (L2/R2 come in as trigger axes: Godot's pad mapping turns trigger buttons into axes).
## Every command but the d-pad can be moved to another button in Menu > Controls (kept in settings.cfg [padmap]).
const ACTS := [
	["hh_up", [JOY_BUTTON_DPAD_UP, "a1-"]],
	["hh_down", [JOY_BUTTON_DPAD_DOWN, "a1+"]],
	["hh_left", [JOY_BUTTON_DPAD_LEFT, "a0-"]],
	["hh_right", [JOY_BUTTON_DPAD_RIGHT, "a0+"]],
	["hh_ok", [JOY_BUTTON_A]],
	["hh_back", [JOY_BUTTON_B]],
	["hh_walk", [JOY_BUTTON_X]],
	["hh_voice", [JOY_BUTTON_Y]],
	["hh_menu", [JOY_BUTTON_START, JOY_BUTTON_GUIDE]],
	["hh_pages", [JOY_BUTTON_BACK]],
	["hh_l1", [JOY_BUTTON_LEFT_SHOULDER]],
	["hh_r1", [JOY_BUTTON_RIGHT_SHOULDER]],
	["hh_l2", ["a4+"]],
	["hh_r2", ["a5+"]],
	["hh_zin", []],
	["hh_zout", []],
	["hh_run", []],
	["hh_char", []],
	["hh_tin", []],
	["hh_bag", []],
	["hh_log", []],
]
## What each command does, for Menu > Controls (the d-pad is fixed and not listed).
const CMDS := [
	["hh_ok", "Pick; talk to or look at what is marked"],
	["hh_back", "Back or close; hold to run, when walking"],
	["hh_walk", "Walk in the place / back to the text"],
	["hh_voice", "Hear the waiting voice"],
	["hh_l1", "Turn the view left; scroll the text up"],
	["hh_r1", "Turn the view right; scroll the text down"],
	["hh_l2", "Mark the one before; scroll the text up"],
	["hh_r2", "Mark the next one; scroll the text down"],
	["hh_zin", "Zoom in"],
	["hh_zout", "Zoom out"],
	["hh_run", "Run (hold)"],
	["hh_pages", "Character, Tin Thoughts, Satchel, Journal in turn"],
	["hh_char", "Character"],
	["hh_tin", "Tin Thoughts"],
	["hh_bag", "Satchel"],
	["hh_log", "Journal"],
	["hh_menu", "Menu"],
]
const NEEDED := ["hh_ok", "hh_back", "hh_menu"]   # must always have a button
const FIXED := ["hh_up", "hh_down", "hh_left", "hh_right"]
const DIRS := { "hh_up": "ui_up", "hh_down": "ui_down", "hh_left": "ui_left", "hh_right": "ui_right" }

var main: Node                 # main.gd
var mode := "panel"            # "panel" or "walk"
var swap := false              # A and B the other way round (Menu > Controls)
var used := false              # a pad has been pressed this session (the hints show then)
var page_i := -1               # which page Select opened last
var _held: Dictionary = {}     # action -> seconds held
var _rep: Dictionary = {}      # direction action -> time to its next repeat
var _back_moved := false       # B was held while walking (a run), so letting go is not "back to the text"
var _sel_chord := false        # Select was used with L1/R1 (zoom), so letting go does not open a page
var _focus_t := 0.0
var _pick_at := -1             # where the picked option was in its list, and how long the list was,
var _pick_n := 0               # so a screen drawn again the same (the creator, Settings) keeps your place
var _pick_ms := 0

signal mode_changed(mode: String)
signal captured(cmd: String, why: String)   # a button was pressed for a command waiting for one ("" or why not)

var capture := ""              # the command waiting for a button (Menu > Controls)
var _capture_ms := 0

func start_capture(cmd: String) -> void:
	capture = cmd
	_capture_ms = Time.get_ticks_msec()

func _ready() -> void:
	setup()

## Add the pad actions. L2/R2 come in as trigger axes (Godot's pad mapping turns trigger buttons into axes).
func setup() -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	swap = bool(c.get_value("pad", "swap", false))
	for a in ACTS:
		var name: String = a[0]
		if not InputMap.has_action(name):
			InputMap.add_action(name, 0.5)
		InputMap.action_erase_events(name)
		for b in bindings(name, c):
			var ev = _event_of(b)
			if ev:
				InputMap.action_add_event(name, ev)

## The buttons a command is on now: what was set in Menu > Controls, else its default (A and B swapped if asked).
func bindings(name: String, c: ConfigFile = null) -> Array:
	if c == null:
		c = ConfigFile.new()
		c.load(CFG)
	if not (name in FIXED) and c.has_section_key("padmap", name):
		return Array(c.get_value("padmap", name))
	for a in ACTS:
		if a[0] == name:
			if swap and name == "hh_ok": return [JOY_BUTTON_B]
			if swap and name == "hh_back": return [JOY_BUTTON_A]
			return a[1].duplicate()
	return []

static func _event_of(b: Variant) -> InputEvent:
	if b is String:
		var s := str(b)
		if not s.begins_with("a") or s.length() < 3:
			return null
		var jm = InputEventJoypadMotion.new()
		jm.axis = int(s.substr(1, s.length() - 2))
		jm.axis_value = 1.0 if s.ends_with("+") else -1.0
		jm.device = -1
		return jm
	var jb = InputEventJoypadButton.new()
	jb.button_index = int(b)
	jb.device = -1
	return jb

## The binding a pad event is (a button, or an axis pushed past halfway), or null.
static func code_of(ev: InputEvent) -> Variant:
	if ev is InputEventJoypadButton:
		return ev.button_index
	if ev is InputEventJoypadMotion and absf(ev.axis_value) > 0.6:
		return "a%d%s" % [ev.axis, "+" if ev.axis_value > 0 else "-"]
	return null

const BNAMES := { JOY_BUTTON_A: "A", JOY_BUTTON_B: "B", JOY_BUTTON_X: "X", JOY_BUTTON_Y: "Y", JOY_BUTTON_BACK: "Select",
	JOY_BUTTON_GUIDE: "Menu", JOY_BUTTON_START: "Start", JOY_BUTTON_LEFT_STICK: "L3", JOY_BUTTON_RIGHT_STICK: "R3",
	JOY_BUTTON_LEFT_SHOULDER: "L1", JOY_BUTTON_RIGHT_SHOULDER: "R1", JOY_BUTTON_DPAD_UP: "Up", JOY_BUTTON_DPAD_DOWN: "Down",
	JOY_BUTTON_DPAD_LEFT: "Left", JOY_BUTTON_DPAD_RIGHT: "Right", JOY_BUTTON_MISC1: "Misc", JOY_BUTTON_PADDLE1: "Paddle 1",
	JOY_BUTTON_PADDLE2: "Paddle 2", JOY_BUTTON_PADDLE3: "Paddle 3", JOY_BUTTON_PADDLE4: "Paddle 4", JOY_BUTTON_TOUCHPAD: "Touchpad" }
static func code_name(b: Variant) -> String:
	if b is String:
		var s := str(b)
		match s:
			"a4+": return "L2"
			"a5+": return "R2"
			"a0-": return "Stick left"
			"a0+": return "Stick right"
			"a1-": return "Stick up"
			"a1+": return "Stick down"
		return "Axis " + s.substr(1)
	return BNAMES.get(int(b), "Button %d" % int(b))

## The buttons a command is on, for hints ("—" when it has none).
func names_of(name: String) -> String:
	var b = bindings(name)
	if b.is_empty():
		return "—"
	return " / ".join(b.map(func(x): return code_name(x)))

## Put a command on one button (taking that button off any other command). Returns "" or why it cannot.
func bind(name: String, code: Variant) -> String:
	if name in FIXED:
		return "The d-pad always walks and moves between options."
	for f in FIXED:
		if _has(bindings(f), code):
			return code_name(code) + " is the d-pad; it always walks and moves between options."
	var c = ConfigFile.new()
	c.load(CFG)
	for a in ACTS:
		var other: String = a[0]
		if other == name or other in FIXED:
			continue
		var bs = bindings(other, c)
		if _has(bs, code):
			var left = bs.filter(func(x): return not _same(x, code))
			if other in NEEDED and left.is_empty():
				return "%s is the only button for \"%s\". Give that another button first." % [code_name(code), _label(other)]
			c.set_value("padmap", other, left)
	c.set_value("padmap", name, [code])
	c.save(CFG)
	setup()
	return ""

## Take every button off a command (not the ones it cannot do without).
func unbind(name: String) -> String:
	if name in NEEDED or name in FIXED:
		return "\"%s\" needs a button." % _label(name)
	var c = ConfigFile.new()
	c.load(CFG)
	c.set_value("padmap", name, [])
	c.save(CFG)
	setup()
	return ""

func reset_map() -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	if c.has_section("padmap"):
		c.erase_section("padmap")
	c.save(CFG)
	setup()

static func _same(a: Variant, b: Variant) -> bool:
	return (a is String) == (b is String) and str(a) == str(b)
static func _has(arr: Array, code: Variant) -> bool:
	return arr.any(func(x): return _same(x, code))
static func _label(name: String) -> String:
	for c in CMDS:
		if c[0] == name:
			return c[1]
	return name

func set_swap(v: bool) -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	c.set_value("pad", "swap", v)
	c.save(CFG)
	setup()

func _action_of(ev: InputEvent) -> String:
	for a in ACTS:
		if ev.is_action(a[0]):
			return a[0]
	return ""

## Called from main.gd's _input. True when the event was a pad event (it is then used up here).
func input(ev: InputEvent) -> bool:
	if not (ev is InputEventJoypadButton or ev is InputEventJoypadMotion):
		return false
	if capture != "":
		var code = code_of(ev)
		var down = (ev is InputEventJoypadButton and ev.pressed) or (ev is InputEventJoypadMotion and code != null)
		if down:
			var why = bind(capture, code)
			var was = capture
			capture = ""
			_held.clear()
			_rep.clear()
			captured.emit(was, why)
		return true
	var act = _action_of(ev)
	if act == "":
		# a stick or a button the game does not use: keep it away from the text panel's own focus moves
		return ev is InputEventJoypadButton
	var pressed = ev.is_action_pressed(act)
	var released = ev.is_action_released(act)
	if pressed and _held.has(act):
		return true            # an axis still past the line, or a repeat from the pad
	if pressed:
		_held[act] = 0.0
		if not used:
			used = true
			main.pad_hints()
		_press(act)
	elif released and _held.has(act):
		var t: float = _held[act]
		_held.erase(act)
		_rep.erase(act)
		_release(act, t)
	return true

func held(act: String) -> bool:
	return _held.has(act)

# ---------------------------------------------------------------- presses

func _press(act: String) -> void:
	if main.ts_box != null:
		if act == "hh_ok":
			main.ts_step()
		return
	var w: World = main.world
	if w and w.in_cut() and act in ["hh_ok", "hh_back", "hh_menu"]:
		w.cut_skip()
		return
	if main._capture != "":
		return
	match act:
		"hh_menu":
			if main.modal.visible:
				main.close_modal()
			elif main.phase != "title":
				main.open_menu()
			return
		"hh_pages":
			_sel_chord = false
			return
		"hh_voice":
			if main.vring and not main.modal.visible:
				main.vring.open_next()
			return
		"hh_char", "hh_tin", "hh_bag", "hh_log":
			if main.phase in ["scene", "talk", "road"]:
				var tag = { "hh_char": "char", "hh_tin": "tin", "hh_bag": "bag", "hh_log": "log" }[act]
				if main.modal.visible and main.modal_tag == tag:
					main.close_modal()
				else:
					match tag:
						"char": main.open_char()
						"tin": main.open_thoughts()
						"bag": main.open_satchel()
						"log": main.open_journal()
			return
		"hh_zin", "hh_zout":
			_zoom(act)
			_rep[act] = REPEAT_DELAY
			return
		"hh_walk":
			if mode == "walk":
				set_mode("panel")
			elif can_walk():
				set_mode("walk")
			return
	if held("hh_pages") and act in ["hh_l1", "hh_r1"]:
		_sel_chord = true
		_zoom("hh_zin" if act == "hh_r1" else "hh_zout")
		return
	if mode == "walk":
		_press_walk(act)
	else:
		_press_panel(act)

func _zoom(act: String) -> void:
	var w: World = main.world
	if w:
		w.zoom = clampf(w.zoom * (0.82 if act == "hh_zin" else 1.22), 3.5, 14.0)

func _release(act: String, t: float) -> void:
	if main._capture != "":
		return
	if act == "hh_pages" and not _sel_chord:
		_next_page()
	elif act == "hh_back" and mode == "walk" and not _back_moved and t < 0.35:
		set_mode("panel")
	if act == "hh_back":
		_back_moved = false

func _press_walk(act: String) -> void:
	var w: World = main.world
	match act:
		"hh_ok":
			if w and w.pad_target != null:
				w.approach(w.pad_target)
		"hh_l2":
			if w: w.pad_cycle(-1)
		"hh_r2":
			if w: w.pad_cycle(1)

func _press_panel(act: String) -> void:
	if DIRS.has(act):
		if _ensure_focus():
			_send(DIRS[act])
		_rep[act] = REPEAT_DELAY
	elif act == "hh_ok":
		if main.beat_btn != null and not main.modal.visible:
			main._next_beat()
		elif _ensure_focus():
			var all = _all_focusable(_box())
			_pick_at = all.find(main.get_viewport().gui_get_focus_owner())
			_pick_n = all.size()
			_pick_ms = Time.get_ticks_msec()
			_send("ui_accept")
	elif act == "hh_back":
		if main.modal.visible:
			main.close_modal()
		elif can_walk():
			set_mode("walk")
	elif act in ["hh_l1", "hh_r1", "hh_l2", "hh_r2"]:
		_scroll(-1 if act in ["hh_l1", "hh_l2"] else 1)

func _send(action: String) -> void:
	for p in [true, false]:
		var e = InputEventAction.new()
		e.action = action
		e.pressed = p
		Input.parse_input_event(e)

func _scroll(dir: int) -> void:
	var sc: ScrollContainer = main.mscroll if main.modal.visible else main.scroll
	sc.scroll_vertical += int(dir * sc.size.y * 0.7)

func _next_page() -> void:
	if not (main.phase in ["scene", "talk", "road"]):
		return
	var tags := ["char", "tin", "bag", "log"]
	if LivingDice.is_on(Game.S.get("ld")):
		tags.append("dice")
	var i := tags.find(main.modal_tag) if main.modal.visible else -1
	if i == tags.size() - 1:
		main.close_modal()
		return
	match tags[i + 1]:
		"char": main.open_char()
		"tin": main.open_thoughts()
		"bag": main.open_satchel()
		"log": main.open_journal()
		"dice": main.open_dice()

# ---------------------------------------------------------------- focus in the text panel

## The box the d-pad moves around in: the menu or page when one is open, otherwise the story panel.
func _box() -> Control:
	return main.mpage if main.modal.visible else main.page

func _focusable(c: Control) -> bool:
	if c.focus_mode != Control.FOCUS_ALL or not c.is_visible_in_tree():
		return false
	if c is BaseButton and c.disabled:
		return false
	return true

func _first_focusable(n: Node) -> Control:
	for ch in n.get_children():
		if ch is Control:
			if _focusable(ch):
				return ch
			var f = _first_focusable(ch)
			if f:
				return f
	return null

## True when something sensible already has focus (so the press can go through); otherwise focus the
## first option and use up the press.
func _ensure_focus() -> bool:
	var f = main.get_viewport().gui_get_focus_owner()
	var box = _box()
	if f and f.is_visible_in_tree() and box.is_ancestor_of(f):
		return true
	focus_first()
	return false

func _all_focusable(n: Node, out: Array = []) -> Array:
	for ch in n.get_children():
		if ch is Control:
			if _focusable(ch):
				out.append(ch)
			_all_focusable(ch, out)
	return out

func focus_first() -> void:
	var box = _box()
	# the same screen drawn again after a pick: stay on the option you picked
	if _pick_at >= 0 and Time.get_ticks_msec() - _pick_ms < 1500:
		var all = _all_focusable(box)
		var at = _pick_at
		_pick_at = -1
		if all.size() == _pick_n and at < all.size():
			all[at].grab_focus()
			return
	if not main.modal.visible:
		if main.beat_btn != null and is_instance_valid(main.beat_btn):
			main.beat_btn.grab_focus()
			return
		for c in main.choices:
			if not c[2] and is_instance_valid(c[0]) and c[0].is_visible_in_tree():
				c[0].grab_focus()
				return
	var f = _first_focusable(box)
	if f:
		f.grab_focus()

# ---------------------------------------------------------------- walking

## There is a place on screen to walk in.
func can_walk() -> bool:
	var w: World = main.world
	return w != null and main.three_d and main.world_view.visible and main.phase == "scene" and not main.modal.visible \
		and not w.input_locked and not w.in_cut() and not (main.editor and main.editor.on)

func set_mode(m: String) -> void:
	if m == mode:
		return
	mode = m
	var w: World = main.world
	if w:
		w.pad_on = m == "walk"
		if m != "walk":
			w.pad_mv = Vector2.ZERO
			w.pad_run = false
			w.pad_turn = 0.0
	if m == "panel":
		focus_first.call_deferred()
	mode_changed.emit(m)

func _process(dt: float) -> void:
	for a in _held:
		_held[a] += dt
	# held zoom buttons keep zooming
	for z in ["hh_zin", "hh_zout"]:
		if _rep.has(z) and held(z):
			_rep[z] -= dt
			if _rep[z] <= 0.0:
				_rep[z] = REPEAT_RATE * 1.6
				_zoom(z)
	if mode == "walk" and not can_walk():
		set_mode("panel")
	var w: World = main.world
	if mode == "walk" and w:
		var mv = Vector2.ZERO
		if held("hh_up"): mv.y -= 1
		if held("hh_down"): mv.y += 1
		if held("hh_left"): mv.x -= 1
		if held("hh_right"): mv.x += 1
		w.pad_mv = mv
		w.pad_run = held("hh_back") or held("hh_run")
		if w.pad_run and mv != Vector2.ZERO:
			_back_moved = true
		w.pad_turn = 0.0 if held("hh_pages") else (1.0 if held("hh_l1") else 0.0) - (1.0 if held("hh_r1") else 0.0)
		return
	# held directions repeat in the panel, as a keyboard's arrows do
	for a in DIRS:
		if _rep.has(a) and held(a):
			_rep[a] -= dt
			if _rep[a] <= 0.0:
				_rep[a] = REPEAT_RATE
				if _ensure_focus():
					_send(DIRS[a])
	# after a pad press, keep something focused when a new screen has been drawn
	if used:
		_focus_t -= dt
		if _focus_t <= 0.0:
			_focus_t = 0.15
			var f = main.get_viewport().gui_get_focus_owner()
			if f == null or not f.is_visible_in_tree() or not _box().is_ancestor_of(f):
				focus_first()
