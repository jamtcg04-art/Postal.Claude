## Sound: one-shot effects, a looping ambience bed and music, from res://assets.
extends Node

var volume := { "master": 1.0, "sfx": 0.8, "amb": 0.6, "music": 0.6 }
var _amb: AudioStreamPlayer
var _music: AudioStreamPlayer
var _amb_key := ""
var _music_key := ""
var _pool: Array = []          # short effects that may overlap (the browser's Web Audio AUD.play)
var _keyed: Dictionary = {}    # one player per sound for the browser's sfx(): playing it again restarts it
var _cache: Dictionary = {}

# The browser's own table (SFX_VOL); anything not listed plays at 0.4.
const SFX_VOL := { "road": 0.8, "duty": 0.7, "ringing": 0.75, "hat": 0.45, "pass": 0.4, "fail": 0.65, "redpass": 0.6, "redfail": 0.85,
	"blast": 0.95, "rumble": 0.75, "keg": 0.95, "ambush": 0.8, "redoubt": 0.75, "door": 0.35, "leg": 0.45 }
const SFX_ALT := { "fail": ["fail", "fail2", "fail3"] }
# voices with a sound of their own (the rest use v_<voice>)
const VOICE_SPECIAL := { "duty": true, "ringing": true, "hat": true }

func _ready() -> void:
	_amb = AudioStreamPlayer.new()
	_music = AudioStreamPlayer.new()
	add_child(_amb)
	add_child(_music)
	for i in 8:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)

func _stream(path: String) -> AudioStream:
	if _cache.has(path):
		return _cache[path]
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		s = load(path)
	_cache[path] = s
	return s

func _has(key: String) -> bool:
	return _stream("res://assets/sfx/" + key + ".mp3") != null

func _db(v: float) -> float:
	return linear_to_db(max(0.0001, v * volume["sfx"] * volume["master"]))

## Overlapping one-shots (footsteps, blips, the thought chime): the browser's AUD.play.
func play(key: String, vol: float = -1.0, delay := 0.0) -> void:
	var s := _stream("res://assets/sfx/" + key + ".mp3")
	if s == null:
		return
	if delay > 0.0:
		get_tree().create_timer(delay).timeout.connect(func(): play(key, vol))
		return
	var v: float = vol if vol >= 0.0 else 0.5
	var best: AudioStreamPlayer = null
	for p in _pool:
		if not p.playing:
			best = p
			break
	if best == null:
		# all busy: take over the one that has played longest
		best = _pool[0]
		for p in _pool:
			if p.get_playback_position() > best.get_playback_position():
				best = p
	best.stream = s
	best.volume_db = _db(v)
	best.play()

## The browser's sfx(): each sound has one player, at its own volume, and starts over if it plays again.
func sfx(key: String, scale := 1.0) -> void:
	if not _has(key):
		return
	var vol: float = float(SFX_VOL.get(key, 0.4)) * scale
	if SFX_ALT.has(key):
		var alts: Array = SFX_ALT[key]
		key = alts[randi() % alts.size()]
	var s := _stream("res://assets/sfx/" + key + ".mp3")
	if s == null:
		return
	var p: AudioStreamPlayer = _keyed.get(key)
	if p == null:
		p = AudioStreamPlayer.new()
		add_child(p)
		_keyed[key] = p
	p.stream = s
	p.volume_db = _db(clampf(vol, 0.0, 1.0))
	p.play()

# ---- everything that happens in one moment queues its sound; only the most important one plays (the browser's sfxEvent)
var _evq: Variant = null
func event(key: String, prio := 1.0, scale := 1.0) -> void:
	if not _has(key):
		return
	if _evq == null:
		_evq = { "k": key, "p": prio, "s": scale }
		get_tree().create_timer(0.04).timeout.connect(_event_fire)
	elif prio > float(_evq.p):
		_evq = { "k": key, "p": prio, "s": scale }

func _event_fire() -> void:
	var q: Variant = _evq
	_evq = null
	if q != null:
		sfx(str(q.k), float(q.s))

# ---- the voices (the browser's sfxVoiceNow / sfxVoice / sfxStaged)
# A voice sounds as its line appears: in a conversation as each line is revealed with Continue, on other screens
# once when the screen opens (the first voice on it). A voice heard in the last 8 seconds still sounds, a step quieter
# each time, down to a third. Lines already seen (kept in the save) are silent.
var _vseen: Dictionary = {}      # voice -> {n, t}
var _vlast: Dictionary = {}      # voice -> the last line it sounded for
var _vq := ""                    # a voice waiting to sound at the end of this moment
var _vq_gen := 0

func voice_key(v: String) -> String:
	var k := v if VOICE_SPECIAL.has(v) else "v_" + v
	return k

func voice_now(v: String) -> void:
	var k := voice_key(v)
	if not _has(k):
		return
	var now := Time.get_ticks_msec()
	var r: Dictionary = _vseen.get(v, {})
	if r.is_empty() or now - int(r.t) > 8000:
		r = { "n": 0, "t": now }
	r.n = int(r.n) + 1
	r.t = now
	_vseen[v] = r
	var sc: float = maxf(0.33, 1.0 - (int(r.n) - 1) * 0.25)
	if _evq != null:
		get_tree().create_timer(0.22).timeout.connect(func(): sfx(k, sc))
	else:
		sfx(k, sc)

## Has the player already seen this line? (marks it seen). Kept in the save, as the browser's beatSeen.
func line_seen(s: String, mark := true) -> bool:
	if Game.S == null or not (Game.S is Dictionary):
		return false
	if not Game.S.has("bseen") or not (Game.S.bseen is Dictionary):
		Game.S.bseen = {}
	var k := str(s.strip_edges().hash())
	var was: bool = Game.S.bseen.has(k)
	if mark:
		Game.S.bseen[k] = 1
	return was

## A voice line was put on a screen: the first one in this moment sounds (unless it was heard before).
func voice(v: String, text: Variant = null) -> void:
	if not _has(voice_key(v)):
		return
	if text != null:
		var t := str(text)
		if line_seen("vs|" + v + "|" + t):
			return
		if str(_vlast.get(v, "")) == t:
			return
		_vlast[v] = t
	if _vq != "":
		return
	_vq = v
	_vq_gen += 1
	var g := _vq_gen
	get_tree().create_timer(0.04).timeout.connect(func():
		if g == _vq_gen and _vq != "":
			var q := _vq
			_vq = ""
			voice_now(q))

## A staged conversation takes over: the screen-open sound is cancelled and each revealed line sounds instead.
func staged() -> void:
	_vq = ""
	_vq_gen += 1

func ambience(key: String, vol: float = 0.35) -> void:
	if key == _amb_key:
		return
	_amb_key = key
	_amb.stop()
	if key == "":
		return
	var s := _stream("res://assets/amb/" + key + ".mp3")
	if s == null:
		return
	if s is AudioStreamMP3:
		(s as AudioStreamMP3).loop = true
	_amb.stream = s
	_amb.volume_db = linear_to_db(max(0.0001, vol * volume["amb"] * volume["master"]))
	_amb.play()

func music(key: String) -> void:
	if key == _music_key:
		return
	_music_key = key
	_music.stop()
	if key == "":
		return
	var s := _stream("res://assets/music/" + key + ".mp3")
	if s == null:
		return
	if s is AudioStreamMP3:
		(s as AudioStreamMP3).loop = true
	_music.stream = s
	_music.volume_db = linear_to_db(max(0.0001, 0.6 * volume["music"] * volume["master"]))
	_music.play()
