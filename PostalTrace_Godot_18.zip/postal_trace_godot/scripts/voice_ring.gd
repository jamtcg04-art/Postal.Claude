class_name VoiceRing
extends Control
## The voice ring over the 3D view (the browser's #wring and #wsay): when a voice in your head has
## something to say about where you are, a ring in its colour hangs over the courier, with a count when
## more are waiting. Press V, click the ring, or (on a touch screen) tap the voice button at the bottom
## of the view, and the line opens in a box at the top of the view; tap the box to put it away.

const VCOL := { "arms": Color("d9695f"), "nerve": Color("cfa74b"), "wits": Color("7fa3b8"), "grit": Color("8bb871"), "duty": Color("93a9ee"), "hat": Color("c9a77f"), "trace": Color("9bbab4") }

var world: World
var shrink := 3.0
var show_button := "auto"      # "auto" (touch screens), "on", "off": the big voice button
var view: Control              # the 3D view this sits over
var area_fn: Callable          # the part of the window where the 3D view can be seen
var ring: Button
var count: Label
var button: Button
var say: PanelContainer
var say_text: RichTextLabel
var say_until := 0.0
var on_inner: Callable          # main.inner_talk: opening a ring that is an offer to talk
var _t := 0.0

func _init(w: World, shrink_by: float, over: Control) -> void:
	world = w
	shrink = shrink_by
	view = over
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	ring = Button.new()
	ring.custom_minimum_size = Vector2(34, 34)
	ring.size = Vector2(34, 34)
	ring.focus_mode = Control.FOCUS_NONE
	ring.tooltip_text = "A voice has something to say (V)"
	ring.pressed.connect(open_next)
	ring.visible = false
	add_child(ring)
	count = Label.new()
	count.add_theme_font_size_override("font_size", 11)
	count.add_theme_color_override("font_color", Color(0.07, 0.07, 0.07))
	count.position = Vector2(26, -6)
	ring.add_child(count)
	button = Button.new()
	button.focus_mode = Control.FOCUS_NONE
	button.custom_minimum_size = Vector2(0, 60)
	button.add_theme_font_size_override("font_size", 18)
	button.pressed.connect(open_next)
	button.clip_text = true
	button.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	button.visible = false
	add_child(button)
	say = PanelContainer.new()
	say.visible = false
	say.mouse_filter = Control.MOUSE_FILTER_STOP
	say.gui_input.connect(func(ev):
		if (ev is InputEventMouseButton and ev.pressed) or (ev is InputEventScreenTouch and ev.pressed):
			say.visible = false)
	add_child(say)
	say_text = RichTextLabel.new()
	say_text.bbcode_enabled = true
	say_text.fit_content = true
	say_text.scroll_active = false
	say_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	say_text.add_theme_font_size_override("normal_font_size", 17)
	say_text.add_theme_font_size_override("bold_font_size", 14)
	say.add_child(say_text)
	world.ring_changed.connect(_refresh)

static func color_of(v: String) -> Color:
	var V: Variant = Data.T.VOICES.get(v)
	var k = str(V.get("sk", v)) if V is Dictionary and V.get("sk") else v
	return VCOL.get(k, VCOL.get(v, Color("c9a77f")))

func _circle(c: Color, fill: Color) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = fill
	sb.border_color = c
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(17)
	sb.shadow_color = Color(c.r, c.g, c.b, 0.6)
	sb.shadow_size = 8
	return sb

func _box(c: Color) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.04, 0.05, 0.055, 0.93)
	sb.border_color = c
	sb.border_width_left = 4
	sb.border_width_top = 1
	sb.border_width_right = 1
	sb.border_width_bottom = 1
	sb.set_corner_radius_all(4)
	sb.content_margin_left = 14
	sb.content_margin_right = 14
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	return sb

func touch_button_wanted() -> bool:
	if show_button == "on":
		return true
	if show_button == "off":
		return false
	return DisplayServer.is_touchscreen_available() or OS.get_environment("PT_TOUCH") == "1"

## Is there anyone to listen to, and somewhere to show it?
func live() -> bool:
	return view.visible and world.active and world.place != null and not world.editing

func _refresh() -> void:
	var q: Array = world.vq
	if q.is_empty() or not live():
		ring.visible = false
		button.visible = false
		return
	var c = color_of(str(q[0].v))
	ring.add_theme_stylebox_override("normal", _circle(c, Color(c.r, c.g, c.b, 0.85)))
	ring.add_theme_stylebox_override("hover", _circle(Color(1, 0.95, 0.8), Color(c.r, c.g, c.b, 1)))
	ring.add_theme_stylebox_override("pressed", _circle(Color(1, 0.95, 0.8), Color(c.r, c.g, c.b, 1)))
	count.text = str(q.size()) if q.size() > 1 else ""
	ring.tooltip_text = Game.voice_head(str(q[0].v)) + " has something to say (V)"
	ring.visible = true
	button.visible = touch_button_wanted()
	if button.visible:
		var sb = _box(c)
		sb.border_width_left = 6
		sb.bg_color = Color(c.r * 0.25, c.g * 0.25, c.b * 0.25, 0.95)
		button.add_theme_stylebox_override("normal", sb)
		button.add_theme_stylebox_override("hover", sb)
		button.add_theme_stylebox_override("pressed", _box(Color(1, 0.95, 0.8)))
		button.text = "  " + Game.voice_head(str(q[0].v)) + " has something to say" + ("  (+%d)" % (q.size() - 1) if q.size() > 1 else "") + "  "

func open_next() -> bool:
	if not live():
		return false
	var it: Variant = world.ring_open()
	if it == null:
		return false
	if it.has("inner"):
		# an offer to talk: the voice takes you aside
		_refresh()
		if on_inner.is_valid():
			on_inner.call(str(it.inner))
		return true
	var v = str(it.v)
	var c = color_of(v)
	say.add_theme_stylebox_override("panel", _box(c))
	say_text.text = "[b][color=#%s]%s[/color][/b]\n%s" % [c.to_html(false), Game.voice_head(v).to_upper(), str(it.text).replace("[", "[lb]")]
	say.visible = true
	say_until = _t + minf(18.0, 6.0 + str(it.text).length() * 0.055)
	_refresh()
	return true

func _process(dt: float) -> void:
	_t += dt
	var vr: Rect2 = area_fn.call() if area_fn.is_valid() else view.get_global_rect()
	var origin = vr.position - get_global_rect().position
	if ring.visible:
		if not live():
			_refresh()
		else:
			var p = world.ring_point() * shrink
			ring.position = origin + p - Vector2(17, 34)
	if button.visible:
		var w = minf(vr.size.x - 24.0, 520.0)
		button.size = Vector2(w, 60)
		button.position = origin + Vector2((vr.size.x - w) / 2.0, vr.size.y - 60 - 10)
	if say.visible:
		if not live() or _t > say_until:
			say.visible = false
		else:
			var w = minf(vr.size.x - 24.0, 420.0)
			say.custom_minimum_size = Vector2(w, 0)
			say.size = Vector2(w, 0)
			say_text.custom_minimum_size = Vector2(w - 30, 0)
			say.position = origin + Vector2((vr.size.x - w) / 2.0, 14)
