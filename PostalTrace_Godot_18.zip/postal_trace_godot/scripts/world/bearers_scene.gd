class_name BearersScene
extends Node
## The ambush on Lieutenant Hale's bearers, in 3D (the browser's W.stage.bearersRide, and more):
## - "ride": the column rolls down the road toward the ford with the courier up on the tail of the cart, then the
##   treeline moves: three rebels and the rider on the grey; Pike and Skerry step out of the line; the fight follows
##   (the fight stage finds these men already standing and uses them);
## - "watch" (standing watch goes wrong, at night) and "warned" (Dunmore would not hear it): the rebels come out of
##   the dark or the trees and the column is hit where it stands.
## Every time, the bearers get the box down off the cart and close round it, kneeling, muskets out.

var world: Node3D
var stage: FightStage
var t := 0.0
var run: Dictionary = {}       # what is moving now
var bearers: Array = []        # [{f: Figure, m: Node3D}]
var box: Node3D
var cart: Node3D
var team: Node3D
var grey: Node3D

const REBEL := [{ "c": [0.3, 0.32, 0.24], "hat": "flatcap", "wpn": "musket", "parts": ["feather"] }, { "c": [0.26, 0.27, 0.2], "hat": "knitcap", "wpn": "axe" }, { "c": [0.3, 0.32, 0.24], "s": 0.86 }]
const RIDER := { "c": [0.2, 0.22, 0.27], "hat": "hat", "wpn": "pistol", "parts": ["cape"] }

func _props(model: String) -> Array:
	var out: Array = []
	var props = world.place.get_node_or_null("Props")
	if props:
		for n in props.get_children():
			if str(n.get_meta("model", "")) == model:
				out.append(n)
	return out

var _place: Node = null
var _cam_mine := false
func _gather() -> bool:
	if world == null or world.place == null or not world.file.begins_with("bearers"):
		return false
	run.clear()
	_place = world.place
	cart = _props("mk_wagon")[0] if _props("mk_wagon").size() else null
	box = _props("coffin")[0] if _props("coffin").size() else null
	team = _props("cp_horse")[0] if _props("cp_horse").size() else null
	grey = _props("cp_horse_grey")[0] if _props("cp_horse_grey").size() else null
	bearers.clear()
	var hold = world.place.get_node_or_null("Bystanders")
	if hold:
		for m in hold.get_children():
			for c in m.get_children():
				if c is Figure:
					bearers.append({ "f": c, "m": m })
	return cart != null

## The box comes down off the cart and the bearers close round it, kneeling, facing out.
func _guard(night: bool) -> void:
	if box and cart:
		var to: Vector3 = PropMotion.spot(cart) + Vector3(-1.8, 0, 0.6)
		to.y = 0.0
		run["box"] = { "from": box.position, "to": box.position + (to - PropMotion.spot(box)), "t0": t, "dur": 1.0 }
	var c: Vector3 = (PropMotion.spot(cart) + Vector3(-1.8, 0, 0.6)) if cart else world.pl
	var n := bearers.size()
	for i in n:
		var b: Dictionary = bearers[i]
		var a := TAU * i / maxf(n, 1)
		var p := c + Vector3(sin(a), 0, cos(a)) * 1.5
		b["goal"] = p
		b["face"] = a        # facing out, away from the box
		b.f.dress(b.f.look.merged({ "wpn": "musket" }, true))
	run["guard"] = true
	run["night"] = night

func _rebels(from_dark: bool) -> void:
	var base: Vector3 = PropMotion.spot(cart) if cart else world.pl
	var spots := [[11.5, -12.2, 7.0, -10.6], [-11.5, -15.5, -4.4, -12.8], [9.5, -18.5, 4.6, -16.0]]
	for i in 3:
		var q: Array = spots[i]
		var f := Figure.new()
		f.dress(REBEL[i])
		f.position = Vector3(q[0], 0, q[1])
		world.place.add_child(f)
		f.set_meta("goal", Vector3(q[2], 0, q[3]))
		stage.cast["r" + str(i + 1)] = { "f": f, "horse": null, "ranged": i == 0, "mounted": false, "down": false, "flee": null, "goal": { "to": Vector3(q[2], 0, q[3]), "sp": 2.6 if from_dark else 2.0 }, "home": Vector3(q[2], 0, q[3]) }
	# the rider in the greatcoat, up on the grey
	if grey:
		var rider := Figure.new()
		rider.dress(RIDER)
		world.place.add_child(rider)
		var hc := PropMotion.spot(grey)
		var to := Vector3(5.4, 0, -13.6)
		grey.rotation.y = atan2(to.x - hc.x, to.z - hc.z)
		if PropMotion.rig_horse(grey, 30):
			rider.mount(grey)
			PropMotion.horse_play(grey, "trot")
			run["grey"] = { "from": hc, "to": to, "t0": t, "dur": 3.0 }
		stage.cast["rider"] = { "f": rider, "horse": grey, "ranged": true, "mounted": true, "down": false, "flee": null, "goal": null, "home": to }
	# Pike steps out of the line; Skerry too, unless he was sent home
	if bearers.size() >= 10:
		var pk: Dictionary = bearers[9]
		bearers.remove_at(9)
		stage.cast["pike"] = { "f": pk.f, "horse": null, "ranged": false, "mounted": false, "down": false, "flee": null, "goal": { "to": base + Vector3(3.2, 0, 3.6), "sp": 2.4 }, "home": base + Vector3(3.2, 0, 3.6) }
	var G := world.get_tree().root.get_node("Game")
	if world.figures.has("skerry") and not G.is_done("skerry_sent"):
		stage.cast["skerry"] = { "f": world.figures.skerry, "horse": null, "ranged": false, "mounted": false, "down": false, "flee": null, "goal": { "to": base + Vector3(-1.6, 0, 4.4), "sp": 2.0 }, "home": base + Vector3(-1.6, 0, 4.4) }

## The game's main screen (the story panel and the stopped moments), found up the tree from the world.
func _main() -> Node:
	var n: Node = world
	while n != null and not n.has_method("time_stop_key"):
		n = n.get_parent()
	return n

## Ride with the bearers to the ford (the browser's bearersRide): then `then` starts the fight.
func ride(then: Callable) -> void:
	if not _gather():
		then.call()
		return
	world.input_locked = true
	stage.cast.clear()
	set_meta("cam_until", t + 14.0)
	var M := _main()
	if M:
		M.cine_for(10.4)    # the story stays out of the way for the ride and the ambush
	var D := 8.2
	var parts: Array = [team, cart, box]
	parts = parts.filter(func(p): return p != null)
	var path := [PropMotion.spot(team) + Vector3(0, 0, -D)] if team else [PropMotion.spot(cart) + Vector3(0, 0, -D)]
	run["ride"] = { "t0": t, "dur": 7.0, "D": D, "marks": bearers.map(func(b): return b.m.position) }
	world.fx.motion.drive(parts, path, D / 7.0, func():
		_rebels(false)
		_guard(false)
		world.get_tree().create_timer(3.4).timeout.connect(func():
			# time stops as the treeline moves: the voices have their say, then the fight
			var go := func():
				world.input_locked = false
				then.call()
			var M2 := _main()
			if M2:
				M2.time_stop_key("bearers:ambush", go)
			else:
				go.call()))

## The column hit where it stands: at night on the watch, or by day when Dunmore would not hear the warning.
func hit(night: bool) -> void:
	if not _gather():
		return
	stage.cast.clear()
	set_meta("cam_until", t + 9.0)
	run["night"] = night
	_rebels(night)
	world.get_tree().create_timer(0.8).timeout.connect(func(): _guard(night))
	run["volleys"] = t + 6.0

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	t += dt
	# the camera watches the cart while the ambush plays, then goes back to the courier
	if world and cart and is_instance_valid(cart) and world.place == _place and float(get_meta("cam_until", 0.0)) > t:
		world.look_here = PropMotion.spot(cart) + Vector3(0.5, 0, -2.5)
		_cam_mine = true
	elif world and _cam_mine:
		# give the camera back, but only if this scene was the one holding it (the quick draw and the stopped moments use it too)
		world.look_here = null
		_cam_mine = false
	if run.is_empty() or world == null or world.place == null:
		return
	if world.place != _place:
		run.clear()      # the place changed under the scene
		return
	if run.has("ride"):
		var r: Dictionary = run.ride
		var k := clampf((t - float(r.t0)) / float(r.dur), 0.0, 1.0)
		for i in bearers.size():
			var b: Dictionary = bearers[i]
			if i < r.marks.size():
				b.m.position = r.marks[i] + Vector3(0, 0, -float(r.D) * k)
				b.f.play("walk" if k < 1.0 else "idle")
		if cart:
			var c := PropMotion.spot(cart)
			world.pl = Vector3(c.x + 0.62, 0, c.z + 1.75)
			world.face = PI
			world.player.position = world.pl + Vector3(0, 0.95, 0)
			world.player.play("sit")
		if k >= 1.0:
			run.erase("ride")
	if run.has("box") and box:
		var bx: Dictionary = run.box
		var k2 := clampf((t - float(bx.t0)) / float(bx.dur), 0.0, 1.0)
		box.position = (bx.from as Vector3).lerp(bx.to, k2)
		if k2 >= 1.0:
			run.erase("box")
	if run.has("grey") and grey:
		var g: Dictionary = run.grey
		var k3 := clampf((t - float(g.t0)) / float(g.dur), 0.0, 1.0)
		var p: Vector3 = (g.from as Vector3).lerp(g.to, k3)
		var c3 := PropMotion.spot(grey)
		grey.position += Vector3(p.x - c3.x, 0, p.z - c3.z)
		if k3 >= 1.0:
			PropMotion.horse_play(grey, "idle")
			run.erase("grey")
	if run.get("guard"):
		for b in bearers:
			if not b.has("goal"):
				continue
			var to: Vector3 = b.goal
			var gp: Vector3 = b.m.global_position
			var d := Vector3(to.x - gp.x, 0, to.z - gp.z)
			if d.length() > 0.08:
				b.m.global_position = gp + d.normalized() * minf(d.length(), 3.2 * dt)
				b.m.rotation.y = atan2(d.x, d.z)
				b.f.play("jog")
			else:
				b.m.rotation.y = float(b.face)
				b.f.play("kneel")
	if run.has("volleys"):
		if t < float(run.volleys):
			if randf() < dt * 2.5 and bearers.size():
				var b2: Dictionary = bearers[randi() % bearers.size()]
				stage._flash(b2.m.global_position + Vector3(sin(b2.m.rotation.y), 0, cos(b2.m.rotation.y)) * 0.6)
				var S := world.get_tree().root.get_node_or_null("Sound")
				if S:
					S.play("pistol", 0.18)
		else:
			run.erase("volleys")
			for id in stage.cast:
				if str(id).begins_with("r") and randf() < 0.6:
					stage._js_flee([id])
