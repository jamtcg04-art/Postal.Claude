class_name FightStage
extends Node
## Fights in 3D, behind the fight screens: the same events the browser's W.stage answers (the fight logic is the
## browser's, run by JsLite, and calls fStage(name, ...)): spawn the men you fight around the courier, riders up on
## horses; each round the brawlers close in and the gunmen keep their range; shots flash, blows land, men reel,
## fall, or run; the dead stay down until the fight is over. Thieves come with cudgels and knives, no guns.

var world: Node3D
var bearers: BearersScene       # the ambush on the bearers (bearers_scene.gd)
var cast: Dictionary = {}       # foe id -> {f: Figure, horse: Node3D, ranged, mounted, down, flee, goal, home}
var flashes: Array = []         # {n, until}
var _end_at := -1.0
var t := 0.0

const PROVOST := { "body": "soldier", "c": [0.15, 0.15, 0.2], "hat": "shako" }
const PLAIN := { "c": [0.3, 0.26, 0.22], "hat": "flatcap" }

func _auto(n: String) -> Node:
	return world.get_tree().root.get_node_or_null(n) if world and world.is_inside_tree() else null

func setup(w: Node3D) -> void:
	world = w
	var B := _auto("Bridge")
	if B == null:
		return
	var W: Variant = B.js("W")
	if not W is Dictionary:
		return
	if not W.get("stage") is Dictionary:
		W["stage"] = {}
	var st: Dictionary = W.stage
	for k in ["spawn", "round", "sel", "shot", "foeShot", "foeHit", "lunge", "hurt", "down", "flee", "ally", "blast", "unhorse", "reset", "despawn"]:
		st[k] = Callable(self, "_js_" + k)

func _f(id: Variant) -> Variant:
	return cast.get(str(id))

func _look_for(F: Dictionary, f: Dictionary) -> Dictionary:
	var cfg: Dictionary = F.get("cfg", {}) if F.get("cfg") is Dictionary else {}
	var lab := (str(cfg.get("foeLabel", "")) + " " + str(f.get("name", "")) + " " + str(cfg.get("stage", ""))).to_lower()
	var o: Dictionary
	if RegEx.create_from_string("provost|trooper|corporal|rider|patrol|lisle|captain|sentry|levies").search(lab):
		o = PROVOST.duplicate(true)
	else:
		o = PLAIN.duplicate(true)
		o.c = [0.26 + randf() * 0.1, 0.24 + randf() * 0.06, 0.2 + randf() * 0.05]
		if randf() < 0.4:
			o.hat = ["knitcap", "strawhat", "flatcap"][randi() % 3]
	var thief := str(cfg.get("stage", "")) == "thieves"
	if f.get("ranged") and not thief:
		o.wpn = "pistol" if f.get("leader") else "musket"
	else:
		o.wpn = ["club", "axe"][randi() % 2] if thief or not o.has("body") else "sabre"
	if f.get("id") == "th3":
		o.erase("wpn")
		o.s = 0.82
	return o

func _here() -> Vector3:
	return world.pl

# ---------------------------------------------------------------- the events

func _js_spawn(a: Array) -> Variant:
	var F: Variant = a[0] if a.size() else null
	if not F is Dictionary or world == null or world.place == null:
		return null
	var cfg: Dictionary = F.get("cfg", {}) if F.get("cfg") is Dictionary else {}
	if bearers and world.file.begins_with("bearers") and str(cfg.get("title", "")).to_lower().find("ambush") >= 0:
		# the ride to the ford, then the treeline moves: these men are the ones you fight
		bearers.ride(func(): pass)
		return null
	_clear_now()
	var road: Variant = world.get("road")
	if road != null and is_instance_valid(road):
		# the men standing by the road for this stop are the ones you fight: they step in
		for n in road.set_nodes:
			if n is Figure and is_instance_valid(n):
				n.visible = false
	var foes: Array = F.get("foes", [])
	var px := _here()
	var base := PI / 2.0 if road != null else atan2(-1.0, -1.0)
	var n := foes.size()
	for i in n:
		var f: Dictionary = foes[i]
		if f.get("ally"):
			continue
		var r := 4.6 if f.get("ranged") else 2.9
		var ang := base + (i - (n - 1) / 2.0) * (0.42 if f.get("ranged") else 0.55)
		var pos := Vector3(px.x + sin(ang) * r, 0, px.z + cos(ang) * r)
		var fig := Figure.new()
		fig.dress(_look_for(F, f))
		fig.position = pos
		fig.rotation.y = atan2(px.x - pos.x, px.z - pos.z)
		world.place.add_child(fig)
		fig.play("pidle" if f.get("ranged") else "idle")
		var e := { "f": fig, "horse": null, "ranged": f.get("ranged", false) == true, "mounted": false, "down": false, "flee": null, "goal": null, "home": pos }
		if f.get("mounted"):
			var h := PlaceBuilder._prop({ "m": "cp_horse", "x": pos.x, "z": pos.z, "h": 1.9, "r": fig.rotation.y, "tint": [0.45 + randf() * 0.2, 0.36, 0.3] }, PlaceBuilder.models().get("sizes", {}))
			world.place.add_child(h)
			if PropMotion.rig_horse(h, i + 20):
				var c := PropMotion.spot(h)
				h.position += Vector3(pos.x - c.x, 0, pos.z - c.z)
				fig.mount(h)
				e.horse = h
				e.mounted = true
			else:
				h.queue_free()
		cast[str(f.get("id"))] = e
	if world.mounted():
		PropMotion.horse_play(world.my_horse, "shy")
	return null

func _js_round(_a: Array) -> Variant:
	var px := _here()
	var close: Array = []
	var far: Array = []
	for id in cast:
		var e: Dictionary = cast[id]
		if e.down or e.flee != null or e.mounted:
			continue
		(far if e.ranged else close).append(e)
	for i in close.size():
		var e: Dictionary = close[i]
		var p: Vector3 = e.f.position
		var ang := atan2(p.x - px.x, p.z - px.z) + (i - (close.size() - 1) / 2.0) * 0.35
		var r := 1.7 + (i % 2) * 0.35
		e.goal = { "to": Vector3(px.x + sin(ang) * r, 0, px.z + cos(ang) * r), "sp": 2.2 }
	for e in far:
		var p2: Vector3 = e.f.position
		var ang2 := atan2(p2.x - px.x, p2.z - px.z) + (randf() - 0.5) * 0.6
		var r2 := clampf(Vector2(p2.x - px.x, p2.z - px.z).length(), 3.4, 5.5)
		e.goal = { "to": Vector3(px.x + sin(ang2) * r2, 0, px.z + cos(ang2) * r2), "sp": 1.6 }
	return null

func _js_sel(_a: Array) -> Variant:
	return null

func _flash(p: Vector3, big := false) -> void:
	var g := PlaceBuilder._light({ "x": p.x, "z": p.z, "flat": true, "w": 9.0 if big else 3.2, "c": [1, 0.6, 0.2] if big else [0.9, 0.7, 0.35] }, 77)
	if g:
		world.place.add_child(g)
		flashes.append({ "n": g, "until": t + (0.7 if big else 0.16) })

func _face_courier_to(e: Dictionary) -> void:
	var p: Vector3 = e.f.position
	world.face = atan2(p.x - world.pl.x, p.z - world.pl.z)

## The courier fires.
func _js_shot(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e != null:
		_face_courier_to(e)
	if not world.mounted():
		world.player.play_once("pshoot", 1.0, 0.6)
	_flash(world.pl + Vector3(sin(world.face), 0, cos(world.face)) * 0.7)
	return null

func _js_foeShot(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e == null or e.down:
		return null
	var p: Vector3 = e.f.position
	e.f.rotation.y = atan2(world.pl.x - p.x, world.pl.z - p.z)
	if not e.mounted:
		e.f.play_once("pshoot", 1.0, 0.6)
	_flash(p)
	return null

## A man swings at the courier: he steps in, strikes, and steps back.
func _js_foeHit(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	var o: Dictionary = a[1] if a.size() > 1 and a[1] is Dictionary else {}
	if e == null or e.down or e.flee != null or e.mounted:
		return null
	var p: Vector3 = e.f.position
	var d := Vector3(world.pl.x - p.x, 0, world.pl.z - p.z)
	var l := maxf(d.length(), 0.01)
	e.f.rotation.y = atan2(d.x, d.z)
	var lk: Dictionary = e.f.look
	var move := "slash" if str(lk.get("wpn", "")) == "sabre" else ("chop" if str(lk.get("wpn", "")) in ["club", "axe"] else "punch")
	e.goal = { "to": p + d / l * maxf(0.0, l - 0.85), "sp": 7.0, "then": move, "back": p }
	if o.get("hit"):
		get_tree().create_timer(0.35).timeout.connect(func():
			if world and world.player and not world.mounted():
				world.player.play_once("hith", 1.0, 0.45))
	return null

## The courier closes with a man (a cut, a blow, a shove).
func _js_lunge(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e == null or e.down or e.flee != null:
		return null
	_face_courier_to(e)
	var p: Vector3 = e.f.position
	var d := Vector3(p.x - world.pl.x, 0, p.z - world.pl.z)
	var l := d.length()
	if l > 1.4 and not world.mounted():
		world._move_to(p.x - d.x / l * 1.1, p.z - d.z / l * 1.1)
	if not world.mounted():
		world.player.play_once("slash" if _auto("Game") and _auto("Game").has("sabre") else "punch", 1.0, 0.5)
	return null

func _js_hurt(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e == null or e.down or e.flee != null:
		return null
	if not e.mounted:
		e.f.play_once("hitc", 1.0, 0.4)
		var p: Vector3 = e.f.position
		var d := Vector3(p.x - world.pl.x, 0, p.z - world.pl.z).normalized()
		e.goal = { "to": p + d * 0.45, "sp": 5.0 }
	elif e.horse:
		PropMotion.horse_play(e.horse, "shy")
	return null

func _js_down(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e == null:
		return null
	if e.mounted:
		_unhorse(e)
	e.down = true
	e.goal = null
	e.f.play_once("death", 1.0, 999.0)
	return null

func _js_flee(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e == null or e.down:
		return null
	var p: Vector3 = e.f.position
	var d := Vector3(p.x - world.pl.x, 0, p.z - world.pl.z).normalized()
	e.flee = d
	e.goal = null
	if e.horse:
		PropMotion.horse_play(e.horse, "gallop", 1.2)
	return null

func _js_ally(a: Array) -> Variant:
	var e: Variant = _f(a[0] if a.size() else "")
	if e:
		var lk: Dictionary = e.f.look.duplicate(true)
		lk.c = [0.3, 0.27, 0.22]
		e.f.dress(lk)
	return null

func _js_blast(a: Array) -> Variant:
	if a.size() >= 2:
		_flash(Vector3(float(a[0]), 0, float(a[1])), true)
	return null

func _unhorse(e: Dictionary) -> void:
	e.mounted = false
	e.f.dismount()
	var p: Vector3 = e.f.position
	e.f.position = p + Vector3(1.0, 0, 0.5)
	if e.horse:
		PropMotion.horse_play(e.horse, "rear")
		e["bolt"] = true

func _js_unhorse(_a: Array) -> Variant:
	for id in cast:
		if cast[id].mounted:
			_unhorse(cast[id])
			break
	return null

func _js_reset(_a: Array) -> Variant:
	for id in cast:
		cast[id].goal = null
	return null

## After a fight the men are gone in a few seconds (the dead too, as in the browser).
func _js_despawn(a: Array) -> Variant:
	var now: bool = a.size() > 1 and a[1] != null and a[1] != false and a[1] != 0
	if now:
		_clear_now()
	else:
		_end_at = t + 5.0
	return null

func _clear_now() -> void:
	for id in cast:
		var e: Dictionary = cast[id]
		if e.f != null and is_instance_valid(e.f):
			e.f.queue_free()
		if e.horse and is_instance_valid(e.horse):
			e.horse.queue_free()
	cast.clear()
	_end_at = -1.0

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	t += dt
	var keep: Array = []
	for fl in flashes:
		if t >= float(fl.until):
			if is_instance_valid(fl.n):
				fl.n.queue_free()
		else:
			keep.append(fl)
	flashes = keep
	if _end_at > 0.0 and t >= _end_at:
		_clear_now()
	for id in cast:
		var e: Dictionary = cast[id]
		if not is_instance_valid(e.f):
			continue
		var fig: Figure = e.f
		if e.get("bolt") and e.horse and is_instance_valid(e.horse):
			e.horse.position += Vector3(sin(e.horse.rotation.y), 0, cos(e.horse.rotation.y)) * dt * 6.0
		if e.flee != null:
			var fd: Vector3 = e.flee
			if e.mounted and e.horse:
				e.horse.rotation.y = atan2(fd.x, fd.z)
				e.horse.position += fd * dt * 7.0
			else:
				fig.position += fd * dt * 4.6
				fig.rotation.y = atan2(fd.x, fd.z)
				fig.play("sprint")
			continue
		if e.goal != null and not e.down:
			var g: Dictionary = e.goal
			var to: Vector3 = g.to
			var d := Vector3(to.x - fig.position.x, 0, to.z - fig.position.z)
			if d.length() > 0.04:
				var step := minf(d.length(), float(g.sp) * dt)
				fig.position += d.normalized() * step
				if g.get("then") == null:
					fig.rotation.y = atan2(d.x, d.z)
				fig.play("jog" if float(g.sp) > 3.0 else "walk")
			else:
				if g.get("then") != null:
					fig.play_once(str(g.then), 1.2, 0.45)
					var back: Vector3 = g.back
					e.goal = { "to": back, "sp": 3.0 }
				else:
					e.goal = null
					fig.rotation.y = atan2(world.pl.x - fig.position.x, world.pl.z - fig.position.z)
					fig.play("pidle" if e.ranged else "idle")
