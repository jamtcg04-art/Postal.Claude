## PlaceBuilder: turns a place layout (data/places/<id>.json) into Godot nodes.
##
## The layout lists every prop with the browser version's placement numbers
## (x, z, height or scale, turn, tilt...). Props become instances of the converted
## models in assets/3d/models; models that are not converted yet become grey
## stand-in blocks of the right height. tools/bake_places.gd saves the result as
## places/<id>.tscn, which is what you open in the editor to rearrange a place.
class_name PlaceBuilder
extends RefCounted

const PSX := preload("res://shaders/psx.gdshader")
const GLOW := preload("res://shaders/glow.gdshader")

## Colours for ground textures that are not converted yet.
const GROUND_BASE := { "grass": Color(0.32, 0.4, 0.24), "mud": Color(0.36, 0.29, 0.21), "mud2": Color(0.33, 0.27, 0.2),
	"gravel": Color(0.46, 0.44, 0.4), "t_water": Color(0.2, 0.3, 0.34), "t_sand": Color(0.6, 0.55, 0.42),
	"t_earth": Color(0.38, 0.3, 0.22), "t_stone": Color(0.5, 0.49, 0.47), "t_planks": Color(0.45, 0.36, 0.26),
	"t_hay": Color(0.62, 0.55, 0.32), "t_charred": Color(0.15, 0.13, 0.12) }

static var _models: Dictionary = {}
static var _tex_cache: Dictionary = {}
static var _mat_cache: Dictionary = {}

static func models() -> Dictionary:
	if _models.is_empty():
		var v: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://data/models.json"))
		_models = v if v is Dictionary else {}
	return _models

static func layout(file: String) -> Dictionary:
	var p = "res://data/places/%s.json" % file
	if not FileAccess.file_exists(p):
		return {}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(p))
	return v if v is Dictionary else {}

static func texture(key: String) -> Texture2D:
	if key == "":
		return null
	if _tex_cache.has(key):
		return _tex_cache[key]
	var t: Texture2D = null
	for ext in ["png", "jpg"]:
		var p = "res://assets/3d/tex/%s.%s" % [key, ext]
		if ResourceLoader.exists(p):
			t = load(p)
			break
	_tex_cache[key] = t
	return t

## A material in the game's own look. Shared between everything that looks the same.
static func psx(tex: Texture2D, col: Color, lit := true, flow := Vector2.ZERO, alpha := 1.0) -> ShaderMaterial:
	var key = "%s|%s|%s|%s|%s" % [tex.resource_path if tex else "", col.to_html(), lit, flow, alpha]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m = ShaderMaterial.new()
	m.shader = PSX
	m.set_shader_parameter("use_tex", tex != null)
	if tex:
		m.set_shader_parameter("tex", tex)
	m.set_shader_parameter("color", Vector3(col.r, col.g, col.b))
	m.set_shader_parameter("lit", lit)
	m.set_shader_parameter("flow", flow)
	m.set_shader_parameter("alpha", alpha)
	_mat_cache[key] = m
	return m

static func _col(a: Variant, fallback := Color(1, 1, 1)) -> Color:
	if a is Array and a.size() >= 3:
		return Color(float(a[0]), float(a[1]), float(a[2]))
	return fallback

## The browser version's placement: turn about y, scale, then tilt about x and z, with the
## model's footprint centred on (x, z) and its base on the ground.
static func item_transform(it: Dictionary, mn: Array, sz: Array) -> Transform3D:
	var h = float(sz[1]) if sz.size() > 1 and float(sz[1]) > 0.0 else 1.0
	var s = _f(it.get("h"), 1.0) / h if it.get("h") else _f(it.get("s"), 1.0)
	var ry = _f(it.get("r"), 0.0)
	var c = cos(ry)
	var sn = sin(ry)
	var sx = s * _f(it.get("sx"), 1.0)
	var sy = s * _f(it.get("sy"), 1.0)
	var sz2 = s * _f(it.get("sz"), 1.0)
	var b = Basis(Vector3(c * sx, 0, -sn * sx), Vector3(0, sy, 0), Vector3(sn * sz2, 0, c * sz2))
	var rx = _f(it.get("rx"), 0.0)
	if rx != 0.0:
		b = b * Basis(Vector3(1, 0, 0), Vector3(0, cos(rx), sin(rx)), Vector3(0, -sin(rx), cos(rx)))
	var rz = _f(it.get("rz"), 0.0)
	if rz != 0.0:
		b = b * Basis(Vector3(cos(rz), sin(rz), 0), Vector3(-sin(rz), cos(rz), 0), Vector3(0, 0, 1))
	var cx = float(mn[0]) + float(sz[0]) / 2.0
	var cz = float(mn[2]) + float(sz[2]) / 2.0
	var off = Vector3(-cx, 0.0 if it.get("spin") else -float(mn[1]), -cz)
	return Transform3D(b, Vector3(_f(it.get("x"), 0.0), _f(it.get("y"), 0.0), _f(it.get("z"), 0.0))) * Transform3D(Basis(), off)

# ================================================================ building

## Build a place. file is the layout's file name ("cross", or "malice__hall" for an inside area).
static func build(file: String) -> Node3D:
	var L = layout(file)
	var root = Node3D.new()
	root.name = "Place_" + file
	if L.is_empty():
		return root
	for k in ["id", "area", "bounds", "start", "enter", "exit", "face", "fog", "fogR", "light", "zoom", "camOff", "lifts", "liftTop"]:
		root.set_meta(k, L.get(k))
	root.set_meta("file", file)
	var ground = Node3D.new(); ground.name = "Ground"; root.add_child(ground)
	var props = Node3D.new(); props.name = "Props"; root.add_child(props)
	var lights = Node3D.new(); lights.name = "Lights"; root.add_child(lights)
	var people = Node3D.new(); people.name = "People"; root.add_child(people)
	var extras = Node3D.new(); extras.name = "Bystanders"; root.add_child(extras)
	var things = Node3D.new(); things.name = "Things"; root.add_child(things)
	var solids = Node3D.new(); solids.name = "Solid"; root.add_child(solids)
	var i = 0
	for g in L.get("grounds", []):
		ground.add_child(_ground(g, i))
		i += 1
	var sizes: Dictionary = models().get("sizes", {})
	i = 0
	for it in L.get("props", []):
		var n = _prop(it, sizes)
		if n:
			n.name = "%s_%d" % [it.m, i]
			props.add_child(n)
		i += 1
	i = 0
	for l in L.get("lights", []):
		var n = _light(l, i)
		if n:
			lights.add_child(n)
		i += 1
	for p in L.get("people", []):
		people.add_child(_marker(p, "person"))
	i = 0
	for p in L.get("extras", []):
		var m = _marker(p, "extra")
		m.name = "Bystander_%d" % i
		extras.add_child(m)
		i += 1
	for t in L.get("things", []):
		things.add_child(_marker(t, "door" if t.get("door") else "thing"))
	i = 0
	for s in L.get("solid", []):
		if not (s is Dictionary):
			continue
		var m = Marker3D.new()
		if s.has("r"):
			m.name = "Post_%d" % i
			m.position = Vector3(float(s.x), 0, float(s.z))
			m.set_meta("r", float(s.r))
		else:
			m.name = "Block_%d" % i
			m.position = Vector3((float(s.x0) + float(s.x1)) / 2.0, 0, (float(s.z0) + float(s.z1)) / 2.0)
			m.set_meta("half", Vector2((float(s.x1) - float(s.x0)) / 2.0, (float(s.z1) - float(s.z0)) / 2.0))
		solids.add_child(m)
		i += 1
	return root

static func _ground(g: Dictionary, i: int) -> MeshInstance3D:
	var r: Array = g.r
	var x0 = float(r[0]); var z0 := float(r[1]); var x1 := float(r[2]); var z1 := float(r[3])
	var y = _f(g.get("y"), 0.0)
	var rep = _f(g.get("rep"), 3.0)
	var st = SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var corners = [Vector3(x0, y, z0), Vector3(x0, y, z1), Vector3(x1, y, z1), Vector3(x0, y, z0), Vector3(x1, y, z1), Vector3(x1, y, z0)]
	# a patch can be turned about its middle (the place editor's "turn"); the texture turns with it
	var rot = _f(g.get("rot"), 0.0)
	var cx = (x0 + x1) / 2.0
	var cz = (z0 + z1) / 2.0
	var c = cos(rot)
	var sn = sin(rot)
	for v in corners:
		st.set_normal(Vector3.UP)
		st.set_uv(Vector2((v.x - x0) / rep, (v.z - z0) / rep))
		var dx = v.x - cx
		var dz = v.z - cz
		st.add_vertex(Vector3(cx + c * dx + sn * dz, y, cz - sn * dx + c * dz) if rot != 0.0 else v)
	var mi = MeshInstance3D.new()
	mi.name = "Ground_%d_%s" % [i, g.get("tex", "")]
	mi.mesh = st.commit()
	var key = str(g.get("tex", ""))
	var t = texture(key)
	var col = _col(g.get("c"))
	if t == null:
		col = col * GROUND_BASE.get(key, Color(0.4, 0.4, 0.36)) * 1.6
	var fl: Variant = g.get("flow")
	mi.material_override = psx(t, col, true, Vector2(float(fl[0]), float(fl[1])) if fl is Array else Vector2.ZERO)
	return mi

static func _prop(it: Dictionary, sizes: Dictionary) -> Node3D:
	var name = str(it.m)
	var path = "res://assets/3d/models/%s.glb" % name
	var tint = _col(it.get("tint"))
	if sizes.has(name) and ResourceLoader.exists(path):
		var inst: Node3D = load(path).instantiate()
		var sz: Dictionary = sizes[name]
		inst.transform = item_transform(it, sz.mn, sz.sz)
		_restyle(inst, tint, str(it.get("mat", "")), bool(it.get("unlit", false)), _f(it.get("a"), 1.0))
		inst.set_meta("model", name)
		inst.set_meta("tint", tint)
		inst.set_meta("mat", str(it.get("mat", "")))
		inst.set_meta("unlit", bool(it.get("unlit", false)))
		inst.set_meta("a", _f(it.get("a"), 1.0))
		return inst
	# not converted yet: a stand-in block of about the right size
	var mi = MeshInstance3D.new()
	var h = _f(it.get("h"), 0.0)
	if h <= 0.0:
		h = 1.5 * _f(it.get("s"), 1.0) * _f(it.get("sy"), 1.0)
	var box = BoxMesh.new()
	var w = h * 0.6
	if name.begins_with("tree") or name.begins_with("dtree"):
		var cyl = CylinderMesh.new()
		cyl.top_radius = 0.0
		cyl.bottom_radius = h * 0.22
		cyl.height = h
		mi.mesh = cyl
		mi.material_override = psx(null, Color(0.22, 0.32, 0.2) * tint)
	else:
		if RegEx.create_from_string("house|tavern|bld|livery|barn|shack|leanto|mvh_|hp_|wd_|uf_|gy_maus|openbarn").search(name):
			box.size = Vector3(h * 1.3, h, h)
		elif RegEx.create_from_string("fence|wall|barrier|logs").search(name):
			box.size = Vector3(3.5 * _f(it.get("sx"), 1.0), h, 0.25)
		else:
			box.size = Vector3(w, h, w)
		mi.mesh = box
		mi.material_override = psx(null, Color(0.42, 0.39, 0.35) * tint)
	var t = item_transform(it, [-0.5, 0.0, -0.5], [1.0, 1.0, 1.0])
	# the block is drawn at its own size, so keep only the placement and the turns
	mi.transform = Transform3D(t.basis.orthonormalized(), t.origin + Vector3(0, mi.mesh.get_aabb().size.y / 2.0, 0))
	mi.set_meta("model", name)
	mi.set_meta("standin", true)
	return mi

## Swap the imported materials for the game's look, keeping texture and colour.
static func _restyle(n: Node, tint: Color, mat_tex: String, unlit: bool, alpha: float) -> void:
	var override = texture(mat_tex) if mat_tex != "" else null
	for mi in n.find_children("*", "MeshInstance3D", true, false):
		var mesh: Mesh = mi.mesh
		if mesh == null:
			continue
		var any_tex = false
		for s in mesh.get_surface_count():
			var src = mesh.surface_get_material(s)
			if src is BaseMaterial3D and src.albedo_texture:
				any_tex = true
		for s in mesh.get_surface_count():
			var src = mesh.surface_get_material(s)
			var t: Texture2D = null
			var c = Color(1, 1, 1)
			var lit = not unlit
			if src is BaseMaterial3D:
				t = src.albedo_texture
				c = src.albedo_color
				if src.shading_mode == BaseMaterial3D.SHADING_MODE_UNSHADED:
					lit = false
			if override and (t != null or not any_tex):
				t = override
			mi.set_surface_override_material(s, psx(t, Color(c.r * tint.r, c.g * tint.g, c.b * tint.b), lit, Vector2.ZERO, alpha))

## A place loaded from a saved .tscn: put the game's look back on its models.
static func restyle_all(root: Node) -> void:
	var props = root.get_node_or_null("Props")
	if props == null:
		return
	for n in props.get_children():
		if n.has_meta("model") and not n.has_meta("standin"):
			_restyle(n, n.get_meta("tint", Color(1, 1, 1)), str(n.get_meta("mat", "")), bool(n.get_meta("unlit", false)), float(n.get_meta("a", 1.0)))

## Save a built place as a scene you can open and edit in Godot.
static func bake(file: String, path: String) -> int:
	var root = build(file)
	_own(root, root)
	var ps = PackedScene.new()
	var err = ps.pack(root)
	if err == OK:
		err = ResourceSaver.save(ps, path)
	root.free()
	return err

static func _own(n: Node, root: Node) -> void:
	for c in n.get_children():
		if c.owner == null:
			c.owner = root
			_own(c, root)

static func _light(l: Dictionary, i: int) -> Node3D:
	if not l.get("flat"):
		return null
	var mi = MeshInstance3D.new()
	mi.name = "Glow_%d" % i
	var q = QuadMesh.new()
	var w = _f(l.get("w"), 3.0)
	q.size = Vector2(w, w)
	q.orientation = PlaneMesh.FACE_Y
	mi.mesh = q
	mi.position = Vector3(_f(l.get("x"), 0.0), 0.15, _f(l.get("z"), 0.0))
	var m = ShaderMaterial.new()
	m.shader = GLOW
	var c = _col(l.get("c"), Color(0.4, 0.25, 0.1))
	m.set_shader_parameter("color", Vector3(c.r, c.g, c.b))
	m.set_shader_parameter("flick", bool(l.get("flick", false)))
	m.set_shader_parameter("seed", float(i) * 1.7)
	mi.material_override = m
	return mi

## People, bystanders, things and doors are markers that carry their data; the World
## puts a figure on each person and makes them all clickable.
static func _marker(p: Dictionary, kind: String) -> Marker3D:
	var m = Marker3D.new()
	m.name = (kind.capitalize() + "_" + str(p.get("id", ""))).replace(" ", "_")
	m.position = Vector3(_f(p.get("x"), 0.0), _f(p.get("y"), 0.0), _f(p.get("z"), 0.0))
	m.rotation.y = _f(p.get("face"), 0.0)
	m.set_meta("kind", kind)
	for k in ["id", "name", "look", "hy", "ax", "az", "pr", "sit", "always", "to", "at", "toFace", "note", "coat", "hue", "pair", "noTurn"]:
		if p.has(k) and p[k] != null:
			m.set_meta(k, p[k])
	return m

static func _f(v: Variant, d: float) -> float:
	return d if v == null or not (typeof(v) in [TYPE_INT, TYPE_FLOAT]) else float(v)
