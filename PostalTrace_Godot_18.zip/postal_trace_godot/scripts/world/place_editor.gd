class_name PlaceEditor
extends Control
## The place editor (Dev Mode), as in the browser build: edit any 3D place by hand. Four modes:
##   Props            select, drag, turn, raise, resize, recolour, change material, copy, delete, add
##                    any model in the game
##   People           move and turn anyone standing in the place, how they stand about, their clothes,
##                    what they carry, their age
##   Ground & roads   move, stretch, turn, retexture and tint each patch; lay new patches and roads
##   Blockers         the invisible walls: move, resize, add, delete; the edges of the walkable area
## Changes are a layer over the place (place_edits.gd) in the browser's own format: they are kept on
## this machine, and Save file / Load file move them between the two builds.

signal changed

const BTN := Color(0.16, 0.19, 0.22)
const GOLD := Color("c9a35a")
const HI := Color("ffe28a")
const R15 := PI / 12.0

var world: World
var shrink := 2.0
var on := false
var mode := "props"
var sel = null          # a prop entry of the place's PlaceEdits
var bsel = null         # a blocker entry
var psel = null         # a person entry
var gsel = null         # a ground entry
var undo: Array = []
var drag = null
var pick = null         # the "add a prop" search, or null when the list is shut
var pmat := false
var gtex := false
var msg := ""
var _sure := false

var panel: PanelContainer
var box: VBoxContainer
var toggle: Button
var overlay: Control

func _init(w: World, shrink_by: float) -> void:
	world = w
	shrink = shrink_by
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay = Control.new()
	overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.draw.connect(_draw_overlay)
	add_child(overlay)
	panel = PanelContainer.new()
	panel.position = Vector2(12, 12)
	panel.custom_minimum_size = Vector2(330, 0)
	var sb = StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.08, 0.1, 0.94)
	sb.border_color = Color("6b5a3a")
	sb.set_border_width_all(1)
	sb.set_content_margin_all(10)
	panel.add_theme_stylebox_override("panel", sb)
	panel.visible = false
	add_child(panel)
	var sc = ScrollContainer.new()
	sc.custom_minimum_size = Vector2(320, 0)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(sc)
	box = VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 3)
	sc.add_child(box)
	toggle = Button.new()
	toggle.text = "Edit place"
	toggle.focus_mode = Control.FOCUS_NONE
	toggle.anchor_top = 1.0
	toggle.anchor_bottom = 1.0
	toggle.offset_left = 12
	toggle.offset_top = -40
	toggle.offset_bottom = -12
	toggle.pressed.connect(func(): stop() if on else start())
	toggle.visible = false
	add_child(toggle)

func E() -> PlaceEdits:
	return world.edits if world and world.place else null

func key() -> String:
	return E().key if E() else ""

## Show the "Edit place" button while Dev Mode is on and a place is in view.
func set_available(yes: bool) -> void:
	toggle.visible = yes
	if not yes and on:
		stop()

func start() -> void:
	if E() == null:
		return
	on = true
	world.editing = true
	world.edit_cam = world.cam_target
	world.label.visible = false
	world.bark_label.visible = false
	sel = null; bsel = null; psel = null; gsel = null
	undo.clear()
	toggle.text = "Done editing"
	panel.visible = true
	refresh_panel()

func stop() -> void:
	on = false
	mode = "props"
	world.editing = false
	world.edit_cam = null
	world.label.visible = false
	world.refresh()
	sel = null; bsel = null; psel = null; gsel = null
	drag = null
	toggle.text = "Edit place"
	panel.visible = false
	overlay.queue_redraw()

func _process(_d: float) -> void:
	if on:
		overlay.queue_redraw()
		_label_sel()
		var vh = get_viewport_rect().size.y
		panel.size.y = 0
		panel.get_child(0).custom_minimum_size.y = minf(vh * 0.7, 640)

# ================================================================ the edit layer

func _push() -> void:
	var a = PlaceEdits.user_all()
	undo.append(JSON.stringify(a.get(key()) if a.has(key()) else (PlaceEdits.for_key(key()) if not PlaceEdits.for_key(key()).is_empty() else null)))
	if undo.size() > 60:
		undo.pop_front()

func do_undo() -> void:
	if undo.is_empty():
		return
	var prev: Variant = JSON.parse_string(undo.pop_back())
	var a = PlaceEdits.user_all()
	if prev is Dictionary:
		a[key()] = prev
	else:
		a.erase(key())
	PlaceEdits.save_user()
	_rebuild()

func _rebuild() -> void:
	var cam = world.edit_cam
	world.rebuild()
	world.editing = true
	world.edit_cam = cam
	sel = null; bsel = null; psel = null; gsel = null
	refresh_panel()

func reset_place() -> void:
	if not _sure:
		_sure = true
		msg = "Press Reset place again to reset."
		refresh_panel()
		get_tree().create_timer(2.5).timeout.connect(func(): _sure = false)
		return
	_sure = false
	_push()
	PlaceEdits.user_all()[key()] = {}       # nothing changed here, even over edits baked into the game
	PlaceEdits.save_user()
	_rebuild()

static func r3(v: float) -> float:
	return PlaceEdits.r3(v)

## Write a prop's state into the edit layer (the browser's edRecord).
func rec_prop(p: Dictionary) -> void:
	var e = E().E_mut()
	var it: Dictionary = p.cur
	var d: Dictionary
	if p.add >= 0:
		if p.add >= e.adds.size():
			return
		d = e.adds[p.add]
	else:
		if not e.mods.has(p.id):
			e.mods[p.id] = {}
		d = e.mods[p.id]
	d["x"] = r3(float(it.x)); d["z"] = r3(float(it.z)); d["y"] = r3(float(it.get("y", 0))); d["r"] = r3(float(it.get("r", 0)))
	if it.get("h") != null:
		d["h"] = r3(float(it.h))
	else:
		d["s"] = r3(float(it.get("s", 1.0)))
	var o: Variant = p.it.get("tint")
	var t: Variant = it.get("tint")
	var same = t == null or (o is Array and range(3).all(func(i): return absf(float(o[i]) - float(t[i])) < 1e-4))
	if not same:
		d["tint"] = t.map(func(v): return r3(float(v)))
	else:
		d.erase("tint")
	if it.get("mat"):
		d["mat"] = str(it.mat)
	else:
		d.erase("mat")
	if p.get("del"):
		d["del"] = true
	PlaceEdits.save_user()
	changed.emit()

func _do(fn: Callable) -> void:
	if sel == null:
		return
	_push()
	fn.call(sel.cur)
	E().pose(sel)
	rec_prop(sel)
	refresh_panel()

func delete_prop() -> void:
	if sel == null:
		return
	_push()
	var e = E().E_mut()
	if sel.add >= 0:
		e.adds.remove_at(sel.add)
		PlaceEdits.save_user()
		_rebuild()
		return
	if not e.mods.has(sel.id):
		e.mods[sel.id] = {}
	e.mods[sel.id]["del"] = true
	PlaceEdits.save_user()
	sel["del"] = true
	sel.node.visible = false
	sel.node.set_meta("ed_del", true)
	for s in E()._solids_at(float(sel.it.get("x", 0)), float(sel.it.get("z", 0))):
		s.set_meta("off", true)
	for l in sel.lights:
		l.node.visible = false
	sel = null
	world.refresh()
	refresh_panel()

func add_prop(m: String, near = null) -> void:
	if E() == null or m == "":
		return
	_push()
	var e = E().E_mut()
	var x = float(near.cur.x) + 0.8 if near else world.edit_cam.x
	var z = float(near.cur.z) + 0.8 if near else world.edit_cam.z
	var ad = { "m": m, "x": r3(x), "z": r3(z), "y": float(near.cur.get("y", 0)) if near else 0.0, "r": float(near.cur.get("r", 0)) if near else 0.0, "solid": true }
	if near:
		if near.cur.get("h") != null: ad["h"] = near.cur.h
		else: ad["s"] = near.cur.get("s", 1.0)
	else:
		var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
		if sizes.has(m): ad["h"] = r3(clampf(float(sizes[m].sz[1]), 0.3, 3.0))
		else: ad["s"] = 1.0
	e.adds.append(ad)
	PlaceEdits.save_user()
	var p = E()._add_prop(ad, e.adds.size() - 1)
	world.refresh()
	sel = p
	pick = null
	refresh_panel()

func act(a: String) -> void:
	match a:
		"rl": _do(func(it): it["r"] = float(it.get("r", 0)) + R15)
		"rr": _do(func(it): it["r"] = float(it.get("r", 0)) - R15)
		"rl1": _do(func(it): it["r"] = float(it.get("r", 0)) + PI / 180.0)
		"rr1": _do(func(it): it["r"] = float(it.get("r", 0)) - PI / 180.0)
		"big", "small":
			var k = 1.1 if a == "big" else 1.0 / 1.1
			_do(func(it):
				if it.get("h") != null: it["h"] = float(it.h) * k
				else: it["s"] = float(it.get("s", 1.0)) * k)
		"up": _do(func(it): it["y"] = float(it.get("y", 0)) + 0.1)
		"down": _do(func(it): it["y"] = float(it.get("y", 0)) - 0.1)
		"nx-": _do(func(it): it["x"] = float(it.x) - 0.1)
		"nx+": _do(func(it): it["x"] = float(it.x) + 0.1)
		"nz-": _do(func(it): it["z"] = float(it.z) - 0.1)
		"nz+": _do(func(it): it["z"] = float(it.z) + 0.1)
		"clight": _do(func(it): it["tint"] = _tint(it).map(func(v): return minf(3.0, v * 1.12)))
		"cdark": _do(func(it): it["tint"] = _tint(it).map(func(v): return v / 1.12))
		"cwarm": _do(func(it): var t = _tint(it); it["tint"] = [minf(3.0, t[0] * 1.07), t[1] * 1.01, t[2] / 1.07])
		"ccool": _do(func(it): var t = _tint(it); it["tint"] = [t[0] / 1.07, t[1] * 1.0, minf(3.0, t[2] * 1.07)])
		"cplain": _do(func(it):
			if sel.it.get("tint") is Array: it["tint"] = sel.it.tint.duplicate()
			else: it.erase("tint"))
		"cmat": pmat = not pmat; refresh_panel()
		"cmat0": _do(func(it): it.erase("mat"))
		"del": delete_prop()
		"dup":
			if sel:
				add_prop(str(sel.cur.m), sel)
		"desel": sel = null; refresh_panel()
		"add": pick = "" if pick == null else null; refresh_panel()
		"undo": do_undo()
		"reset": reset_place()
		"save": save_file()
		"copy": copy_all()
		"load": load_file()
		"drops": check_drops()
		"dropdir": open_drop_dir()
		_:
			if a.begins_with("m:"):
				var t = a.substr(2)
				_do(func(it): it["mat"] = t)

static func _tint(it: Dictionary) -> Array:
	return (it.tint.duplicate() if it.get("tint") is Array else [1.0, 1.0, 1.0]).map(func(v): return float(v))

# ---------------------------------------------------------------- files

func save_file() -> void:
	_dialog(FileDialog.FILE_MODE_SAVE_FILE, "Save place edits", func(path):
		var f = FileAccess.open(path, FileAccess.WRITE)
		if f:
			f.store_string(PlaceEdits.export_text())
			msg = "Saved " + path.get_file()
		else:
			msg = "Could not save a file there."
		refresh_panel(), "postal-trace-place-edits.json")

func copy_all() -> void:
	DisplayServer.clipboard_set(JSON.stringify(PlaceEdits.user_all()))
	msg = "Copied all edits."
	refresh_panel()

## Read any new edits files in the edits folders now (they are also read whenever a place is built).
func check_drops() -> void:
	var n = PlaceEdits.refresh_drops(true)
	if n > 0:
		msg = "Took edits for %d place%s from the edits folder." % [n, "" if n == 1 else "s"]
		_rebuild()
	else:
		msg = "Nothing new in the edits folders." if PlaceEdits.drop_files().size() else "No edits files yet. Put postal-trace-place-edits.json in " + ProjectSettings.globalize_path("user://edits") + " or the project's edits folder."
	refresh_panel()

func open_drop_dir() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://edits"))
	OS.shell_open(ProjectSettings.globalize_path("user://edits"))
	msg = "Edits folder: " + ProjectSettings.globalize_path("user://edits")
	refresh_panel()

func load_file() -> void:
	_dialog(FileDialog.FILE_MODE_OPEN_FILE, "Load place edits", func(path):
		if PlaceEdits.import_text(FileAccess.get_file_as_string(path)):
			msg = "Loaded edits."
			_rebuild()
		else:
			msg = "That file is not a place-edits file."
		refresh_panel())

func _dialog(mode_: int, title: String, cb: Callable, name := "") -> void:
	var fd = FileDialog.new()
	fd.file_mode = mode_
	fd.access = FileDialog.ACCESS_FILESYSTEM
	fd.use_native_dialog = true
	fd.title = title
	fd.filters = PackedStringArray(["*.json ; Place edits"])
	fd.current_dir = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
	if name != "":
		fd.current_file = name
	fd.size = Vector2i(820, 560)
	fd.file_selected.connect(func(p): fd.queue_free(); cb.call(p))
	fd.canceled.connect(fd.queue_free)
	add_child(fd)
	fd.popup_centered()

# ================================================================ the panel

func _b(t: String, a: String, row: Container, handler := "") -> Button:
	var b = Button.new()
	b.text = t
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 13)
	var h = handler if handler != "" else "act"
	b.pressed.connect(func(): call(h, a))
	row.add_child(b)
	return b

func _row() -> HFlowContainer:
	var r = HFlowContainer.new()
	r.add_theme_constant_override("h_separation", 3)
	r.add_theme_constant_override("v_separation", 3)
	box.add_child(r)
	return r

func _text(t: String, col := Color(0.67, 0.67, 0.73), size := 12) -> Label:
	var l = Label.new()
	l.text = t
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.custom_minimum_size = Vector2(300, 0)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	box.add_child(l)
	return l

func _rule() -> void:
	var s = HSeparator.new()
	box.add_child(s)

func refresh_panel() -> void:
	if not on:
		return
	for c in box.get_children():
		box.remove_child(c)
		c.queue_free()
	_text("PLACE EDITOR · " + key(), GOLD, 11)
	var r = _row()
	for m in [["props", "Props"], ["ppl", "People"], ["gnd", "Ground & roads"], ["blk", "Blockers"]]:
		var b = _b(m[1], m[0], r, "set_mode")
		if m[0] == mode:
			b.modulate = HI
	match mode:
		"ppl": _panel_people()
		"gnd": _panel_ground()
		"blk": _panel_blockers()
		_: _panel_props()
	if msg != "":
		_text(msg, Color(0.6, 0.8, 0.6))

func set_mode(m: String) -> void:
	mode = m
	sel = null; bsel = null; psel = null; gsel = null
	refresh_panel()

func _counts(e: Dictionary) -> String:
	return "This place: %d changed, %d added." % [e.get("mods", {}).size(), e.get("adds", []).size()]

func _panel_props() -> void:
	_text("Click a prop to select it, drag it to move it. Drag empty ground to look around; the wheel zooms.")
	if sel:
		var it: Dictionary = sel.cur
		_text(str(it.m) + ("  (added)" if sel.add >= 0 else ""), Color(0.9, 0.86, 0.75), 14)
		_text("x %.2f  z %.2f  height %.2f  turn %d°  size %s" % [float(it.x), float(it.z), float(it.get("y", 0)), roundi(rad_to_deg(float(it.get("r", 0)))), ("%.2fm" % float(it.h)) if it.get("h") != null else ("×%.2f" % float(it.get("s", 1.0)))])
		var r = _row(); _b("⟲ 15°", "rl", r); _b("⟳ 15°", "rr", r); _b("⟲ 1°", "rl1", r); _b("⟳ 1°", "rr1", r)
		r = _row(); _b("Lighter", "clight", r); _b("Darker", "cdark", r); _b("Warmer", "cwarm", r); _b("Cooler", "ccool", r); _b("Original colour", "cplain", r)
		r = _row(); _b("Hide materials" if pmat else "Change material…", "cmat", r)
		if it.get("mat"):
			_b("Original material", "cmat0", r)
		if pmat:
			_tex_grid("m:", str(it.get("mat", "")))
		r = _row(); _b("Bigger", "big", r); _b("Smaller", "small", r); _b("Raise", "up", r); _b("Lower", "down", r)
		r = _row(); _b("x −", "nx-", r); _b("x +", "nx+", r); _b("z −", "nz-", r); _b("z +", "nz+", r)
		r = _row(); _b("Copy it", "dup", r); _b("Delete", "del", r); _b("Deselect", "desel", r)
	else:
		_text("Nothing selected.")
	_rule()
	var r2 = _row(); _b("Add a prop…", "add", r2); _b("Undo", "undo", r2); _b("Tap again to reset" if _sure else "Reset place", "reset", r2)
	if pick != null:
		var le = LineEdit.new()
		le.placeholder_text = "Search models (barrel, table, lantern…)"
		le.text = pick
		box.add_child(le)
		var list_box = VBoxContainer.new()
		le.text_changed.connect(func(t):
			pick = t
			_fill_models(list_box, t))
		var sc = ScrollContainer.new()
		sc.custom_minimum_size = Vector2(300, 180)
		sc.add_child(list_box)
		box.add_child(sc)
		_fill_models(list_box, pick)
		le.call_deferred("grab_focus")
		le.caret_column = le.text.length()
	_rule()
	var e = E().E()
	_text(_counts(e))
	var r3_ = _row(); _b("Save file", "save", r3_); _b("Copy", "copy", r3_); _b("Load file", "load", r3_)
	var r3b = _row(); _b("Check edits folder", "drops", r3b); _b("Open edits folder", "dropdir", r3b)
	_text("Keys: arrows move · Q/E turn · R/F raise/lower · +/- size · Del delete · Ctrl+Z undo · Esc done", Color(0.47, 0.47, 0.53), 10)

func _fill_models(list_box: VBoxContainer, q: String) -> void:
	for c in list_box.get_children():
		c.queue_free()
	var names: Array = PlaceBuilder.models().get("sizes", {}).keys().filter(func(n): return not (n in ["human", "mvh_hall"]) and (q == "" or n.to_lower().contains(q.to_lower())))
	names.sort()
	for n in names.slice(0, 80):
		var b = Button.new()
		b.text = n
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 12)
		b.pressed.connect(func(): add_prop(n))
		list_box.add_child(b)

## The textures a material or a patch of ground can take.
static func textures() -> Array:
	var out = []
	for f in DirAccess.get_files_at("res://assets/3d/tex"):
		f = f.trim_suffix(".import").trim_suffix(".remap")
		var k = f.get_basename()
		if f.get_extension() in ["png", "jpg", "webp"] and not k.begins_with("l_") and not k.begins_with("rig_") and not out.has(k):
			out.append(k)
	out.sort()
	return out

func _tex_grid(prefix: String, cur: String) -> void:
	var g = HFlowContainer.new()
	g.add_theme_constant_override("h_separation", 3)
	g.add_theme_constant_override("v_separation", 3)
	for t in textures():
		var b = Button.new()
		b.custom_minimum_size = Vector2(38, 38)
		b.icon = PlaceBuilder.texture(t)
		b.expand_icon = true
		b.tooltip_text = t
		b.focus_mode = Control.FOCUS_NONE
		if t == cur:
			b.modulate = HI
		var a = prefix + t
		b.pressed.connect(func(): call("gnd_act" if prefix == "t:" else "act", a))
		g.add_child(b)
	box.add_child(g)

# ---------------------------------------------------------------- blockers

func _panel_blockers() -> void:
	_text("Blockers are the invisible walls you cannot walk through: orange boxes and rings on the ground. The dashed line is the edge of where you can walk. Click a blocker to select it, drag it to move it, drag a corner or the rim to resize it.")
	var s = bsel
	if s:
		var n: Node3D = s.node
		var own = "  (added)" if s.add >= 0 else ("" if s.sid != "" else ("  (belongs to a prop you added: move the prop)" if s.own else ""))
		_text(("Ring" if n.has_meta("r") else "Box") + own, Color(0.9, 0.86, 0.75), 14)
		if n.has_meta("r"):
			_text("x %.2f  z %.2f  radius %.2f" % [n.position.x, n.position.z, float(n.get_meta("r"))])
		else:
			var b = PlaceEdits.solid_box(n)
			_text("x %.2f to %.2f  z %.2f to %.2f" % [b.x0, b.x1, b.z0, b.z1])
		var r = _row(); _b("Bigger", "grow", r, "blk_act"); _b("Smaller", "shrink", r, "blk_act")
		if not n.has_meta("r"):
			_b("Wider", "wider", r, "blk_act"); _b("Narrower", "narrower", r, "blk_act"); _b("Deeper", "deeper", r, "blk_act"); _b("Shallower", "shallower", r, "blk_act")
		r = _row(); _b("Delete", "bdel", r, "blk_act"); _b("Deselect", "bdesel", r, "blk_act")
	else:
		_text("Nothing selected.")
	var r2 = _row(); _b("Add a box", "addbox", r2, "blk_act"); _b("Add a ring", "addring", r2, "blk_act"); _b("Undo", "undo", r2)
	var bd: Variant = world.place.get_meta("bounds", null) if world.place.has_meta("bounds") else null
	if bd is Array:
		_rule()
		_text("Walkable area  x %.2f to %.2f, z %.2f to %.2f" % [float(bd[0]), float(bd[2]), float(bd[1]), float(bd[3])], Color(0.9, 0.86, 0.75), 12)
		var r3_ = _row()
		_text_inline("West edge", r3_); _b("−", "b0-", r3_, "blk_act"); _b("+", "b0+", r3_, "blk_act")
		_text_inline("East edge", r3_); _b("−", "b2-", r3_, "blk_act"); _b("+", "b2+", r3_, "blk_act")
		var r4 = _row()
		_text_inline("North edge", r4); _b("−", "b1-", r4, "blk_act"); _b("+", "b1+", r4, "blk_act")
		_text_inline("South edge", r4); _b("−", "b3-", r4, "blk_act"); _b("+", "b3+", r4, "blk_act")
	_rule()
	var e = E().E()
	var S: Dictionary = e.get("solids", {})
	_text("Blockers here: %d changed, %d added%s." % [S.get("mods", {}).size(), S.get("adds", []).size(), ", walkable area changed" if e.get("bounds") else ""])
	var r5 = _row(); _b("Try walking it", "test", r5, "blk_act"); _b("Save file", "save", r5); _b("Load file", "load", r5)
	_text("Keys: arrows move · +/- size · Del delete · Ctrl+Z undo · Esc done", Color(0.47, 0.47, 0.53), 10)

func _text_inline(t: String, row: Container) -> void:
	var l = Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 12)
	row.add_child(l)

func _blk_shape(n: Node3D) -> Dictionary:
	if n.has_meta("r"):
		return { "x": r3(n.position.x), "z": r3(n.position.z), "r": r3(float(n.get_meta("r"))) }
	var b = PlaceEdits.solid_box(n)
	return { "x0": r3(b.x0), "x1": r3(b.x1), "z0": r3(b.z0), "z1": r3(b.z1) }

func _blk_edit() -> Dictionary:
	var e = E().E_mut()
	if not (e.get("solids") is Dictionary):
		e["solids"] = { "mods": {}, "adds": [] }
	if not e.solids.has("mods"): e.solids["mods"] = {}
	if not e.solids.has("adds"): e.solids["adds"] = []
	return e.solids

func blk_record(s: Dictionary) -> void:
	var S = _blk_edit()
	if s.add >= 0:
		if s.add < S.adds.size():
			S.adds[s.add] = _blk_shape(s.node)
	elif s.sid != "":
		var d: Dictionary = S.mods.get(s.sid, {})
		if s.node.get_meta("off", false):
			d["del"] = true
		else:
			for k in _blk_shape(s.node):
				d[k] = _blk_shape(s.node)[k]
		S.mods[s.sid] = d
	PlaceEdits.save_user()
	world.refresh()
	changed.emit()

func _blk_do(fn: Callable) -> void:
	if bsel == null:
		return
	_push()
	fn.call(bsel.node)
	blk_record(bsel)
	refresh_panel()

func _grow(n: Node3D, fx: float, fz: float) -> void:
	var b = PlaceEdits.solid_box(n)
	b.x0 -= fx / 2.0; b.x1 += fx / 2.0; b.z0 -= fz / 2.0; b.z1 += fz / 2.0
	if b.x1 - b.x0 < 0.1: b.x1 = b.x0 + 0.1
	if b.z1 - b.z0 < 0.1: b.z1 = b.z0 + 0.1
	E().set_solid(n, b)

func blk_act(a: String) -> void:
	match a:
		"grow", "shrink":
			var f = 0.1 if a == "grow" else -0.1
			_blk_do(func(n):
				if n.has_meta("r"): n.set_meta("r", maxf(0.1, float(n.get_meta("r")) + f))
				else: _grow(n, f, f))
		"wider", "narrower":
			var w = 0.1 if a == "wider" else -0.1
			_blk_do(func(n):
				if not n.has_meta("r"):
					_grow(n, w, 0.0))
		"deeper", "shallower":
			var dz = 0.1 if a == "deeper" else -0.1
			_blk_do(func(n):
				if not n.has_meta("r"):
					_grow(n, 0.0, dz))
		"addbox", "addring":
			_push()
			var S = _blk_edit()
			var c: Vector3 = world.edit_cam
			var ad = { "x": r3(c.x), "z": r3(c.z), "r": 0.5 } if a == "addring" else { "x0": r3(c.x - 0.6), "x1": r3(c.x + 0.6), "z0": r3(c.z - 0.4), "z1": r3(c.z + 0.4) }
			S.adds.append(ad)
			PlaceEdits.save_user()
			bsel = E()._add_solid(ad, S.adds.size() - 1)
			world.refresh()
			refresh_panel()
		"bdel":
			if bsel == null:
				return
			if bsel.add >= 0:
				_push()
				_blk_edit().adds.remove_at(bsel.add)
				PlaceEdits.save_user()
				bsel = null
				_rebuild()
				return
			if bsel.sid == "":
				msg = "That blocker belongs to a prop you added: delete or move the prop."
				refresh_panel()
				return
			_push()
			bsel.node.set_meta("off", true)
			blk_record(bsel)
			bsel = null
			refresh_panel()
		"bdesel": bsel = null; refresh_panel()
		"test": stop()
		_:
			if a.length() == 3 and a[0] == "b":
				var i = int(a[1])
				var sg = 1.0 if a[2] == "+" else -1.0
				var bd: Array = world.place.get_meta("bounds").duplicate()
				_push()
				bd[i] = roundf((float(bd[i]) + sg * 0.25) * 100.0) / 100.0
				world.place.set_meta("bounds", bd)
				world.bounds = Rect2(float(bd[0]), float(bd[1]), float(bd[2]) - float(bd[0]), float(bd[3]) - float(bd[1]))
				E().E_mut()["bounds"] = bd.duplicate()
				PlaceEdits.save_user()
				world.nav.clear()
				refresh_panel()

func _blk_list() -> Array:
	return E().solids.filter(func(s): return is_instance_valid(s.node) and not s.node.get_meta("off", false))

func _blk_pick(g: Vector3) -> Variant:
	var best = null
	var ba = 1e9
	for s in _blk_list():
		var n: Node3D = s.node
		var inside: bool
		var area: float
		if n.has_meta("r"):
			var r = float(n.get_meta("r"))
			inside = Vector2(g.x - n.position.x, g.z - n.position.z).length() <= r + 0.12
			area = PI * r * r
		else:
			var b = PlaceEdits.solid_box(n)
			inside = g.x >= b.x0 - 0.12 and g.x <= b.x1 + 0.12 and g.z >= b.z0 - 0.12 and g.z <= b.z1 + 0.12
			area = (b.x1 - b.x0) * (b.z1 - b.z0)
		if inside and area < ba:
			ba = area
			best = s
	return best

func _blk_handle(s, g: Vector3) -> String:
	if s == null:
		return ""
	var n: Node3D = s.node
	var tol = maxf(0.18, world.zoom * 0.03)
	if n.has_meta("r"):
		return "rim" if absf(Vector2(g.x - n.position.x, g.z - n.position.z).length() - float(n.get_meta("r"))) < tol else ""
	var b = PlaceEdits.solid_box(n)
	for c in [["x0z0", b.x0, b.z0], ["x1z0", b.x1, b.z0], ["x0z1", b.x0, b.z1], ["x1z1", b.x1, b.z1]]:
		if Vector2(g.x - c[1], g.z - c[2]).length() < tol * 1.4:
			return c[0]
	return ""

# ---------------------------------------------------------------- people

func _panel_people() -> void:
	_text("Click a person to select them and drag to move them. The blue rings are the people you can talk to, the gold ones are townsfolk. The tick shows which way they face.")
	var q = psel
	if q:
		var n: Node3D = q.node
		_text(_pname(q) + ("  (sitting)" if n.get_meta("sit", false) else ""), Color(0.9, 0.86, 0.75), 14)
		_text("x %.2f  z %.2f  height %.2f  facing %d°" % [n.position.x, n.position.z, n.position.y, roundi(rad_to_deg(n.rotation.y)) % 360])
		var r = _row(); _b("⟲ 15°", "pl", r, "ppl_act"); _b("⟳ 15°", "pr", r, "ppl_act"); _b("Face the camera", "pface", r, "ppl_act")
		r = _row(); _b("x −", "px-", r, "ppl_act"); _b("x +", "px+", r, "ppl_act"); _b("z −", "pz-", r, "ppl_act"); _b("z +", "pz+", r, "ppl_act")
		r = _row(); _b("Raise", "pup", r, "ppl_act"); _b("Lower", "pdn", r, "ppl_act"); _b("Put back", "pback", r, "ppl_act"); _b("Deselect", "pdesel", r, "ppl_act")
		var d: Dictionary = E().E().get("people", {}).get(q.pk, {})
		var anims: Array = [["", "As the game has it"]] + _lib("PPL_ANIMS", [])
		_select("Standing about:", anims, str(d.get("anim", "")) if d.get("anim") != null else "", "anim")
		_select("Carrying:", [["-", "As the game has it"], ["", "Nothing"], ["stick", "A walking stick"], ["basket", "A basket"], ["bundle", "A bundle on the back"], ["pipe", "A pipe"]], str(d.get("item", "-")) if d.get("item") != null else "-", "item")
		_select("Age:", [["", "As the game has it"], ["young", "Grown, upright"], ["old", "Old (stoops, walks slowly)"], ["kid", "A child"]], str(d.get("age", "")) if d.get("age") != null else "", "age")
		var fits: Array = [["", "As the game has it"]]
		var names: Dictionary = _lib("RG_FIT_NAMES", {})
		for k in names:
			fits.append([k, str(names[k])])
		_select("Clothes:", fits, str(d.get("outfit", "")) if d.get("outfit") != null else "", "outfit")
	else:
		_text("Nobody selected.")
	_rule()
	_text("People moved here: %d." % E().E().get("people", {}).size())
	var r2 = _row(); _b("Undo", "undo", r2); _b("Save file", "save", r2); _b("Load file", "load", r2)
	_text("Keys: arrows move · Q/E turn · R/F raise/lower · Ctrl+Z undo · Esc done", Color(0.47, 0.47, 0.53), 10)

static func _lib(name: String, fallback: Variant) -> Variant:
	var v: Variant = Data.js.globals.vars.get(name)
	return Game._plain(v) if v != null else fallback

func _select(label: String, opts: Array, cur: String, field: String) -> void:
	var r = _row()
	_text_inline(label, r)
	var ob = OptionButton.new()
	ob.focus_mode = Control.FOCUS_NONE
	ob.add_theme_font_size_override("font_size", 12)
	for i in opts.size():
		ob.add_item(str(opts[i][1]), i)
		if str(opts[i][0]) == cur:
			ob.select(i)
	ob.item_selected.connect(func(i): style_set({ field: str(opts[i][0]) }))
	r.add_child(ob)

func _pname(q: Dictionary) -> String:
	var n: Node3D = q.node
	if n.has_meta("name"):
		return str(n.get_meta("name"))
	return str(n.get_meta("id", "Townsperson")).replace("_", " ") if q.named else "Townsperson"

func ppl_record(q: Dictionary) -> void:
	var e = E().E_mut()
	if not (e.get("people") is Dictionary):
		e["people"] = {}
	var n: Node3D = q.node
	var old: Dictionary = e.people.get(q.pk, {})
	e.people[q.pk] = { "x": r3(n.position.x), "z": r3(n.position.z), "y": r3(n.position.y), "face": r3(n.rotation.y), "anim": old.get("anim"), "outfit": old.get("outfit"), "item": old.get("item"), "age": old.get("age") }
	PlaceEdits.save_user()
	world.refresh()
	changed.emit()

func _ppl_do(fn: Callable) -> void:
	if psel == null:
		return
	_push()
	var n: Node3D = psel.node
	var o = { "x": n.position.x, "z": n.position.z, "y": n.position.y, "face": n.rotation.y }
	fn.call(o)
	E().set_person(psel, o)
	ppl_record(psel)
	refresh_panel()

func ppl_act(a: String) -> void:
	match a:
		"pl": _ppl_do(func(o): o["face"] += R15)
		"pr": _ppl_do(func(o): o["face"] -= R15)
		"pup": _ppl_do(func(o): o["y"] = roundf((o.y + 0.1) * 100.0) / 100.0)
		"pdn": _ppl_do(func(o): o["y"] = maxf(0.0, roundf((o.y - 0.1) * 100.0) / 100.0))
		"px-": _ppl_do(func(o): o["x"] -= 0.1)
		"px+": _ppl_do(func(o): o["x"] += 0.1)
		"pz-": _ppl_do(func(o): o["z"] -= 0.1)
		"pz+": _ppl_do(func(o): o["z"] += 0.1)
		"pface":
			var c = world.cam.global_position
			_ppl_do(func(o): o["face"] = atan2(c.x - o.x, c.z - o.z))
		"pback":
			if psel == null:
				return
			_push()
			var e = E().E_mut()
			if e.get("people") is Dictionary:
				e.people.erase(psel.pk)
			PlaceEdits.save_user()
			_rebuild()
		"pdesel": psel = null; refresh_panel()
		_: act(a)

## How they stand, what they wear and carry (kept with where they stand).
func style_set(d: Dictionary) -> void:
	if psel == null:
		return
	_push()
	var e = E().E_mut()
	if not (e.get("people") is Dictionary):
		e["people"] = {}
	var n: Node3D = psel.node
	var cur: Dictionary = e.people.get(psel.pk, { "x": r3(n.position.x), "z": r3(n.position.z), "y": r3(n.position.y), "face": r3(n.rotation.y) })
	for k in d:
		cur[k] = d[k]
	e.people[psel.pk] = cur
	PlaceEdits.save_user()
	E().style_person(psel, cur)
	world.refresh()
	refresh_panel()

func _ppl_list() -> Array:
	return E().people.filter(func(q): return is_instance_valid(q.node) and q.node.visible)

func _ppl_pick(pos: Vector2) -> Variant:
	var best = null
	var bd = 1e9
	for q in _ppl_list():
		var n: Node3D = q.node
		var a = world.cam.unproject_position(n.global_position)
		var b = world.cam.unproject_position(n.global_position + Vector3(0, 1.7, 0))
		var v = b - a
		var l2 = maxf(v.length_squared(), 1.0)
		var t = clampf((pos - a).dot(v) / l2, 0.0, 1.0)
		var d = pos.distance_to(a + v * t)
		var tol = maxf(16.0 / shrink, sqrt(l2) * 0.28)
		if d < tol and d < bd:
			bd = d
			best = q
	return best

# ---------------------------------------------------------------- ground and roads

func _panel_ground() -> void:
	_text("Each road, yard, floor and rug is a flat patch, outlined on the ground. Click one to select it; drag it to move it; drag a corner to stretch it. Click bare ground to pick the ground under everything.")
	var q = gsel
	if q:
		var g: Dictionary = q.g
		var r: Array = g.r
		_text(("Ground under everything" if q.base else ("Added patch" if q.add >= 0 else "Patch")) + "   " + str(g.get("tex", "")), Color(0.9, 0.86, 0.75), 14)
		_text(("" if q.base else "%.1f × %.1f m  turn %d°  layer %.2f  " % [float(r[2]) - float(r[0]), float(r[3]) - float(r[1]), roundi(rad_to_deg(float(g.get("rot", 0)))), float(g.get("y", 0))]) + "texture size %.1fm" % float(g.get("rep", 3)))
		if not q.base:
			var rr = _row(); _b("⟲ 15°", "gl", rr, "gnd_act"); _b("⟳ 15°", "gr", rr, "gnd_act"); _b("⟲ 1°", "gl1", rr, "gnd_act"); _b("⟳ 1°", "gr1", rr, "gnd_act")
			rr = _row(); _b("Wider", "gwid", rr, "gnd_act"); _b("Narrower", "gnar", rr, "gnd_act"); _b("Longer", "glong", rr, "gnd_act"); _b("Shorter", "gshort", rr, "gnd_act")
			rr = _row(); _b("Layer up", "gup", rr, "gnd_act"); _b("Layer down", "gdn", rr, "gnd_act"); _b("Delete", "gdel", rr, "gnd_act")
		var r2 = _row(); _b("Hide textures" if gtex else "Change texture…", "gtex", r2, "gnd_act"); _b("Smaller texture", "gfine", r2, "gnd_act"); _b("Bigger texture", "gcoarse", r2, "gnd_act")
		r2 = _row(); _b("Lighter", "glight", r2, "gnd_act"); _b("Darker", "gdark", r2, "gnd_act"); _b("Warmer", "gwarm", r2, "gnd_act"); _b("Cooler", "gcool", r2, "gnd_act"); _b("Deselect", "gdesel", r2, "gnd_act")
		if gtex:
			_tex_grid("t:", str(g.get("tex", "")))
	else:
		_text("Nothing selected.")
	var r3_ = _row(); _b("Lay a road", "gaddr", r3_, "gnd_act"); _b("Lay a patch", "gaddp", r3_, "gnd_act"); _b("Undo", "undo", r3_)
	_rule()
	var G: Dictionary = E().E().get("grounds", {})
	_text("Ground here: %d changed, %d added." % [G.get("mods", {}).size(), G.get("adds", []).size()])
	var r4 = _row(); _b("Save file", "save", r4); _b("Load file", "load", r4)
	_text("Keys: arrows move · Q/E turn · +/- size · Del delete · Ctrl+Z undo · Esc done", Color(0.47, 0.47, 0.53), 10)

func gnd_record(q: Dictionary) -> void:
	var e = E().E_mut()
	if not (e.get("grounds") is Dictionary):
		e["grounds"] = { "mods": {}, "adds": [] }
	if not e.grounds.has("mods"): e.grounds["mods"] = {}
	if not e.grounds.has("adds"): e.grounds["adds"] = []
	if q.add >= 0:
		if q.add < e.grounds.adds.size():
			e.grounds.adds[q.add] = PlaceEdits.ground_data(q.g)
	else:
		var d = PlaceEdits.ground_data(q.g)
		if q.get("del"):
			d["del"] = true
		e.grounds.mods[q.gk] = d
	PlaceEdits.save_user()
	changed.emit()

func _gnd_do(fn: Callable) -> void:
	if gsel == null:
		return
	_push()
	fn.call(gsel.g)
	E().rebuild_ground(gsel)
	gnd_record(gsel)
	refresh_panel()

static func _gmove(g: Dictionary, dx: float, dz: float) -> void:
	var r: Array = g.r
	g["r"] = [float(r[0]) + dx, float(r[1]) + dz, float(r[2]) + dx, float(r[3]) + dz]

static func _gresize(g: Dictionary, fx: float, fz: float) -> void:
	var r: Array = g.r
	var cx = (float(r[0]) + float(r[2])) / 2.0
	var cz = (float(r[1]) + float(r[3])) / 2.0
	var hw = maxf(0.2, (float(r[2]) - float(r[0])) / 2.0 + fx)
	var hd = maxf(0.2, (float(r[3]) - float(r[1])) / 2.0 + fz)
	g["r"] = [cx - hw, cz - hd, cx + hw, cz + hd]

const GMOVE := ["gl", "gr", "gl1", "gr1", "gx-", "gx+", "gz-", "gz+", "gwid", "gnar", "glong", "gshort", "gbig", "gsmall", "gup", "gdn", "gdel"]

func gnd_act(a: String) -> void:
	var mv = gsel != null and not gsel.base
	if a in GMOVE and not mv:
		return
	match a:
		"gl": _gnd_do(func(g): g["rot"] = float(g.get("rot", 0)) + R15)
		"gr": _gnd_do(func(g): g["rot"] = float(g.get("rot", 0)) - R15)
		"gl1": _gnd_do(func(g): g["rot"] = float(g.get("rot", 0)) + PI / 180.0)
		"gr1": _gnd_do(func(g): g["rot"] = float(g.get("rot", 0)) - PI / 180.0)
		"gx-": _gnd_do(func(g): _gmove(g, -0.1, 0))
		"gx+": _gnd_do(func(g): _gmove(g, 0.1, 0))
		"gz-": _gnd_do(func(g): _gmove(g, 0, -0.1))
		"gz+": _gnd_do(func(g): _gmove(g, 0, 0.1))
		"gwid": _gnd_do(func(g): _gresize(g, 0.1, 0))
		"gnar": _gnd_do(func(g): _gresize(g, -0.1, 0))
		"glong": _gnd_do(func(g): _gresize(g, 0, 0.25))
		"gshort": _gnd_do(func(g): _gresize(g, 0, -0.25))
		"gbig": _gnd_do(func(g): _gresize(g, 0.1, 0.1))
		"gsmall": _gnd_do(func(g): _gresize(g, -0.1, -0.1))
		"gup": _gnd_do(func(g): g["y"] = minf(0.06, r3(float(g.get("y", 0)) + 0.004)))
		"gdn": _gnd_do(func(g): g["y"] = maxf(0.002, r3(float(g.get("y", 0)) - 0.004)))
		"glight": _gnd_do(func(g): g["c"] = _gc(g).map(func(v): return minf(2.0, v * 1.1)))
		"gdark": _gnd_do(func(g): g["c"] = _gc(g).map(func(v): return v / 1.1))
		"gwarm": _gnd_do(func(g): var c = _gc(g); g["c"] = [minf(2.0, c[0] * 1.06), c[1], c[2] / 1.06])
		"gcool": _gnd_do(func(g): var c = _gc(g); g["c"] = [c[0] / 1.06, c[1], minf(2.0, c[2] * 1.06)])
		"gfine": _gnd_do(func(g): g["rep"] = maxf(0.4, r3(float(g.get("rep", 3)) / 1.25)))
		"gcoarse": _gnd_do(func(g): g["rep"] = minf(20.0, r3(float(g.get("rep", 3)) * 1.25)))
		"gaddp", "gaddr": _gnd_add(a == "gaddr")
		"gdel":
			if not mv:
				return
			_push()
			if gsel.add >= 0:
				var e = E().E_mut()
				e.grounds.adds.remove_at(gsel.add)
				PlaceEdits.save_user()
				_rebuild()
				return
			gsel["del"] = true
			gsel.node.visible = false
			gnd_record(gsel)
			gsel = null
			refresh_panel()
		"gtex": gtex = not gtex; refresh_panel()
		"gdesel": gsel = null; refresh_panel()
		_:
			if a.begins_with("t:"):
				var t = a.substr(2)
				_gnd_do(func(g):
					g["tex"] = t
					g["flow"] = (g.get("flow") if g.get("flow") != null else [0.0001, 0.00002]) if t == "t_water" else null)
			else:
				act(a)

static func _gc(g: Dictionary) -> Array:
	return (g.c if g.get("c") is Array else [1, 1, 1]).map(func(v): return float(v))

func _gnd_add(road: bool) -> void:
	_push()
	var top = 0.0
	for q in E().grounds:
		if not q.base and not q.get("del"):
			top = maxf(top, float(q.g.get("y", 0)))
	var c: Vector3 = world.edit_cam
	var d = { "x0": c.x - (1.2 if road else 1.5), "z0": c.z - (5.0 if road else 1.5), "x1": c.x + (1.2 if road else 1.5), "z1": c.z + (5.0 if road else 1.5),
		"rot": 0.0, "c": [0.85, 0.82, 0.78] if road else [0.8, 0.78, 0.74], "rep": 3.2 if road else 3.0, "y": minf(0.06, r3(top + 0.004)), "tex": "mud" if road else "gravel" }
	var e = E().E_mut()
	if not (e.get("grounds") is Dictionary):
		e["grounds"] = { "mods": {}, "adds": [] }
	if not e.grounds.has("adds"): e.grounds["adds"] = []
	if not e.grounds.has("mods"): e.grounds["mods"] = {}
	var g = { "r": [0, 0, 0, 0] }
	PlaceEdits.ground_from(g, d)
	e.grounds.adds.append(PlaceEdits.ground_data(g))
	PlaceEdits.save_user()
	gsel = E().add_ground(e.grounds.adds[-1], e.grounds.adds.size() - 1)
	refresh_panel()

static func corners(g: Dictionary) -> Array:
	var r: Array = g.r
	var x0 = float(r[0]); var z0 = float(r[1]); var x1 = float(r[2]); var z1 = float(r[3])
	var cx = (x0 + x1) / 2.0
	var cz = (z0 + z1) / 2.0
	var c = cos(float(g.get("rot", 0)))
	var s = sin(float(g.get("rot", 0)))
	var out = []
	for q in [[x0, z0], [x1, z0], [x1, z1], [x0, z1]]:
		var dx = q[0] - cx
		var dz = q[1] - cz
		out.append(Vector2(cx + c * dx + s * dz, cz - s * dx + c * dz))
	return out

static func local(g: Dictionary, x: float, z: float) -> Vector2:
	var r: Array = g.r
	var cx = (float(r[0]) + float(r[2])) / 2.0
	var cz = (float(r[1]) + float(r[3])) / 2.0
	var c = cos(float(g.get("rot", 0)))
	var s = sin(float(g.get("rot", 0)))
	var dx = x - cx
	var dz = z - cz
	return Vector2(c * dx - s * dz, s * dx + c * dz)

func _gnd_pick(p: Vector3) -> Variant:
	var list = E().grounds.filter(func(q): return not q.get("del"))
	list.sort_custom(func(a, b): return float(a.g.get("y", 0)) < float(b.g.get("y", 0)))
	for i in range(list.size() - 1, -1, -1):
		var q = list[i]
		if q.base:
			continue
		var l = local(q.g, p.x, p.z)
		var r: Array = q.g.r
		if absf(l.x) <= (float(r[2]) - float(r[0])) / 2.0 and absf(l.y) <= (float(r[3]) - float(r[1])) / 2.0:
			return q
	for q in list:
		if q.base:
			return q
	return null

# ================================================================ pointing

func ground_at(pos: Vector2, y := 0.0) -> Vector3:
	var o = world.cam.project_ray_origin(pos)
	var d = world.cam.project_ray_normal(pos)
	if absf(d.y) < 1e-5:
		return Vector3(o.x, y, o.z)
	var t = (y - o.y) / d.y
	return o + d * t

func _prop_pick(pos: Vector2) -> Variant:
	var best = null
	var bd = 1e9
	for p in E().props:
		var n: Node3D = p.node
		if p.get("del") or not n.visible or str(p.cur.m) == "fire":
			continue
		var it: Dictionary = p.cur
		var cy = float(it.get("y", 0)) + 0.5
		var at = Vector3(float(it.x), cy, float(it.z))
		if world.cam.is_position_behind(at):
			continue
		var c = world.cam.unproject_position(at)
		var e = world.cam.unproject_position(at + Vector3(minf(E().foot(it) / 0.8, 4.0), 0, 0))
		var rad = maxf(14.0 / shrink, absf(e.x - c.x))
		var d = pos.distance_to(c)
		if d < rad and d / rad < bd:
			bd = d / rad
			best = p
	return best

## Mouse in the 3D view's own pixels (main.gd passes them as for walking).
func pointer(ev: InputEvent, pos: Vector2) -> void:
	if ev is InputEventMouseButton:
		if ev.pressed and ev.button_index == MOUSE_BUTTON_WHEEL_UP:
			world.zoom = clampf(world.zoom / 1.12, 2.5, 30.0)
			return
		if ev.pressed and ev.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			world.zoom = clampf(world.zoom * 1.12, 2.5, 30.0)
			return
		if ev.button_index != MOUSE_BUTTON_LEFT:
			return
		if ev.pressed:
			_down(pos)
		else:
			_up(pos)
	elif ev is InputEventMouseMotion and drag != null:
		_move(pos)

func _down(pos: Vector2) -> void:
	var g = ground_at(pos)
	match mode:
		"blk":
			var h = _blk_handle(bsel, g)
			if bsel and h != "":
				drag = { kind = "blk", what = h, s = bsel, start = g, o = _blk_shape(bsel.node), pushed = false }
				return
			var p = _blk_pick(g)
			if p:
				bsel = p
				refresh_panel()
				drag = { kind = "blk", what = "move", s = p, start = g, o = _blk_shape(p.node), pushed = false }
				return
		"ppl":
			var q = _ppl_pick(pos)
			if q:
				if q != psel:
					psel = q
					refresh_panel()
				var y = q.node.position.y
				drag = { kind = "ppl", q = q, py = y, start = ground_at(pos, y), ox = q.node.position.x, oz = q.node.position.z, pushed = false }
				return
		"gnd":
			if gsel and not gsel.base:
				var cs = corners(gsel.g)
				var tol = maxf(0.25, world.zoom * 0.035)
				for i in 4:
					if Vector2(g.x, g.z).distance_to(cs[i]) < tol:
						drag = { kind = "gnd", what = i, q = gsel, start = g, o = gsel.g.r.duplicate(), pushed = false }
						return
			var q = _gnd_pick(g)
			if q and not q.base:
				if q != gsel:
					gsel = q
					refresh_panel()
				drag = { kind = "gnd", what = "move", q = q, start = g, o = q.g.r.duplicate(), pushed = false }
				return
			drag = { kind = "pan", at = pos, g = g, t = Time.get_ticks_msec(), base = q }
			return
		_:
			var p = _prop_pick(pos)
			if p:
				if p != sel:
					sel = p
					refresh_panel()
				drag = { kind = "prop", start = g, ox = float(p.cur.x), oz = float(p.cur.z), pushed = false, moved = false }
				return
	drag = { kind = "pan", at = pos, g = g, t = Time.get_ticks_msec() }

func _move(pos: Vector2) -> void:
	var d: Dictionary = drag
	match d.kind:
		"pan":
			var g = ground_at(pos)
			world.edit_cam -= Vector3(g.x - d.g.x, 0, g.z - d.g.z)
			world.cam_target = world.edit_cam
			world._place_camera(0.0)
		"prop":
			if sel == null:
				return
			var g = ground_at(pos)
			if not d.pushed:
				if Vector2(g.x - d.start.x, g.z - d.start.z).length() < 0.03:
					return
				_push()
				d.pushed = true
			sel.cur["x"] = d.ox + g.x - d.start.x
			sel.cur["z"] = d.oz + g.z - d.start.z
			E().pose(sel)
			d.moved = true
		"blk":
			var g = ground_at(pos)
			var dx = g.x - d.start.x
			var dz = g.z - d.start.z
			if not d.pushed:
				if Vector2(dx, dz).length() < 0.03:
					return
				_push()
				d.pushed = true
			var n: Node3D = d.s.node
			var o: Dictionary = d.o
			if d.what == "move":
				if n.has_meta("r"):
					n.position = Vector3(o.x + dx, 0, o.z + dz)
				else:
					E().set_solid(n, { "x0": o.x0 + dx, "x1": o.x1 + dx, "z0": o.z0 + dz, "z1": o.z1 + dz })
			elif d.what == "rim":
				n.set_meta("r", maxf(0.1, Vector2(g.x - n.position.x, g.z - n.position.z).length()))
			else:
				var b = PlaceEdits.solid_box(n)
				if d.what.begins_with("x0"): b.x0 = minf(g.x, b.x1 - 0.1)
				else: b.x1 = maxf(g.x, b.x0 + 0.1)
				if d.what.ends_with("z0"): b.z0 = minf(g.z, b.z1 - 0.1)
				else: b.z1 = maxf(g.z, b.z0 + 0.1)
				E().set_solid(n, b)
			d.moved = true
		"ppl":
			var g = ground_at(pos, d.py)
			var dx = g.x - d.start.x
			var dz = g.z - d.start.z
			if not d.pushed:
				if Vector2(dx, dz).length() < 0.03:
					return
				_push()
				d.pushed = true
			E().set_person(d.q, { "x": d.ox + dx, "z": d.oz + dz })
			d.moved = true
		"gnd":
			var p = ground_at(pos)
			var q: Dictionary = d.q
			var g: Dictionary = q.g
			var dx = p.x - d.start.x
			var dz = p.z - d.start.z
			if not d.pushed:
				if Vector2(dx, dz).length() < 0.03:
					return
				_push()
				d.pushed = true
			var o: Array = d.o
			if str(d.what) == "move":
				g["r"] = [float(o[0]) + dx, float(o[1]) + dz, float(o[2]) + dx, float(o[3]) + dz]
			else:
				# the far corner stays put; work in the patch's own frame, then put the middle back in the world
				var tmp = { "r": o, "rot": g.get("rot", 0) }
				var opp: Vector2 = corners(tmp)[(int(d.what) + 2) % 4]
				var lp = local(tmp, p.x, p.z)
				var lo = local(tmp, opp.x, opp.y)
				var w = maxf(0.3, absf(lp.x - lo.x))
				var dd = maxf(0.3, absf(lp.y - lo.y))
				var mx = lo.x + (1.0 if lp.x >= lo.x else -1.0) * w / 2.0
				var mz = lo.y + (1.0 if lp.y >= lo.y else -1.0) * dd / 2.0
				var c = cos(float(g.get("rot", 0)))
				var s = sin(float(g.get("rot", 0)))
				var cx0 = (float(o[0]) + float(o[2])) / 2.0
				var cz0 = (float(o[1]) + float(o[3])) / 2.0
				var cx = cx0 + c * mx + s * mz
				var cz = cz0 - s * mx + c * mz
				g["r"] = [cx - w / 2.0, cz - dd / 2.0, cx + w / 2.0, cz + dd / 2.0]
			E().rebuild_ground(q)
			d.moved = true

func _up(pos: Vector2) -> void:
	var d = drag
	drag = null
	if d == null:
		return
	match d.kind:
		"prop":
			if d.moved and sel:
				rec_prop(sel)
				world.refresh()
				refresh_panel()
		"blk":
			if d.get("moved"):
				blk_record(d.s)
				refresh_panel()
		"ppl":
			if d.get("moved"):
				ppl_record(d.q)
				refresh_panel()
		"gnd":
			if d.get("moved"):
				gnd_record(d.q)
				refresh_panel()
		"pan":
			# a click on empty ground: let go of what was selected
			if Time.get_ticks_msec() - int(d.t) < 250 and pos.distance_to(d.at) < 6.0 / shrink:
				match mode:
					"gnd": gsel = d.get("base"); refresh_panel()
					"ppl": psel = null; refresh_panel()
					"blk": bsel = null; refresh_panel()
					_: sel = null; refresh_panel()

# ================================================================ keys

func _input(ev: InputEvent) -> void:
	if not on or not (ev is InputEventKey) or not ev.pressed:
		return
	var fo = get_viewport().gui_get_focus_owner()
	if fo is LineEdit or fo is TextEdit:
		return
	var k: int = ev.keycode
	var used = true
	if (ev.ctrl_pressed or ev.meta_pressed) and k == KEY_Z:
		do_undo()
	elif k == KEY_ESCAPE:
		stop()
	elif mode == "blk":
		var n = 0.1
		match k:
			KEY_LEFT: _blk_do(func(s): _shift_solid(s, -n, 0))
			KEY_RIGHT: _blk_do(func(s): _shift_solid(s, n, 0))
			KEY_UP: _blk_do(func(s): _shift_solid(s, 0, -n))
			KEY_DOWN: _blk_do(func(s): _shift_solid(s, 0, n))
			KEY_EQUAL, KEY_PLUS, KEY_KP_ADD: blk_act("grow")
			KEY_MINUS, KEY_KP_SUBTRACT: blk_act("shrink")
			KEY_DELETE, KEY_BACKSPACE: blk_act("bdel")
			_: used = _letter(k)
	elif mode == "ppl":
		var m = { KEY_LEFT: "px-", KEY_RIGHT: "px+", KEY_UP: "pz-", KEY_DOWN: "pz+", KEY_Q: "pl", KEY_E: "pr", KEY_R: "pup", KEY_F: "pdn" }
		if psel and m.has(k): ppl_act(m[k])
		else: used = _letter(k)
	elif mode == "gnd":
		var m = { KEY_LEFT: "gx-", KEY_RIGHT: "gx+", KEY_UP: "gz-", KEY_DOWN: "gz+", KEY_Q: "gl", KEY_E: "gr", KEY_EQUAL: "gbig", KEY_PLUS: "gbig", KEY_KP_ADD: "gbig", KEY_MINUS: "gsmall", KEY_KP_SUBTRACT: "gsmall", KEY_DELETE: "gdel", KEY_BACKSPACE: "gdel" }
		if gsel and m.has(k): gnd_act(m[k])
		else: used = _letter(k)
	else:
		var m = { KEY_LEFT: "nx-", KEY_RIGHT: "nx+", KEY_UP: "nz-", KEY_DOWN: "nz+", KEY_Q: "rl", KEY_E: "rr", KEY_R: "up", KEY_F: "down", KEY_EQUAL: "big", KEY_PLUS: "big", KEY_KP_ADD: "big", KEY_MINUS: "small", KEY_KP_SUBTRACT: "small", KEY_DELETE: "del", KEY_BACKSPACE: "del" }
		if m.has(k): act(m[k])
		else: used = _letter(k)
	if used:
		get_viewport().set_input_as_handled()

## Letters and space would walk or talk: keep them from the game while editing.
static func _letter(k: int) -> bool:
	return (k >= KEY_A and k <= KEY_Z) or k == KEY_SPACE or (k >= KEY_0 and k <= KEY_9)

func _shift_solid(n: Node3D, dx: float, dz: float) -> void:
	n.position += Vector3(dx, 0, dz)

# ================================================================ drawing over the view

func _label_sel() -> void:
	var l: Label3D = world.label
	if mode == "props" and sel and is_instance_valid(sel.node):
		l.text = str(sel.cur.m)
		l.position = Vector3(float(sel.cur.x), float(sel.cur.get("y", 0)) + 1.0, float(sel.cur.z))
		l.visible = true
	elif mode == "ppl" and psel:
		l.text = _pname(psel)
		l.position = psel.node.global_position + Vector3(0, 2.2, 0)
		l.visible = true
	else:
		l.visible = false

func _P(x: float, z: float, y := 0.05) -> Vector2:
	return world.cam.unproject_position(Vector3(x, y, z)) * shrink

func _poly(pts: Array, fill: Color, line: Color, w: float, closed := true) -> void:
	var pv = PackedVector2Array(pts)
	if fill.a > 0 and pts.size() > 2:
		overlay.draw_colored_polygon(pv, fill)
	if closed:
		pv.append(pts[0])
	overlay.draw_polyline(pv, line, w, true)

func _draw_overlay() -> void:
	if not on or E() == null or world.cam == null:
		return
	if mode == "blk":
		for s in E().solids:
			if not is_instance_valid(s.node):
				continue
			var n: Node3D = s.node
			var off = n.get_meta("off", false)
			if off and s.sid == "":
				continue
			var is_sel = s == bsel
			var line = HI if is_sel else (Color(0.55, 0.57, 0.6, 0.7) if off else Color(0.88, 0.63, 0.31, 0.95))
			var fill = Color(1, 0.89, 0.54, 0.25) if is_sel else (Color(0.47, 0.49, 0.53, 0.12) if off else Color(0.88, 0.47, 0.16, 0.18))
			var pts = []
			if n.has_meta("r"):
				var r = float(n.get_meta("r"))
				for i in 24:
					var a = i / 24.0 * TAU
					pts.append(_P(n.position.x + cos(a) * r, n.position.z + sin(a) * r))
			else:
				var b = PlaceEdits.solid_box(n)
				pts = [_P(b.x0, b.z0), _P(b.x1, b.z0), _P(b.x1, b.z1), _P(b.x0, b.z1)]
			_poly(pts, fill, line, 2.5 if is_sel else 1.5)
			if is_sel:
				var hs = []
				if n.has_meta("r"):
					var r = float(n.get_meta("r"))
					hs = [_P(n.position.x + r, n.position.z), _P(n.position.x - r, n.position.z), _P(n.position.x, n.position.z + r), _P(n.position.x, n.position.z - r)]
				else:
					hs = pts
				for h in hs:
					overlay.draw_rect(Rect2(h - Vector2(5, 5), Vector2(10, 10)), HI)
		var bd: Variant = world.place.get_meta("bounds") if world.place.has_meta("bounds") else null
		if bd is Array:
			var c = [_P(bd[0], bd[1]), _P(bd[2], bd[1]), _P(bd[2], bd[3]), _P(bd[0], bd[3]), _P(bd[0], bd[1])]
			for i in 4:
				overlay.draw_dashed_line(c[i], c[i + 1], Color(0.55, 0.86, 1, 0.9), 2.0, 7.0)
		overlay.draw_circle(_P(world.pl.x, world.pl.z), 4, Color(0.55, 0.86, 1, 0.9))
	elif mode == "ppl":
		for q in _ppl_list():
			var n: Node3D = q.node
			var y = n.position.y
			var is_sel = q == psel
			var pts = []
			for i in 20:
				var a = i / 20.0 * TAU
				pts.append(_P(n.position.x + cos(a) * 0.4, n.position.z + sin(a) * 0.4, y + 0.05))
			var line = HI if is_sel else (Color(0.55, 0.86, 1, 0.95) if q.named else Color(0.79, 0.64, 0.35, 0.9))
			_poly(pts, Color(1, 0.89, 0.54, 0.22) if is_sel else Color(0, 0, 0, 0.12), line, 3.0 if is_sel else 1.6)
			var f = n.rotation.y
			overlay.draw_line(_P(n.position.x, n.position.z, y + 0.05), _P(n.position.x + sin(f) * 0.75, n.position.z + cos(f) * 0.75, y + 0.05), line, 2.0)
	elif mode == "gnd":
		for q in E().grounds:
			if q.base or q.get("del") or not is_instance_valid(q.node):
				continue
			var is_sel = q == gsel
			var cs = corners(q.g).map(func(v): return _P(v.x, v.y, float(q.g.get("y", 0)) + 0.02))
			_poly(cs, Color(1, 0.89, 0.54, 0.12) if is_sel else Color(0, 0, 0, 0), HI if is_sel else Color(0.63, 0.9, 0.55, 0.85), 3.0 if is_sel else 1.4)
			if is_sel:
				for c in cs:
					overlay.draw_rect(Rect2(c - Vector2(6, 6), Vector2(12, 12)), HI)
		if gsel and gsel.base:
			overlay.draw_string(ThemeDB.fallback_font, Vector2(360, 24), "Ground under everything selected", HORIZONTAL_ALIGNMENT_LEFT, -1, 13, HI)
	elif sel and is_instance_valid(sel.node):
		# the selected prop: a ring on the ground round its foot
		var it: Dictionary = sel.cur
		var r = E().foot(it) / 0.8
		var pts = []
		for i in 24:
			var a = i / 24.0 * TAU
			pts.append(_P(float(it.x) + cos(a) * r, float(it.z) + sin(a) * r, float(it.get("y", 0)) + 0.05))
		_poly(pts, Color(1, 0.89, 0.54, 0.12), HI, 2.0)
