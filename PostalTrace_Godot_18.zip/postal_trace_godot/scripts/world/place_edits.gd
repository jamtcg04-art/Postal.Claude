class_name PlaceEdits
extends Node
## The place editor's layer of changes over a place, in the browser build's own format, so an
## edits file made in either build applies in the other. A place's edits are kept under its key
## ("cross", "market:yard") as:
##   mods   {"<model>@<x>,<z>#<n>": {x, z, y, r, s|h, tint, mat, del}}   props the game put there
##   adds   [{m, x, z, y, r, s|h, tint, mat, solid}]                     props added in the editor
##   solids {mods: {"c@x,z,r#n" | "b@x0,z0,x1,z1#n": {...|del}}, adds: [...]}   blockers
##   bounds [x0, z0, x1, z1]                                              the walkable area
##   people {"p:<id>" | "e:<id or x,z>#n": {x, z, y, face, anim, outfit, item, age}}
##   grounds {mods: {"g<i>:<tex>": {x0, z0, x1, z1, rot, tex, c, rep, y, flow, del}}, adds: [...]}
## Keys use where the game first put each thing (two decimals), as the browser does.
##
## One of these sits in each place (as its child "Edits"); it knows every prop, blocker, patch of
## ground and person by that key, applies the stored changes, and lets the editor change them.

const USER_PATH := "user://place_edits.json"
const BAKED_PATH := "res://data/place_edits.json"   # edits baked into the game for everyone
const LIT := "lantern|lamp|fire|flame|brazier|candle|torch|sconce|hearth|stove|forge"

static var _user: Variant = null
static var _baked: Variant = null

# ---------------------------------------------------------------- the store

static func _read(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var v: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
	if v is Dictionary and v.get("edits") is Dictionary:
		v = v.edits
	return v if v is Dictionary else {}

## Everything the editor has changed on this machine (the browser's localStorage copy), plus any
## edits files dropped into an edits folder (see refresh_drops).
static func user_all() -> Dictionary:
	if _user == null:
		_user = _read(USER_PATH)
		_meta_load()
		_snap = _snapshot(_user)
	return _user

static func save_user() -> void:
	# every place whose edits changed since the last save is stamped with the time, so a newer
	# edits file dropped in later can tell whether it is newer than what was done here
	var now = Time.get_unix_time_from_system()
	var cur = _snapshot(user_all())
	for k in cur:
		if _snap.get(k, "") != cur[k]:
			_meta.times[k] = now
	_snap = cur
	var f = FileAccess.open(USER_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(user_all()))
	_meta_save()

## A place's edits: the ones made here (or taken from a dropped edits file), else the ones baked into the game.
static func for_key(k: String) -> Dictionary:
	refresh_drops()
	if user_all().has(k):
		return user_all()[k]
	if _baked == null:
		_baked = _read(BAKED_PATH)
	return _baked.get(k, {})

static func key_of(file: String) -> String:
	return file.replace("__", ":")

## The file the browser's "Save file" writes.
static func export_text() -> String:
	refresh_drops()
	var all = {}
	if _baked == null:
		_baked = _read(BAKED_PATH)
	for k in _baked:
		all[k] = _baked[k]
	for k in user_all():
		all[k] = user_all()[k]
	return JSON.stringify({ "game": "The Postal Trace", "kind": "place edits", "at": Time.get_datetime_string_from_system(true) + "Z", "edits": all }, " ")

## Load an edits file (or the bare edits copied from the browser); its places replace ours.
static func import_text(txt: String) -> bool:
	var v: Variant = JSON.parse_string(txt)
	if v is Dictionary and v.get("edits") is Dictionary:
		v = v.edits
	if not (v is Dictionary):
		return false
	for k in v:
		if v[k] is Dictionary:
			user_all()[k] = v[k]
	save_user()
	return true

# ---------------------------------------------------------------- edits files dropped in
## Drop the browser editor's "Save file" (postal-trace-place-edits.json, or any number of edits
## files) into one of these folders and the game reads it the next time a place is built:
##   res://edits/            in the project (and so in every export: it is in the export filter)
##   user://edits/           this machine's game data folder (Place editor > Open edits folder)
##   <game folder>/edits/    next to the exported game (for the handheld: the port's folder)
## Each place in a file is taken when the file is newer than the edits already here for that
## place (made in this editor, or from an older file); the file's own "at" time decides, or its
## modified time if it has none. Taken edits become this machine's edits, so the editor carries
## on from them. Taking a file again only happens when it changes.
const META_PATH := "user://place_edits_meta.json"
static var _meta: Dictionary = { "times": {}, "files": {} }
static var _snap: Dictionary = {}
static var _last_scan := -100000
static var drop_log: Array = []   # what the last scans took, for the editor's panel and the console

static func _snapshot(a: Dictionary) -> Dictionary:
	var o = {}
	for k in a:
		o[k] = JSON.stringify(a[k])
	return o

static func _meta_load() -> void:
	var v: Variant = null
	if FileAccess.file_exists(META_PATH):
		v = JSON.parse_string(FileAccess.get_file_as_string(META_PATH))
	_meta = v if v is Dictionary else {}
	if not (_meta.get("times") is Dictionary): _meta["times"] = {}
	if not (_meta.get("files") is Dictionary): _meta["files"] = {}

static func _meta_save() -> void:
	var f = FileAccess.open(META_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(_meta))

static func drop_dirs() -> Array:
	var d = ["res://edits", "user://edits"]
	if not OS.has_feature("editor"):
		d.append(OS.get_executable_path().get_base_dir().path_join("edits"))
		# started with --main-pack (the handheld port): the edits folder beside the game's pack
		var args = OS.get_cmdline_args()
		var at = args.find("--main-pack")
		if at >= 0 and at + 1 < args.size():
			var pd = str(args[at + 1]).get_base_dir().path_join("edits")
			if not d.has(pd):
				d.append(pd)
	return d

## "2026-11-05T23:14:02.118Z" -> seconds (UTC); 0 when it is not a time.
static func iso_time(t: String) -> float:
	if t.length() < 19:
		return 0.0
	return float(Time.get_unix_time_from_datetime_string(t.substr(0, 19)))

static func drop_files() -> Array:
	var out = []
	for dir in drop_dirs():
		var da = DirAccess.open(dir)
		if da == null:
			continue
		var names = Array(da.get_files())
		names.sort()
		for n in names:
			if n.get_extension().to_lower() == "json":
				out.append(dir.path_join(n))
	return out

## Look for new or changed edits files (at most once a second, or now with force).
static func refresh_drops(force := false) -> int:
	var t = Time.get_ticks_msec()
	if not force and t - _last_scan < 1000:
		return 0
	_last_scan = t
	user_all()
	var took = 0
	var changed = false
	for path in drop_files():
		var txt = FileAccess.get_file_as_string(path)
		if txt == "":
			continue
		var sig = str(txt.length()) + ":" + str(txt.hash())
		if _meta.files.get(path, "") == sig:
			continue
		_meta.files[path] = sig
		changed = true
		var v: Variant = JSON.parse_string(txt)
		var when = 0.0
		if v is Dictionary and v.get("at") is String:
			when = iso_time(v.at)
		if when <= 0.0:
			when = float(FileAccess.get_modified_time(path))
		if v is Dictionary and v.get("edits") is Dictionary:
			v = v.edits
		if not (v is Dictionary):
			drop_log.append(path.get_file() + ": not a place-edits file")
			continue
		var names = []
		for k in v:
			if not (v[k] is Dictionary):
				continue
			if user_all().has(k) and float(_meta.times.get(k, 0.0)) >= when:
				continue   # what was done here is newer
			user_all()[k] = v[k].duplicate(true)
			_meta.times[k] = when
			names.append(k)
		took += names.size()
		var line = path.get_file() + ": " + (("took " + ", ".join(names)) if names.size() else "nothing newer than the edits here")
		drop_log.append(line)
		print("Place edits: ", path, " — ", line)
	if changed:
		_snap = _snapshot(user_all())
		var f = FileAccess.open(USER_PATH, FileAccess.WRITE)
		if f:
			f.store_string(JSON.stringify(user_all()))
		_meta_save()
	return took

## JavaScript's toFixed(2). An exact tie (an odd number of eighths, such as -7.625) rounds away
## from zero there, where printf rounds to even.
static func fx2(v: float) -> String:
	var a = absf(v)
	if fmod(a * 8.0, 2.0) == 1.0:
		var t = (floor(a * 100.0) + 1.0) / 100.0
		return ("-" if v < 0 else "") + "%.2f" % t
	return "%.2f" % v

static func r3(v: float) -> float:
	return roundf(v * 1000.0) / 1000.0

# ---------------------------------------------------------------- the layer in a place

var place: Node3D
var file := ""
var key := ""
var L: Dictionary = {}
var props: Array = []      # {node, it (as the game made it), cur (as it is now), id, add, sol: [markers], lights: [glows]}
var solids: Array = []     # {node, sid, add, own (a prop's own)}
var grounds: Array = []    # {node, gk, base, add, g (as it is now)}
var people: Array = []     # {node, pk, o: {x, z, y, face, ax, az}, look}
var bounds0: Variant = null

static func attach(p: Node3D, f: String) -> PlaceEdits:
	var e = PlaceEdits.new()
	e.name = "Edits"
	e.place = p
	e.file = f
	e.key = key_of(f)
	e.L = PlaceBuilder.layout(f)
	p.add_child(e)
	e._index()
	e._apply(for_key(e.key))
	return e

func E() -> Dictionary:
	return for_key(key)

## This place's edits, ready to change (made here, so they are kept here).
func E_mut() -> Dictionary:
	var a = user_all()
	if not a.has(key):
		a[key] = for_key(key).duplicate(true) if not for_key(key).is_empty() else { "mods": {}, "adds": [] }
	var e: Dictionary = a[key]
	if not e.has("mods"): e["mods"] = {}
	if not e.has("adds"): e["adds"] = []
	return e

func _sizes() -> Dictionary:
	return PlaceBuilder.models().get("sizes", {})

func _index() -> void:
	# props, known by model and where the game first put them
	var nodes = {}
	var holder = place.get_node_or_null("Props")
	if holder:
		for n in holder.get_children():
			var nm = str(n.name)
			var at = nm.rfind("_")
			if at > 0 and nm.substr(at + 1).is_valid_int():
				nodes[int(nm.substr(at + 1))] = n
	var seen = {}
	var lp: Array = L.get("props", [])
	for i in lp.size():
		var it: Dictionary = lp[i]
		var b = str(it.m) + "@" + fx2(float(it.get("x", 0))) + "," + fx2(float(it.get("z", 0)))
		seen[b] = int(seen.get(b, 0)) + 1
		if nodes.has(i):
			props.append({ node = nodes[i], it = it, cur = it.duplicate(true), id = b + "#" + str(seen[b]), add = -1, sol = [], lights = [] })
	# blockers, by shape and where the game put them
	var sh = place.get_node_or_null("Solid")
	var ls: Array = L.get("solid", [])
	var sseen = {}
	if sh:
		for n in sh.get_children():
			var nm = str(n.name)
			var at = nm.rfind("_")
			if at < 0 or not nm.substr(at + 1).is_valid_int() or not (nm.begins_with("Post_") or nm.begins_with("Block_")):
				continue
			var i = int(nm.substr(at + 1))
			if i >= ls.size():
				continue
			n.set_meta("o", { "pos": n.position, "r": (n.get_meta("r") if n.has_meta("r") else null), "half": (n.get_meta("half") if n.has_meta("half") else null) })
	for i in ls.size():
		var s: Dictionary = ls[i]
		var b = ("c@" + fx2(float(s.x)) + "," + fx2(float(s.z)) + "," + fx2(float(s.r))) if s.has("r") else ("b@" + fx2(float(s.x0)) + "," + fx2(float(s.z0)) + "," + fx2(float(s.x1)) + "," + fx2(float(s.z1)))
		sseen[b] = int(sseen.get(b, 0)) + 1
		var node = sh.get_node_or_null(("Post_%d" if s.has("r") else "Block_%d") % i) if sh else null
		if node:
			solids.append({ node = node, sid = b + "#" + str(sseen[b]), add = -1, own = false })
	# patches of ground
	var gh = place.get_node_or_null("Ground")
	var lg: Array = L.get("grounds", [])
	if gh:
		for n in gh.get_children():
			var nm = str(n.name)
			if not nm.begins_with("Ground_"):
				continue
			var i = int(nm.split("_")[1])
			if i < lg.size():
				grounds.append({ node = n, gk = "g%d:%s" % [i, str(lg[i].get("tex", ""))], base = i == 0, add = -1, g = lg[i].duplicate(true) })
	# people and townsfolk
	var lpp: Array = L.get("people", [])
	var ph = place.get_node_or_null("People")
	if ph:
		for n in ph.get_children():
			var id = str(n.get_meta("id", ""))
			people.append({ node = n, pk = "p:" + id, o = _p_orig(n), named = true })
	var eh = place.get_node_or_null("Bystanders")
	var le: Array = L.get("extras", [])
	var eseen = {}
	for i in le.size():
		var p: Dictionary = le[i]
		# the export gave nameless townsfolk an id of their own ("<place>_x<n>"); the browser knows them by where they stand
		var own_id = p.get("id") and str(p.id) != str(L.get("id", "")) + "_x" + str(i)
		var b = "e:" + (str(p.id) if own_id else (fx2(float(p.get("x", 0))) + "," + fx2(float(p.get("z", 0)))))
		eseen[b] = int(eseen.get(b, 0)) + 1
		var n = eh.get_node_or_null("Bystander_%d" % i) if eh else null
		if n:
			people.append({ node = n, pk = b + "#" + str(eseen[b]), o = _p_orig(n), named = false, src = p })
	# each person stands on a small round blocker of their own
	for q in people:
		for s in solids:
			var o: Dictionary = s.node.get_meta("o", {})
			if o.get("r") != null and absf(float(o.r) - 0.35) < 1e-6 and Vector2(o.pos.x, o.pos.z).distance_to(Vector2(q.o.x, q.o.z)) < 1e-4:
				q["sol"] = s.node
	bounds0 = (place.get_meta("bounds") if place.has_meta("bounds") else null)
	_link_lights()

func _p_orig(n: Node3D) -> Dictionary:
	return { "x": n.position.x, "y": n.position.y, "z": n.position.z, "face": n.rotation.y, "ax": (n.get_meta("ax") if n.has_meta("ax") else null), "az": (n.get_meta("az") if n.has_meta("az") else null) }

## The round blockers standing on a prop (within 0.35 of where it was put).
func _solids_at(x: float, z: float) -> Array:
	var out = []
	for s in solids:
		var o: Dictionary = s.node.get_meta("o", {})
		if o.get("r") != null and absf(o.pos.x - x) < 0.35 and absf(o.pos.z - z) < 0.35:
			out.append(s.node)
	return out

# ---------------------------------------------------------------- applying

func _apply(e: Dictionary) -> void:
	if e.is_empty():
		return
	var by = {}
	for p in props:
		by[p.id] = p
	var mods: Dictionary = e.get("mods", {})
	for k in mods:
		if not by.has(k):
			continue
		var p: Dictionary = by[k]
		var d: Dictionary = mods[k]
		p.sol = _solids_at(float(p.it.get("x", 0)), float(p.it.get("z", 0)))
		if d.get("del"):
			p["del"] = true
			p.node.visible = false
			p.node.set_meta("ed_del", true)
			for s in p.sol:
				s.set_meta("off", true)
			continue
		for f in ["x", "z", "y", "r", "s", "h"]:
			if d.get(f) != null:
				p.cur[f] = float(d[f])
		if d.get("tint") is Array: p.cur["tint"] = d.tint.duplicate()
		if d.get("mat"): p.cur["mat"] = str(d.mat)
		pose(p)
	var adds: Array = e.get("adds", [])
	for i in adds.size():
		_add_prop(adds[i], i)
	_apply_solids(e)
	_apply_people(e)
	_apply_grounds(e)

## Put a prop where its current values say, with its colour and material, and its blockers and lights with it.
func pose(p: Dictionary) -> void:
	var sizes = _sizes()
	var it: Dictionary = p.cur
	var n: Node3D = p.node
	if sizes.has(str(it.m)) and not n.has_meta("standin"):
		n.transform = PlaceBuilder.item_transform(it, sizes[it.m].mn, sizes[it.m].sz)
	else:
		n.position = Vector3(float(it.get("x", 0)), float(it.get("y", 0)) + n.position.y - float(p.it.get("y", 0)), float(it.get("z", 0)))
		n.rotation.y = float(it.get("r", 0))
	var tint = PlaceBuilder._col(it.get("tint"))
	PlaceBuilder._restyle(n, tint, str(it.get("mat", "")), bool(it.get("unlit", false)), float(it.get("a", 1.0)) if it.get("a") != null else 1.0)
	n.set_meta("tint", tint)
	# the round blockers on it go with it
	var dx = float(it.get("x", 0)) - float(p.it.get("x", 0))
	var dz = float(it.get("z", 0)) - float(p.it.get("z", 0))
	for s in p.sol:
		var o: Dictionary = s.get_meta("o", {})
		if o.has("pos"):
			s.position = Vector3(o.pos.x + dx, 0, o.pos.z + dz)
	if p.get("own_solid"):
		p.own_solid.position = Vector3(float(it.x), 0, float(it.z))
		p.own_solid.set_meta("r", foot(it))
	_sync_lights(p)

## How wide a prop's own blocker is (the browser's edFoot).
func foot(it: Dictionary) -> float:
	var sizes = _sizes()
	if not sizes.has(str(it.m)):
		return 0.5
	var sz: Array = sizes[it.m].sz
	var s = float(it.h) / float(sz[1]) if it.get("h") != null and float(sz[1]) > 0 else float(it.get("s", 1.0))
	return clampf(maxf(float(sz[0]) * float(it.get("sx", 1.0)), float(sz[2]) * float(it.get("sz", 1.0))) * s / 2.0 * 0.8, 0.25, 3.0)

func _add_prop(a: Dictionary, i: int) -> Dictionary:
	var it = { "m": str(a.m), "x": float(a.get("x", 0)), "z": float(a.get("z", 0)), "y": float(a.get("y", 0)), "r": float(a.get("r", 0)) }
	if a.get("h") != null: it["h"] = float(a.h)
	else: it["s"] = float(a.get("s", 1.0))
	if a.get("tint") is Array: it["tint"] = a.tint.duplicate()
	if a.get("mat"): it["mat"] = str(a.mat)
	var n = PlaceBuilder._prop(it, _sizes())
	n.name = "Added_%d" % i
	var holder = place.get_node_or_null("Props")
	(holder if holder else place).add_child(n)
	var p = { node = n, it = it.duplicate(true), cur = it, id = "", add = i, sol = [], lights = [] }
	if a.get("solid"):
		var m = Marker3D.new()
		m.name = "AddedPost_%d" % i
		m.position = Vector3(it.x, 0, it.z)
		m.set_meta("r", foot(it))
		var sh = place.get_node_or_null("Solid")
		if sh:
			sh.add_child(m)
			p["own_solid"] = m
			solids.append({ node = m, sid = "", add = -1, own = true })
	props.append(p)
	# a lantern or a fire put down in the editor lights itself
	if RegEx.create_from_string(LIT).search(str(it.m)):
		var fire = RegEx.create_from_string("fire|brazier|flame|hearth|forge|stove").search(str(it.m)) != null
		var l = { "x": it.x, "z": it.z, "flat": true, "w": 5.0 if fire else 3.4, "c": [0.5, 0.26, 0.08] if fire else [0.42, 0.3, 0.12], "flick": true }
		var g = PlaceBuilder._light(l, 200 + i)
		var lh = place.get_node_or_null("Lights")
		(lh if lh else place).add_child(g)
		p.lights.append({ node = g, dx = 0.0, dz = 0.0, r0 = float(it.r), k0 = size_of(it), w0 = g.scale.x, y = g.position.y })
	pose(p)
	return p

## The browser's own wFitFor: what someone wears and carries, how old, in this place.
static func fit_for(p: Dictionary, coat: Variant, h: Variant, named: bool, place_id: String) -> Variant:
	if not Bridge.has_js("wFitFor"):
		return null
	var keepW: Variant = Data.js.globals.vars.get("W")
	Data.js.set_global("W", { "scene": { "id": place_id } })
	var f: Variant = Bridge.call_js("wFitFor", [p, coat, h, named])
	if keepW == null: Data.js.globals.vars.erase("W")
	else: Data.js.set_global("W", keepW)
	return Game._plain(f) if f is Dictionary else null

static func size_of(it: Dictionary) -> float:
	return float(it.h) if it.get("h") != null else float(it.get("s", 1.0))

# ---------------------------------------------------------------- lights follow what makes them

func _link_lights() -> void:
	var lh = place.get_node_or_null("Lights")
	if lh == null:
		return
	var lit = RegEx.create_from_string(LIT)
	var ll: Array = L.get("lights", [])
	for n in lh.get_children():
		var nm = str(n.name)
		if not nm.begins_with("Glow_"):
			continue
		var i = int(nm.substr(5))
		if i >= ll.size():
			continue
		var l: Dictionary = ll[i]
		if l.get("until") != null:
			continue
		var best = null
		var bd = 1.3
		for p in props:
			if not lit.search(str(p.it.m)):
				continue
			var d = Vector2(float(l.get("x", 0)) - float(p.it.get("x", 0)), float(l.get("z", 0)) - float(p.it.get("z", 0))).length() - (0.05 if str(p.it.m) in ["lantern", "fire"] else 0.0)
			if d < bd:
				bd = d
				best = p
		if best:
			best.lights.append({ node = n, dx = float(l.get("x", 0)) - float(best.it.get("x", 0)), dz = float(l.get("z", 0)) - float(best.it.get("z", 0)), r0 = float(best.it.get("r", 0)), k0 = maxf(size_of(best.it), 0.001), w0 = n.scale.x, y = n.position.y })

func _sync_lights(p: Dictionary) -> void:
	var it: Dictionary = p.cur
	for l in p.lights:
		var n: Node3D = l.node
		n.visible = not p.get("del", false)
		var ang = float(it.get("r", 0)) - float(l.r0)
		var k = size_of(it) / float(l.k0)
		var c = cos(ang)
		var s = sin(ang)
		n.position = Vector3(float(it.x) + (c * l.dx + s * l.dz) * k, l.y, float(it.z) + (-s * l.dx + c * l.dz) * k)
		n.scale = Vector3.ONE * l.w0 * k

# ---------------------------------------------------------------- blockers

func _apply_solids(e: Dictionary) -> void:
	var S: Dictionary = e.get("solids", {})
	var by = {}
	for s in solids:
		if s.sid != "":
			by[s.sid] = s
	var mods: Dictionary = S.get("mods", {})
	for k in mods:
		if not by.has(k):
			continue
		var d: Dictionary = mods[k]
		var n: Node3D = by[k].node
		if d.get("del"):
			n.set_meta("off", true)
			continue
		set_solid(n, d)
	var adds: Array = S.get("adds", [])
	for i in adds.size():
		_add_solid(adds[i], i)
	if e.get("bounds") is Array:
		place.set_meta("bounds", e.bounds.duplicate())

## Shape a blocker from {x, z, r} or {x0, x1, z0, z1} (only the parts given change).
func set_solid(n: Node3D, d: Dictionary) -> void:
	if n.has_meta("r"):
		n.position = Vector3(float(d.get("x", n.position.x)), 0, float(d.get("z", n.position.z)))
		if d.get("r") != null: n.set_meta("r", float(d.r))
	else:
		var b = solid_box(n)
		for f in ["x0", "x1", "z0", "z1"]:
			if d.get(f) != null: b[f] = float(d[f])
		n.position = Vector3((b.x0 + b.x1) / 2.0, 0, (b.z0 + b.z1) / 2.0)
		n.set_meta("half", Vector2((b.x1 - b.x0) / 2.0, (b.z1 - b.z0) / 2.0))

static func solid_box(n: Node3D) -> Dictionary:
	var h: Vector2 = n.get_meta("half", Vector2(0.5, 0.5))
	return { "x0": n.position.x - h.x, "x1": n.position.x + h.x, "z0": n.position.z - h.y, "z1": n.position.z + h.y }

func _add_solid(a: Dictionary, i: int) -> Dictionary:
	var m = Marker3D.new()
	m.name = "AddedSolid_%d" % i
	if a.get("r") != null:
		m.set_meta("r", float(a.r))
		m.position = Vector3(float(a.x), 0, float(a.z))
	else:
		m.set_meta("half", Vector2.ONE)
		set_solid(m, a)
	var sh = place.get_node_or_null("Solid")
	if sh:
		sh.add_child(m)
	var s = { node = m, sid = "", add = i, own = false }
	solids.append(s)
	return s

# ---------------------------------------------------------------- people

func _apply_people(e: Dictionary) -> void:
	var P: Dictionary = e.get("people", {})
	if P.is_empty():
		return
	for q in people:
		if P.has(q.pk) and P[q.pk] is Dictionary:
			set_person(q, P[q.pk])
			style_person(q, P[q.pk])

func set_person(q: Dictionary, d: Dictionary) -> void:
	var n: Node3D = q.node
	var dx = float(d.get("x", n.position.x)) - n.position.x
	var dz = float(d.get("z", n.position.z)) - n.position.z
	n.position = Vector3(float(d.get("x", n.position.x)), float(d.y) if d.get("y") != null else n.position.y, float(d.get("z", n.position.z)))
	if (n.get_meta("ax") if n.has_meta("ax") else null) != null: n.set_meta("ax", float(n.get_meta("ax")) + dx)
	if (n.get_meta("az") if n.has_meta("az") else null) != null: n.set_meta("az", float(n.get_meta("az")) + dz)
	if d.get("face") != null:
		n.rotation.y = float(d.face)
	if q.get("sol"):
		q.sol.position = Vector3(n.position.x, 0, n.position.z)

## How they stand about, and what they wear and carry, worked out by the browser's own wFitFor.
func style_person(q: Dictionary, d: Dictionary) -> void:
	var n: Node3D = q.node
	if not n.has_meta("look0"):
		n.set_meta("look0", n.get_meta("look", {}).duplicate(true) if (n.get_meta("look") if n.has_meta("look") else null) is Dictionary else {})
		n.set_meta("sit0", (n.get_meta("sit") if n.has_meta("sit") else null))
	var look: Dictionary = n.get_meta("look0").duplicate(true)
	var o: Dictionary = look.get("o", {}) if look.get("o") is Dictionary else {}
	if d.get("anim") != null:
		if str(d.anim) != "":
			look["want"] = str(d.anim)
			n.set_meta("sit", str(d.anim) == "sit")
		else:
			n.set_meta("sit", n.get_meta("sit0"))
	var fit_change = (d.get("outfit") != null and str(d.outfit) != "") or (d.get("item") != null and str(d.item) != "-") or (d.get("age") != null and str(d.age) != "")
	if fit_change and not o.get("body") and Bridge.has_js("wFitFor"):
		var id = str(n.get_meta("id", ""))
		var p = { "id": id, "name": str(n.get_meta("name", "")) }
		if d.get("outfit") and str(d.outfit) != "": p["rgOutfit"] = str(d.outfit)
		if d.get("item") != null and str(d.item) != "-": p["rgItem"] = null if str(d.item) == "" else str(d.item)
		var age = str(d.get("age", "")) if d.get("age") != null else ""
		if age != "":
			p["rgOld"] = age == "old"
			p["rgKid"] = age == "kid"
		if n.get_meta("sit", false): p["sit"] = true
		var named: bool = q.named
		var h: Variant
		if named:
			h = Bridge.call_js("wRigHash", [id])
		else:
			var src: Dictionary = q.get("src", {})
			var home: Variant = src.get("home")
			var hx = float(home[0]) if home is Array else float(src.get("x", 0))
			h = Bridge.call_js("wRigHash", [id + JsLite.to_str(src.get("hue")) + JsLite.num_str(roundf(hx * 10.0))])
		var coat: Variant = o.get("c") if o.get("c") is Array else [0.3, 0.28, 0.26]
		var f: Variant = fit_for(p, coat, h, named, file.split("__")[0])
		if f is Dictionary:
			o["fit"] = f
			# as the browser's wDress: a fresh look each time, so a child made grown loses the small size, and so on
			if f.get("s") != null: o["s"] = f.s
			else: o.erase("s")
			if f.get("stoop"): o["stoop"] = f.stoop
			else: o.erase("stoop")
			if o.get("head", true) and f.has("hat"):
				o["hat"] = f.hat
				o["hatc"] = f.get("hatc")
			look["o"] = o
	n.set_meta("look", look)

# ---------------------------------------------------------------- ground and roads

## A patch as the editor keeps it.
static func ground_data(g: Dictionary) -> Dictionary:
	var r: Array = g.r
	var c: Array = g.get("c", [1, 1, 1]) if g.get("c") is Array else [1, 1, 1]
	return { "x0": r3(float(r[0])), "z0": r3(float(r[1])), "x1": r3(float(r[2])), "z1": r3(float(r[3])), "rot": r3(float(g.get("rot", 0.0))),
		"tex": g.get("tex"), "c": c.map(func(v): return r3(float(v))), "rep": r3(float(g.get("rep", 3.0))), "y": r3(float(g.get("y", 0.0))), "flow": g.get("flow") }

static func ground_from(g: Dictionary, d: Dictionary) -> void:
	g["r"] = [float(d.x0), float(d.z0), float(d.x1), float(d.z1)]
	g["rot"] = float(d.get("rot", 0.0))
	if d.get("tex"): g["tex"] = str(d.tex)
	if d.get("c") is Array: g["c"] = d.c.duplicate()
	if d.get("rep"): g["rep"] = float(d.rep)
	if d.get("y") != null: g["y"] = minf(0.06, float(d.y))
	if d.has("flow"): g["flow"] = d.flow
	if str(g.get("tex", "")) == "t_water" and g.get("flow") == null: g["flow"] = [0.0001, 0.00002]

## Redraw a patch after a change.
func rebuild_ground(q: Dictionary) -> void:
	var fresh: MeshInstance3D = PlaceBuilder._ground(q.g, 0)
	var n: MeshInstance3D = q.node
	n.mesh = fresh.mesh
	n.material_override = fresh.material_override
	fresh.free()

func _apply_grounds(e: Dictionary) -> void:
	var G: Dictionary = e.get("grounds", {})
	if G.is_empty():
		return
	var by = {}
	for q in grounds:
		by[q.gk] = q
	var mods: Dictionary = G.get("mods", {})
	for k in mods:
		if not by.has(k):
			continue
		var q: Dictionary = by[k]
		if mods[k].get("del"):
			q["del"] = true
			q.node.visible = false
			continue
		ground_from(q.g, mods[k])
		rebuild_ground(q)
	var adds: Array = G.get("adds", [])
	for i in adds.size():
		add_ground(adds[i], i)

func add_ground(d: Dictionary, i: int) -> Dictionary:
	var g = { "r": [0, 0, 0, 0], "tex": null, "c": [1, 1, 1], "rep": 3.0, "y": 0.05, "rot": 0.0 }
	ground_from(g, d)
	var n: MeshInstance3D = PlaceBuilder._ground(g, 0)
	n.name = "AddedGround_%d" % i
	var gh = place.get_node_or_null("Ground")
	(gh if gh else place).add_child(n)
	var q = { node = n, gk = "", base = false, add = i, g = g }
	grounds.append(q)
	return q
