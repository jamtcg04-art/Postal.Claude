class_name PropMotion
extends Node
## Things in a place that move on their own, made from the game's existing models:
## - street lamps outdoors: the lamp head swings from its hook in the wind (PropParts splits it off the post);
##   lanterns hung high outdoors swing from their tops;
## - doors that are their own model swing open when the courier goes through, and shut behind;
## - cart and wagon wheels turn with the distance the cart travels (roll()).
## The place's FX node makes one of these for every place (fx.gd).

var place: Node3D
var file := ""
var t := 0.0
var swings: Array = []     # {n: Node3D, base: Transform3D, pivot: Vector3, amp: float, ph: float, whole: bool}
var doors: Array = []      # {n: Node3D, base: Transform3D, hinge: Vector3, w: float, ang: float, to: float}
var horses: Array = []     # the place's horse props, each carrying a rigged horse (see rig_horse())
var drives: Array = []     # {nodes: [Node3D], cart: Node3D, horse: Node3D, path: [Vector3], speed, dist, then}

const DOOR_MODELS := ["f_door", "f_doortall", "bell_door", "bell_rooms_door", "c_towerdoor"]
const DOOR_NEAR := 1.6     # how close a door model must stand to a doorway to belong to it

func setup(p: Node3D, f: String) -> void:
	place = p
	file = f
	var outdoor := not f.contains("__")
	var props = place.get_node_or_null("Props")
	if props == null:
		return
	var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
	var i := 0
	for n in props.get_children():
		if not n is Node3D or not n.has_meta("model"):
			continue
		i += 1
		var m := str(n.get_meta("model"))
		if outdoor and m == "b_lamp":
			var parts: Dictionary = PropParts.apply(n)
			if parts.has("head"):
				var hd: Node3D = parts.head
				swings.append({ n = hd, base = hd.transform, pivot = Vector3.ZERO, amp = 0.09, ph = i * 1.37, whole = false })
		elif outdoor and m == "lantern" and n.position.y >= 1.8 and sizes.has(m):
			var mn: Array = sizes[m].mn
			var sz: Array = sizes[m].sz
			var top := Vector3(float(mn[0]) + float(sz[0]) / 2.0, float(mn[1]) + float(sz[1]), float(mn[2]) + float(sz[2]) / 2.0)
			swings.append({ n = n, base = n.transform, pivot = top, amp = 0.13, ph = i * 0.91, whole = true })
		elif m.begins_with("cp_horse") and rig_horse(n, i):
			horses.append(n)
		elif m in DOOR_MODELS and sizes.has(m) and _near_doorway(n):
			var mn2: Array = sizes[m].mn
			var sz2: Array = sizes[m].sz
			doors.append({ n = n, base = n.transform, hinge = Vector3(float(mn2[0]), 0.0, float(mn2[2]) + float(sz2[2]) / 2.0), w = float(sz2[0]), ang = 0.0, to = 0.0 })

func _near_doorway(n: Node3D) -> bool:
	var things = place.get_node_or_null("Things")
	if things == null:
		return false
	for m in things.get_children():
		if str(m.get_meta("kind", "")) == "door" and Vector2(m.position.x - n.position.x, m.position.z - n.position.z).length() <= DOOR_NEAR:
			return true
	return false

## The wind: a slow swell with gusts, so the lamps along a street do not swing in step.
func _wind(ph: float) -> Vector2:
	var gust := 0.55 + 0.45 * sin(t * 0.21 + ph * 0.7)
	return Vector2(sin(t * 1.55 + ph) * 0.7 + sin(t * 0.47 + ph * 2.1) * 0.3, sin(t * 1.12 + ph * 1.3) * 0.5) * gust

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	t += dt
	for s in swings:
		var n: Node3D = s.n
		if not is_instance_valid(n) or not n.is_visible_in_tree():
			continue
		var w := _wind(s.ph) * float(s.amp)
		var r := Basis.from_euler(Vector3(w.x, 0.0, w.y))
		if s.whole:
			n.transform = s.base * Transform3D(Basis(), s.pivot) * Transform3D(r, Vector3.ZERO) * Transform3D(Basis(), -s.pivot)
		else:
			n.transform = Transform3D(s.base.basis * r, s.base.origin)
	_drive(dt)
	for d in doors:
		if absf(d.ang - d.to) < 0.001:
			continue
		d.ang = move_toward(d.ang, d.to, dt * 4.2)
		_door_pose(d)

func _door_pose(d: Dictionary) -> void:
	var n: Node3D = d.n
	if not is_instance_valid(n):
		return
	var h: Vector3 = d.hinge
	n.transform = d.base * Transform3D(Basis(), h) * Transform3D(Basis(Vector3.UP, d.ang), Vector3.ZERO) * Transform3D(Basis(), -h)

## The door model standing in a doorway, nearest to a point (the doorway's marker), or null.
func door_at(p: Vector3, near := DOOR_NEAR) -> Variant:
	var best: Variant = null
	var bd := near
	for d in doors:
		var n: Node3D = d.n
		var dd := Vector2(n.position.x - p.x, n.position.z - p.z).length()
		if dd <= bd:
			bd = dd
			best = d
	return best

## Which way a door opens: away from whoever pushes it, from where they stand.
func _away(d: Dictionary, from: Vector3) -> float:
	var n: Node3D = d.n
	var local: Vector3 = n.global_transform.affine_inverse() * from
	return 1.65 if local.z > (d.hinge as Vector3).z else -1.65

## Swing a door open (away from `from`); returns how long it takes, 0 if there is no door here.
func open_door(p: Vector3, from: Vector3) -> float:
	var d: Variant = door_at(p)
	if d == null:
		return 0.0
	d.to = _away(d, from)
	_snd("door_open", 0.35)
	return 0.4

## Arriving through a doorway: its door starts open behind you and swings shut.
func shut_behind(p: Vector3, from: Vector3) -> void:
	var d: Variant = door_at(p, 2.4)
	if d == null:
		return
	d.ang = -_away(d, from)
	_door_pose(d)
	d.to = 0.0
	_snd("door_close", 0.3, 0.35)

func _snd(key: String, vol: float, delay := 0.0) -> void:
	var S = get_tree().root.get_node_or_null("Sound") if is_inside_tree() else null
	if S:
		S.play(key, vol, delay)

## A horse prop gets the rigged copy of its own model (tools/anim/rig_horse.py), in the prop's colours,
## standing at ease: idle, started at a different point for every horse so they do not move in step.
static func rig_horse(n: Node3D, seed_i := 0) -> bool:
	if n.has_meta("rig"):
		return true
	var m := str(n.get_meta("model", ""))
	var path := "res://assets/3d/models/%s_rig.glb" % m
	if not ResourceLoader.exists(path):
		return false
	var rig: Node3D = load(path).instantiate()
	rig.name = "Rig"
	for mi in n.find_children("*", "MeshInstance3D", false, false):
		mi.visible = false
	n.add_child(rig)
	PlaceBuilder._restyle(rig, n.get_meta("tint", Color(1, 1, 1)), str(n.get_meta("mat", "")), bool(n.get_meta("unlit", false)), float(n.get_meta("a", 1.0)))
	n.set_meta("rig", rig)
	var ap := horse_anim(n)
	if ap:
		ap.play("idle")
		ap.seek(fmod(seed_i * 1.73, 6.0), true)
		ap.speed_scale = 0.85 + fmod(seed_i * 0.37, 0.3)
	return true

static func horse_anim(n: Node3D) -> AnimationPlayer:
	var rig: Variant = n.get_meta("rig", null)
	return rig.find_child("AnimationPlayer", true, false) if rig is Node3D else null

## Play a horse movement: idle, walk, pull, trot, gallop, rear, shy. One-offs (rear, shy) go back to idle.
static func horse_play(n: Node3D, anim_name: String, speed := 1.0) -> void:
	var ap := horse_anim(n)
	if ap == null or not ap.has_animation(anim_name):
		return
	var once := anim_name in ["rear", "shy"]
	ap.get_animation(anim_name).loop_mode = Animation.LOOP_NONE if once else Animation.LOOP_LINEAR
	if ap.current_animation != anim_name or once:
		ap.play(anim_name, 0.25)
		if once:
			ap.seek(0.0, true)
	ap.speed_scale = speed
	if once and not ap.animation_finished.is_connected(_back_to_idle.bind(ap)):
		ap.animation_finished.connect(_back_to_idle.bind(ap), CONNECT_ONE_SHOT)

static func _back_to_idle(_name: StringName, ap: AnimationPlayer) -> void:
	ap.play("idle", 0.4)
	ap.speed_scale = 1.0

## Where a rider sits on a rigged horse: a node that follows its "saddle" bone (made the first time), or null.
static func saddle(n: Node3D) -> Node3D:
	var rig: Variant = n.get_meta("rig", null)
	if not rig is Node3D:
		return null
	var sk: Skeleton3D = rig.find_child("Skeleton3D", true, false)
	if sk == null or sk.find_bone("saddle") < 0:
		return null
	var at: Node3D = sk.get_node_or_null("SaddleMount")
	if at == null:
		at = BoneAttachment3D.new()
		at.name = "SaddleMount"
		at.bone_name = "saddle"
		sk.add_child(at)
	return at

## Move props along a path at walking pace: a horse pulls (its "pull" movement, or "walk", "trot",
## "gallop" by speed), a cart's wheels turn with the ground covered, and anything else listed (the box,
## a driver) keeps its place relative to the first node. Turns to face the way it goes. `then` runs on arrival.
func drive(nodes: Array, path: Array, speed := 1.4, then := Callable(), horse_anim_name := "") -> void:
	if nodes.is_empty() or path.is_empty():
		return
	var lead: Node3D = nodes[0]
	# everything moves with a frame at the lead's footprint (the prop's own origin can sit far from its middle)
	var mid: Vector3 = lead.get_parent().to_global(spot(lead)) if lead.get_parent() is Node3D else lead.global_position
	var frame := Transform3D(lead.global_transform.basis.orthonormalized(), mid)
	var e := { "nodes": nodes, "frame": frame, "path": path.duplicate(), "speed": speed, "then": then, "dist": 0.0,
		"offs": [], "cart": null, "horse": null }
	for n in nodes:
		e.offs.append(frame.affine_inverse() * n.global_transform)
		var m := str(n.get_meta("model", ""))
		if m.begins_with("cp_horse") and n.has_meta("rig"):
			e.horse = n
		elif PropParts.has_parts(m) and e.cart == null and not m.begins_with("b_lamp"):
			e.cart = n
	if e.horse:
		var g: String = horse_anim_name if horse_anim_name != "" else ("pull" if e.cart else ("walk" if speed < 2.2 else ("trot" if speed < 4.5 else "gallop")))
		horse_play(e.horse, g, clampf(speed / (1.3 if g in ["walk", "pull"] else (3.2 if g == "trot" else 7.0)), 0.6, 1.6))
	drives.append(e)

func _drive(dt: float) -> void:
	var keep: Array = []
	for e in drives:
		var fr: Transform3D = e.frame
		var to: Vector3 = e.path[0]
		var d := Vector3(to.x - fr.origin.x, 0.0, to.z - fr.origin.z)
		var step := minf(d.length(), float(e.speed) * dt)
		if d.length() > 0.001:
			var dir := d.normalized()
			var want := Basis.looking_at(-dir, Vector3.UP)    # the model's +z (a horse's head) toward the way it goes
			var q := Quaternion(fr.basis).slerp(Quaternion(want), minf(1.0, dt * 3.0))
			fr = Transform3D(Basis(q), fr.origin + dir * step)
			e.frame = fr
			e.dist += step
		for i in e.nodes.size():
			var n: Node3D = e.nodes[i]
			if is_instance_valid(n):
				n.global_transform = fr * e.offs[i]
		if e.cart:
			roll(e.cart, e.dist)
		if d.length() <= 0.05:
			e.path.pop_front()
			if e.path.is_empty():
				if e.horse:
					horse_play(e.horse, "idle")
				if e.then.is_valid():
					e.then.call()
				continue
		keep.append(e)
	drives = keep

## Where a prop stands (its footprint's middle), as the layout places it (the same as PlaceFX.spot).
static func spot(n: Node3D) -> Vector3:
	var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
	var m = str(n.get_meta("model", ""))
	if not sizes.has(m):
		return n.position
	var mn: Array = sizes[m].mn
	var s3: Array = sizes[m].sz
	var off = Vector3(-(float(mn[0]) + float(s3[0]) / 2.0), -float(mn[1]), -(float(mn[2]) + float(s3[2]) / 2.0))
	return n.transform.origin - n.transform.basis * off

func driving() -> bool:
	return not drives.is_empty()

## The saddle bone's place and turn in the world (orthonormal: the prop's scale taken out), or null.
static func saddle_xform(n: Node3D) -> Variant:
	var rig: Variant = n.get_meta("rig", null)
	if not rig is Node3D:
		return null
	var sk: Skeleton3D = rig.find_child("Skeleton3D", true, false)
	if sk == null:
		return null
	var b := sk.find_bone("saddle")
	if b < 0:
		return null
	var t: Transform3D = sk.global_transform * sk.get_bone_global_pose(b)
	return Transform3D(t.basis.orthonormalized(), t.origin)

## Turn a cart's wheels for `dist` metres travelled (forward is positive).
static func roll(prop: Node3D, dist: float) -> void:
	var parts: Dictionary = PropParts.apply(prop)
	for k in parts:
		var pv: Node3D = parts[k]
		if str(pv.get_meta("kind", "")) != "wheel":
			continue
		var r := maxf(float(pv.get_meta("r", 0.5)), 0.05)
		var ax := int(pv.get_meta("axis", 0))
		var a := -dist / r
		pv.rotation = Vector3(a if ax == 0 else 0.0, a if ax == 1 else 0.0, a if ax == 2 else 0.0)
