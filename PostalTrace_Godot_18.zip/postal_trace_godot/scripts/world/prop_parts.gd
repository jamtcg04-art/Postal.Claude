class_name PropParts
## Splits a prop's own mesh into moving parts (cart wheels, the hanging head of a street lamp) so the
## game can turn them without new art. The parts are found by geometry: every piece of the mesh that
## is not welded to the rest is a "component", and data/prop_parts.json says which components belong
## to which part (inside a wheel's disc, inside a lamp head's box) and where each part turns.
##
##   var parts = PropParts.apply(prop)      # {name: Node3D pivot}, or {} if the model has no parts
##
## The split meshes are made once per model and shared by every copy of it.

const DATA := "res://data/prop_parts.json"
static var _defs: Variant = null
static var _cache: Dictionary = {}     # model -> {rest: ArrayMesh, parts: [{name, kind, pivot, axis, mesh, src: [surface]}]}

static func defs() -> Dictionary:
	if _defs == null:
		_defs = {}
		if FileAccess.file_exists(DATA):
			var j = JSON.parse_string(FileAccess.get_file_as_string(DATA))
			if j is Dictionary:
				_defs = j
	return _defs

static func has_parts(model: String) -> bool:
	return defs().has(model)

static func _v3(a: Variant, d := Vector3.ZERO) -> Vector3:
	return Vector3(float(a[0]), float(a[1]), float(a[2])) if a is Array and a.size() >= 3 else d

## The welded pieces of each surface: [{s, tris: PackedInt32Array (first index of each triangle), lo, hi}]
static func components(mesh: Mesh) -> Array:
	var out: Array = []
	for s in mesh.get_surface_count():
		var arr: Array = mesh.surface_get_arrays(s)
		var vtx: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var idx: PackedInt32Array = arr[Mesh.ARRAY_INDEX] if arr[Mesh.ARRAY_INDEX] != null else PackedInt32Array()
		if idx.is_empty():
			idx.resize(vtx.size())
			for i in vtx.size():
				idx[i] = i
		# weld vertices that share a position
		var key: Dictionary = {}
		var rep := PackedInt32Array()
		rep.resize(vtx.size())
		for i in vtx.size():
			var v: Vector3 = vtx[i]
			var k := Vector3i(roundi(v.x * 10000.0), roundi(v.y * 10000.0), roundi(v.z * 10000.0))
			if not key.has(k):
				key[k] = key.size()
			rep[i] = key[k]
		var par: Array = []     # an Array, not a packed one: the lambda below must share it
		par.resize(key.size())
		for i in par.size():
			par[i] = i
		var find := func(x: int) -> int:
			while par[x] != x:
				par[x] = par[par[x]]
				x = par[x]
			return x
		for t in range(0, idx.size() - 2, 3):
			var a: int = find.call(rep[idx[t]])
			var b: int = find.call(rep[idx[t + 1]])
			var c: int = find.call(rep[idx[t + 2]])
			par[b] = a
			par[find.call(c)] = a
		var groups: Dictionary = {}
		for t in range(0, idx.size() - 2, 3):
			var r: int = find.call(rep[idx[t]])
			if not groups.has(r):
				groups[r] = { "s": s, "tris": PackedInt32Array(), "lo": Vector3(INF, INF, INF), "hi": Vector3(-INF, -INF, -INF) }
			var g: Dictionary = groups[r]
			g.tris.append(t)
			for k in 3:
				var v: Vector3 = vtx[idx[t + k]]
				g.lo = g.lo.min(v)
				g.hi = g.hi.max(v)
		for r in groups:
			out.append(groups[r])
	return out

static func _inside(part: Dictionary, c: Vector3) -> bool:
	if part.kind == "wheel":
		var ax: int = int(part.axis)
		var d: Vector3 = c - part.pivot
		var along: float = absf(d[ax])
		d[ax] = 0.0
		return d.length() <= float(part.r) * 1.03 and along <= maxf(float(part.half) * 3.0, 0.16)
	var lo: Vector3 = part.lo
	var hi: Vector3 = part.hi
	return c.x >= lo.x and c.y >= lo.y and c.z >= lo.z and c.x <= hi.x and c.y <= hi.y and c.z <= hi.z

## A mesh made of the given triangles (by surface): surfaces keep their materials.
static func _build(mesh: Mesh, tris_by_surface: Dictionary, src_out: Array) -> ArrayMesh:
	var m := ArrayMesh.new()
	for s in tris_by_surface:
		var tris: PackedInt32Array = tris_by_surface[s]
		if tris.is_empty():
			continue
		var arr: Array = mesh.surface_get_arrays(s)
		var vtx: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
		var idx: PackedInt32Array = arr[Mesh.ARRAY_INDEX] if arr[Mesh.ARRAY_INDEX] != null else PackedInt32Array()
		var remap: Dictionary = {}
		var order := PackedInt32Array()
		var ni := PackedInt32Array()
		for t in tris:
			for k in 3:
				var o: int = idx[t + k] if not idx.is_empty() else t + k
				if not remap.has(o):
					remap[o] = order.size()
					order.append(o)
				ni.append(remap[o])
		var na: Array = []
		na.resize(Mesh.ARRAY_MAX)
		for a in Mesh.ARRAY_MAX:
			var src: Variant = arr[a]
			if src == null or a == Mesh.ARRAY_INDEX:
				continue
			var per := 1
			if a == Mesh.ARRAY_TANGENT:
				per = 4
			elif a == Mesh.ARRAY_BONES or a == Mesh.ARRAY_WEIGHTS:
				continue
			var dst = src.duplicate()
			dst.resize(order.size() * per)
			for i in order.size():
				for p in per:
					dst[i * per + p] = src[order[i] * per + p]
			na[a] = dst
		na[Mesh.ARRAY_INDEX] = ni
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, na)
		m.surface_set_material(m.get_surface_count() - 1, mesh.surface_get_material(s))
		src_out.append(s)
	return m

static func _split(model: String, mesh: Mesh) -> Dictionary:
	if _cache.has(model):
		return _cache[model]
	var d: Dictionary = defs().get(model, {})
	var parts: Array = []
	for p in d.get("parts", []):
		var e := { "name": str(p.name), "kind": str(p.get("kind", "swing")), "pivot": _v3(p.get("pivot")), "axis": int(p.get("axis", 0)),
			"r": float(p.get("r", 0.0)), "half": float(p.get("half", 0.0)), "lo": _v3(p.get("lo"), Vector3(-INF, -INF, -INF)), "hi": _v3(p.get("hi"), Vector3(INF, INF, INF)),
			"tris": {}, "n": 0 }
		parts.append(e)
	var rest: Dictionary = {}
	for c in components(mesh):
		var ctr: Vector3 = (c.lo + c.hi) * 0.5
		var owner: Variant = null
		for p in parts:
			if _inside(p, ctr):
				owner = p
				break
		var bucket: Dictionary = owner.tris if owner != null else rest
		if not bucket.has(c.s):
			bucket[c.s] = PackedInt32Array()
		bucket[c.s].append_array(c.tris)
		if owner != null:
			owner.n += 1
	var res := { "rest": null, "rest_src": [], "parts": [] }
	res.rest = _build(mesh, rest, res.rest_src)
	for p in parts:
		if p.n == 0:
			continue
		var src: Array = []
		p.mesh = _build(mesh, p.tris, src)
		p.src = src
		p.erase("tris")
		res.parts.append(p)
	_cache[model] = res
	return res

## Turn a placed prop into a rest mesh plus a pivot per moving part. Safe to call twice.
static func apply(prop: Node3D) -> Dictionary:
	var model := str(prop.get_meta("model", ""))
	if not has_parts(model) or prop.has_meta("parts_done"):
		return prop.get_meta("parts", {}) if prop.has_meta("parts") else {}
	var mi: MeshInstance3D = null
	for c in prop.find_children("*", "MeshInstance3D", true, false):
		if c.mesh:
			mi = c
			break
	if mi == null:
		return {}
	var src_mesh: Mesh = mi.mesh
	var overrides: Array = []
	for s in src_mesh.get_surface_count():
		overrides.append(mi.get_surface_override_material(s))
	var sp: Dictionary = _split(model, src_mesh)
	if sp.parts.is_empty():
		return {}
	mi.mesh = sp.rest
	for i in sp.rest_src.size():
		mi.set_surface_override_material(i, overrides[sp.rest_src[i]])
	var out: Dictionary = {}
	for p in sp.parts:
		var pv := Node3D.new()
		pv.name = "Part_" + str(p.name)
		pv.position = p.pivot
		mi.add_child(pv)
		var pm := MeshInstance3D.new()
		pm.mesh = p.mesh
		pm.position = -p.pivot
		for i in p.src.size():
			pm.set_surface_override_material(i, overrides[p.src[i]])
		pv.add_child(pm)
		pv.set_meta("kind", p.kind)
		pv.set_meta("axis", p.axis)
		pv.set_meta("r", p.r)
		out[str(p.name)] = pv
	prop.set_meta("parts_done", true)
	prop.set_meta("parts", out)
	return out
