class_name RoadView
extends Node3D
## The road between stops, in 3D: the courier walks (or leads the horse) in place while the road, the verges and
## everything beside it slide past and come round again; it stops for what the road brings (thieves from a hedge,
## a pole across the road, a rider down) and for camp: a tent off the saddle, a lean-to of branches, or a cold
## camp under brush with no fire when Notice is high. Built from the game's own models, like any place.
##
## The World holds one of these as its place while the story is on the road (world.gd: enter_road, road_set).

const SPEED := 1.45            # metres a second: the walk movement's own pace
const TILE := 48.0             # ground tiles this long come round again
const SPAN := 26.0             # how far ahead and behind the roadside things live
const SIDE := ["tree1", "tree2", "tree3", "tree5", "dtree1", "dtree3", "bush1", "bush2", "bush3", "fo_bush1", "fo_bush2", "fo_fern", "fo_grass", "fo_grass", "rk_a", "rk_b", "rock1", "fence", "fence_broken", "stonewall"]
const NEAR := ["fo_grass", "fo_fern", "fo_bush1", "rk_c", "fence_pole", "fo_grass"]
# the heights the place layouts give these models (a model's own units are not metres)
const H := { "tree1": 8.0, "tree2": 7.5, "tree3": 7.0, "tree5": 7.0, "dtree1": 6.0, "dtree3": 6.0, "bush1": 1.1, "bush2": 1.1, "bush3": 1.1,
	"fo_bush1": 1.3, "fo_bush2": 1.4, "fo_fern": 0.9, "fo_grass": 1.0, "rk_a": 1.2, "rk_b": 0.7, "rk_c": 0.35, "fence": 1.1, "fence_broken": 1.1,
	"stonewall": 1.0, "fence_pole": 1.2, "cp_fire": 0.35, "flame": 0.5, "cp_logs": 0.45, "sh_leanto": 2.4, "sh_leanto2": 2.0, "cp_horse": 1.9, "cp_horse_grey": 1.9 }
const S_OF := { "rock1": 0.7, "tent": 0.8, "cart": 1.0 }
const PROVOST := { "body": "soldier", "c": [0.16, 0.16, 0.2], "hat": "shako", "wpn": "musket" }
const THIEF := [{ "c": [0.32, 0.27, 0.21], "hat": "flatcap", "wpn": "club" }, { "c": [0.26, 0.25, 0.22], "hat": "knitcap", "wpn": "axe" }, { "c": [0.4, 0.34, 0.26], "s": 0.82 }]

var speed := 0.0               # how fast the world slides past now
var want := SPEED               # how fast it should
var tiles: Array = []
var side: Array = []           # {n: Node3D, x: float}
var set_nodes: Array = []       # what the current stop has put by the road
var mode := "walk"
var horse: Node3D = null
var rng := RandomNumberGenerator.new()
var player_anim := "walk"
var night := false
var camp: Dictionary = {}

static func build(seed_i: int, with_horse: bool) -> RoadView:
	var r := RoadView.new()
	r.name = "Road"
	r.rng.seed = 7919 * (seed_i + 3)
	for g in ["Props", "People", "Bystanders", "Things", "Solid", "Lights"]:
		var n := Node3D.new()
		n.name = g
		r.add_child(n)
	r.set_meta("bounds", [-30, -30, 30, 30])
	r.set_meta("fog", [0.13, 0.15, 0.17])
	r._ground()
	r._scatter()
	if with_horse:
		r._horse()
	return r

func _ground() -> void:
	for i in 3:
		var t := Node3D.new()
		t.position.x = (i - 1) * TILE
		add_child(t)
		t.add_child(PlaceBuilder._ground({ "r": [-TILE / 2.0, -40, TILE / 2.0, 40], "rep": 3.6, "tex": "grass", "c": [0.6, 0.62, 0.55] }, i * 3))
		t.add_child(PlaceBuilder._ground({ "r": [-TILE / 2.0, -1.6, TILE / 2.0, 1.6], "rep": 3.2, "y": 0.04, "tex": "mud", "c": [0.85, 0.82, 0.78] }, i * 3 + 1))
		t.add_child(PlaceBuilder._ground({ "r": [-TILE / 2.0, -2.2, TILE / 2.0, -1.6], "rep": 3.0, "y": 0.03, "tex": "t_earth", "c": [0.7, 0.68, 0.6] }, i * 3 + 2))
		tiles.append(t)

func _prop(m: String, x: float, z: float, h := 0.0, r := 0.0, tint: Variant = null) -> Node3D:
	var it := { "m": m, "x": x, "z": z, "r": r }
	if tint is Array:
		it["tint"] = tint
	if h <= 0.0:
		h = float(H.get(m, 0.0))
	if h > 0.0:
		it["h"] = h
	elif S_OF.has(m):
		it["s"] = S_OF[m]
	var n := PlaceBuilder._prop(it, PlaceBuilder.models().get("sizes", {}))
	get_node("Props").add_child(n)
	return n

func _scatter() -> void:
	var x := -SPAN
	while x < SPAN:
		x += rng.randf_range(1.6, 4.2)
		_side_one(x)

func _side_one(x: float) -> void:
	var far := rng.randf() < 0.75
	var m: String = SIDE[rng.randi() % SIDE.size()] if far else NEAR[rng.randi() % NEAR.size()]
	var z := rng.randf_range(4.0, 16.0) if far else rng.randf_range(2.4, 3.4)
	if rng.randf() < 0.5:
		z = -z
	var tall := m.begins_with("tree") or m.begins_with("dtree")
	if tall and z > 0.0 and z < 7.0:
		z = -z       # nothing tall between the camera and the courier
	var n := _prop(m, x, z, 0.0, rng.randf() * TAU)
	side.append({ "n": n, "x": x })

func _horse() -> void:
	var hs := ["cp_horse_grey", "cp_horse"]
	horse = _prop(hs[rng.randi() % 2], 0.0, 1.0, 1.9, PI / 2)
	if not PropMotion.rig_horse(horse, 2):
		horse.queue_free()
		horse = null
		return
	PropMotion.horse_play(horse, "walk")
	# the courier rides her: she stands where he walks, head forward (world.gd puts him in the saddle)
	var c := PropMotion.spot(horse)
	horse.position += Vector3(-0.2 - c.x, 0, 0.0 - c.z)
	horse.set_meta("home", horse.position)

# ---------------------------------------------------------------- what the road brings

## Move on (walk), or stop for something: "stop", "camp", "camp_found", "thieves", "patrol", "hunt",
## "rider", "wheel", "deadhorse", "fire", "forage", "fight".
func set_mode(m: String, info := {}) -> void:
	if m == mode and m != "camp":
		return
	var keep_set := m == "fight" or (mode == "camp" and m == "camp_found")
	if not keep_set:
		_clear_set()
	mode = m
	want = SPEED if m == "walk" else 0.0
	player_anim = "walk" if m == "walk" else "idle"
	if horse:
		PropMotion.horse_play(horse, "walk" if m == "walk" else "idle")
	match m:
		"camp":
			_camp(info)
		"camp_found":
			_lanterns()
		"thieves":
			_thieves(int(info.get("n", 2)))
		"patrol":
			_pole()
		"hunt":
			_riders()
		"rider":
			_rider_down()
		"wheel":
			_broken_wheel()
		"deadhorse":
			_dead_horse()
		"fire":
			_farm_fire()
		"forage":
			_foragers()

func _clear_set() -> void:
	if horse and horse.has_meta("home"):
		horse.position = horse.get_meta("home")
	for n in set_nodes:
		if is_instance_valid(n):
			n.queue_free()
	set_nodes.clear()
	camp = {}
	night = false
	for n in get_meta("hid", []):
		if is_instance_valid(n):
			n.visible = true
	set_meta("hid", [])

func _keep(n: Node3D) -> Node3D:
	set_nodes.append(n)
	return n

func _fig(look: Dictionary, x: float, z: float, face: float, anim := "idle") -> Figure:
	var f := Figure.new()
	f.dress(look)
	f.position = Vector3(x, 0, z)
	f.rotation.y = face
	get_node("People").add_child(f)
	f.play(anim)
	_keep(f)
	return f

func _fire(x: float, z: float) -> void:
	_keep(_prop("cp_fire", x, z))
	var fl := _keep(_prop("flame", x, z, 0.5))
	fl.set_meta("flick", true)
	var g := PlaceBuilder._light({ "x": x, "z": z, "flat": true, "w": 5.0, "c": [0.5, 0.32, 0.12], "flick": true }, 40)
	if g:
		get_node("Lights").add_child(g)
		_keep(g)

## Camp, off the road: the shelter, the fire (or none), the horse tied to a tree, the courier sitting or lying low.
func _camp(c: Dictionary) -> void:
	camp = c
	night = true
	# clear the hollow: roadside things standing where the camp goes are hidden while it stands
	for s in side:
		var n: Node3D = s.n
		if is_instance_valid(n) and absf(float(s.x)) < 5.0 and PropMotion.spot(n).z < -1.5:
			n.visible = false
			set_meta("hid", (get_meta("hid", []) as Array) + [n])
	var kind := str(c.get("kind", "fire"))
	var shelter := str(c.get("shelter", "leanto"))
	var cx := 0.6
	var cz := -4.6
	# a tent off the saddle roll with a horse; a lean-to of cut branches and the greatcoat without one (cp_leanto, the
	# browser's PROC model); a cold camp pulls brush over whichever it is, and rubs mud into the canvas
	var hidden := shelter != "tent" and shelter != "leanto"
	if shelter == "tent" or (hidden and c.get("horse") == true):
		_keep(_prop("tent", cx, cz - 0.6, 0.0, PI, [0.52, 0.5, 0.4] if hidden else null))
	else:
		_keep(_prop("cp_leanto", cx, cz - 0.4, 0.0, 0.0))
	if hidden:
		# brush pulled over it: no fire, nothing that shines
		for q in [[-0.9, -0.3], [0.2, 0.3], [1.3, -0.2], [0.6, -1.4], [-0.4, -1.2], [1.8, -1.0]]:
			_keep(_prop(["fo_bush1", "fo_bush2", "fo_fern", "bush2"][rng.randi() % 4], cx + q[0], cz + q[1], 0.0, rng.randf() * TAU))
	if kind == "fire":
		_fire(cx + 0.2, cz + 1.7)
		_keep(_prop("cp_logs", cx - 1.1, cz + 1.9, 0.0, 0.4))
	if horse:
		var c2 := PropMotion.spot(horse)
		horse.position += Vector3(-3.0 - c2.x, 0, -3.8 - c2.z)
		PropMotion.horse_play(horse, "idle")
	player_anim = "sit" if kind == "fire" else "crouch"

func camp_player_spot() -> Vector3:
	if camp.is_empty():
		return Vector3.ZERO
	return Vector3(1.8, 0, -2.5) if str(camp.get("kind", "")) == "fire" else Vector3(0.6, 0, -4.3)   # beside the fire, not in it

## A patrol comes in on the camp with lanterns.
func _lanterns() -> void:
	night = true
	for i in 3:
		var f := _fig(PROVOST if i else PROVOST.merged({ "wpn": "pistol" }, true), -5.5 + i * 1.6, -1.4 - i * 0.7, PI * 0.75, "lantern" if i == 0 else "walk")
		f.set_meta("walk_to", Vector3(-1.6 + i * 1.2, 0, -3.0 - i * 0.6))

func _thieves(n: int) -> void:
	for i in n:
		var f := _fig(THIEF[i], 3.2 + i * 0.9, -3.6 + (i % 2) * 0.4, -PI / 2, "walk")
		f.set_meta("walk_to", Vector3(2.4 + i * 0.7, 0, -0.4 + i * 0.9))
		f.set_meta("then", "arms")

func _pole() -> void:
	_keep(_prop("fence_pole", 4.2, 0.0, 0.0, PI / 2))
	_keep(_prop("fence", 4.4, -3.4, 0.0, 0.0))
	_fig(PROVOST, 4.9, 0.8, -PI / 2, "arms")
	_fig(PROVOST, 5.3, -0.9, -PI / 2, "idle")
	_fig(PROVOST.merged({ "wpn": "pistol" }, true), 3.6, -2.2, -PI / 2 - 0.4, "talk")

func _riders() -> void:
	for i in 3:
		var h := _keep(_prop("cp_horse" if i else "cp_horse_grey", 6.0 + i * 2.4, -1.6 + i * 1.5, 1.9, -PI / 2))
		if PropMotion.rig_horse(h, i + 4):
			PropMotion.horse_play(h, "idle")
		_fig(PROVOST, 5.6 + i * 2.4, -0.4 + i * 1.5, -PI / 2, "idle")

func _rider_down() -> void:
	var h := _keep(_prop("cp_horse", 4.6, -3.4, 1.9, 0.3))
	if PropMotion.rig_horse(h, 9):
		PropMotion.horse_play(h, "idle")
	var f := _fig({ "body": "soldier", "c": [0.22, 0.25, 0.31], "hat": "shako" }, 3.4, -1.0, 0.0, "death")
	f.play_once("death", 1.0)

func _broken_wheel() -> void:
	var w := _keep(_prop("cart", 4.4, -2.4, 0.0, PI / 2 + 0.2))
	w.rotation.z = 0.18
	_fig({ "c": [0.36, 0.3, 0.24], "hat": "strawhat" }, 3.5, -1.0, 0.4, "kneel")

func _dead_horse() -> void:
	var h := _keep(_prop("cp_horse_grey", 4.5, -2.6, 1.9, 0.2))
	h.rotation.z = PI / 2.1
	h.position.y += 0.35

func _farm_fire() -> void:
	night = true
	_keep(_prop("sh_leanto", 6.0, -6.0, 2.4, 0.3))
	for q in [[5.4, -5.0], [6.8, -5.6], [6.0, -4.2]]:
		_fire(q[0], q[1])

func _foragers() -> void:
	for i in 3:
		_fig({ "body": "soldier", "c": [0.28, 0.24, 0.2], "hat": "shako", "wpn": "musket" }, 5.0 + i * 1.1, -3.2 + i * 0.8, -PI / 2, "carry" if i else "talk")

# ---------------------------------------------------------------- every frame

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	speed = move_toward(speed, want, dt * 1.6)
	var dx := speed * dt
	if dx > 0.0:
		for t in tiles:
			t.position.x -= dx
			if t.position.x < -TILE * 1.5:
				t.position.x += TILE * 3.0
		var keep: Array = []
		for s in side:
			var n: Node3D = s.n
			if not is_instance_valid(n):
				continue
			n.position.x -= dx
			s.x -= dx
			if s.x < -SPAN:
				n.queue_free()
				continue
			keep.append(s)
		side = keep
		var last := -SPAN
		for s in side:
			last = maxf(last, float(s.x))
		while last < SPAN:
			last += rng.randf_range(1.6, 4.2)
			_side_one(last)
	# the people of a stop walk to their marks, then do what they came to do
	for n in set_nodes:
		if n is Figure and is_instance_valid(n) and n.has_meta("walk_to"):
			var to: Vector3 = n.get_meta("walk_to")
			var d: Vector3 = to - n.position
			d.y = 0.0
			if d.length() > 0.05:
				n.position += d.normalized() * minf(d.length(), 1.3 * dt)
				n.rotation.y = atan2(d.x, d.z)
				n.play("walk")
			else:
				n.remove_meta("walk_to")
				n.play(str(n.get_meta("then", "idle")))
