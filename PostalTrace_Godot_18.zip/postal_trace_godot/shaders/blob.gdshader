// The soft dark spot under each person, as in the original.
shader_type spatial;
render_mode unshaded, blend_mix, depth_draw_never, cull_disabled, shadows_disabled;

void fragment() {
	float d = length(UV - vec2(0.5)) * 2.0;
	ALBEDO = vec3(0.0);
	ALPHA = 0.42 * (1.0 - smoothstep(0.45, 1.0, d));
}
