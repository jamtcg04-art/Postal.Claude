// A pool of firelight or lamplight on the ground: an additive disc that flickers.
shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_disabled;

uniform vec3 color = vec3(0.5, 0.26, 0.08);
uniform bool flick = false;
uniform float seed = 0.0;

void fragment() {
	float r = length(UV - vec2(0.5)) * 2.0;
	float k = clamp(1.0 - r, 0.0, 1.0);
	k = k * k;
	float f = flick ? 0.85 + 0.15 * sin(TIME * 13.0 + seed) * sin(TIME * 7.3 + seed * 1.7) : 1.0;
	ALBEDO = color * k * f;
	ALPHA = 1.0;
}
