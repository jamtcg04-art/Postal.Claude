// Hue rotation for portraits, matching CSS hue-rotate() in the browser version.
shader_type canvas_item;

uniform float hue = 0.0; // radians

void fragment() {
	vec4 c = texture(TEXTURE, UV);
	float ca = cos(hue);
	float sa = sin(hue);
	mat3 m = mat3(
		vec3(0.213 + ca * 0.787 - sa * 0.213, 0.213 - ca * 0.213 + sa * 0.143, 0.213 - ca * 0.213 - sa * 0.787),
		vec3(0.715 - ca * 0.715 - sa * 0.715, 0.715 + ca * 0.285 + sa * 0.140, 0.715 - ca * 0.715 + sa * 0.715),
		vec3(0.072 - ca * 0.072 + sa * 0.928, 0.072 - ca * 0.072 - sa * 0.283, 0.072 + ca * 0.928 + sa * 0.072));
	COLOR = vec4(clamp(m * c.rgb, 0.0, 1.0), c.a);
}
