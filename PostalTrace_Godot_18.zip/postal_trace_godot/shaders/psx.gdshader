// The look of the browser version's 3D: vertices snapped to the pixel grid, flat
// half-lambert light, distance fog around the player, and a fine ordered dither.
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_opaque;

global uniform vec3 pt_cam;        // where the camera is looking (the player), for the fog
global uniform vec3 pt_fog;        // fog colour
global uniform vec2 pt_fog_range;  // fog starts, fog is total
global uniform vec3 pt_light;      // direction towards the light
global uniform vec4 pt_hole;       // the courier (xyz) and the radius (w) of the see-through hole

uniform sampler2D tex : source_color, filter_nearest_mipmap, repeat_enable;
uniform bool use_tex = false;
uniform vec3 color = vec3(1.0);
uniform bool lit = true;
uniform vec2 flow = vec2(0.0);     // texture drift per millisecond (running water)
uniform float alpha = 1.0;
uniform float sel = 0.0;           // highlight when the mouse is over it
uniform bool fade = false;         // stands between the camera and the courier: stipple a hole round him

varying vec3 wpos;
varying vec3 wnorm;
varying vec3 vview;

void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	wnorm = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
	vview = (VIEW_MATRIX * vec4(wpos, 1.0)).xyz;
	vec4 c = PROJECTION_MATRIX * VIEW_MATRIX * vec4(wpos, 1.0);
	vec2 g = VIEWPORT_SIZE * 0.5;
	c.xy = floor(c.xy / c.w * g + 0.5) / g * c.w;
	POSITION = c;
}

float bay2(vec2 a) { a = floor(a); return fract(dot(a, vec2(0.5, a.y * 0.75))); }
float bay4(vec2 a) { return bay2(0.5 * a) * 0.25 + bay2(a); }

void fragment() {
	if (alpha < 0.999 && bay4(FRAGCOORD.xy) > alpha) discard;
	if (fade) {
		// the original's see-through: a stippled circle round the courier, only on the near side of him
		vec3 hv = (VIEW_MATRIX * vec4(pt_hole.xyz, 1.0)).xyz;
		float hd = length(vview.xy - hv.xy) / max(0.001, pt_hole.w);
		if (hd < 1.0 && vview.z > hv.z) {
			vec2 q = mod(floor(FRAGCOORD.xy), 2.0);
			if (hd < 0.65) { if (q.x + q.y > 0.5) discard; }
			else if (q.x + q.y == 1.0) discard;
		}
	}
	vec4 t = use_tex ? texture(tex, UV + flow * TIME * 1000.0) : vec4(1.0);
	if (t.a < 0.5) discard;
	vec3 c = t.rgb * color;
	float l = lit ? 0.58 + 0.55 * max(dot(normalize(wnorm), normalize(pt_light)), 0.0) : 1.0;
	c *= l;
	c += sel * vec3(0.18, 0.14, 0.05);
	float d = distance(wpos.xz, pt_cam.xz);
	float f = clamp((d - pt_fog_range.x) / max(0.001, pt_fog_range.y - pt_fog_range.x), 0.0, 1.0);
	c = mix(c, pt_fog, f);
	vec2 p = floor(FRAGCOORD.xy);
	c += (mod(p.x + p.y * 2.0, 4.0) / 4.0 - 0.375) / 32.0;
	ALBEDO = c;
}
