extends SceneTree
## Screenshots for the moving things (needs a display):
##   godot -s res://tests/anim_shots.gd -- <outdir>
## Each shot: place, where the courier stands, zoom, what to do first, file name.
var w
var vp: SubViewport
var out := "user://"
var f := 0
var i := 0
var shots: Array = []
var G
func _initialize() -> void:
	out = OS.get_cmdline_user_args()[0]
	shots = [
		{ "p": "market", "at": [-2.0, 4.0], "z": 4.0, "name": "lamp_a" },
		{ "p": "market", "at": [-2.0, 4.0], "z": 4.0, "name": "lamp_b", "wait": 50 },
		{ "p": "market__tavern_up", "at": null, "z": 5.0, "name": "door_shut" },
		{ "p": "market__tavern_up", "at": null, "z": 5.0, "name": "door_open", "door": true, "wait": 60 },
	]
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		G = root.get_node("Game")
		G.begin_run({ "trait": "steady" })
		var c := SubViewportContainer.new()
		c.stretch = true
		c.size = Vector2(960, 640)
		root.add_child(c)
		vp = SubViewport.new()
		c.add_child(vp)
		w = load("res://scripts/world/world.gd").new()
		vp.add_child(w)
		return false
	if f < 4:
		return false
	if i >= shots.size():
		return true
	var s: Dictionary = shots[i]
	var wait: int = int(s.get("wait", 25))
	if s.get("_t0") == null:
		G.S.route = [str(s.p).split("__")[0]]; G.S.idx = 0
		w.enter(s.p)
		w.zoom = float(s.z)
		if s.at != null:
			w.pl = Vector3(s.at[0], 0, s.at[1])
		w.cam_target = w.pl
		if s.get("door"):
			for k in w.picks:
				if k.kind == "door": w.fx.motion.open_door(k.node.position, w.pl)
		s["_t0"] = f
	elif f - int(s._t0) >= wait:
		root.get_viewport().get_texture().get_image().save_png(out + "/" + str(s.name) + ".png")
		i += 1
	return false
