extends SceneTree
## Things that move: lamp heads swing outdoors, doors that are models swing open and shut, cart wheels turn.
##   godot --headless -s res://tests/anim_test.gd
var w
var f := 0
var ok := 0
var n := 0
var G
func check(name: String, c: bool, note: Variant = "") -> void:
	n += 1
	if c: ok += 1
	print(("PASS " if c else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		G = root.get_node("Game")
		G.begin_run({ "trait": "steady" })
		G.S.route = ["market"]; G.S.idx = 0
		w = load("res://scripts/world/world.gd").new()
		root.add_child(w)
	if f == 4:
		w.enter("market")
	if f == 30:
		var heads := 0
		var moved := 0
		for s in w.fx.motion.swings:
			if not s.whole:
				heads += 1
				if s.n.transform.basis != s.base.basis: moved += 1
		check("market street lamps: heads split off and swinging", heads >= 15 and moved >= heads - 1, "%d heads, %d moving" % [heads, moved])
		var lamp: Node3D = null
		for p in w.place.get_node("Props").get_children():
			if str(p.get_meta("model", "")) == "b_lamp": lamp = p; break
		var mi: MeshInstance3D = lamp.find_children("*", "MeshInstance3D", true, false)[0]
		check("the post keeps the rest of the lamp", mi.mesh.get_surface_count() >= 1 and mi.get_node_or_null("Part_head") != null)
		var cart = PlaceBuilder._prop({ "m": "cart", "x": 0, "z": 0 }, PlaceBuilder.models().get("sizes", {}))
		w.place.add_child(cart)
		PropMotion.roll(cart, 1.2)
		var parts: Dictionary = PropParts.apply(cart)
		check("cart: two wheels found", parts.size() == 2, parts.keys())
		if parts.size():
			check("cart wheels turn with distance (1.2 m on a 0.6 m wheel = 2 rad)", absf(absf(parts.values()[0].rotation.x) - 2.0) < 0.01, parts.values()[0].rotation)
		var wag = PlaceBuilder._prop({ "m": "mk_wagon", "x": 3, "z": 0 }, PlaceBuilder.models().get("sizes", {}))
		w.place.add_child(wag)
		check("wagon: two wheels found", PropParts.apply(wag).size() == 2)
		var mn = PlaceBuilder._prop({ "m": "mn_cart_a", "x": 6, "z": 0 }, PlaceBuilder.models().get("sizes", {}))
		w.place.add_child(mn)
		check("mine cart: four wheels found", PropParts.apply(mn).size() == 4)
		G.S.route = ["cross"]
		w.enter("cross")
		var rigged := 0
		for h in w.fx.motion.horses:
			var ap = PropMotion.horse_anim(h)
			if ap and ap.current_animation == "idle": rigged += 1
		check("Cross-Pillars: every horse is rigged and standing at ease", rigged >= 2 and rigged == w.fx.motion.horses.size(), "%d of %d" % [rigged, w.fx.motion.horses.size()])
		if w.fx.motion.horses.size():
			var h0 = w.fx.motion.horses[0]
			PropMotion.horse_play(h0, "rear")
			check("a horse can rear, then goes back to idle", PropMotion.horse_anim(h0).current_animation == "rear")
			check("the saddle is there for a rider", PropMotion.saddle(h0) != null)
			# a horse and cart driven 4 m: the horse pulls, the cart keeps its place behind, the wheels turn
			var hz = w.fx.motion.horses[1]
			var cart2 = PlaceBuilder._prop({ "m": "cart", "x": PropMotion.spot(hz).x, "z": PropMotion.spot(hz).z - 2.6 }, PlaceBuilder.models().get("sizes", {}))
			w.place.get_node("Props").add_child(cart2)
			var gap0 = (cart2.global_position - hz.global_position).length()
			var start = PropMotion.spot(hz)
			w.fx.motion.drive([hz, cart2], [start + Vector3(0, 0, 4.0)], 3.0, func(): set_meta("arrived", true))
			check("the team moves off: the horse pulls", PropMotion.horse_anim(hz).current_animation == "pull")
			set_meta("team", [hz, cart2, gap0, start])
	if f == 40:
		var tm: Array = get_meta("team", [])
		if tm.size():
			var deadline = Time.get_ticks_msec() + 3000
			while not has_meta("arrived") and Time.get_ticks_msec() < deadline:
				w.fx.motion._drive(0.05)
			check("the team arrives 4 m on", has_meta("arrived") and PropMotion.spot(tm[0]).distance_to(tm[3] + Vector3(0, 0, 4.0)) < 0.2, PropMotion.spot(tm[0]))
			check("the cart kept its distance", absf((tm[1].global_position - tm[0].global_position).length() - tm[2]) < 0.05)
			var wl: Node3D = PropParts.apply(tm[1]).values()[0]
			check("its wheels turned (4 m on 0.6 m wheels)", absf(absf(wl.rotation.x) - 4.0 / 0.6) < 0.05, wl.rotation.x)
		G.S.route = ["market"]
		w.enter("market__tavern_up")
	if f == 44:
		check("tavern upstairs: the bedroom door is a door", w.fx.motion.doors.size() >= 1, w.fx.motion.doors.size())
		var dk = null
		for k in w.picks:
			if k.kind == "door": dk = k
		if dk and w.fx.motion.doors.size():
			var tm = w.fx.motion.open_door(dk.node.position, w.pl)
			check("going through swings it open", tm > 0.0)
	if f == 70:
		if w.fx.motion.doors.size():
			check("the door is swinging open", absf(w.fx.motion.doors[0].ang) > 0.3 and absf(w.fx.motion.doors[0].to) > 1.5, w.fx.motion.doors[0].ang)
		print("ANIM: %d/%d" % [ok, n])
		return true
	return false
