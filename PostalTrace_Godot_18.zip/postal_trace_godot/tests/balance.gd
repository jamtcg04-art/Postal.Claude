extends SceneTree
## Plays whole runs and records what happened, for the balance report (tools/balance_report.py):
## every check (where, difficulty, the courier's total, passed or not), supplies at each stop, fights
## met, how the run ended.
##   godot --headless --path . -s res://tests/balance.gd -- <seed> <steps> <random|careful> <out.json>
var main: Control
var step := 0
var max_steps := 600
var started := false
var endings := 0
var log_lines: PackedStringArray = []
var rush := false
var policy := "random"
var out_path := ""
var rec := { "checks": [], "stops": [], "fights": [], "ending": "", "steps": 0 }
var _last_idx := -1
var _in_fight := ""
var _hurry_pick = null

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var sd := int(args[0]) if args.size() > 0 else 1
	max_steps = int(args[1]) if args.size() > 1 else 600
	policy = args[2] if args.size() > 2 else "random"
	out_path = args[3] if args.size() > 3 else "user://balance.json"
	rush = true
	if rush:
		for i in 7:
			DirAccess.remove_absolute("user://save_%d.json" % i)
	seed(sd)
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	rec["seed"] = sd
	rec["policy"] = policy

func _snap() -> Dictionary:
	var S: Dictionary = root.get_node("Game").S
	var o = {}
	for k in ["hp", "st", "pw", "ra", "coin", "hrs", "notice", "trust", "duty", "level", "idx"]:
		o[k] = S.get(k)
	return o

func _finish(why: String) -> void:
	var G = root.get_node("Game")
	rec["ending"] = main.last_ending if main.last_ending != "" else why
	rec["steps"] = step
	rec["final"] = _snap()
	rec["route"] = G.S.get("route", [])
	var f = FileAccess.open(out_path, FileAccess.WRITE)
	f.store_string(JSON.stringify(rec))
	f.close()

func _texts(n: Node, out: PackedStringArray) -> void:
	if n is Label and n.is_visible_in_tree():
		out.append(n.text)
	for c in n.get_children():
		_texts(c, out)

func _buttons(n: Node, out: Array) -> void:
	if n is Button and n.is_visible_in_tree() and not n.disabled:
		out.append(n)
	for c in n.get_children():
		_buttons(c, out)

func _process(_d: float) -> bool:
	if step == 0 and not started:
		started = true
		root.get_node("Game").on_roll = func(m, r):
			rec.checks.append({ "where": root.get_node("Game").cur_id(), "phase": main.phase, "dc": int(m.dc), "tot": int(m.tot), "ok": bool(r.ok), "odds": root.get_node("Game").odds(m) })
		return false
	step += 1
	if step > max_steps:
		print("BOT: stopped after ", max_steps, " steps; endings=", endings, " phase=", main.phase, " idx=", main.get_node("/root/Game").S.get("idx"))
		_finish("unfinished")
		return true
	var G = root.get_node("Game")
	if main.modal.visible:
		main.close_modal()
		return false
	if main.beat_btn != null:
		main._reveal_all()
		return false
	var heads: PackedStringArray = []
	_texts(main.page, heads)
	var head := " | ".join(heads.slice(0, 2))
	if head.begins_with("DUTY") or head.begins_with("THE ROAD WINS") or head.begins_with("THE WAR MOVES ON"):
		pass
	var live: Array = main.choices.filter(func(c): return not c[2] and is_instance_valid(c[0]) and c[0].is_visible_in_tree())
	var btns: Array = []
	_buttons(main.page, btns)
	# occasionally open the panels to exercise them
	if randi() % 25 == 0 and main.phase in ["scene", "road", "talk"]:
		var which = ["char", "tin", "bag", "log"][randi() % 4]
		main._on_top(which)
		var mb: Array = []
		_buttons(main.mpage, mb)
		if mb.size() > 1 and randi() % 2 == 0:
			mb[randi() % mb.size()].pressed.emit()
		main.close_modal()
		return false
	if main.phase == "title":
		if step > 5:
			endings += 1
			print("BOT: back at title after an ending; step ", step)
			_finish("title")
			return true
	if main.last_ending != "" and not rec.has("at_end"):
		rec["at_end"] = _snap()
	var idx = int(G.S.get("idx", -1))
	if idx != _last_idx and G.S.get("route", []).size():
		_last_idx = idx
		var s = _snap()
		s["stop"] = G.cur_id()
		rec.stops.append(s)
	var fight_now = main.phase == "page" and head.to_lower().contains("· round")
	if fight_now and _in_fight == "":
		_in_fight = G.cur_id()
		rec.fights.append({ "where": _in_fight, "hp_before": G.S.get("hp") })
	elif not fight_now and _in_fight != "":
		rec.fights[-1]["hp_after"] = G.S.get("hp")
		_in_fight = ""
	var opts: Array = []
	for c in live:
		opts.append(c[1])
	for b in btns:
		if b.text == "Back" or b.text.begins_with("Practice") or b.text.begins_with("Quit") or b.text.begins_with("Load") or b.text.begins_with("Credits") or b.text.begins_with("Back to the scene") and live.size() > 1:
			continue
		opts.append(b)
	if opts.is_empty():
		print("BOT: stuck at ", head)
		return true
	var pick = opts[randi() % opts.size()]
	if policy == "careful":
		# a careful courier rests and eats when low, and keeps to the safer of the offered checks
		var S: Dictionary = G.S
		var want = []
		if int(S.get("st", 9)) <= 3 or int(S.get("hp", 9)) <= 3:
			want = ["Rest", "Eat", "ration"]
		for b in btns:
			if want.any(func(w): return b.text.contains(w)):
				pick = b
				break
	if policy == "hurry":
		# a courier watching the clock: rests and eats only when low, goes round road meetings, takes
		# the pole road at Hob's Cutting, and does not dawdle between stops
		var S2: Dictionary = G.S
		var low = int(S2.get("st", 9)) <= 3 or int(S2.get("hp", 9)) <= 3
		if low:
			for b in btns:
				if b.text.contains("Rest") or b.text.contains("Eat"):
					pick = b
					break
		elif main.phase == "road":
			pick = live[live.size() - 1][1] if live.size() else pick
			for b in btns:
				if b.text.contains("by the back lanes") and int(S2.get("st", 9)) > 4:
					pick = b
					break
		elif main.phase == "scene" and G.cur_id() == "wirehut":
			for c in live:
				if c[0] is Control and str(c[0].get_meta("label", "")).contains("splice"):
					pick = c[1]
		_hurry_pick = pick
	if rush and policy != "hurry" and main.phase in ["scene", "road"] and live.size() and randi() % 2 == 0:
		pick = live[live.size() - 1][1]
	if rush and main.phase == "talk" and btns.size() and randi() % 3 == 0:
		for b in btns:
			if b.text == "Back to the scene":
				pick = b
	if step % 10 == 0 or main.phase == "other":
		print("BOT ", step, " [", main.phase, "] ", head.substr(0, 90), "  hrs=", G.S.get("hrs"), " hp=", G.S.get("hp"))
	if pick is Callable:
		pick.call()
	else:
		pick.pressed.emit()
	return false
