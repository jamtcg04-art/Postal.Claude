extends SceneTree
## The ambush on the bearers (needs a display): godot -s res://tests/bearers_shots.gd -- <outdir>
var main
var G
var f := 0
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/bearers_" + name + ".png")
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["bearers"]; G.S.idx = 0
			main.scene(),
		"w60", func(): shot("before"); main.world.zoom = 9.0; main.world.stage.bearers.hit(false),
		"w200", func(): shot("hit"),
		func(): G.S.route = ["bearers"]; main.world.place.queue_free(); main.world.place = null; main.world.file = ""; main.scene(),
		"w40", func(): root.get_node("Bridge").call_js("bearersAmbush", [root.get_node("Bridge").js("ENC").bearers.choices[2], 2]),
		"w180", func(): shot("ride"),
		"w420", func(): shot("ride_ambush"),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
