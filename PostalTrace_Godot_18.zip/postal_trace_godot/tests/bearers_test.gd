extends SceneTree
## The ambush on the bearers in 3D: riding to the ford, and hit where they stand (watch, warning ignored).
##   godot --headless -s res://tests/bearers_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			G.S.route = ["bearers"]; G.S.idx = 0
			main.scene(),
		func():
			var b = main.world.stage.bearers
			_check("at the bearers: the cart, the box, ten bearers", b._gather() and b.box != null and b.bearers.size() >= 10, b.bearers.size())
			b.hit(true),
		"t2000",
		func():
			var b = main.world.stage.bearers
			var st = main.world.stage
			_check("the rebels come out: three men and the rider on the grey", st.cast.has("r1") and st.cast.has("r3") and st.cast.has("rider") and st.cast.rider.mounted)
			_check("Pike steps out of the line", st.cast.has("pike"))
			_check("the box comes down off the cart", b.box.position.y < 0.5, b.box.position)
			var kneel := 0
			for q in b.bearers:
				if q.f.current == "kneel" or q.f.current == "jog": kneel += 1
			_check("the bearers close round it", kneel >= 7, kneel),
		func():
			G.S.route = ["bearers"]
			main.world.place.queue_free(); main.world.place = null; main.world.file = ""
			main.scene(),
		func():
			root.get_node("Bridge").call_js("bearersAmbush", [root.get_node("Bridge").js("ENC").bearers.choices[2], 2]),
		"t9000",
		func():
			var st = main.world.stage
			_check("riding to the ford ends in the ambush, and the fight uses those men", st.cast.has("rider") and st.cast.has("r2") and main._in_fight(), st.cast.keys()),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("BEARERS: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String and s.begins_with("t"):
		var until := Time.get_ticks_msec() + int(s.substr(1))
		steps.push_front(func(): pass)
		set_meta("until", until)
		return false
	if has_meta("until") and Time.get_ticks_msec() < int(get_meta("until")):
		steps.push_front(s); return false
	if has_meta("until"): remove_meta("until")
	s.call(); wait = 4
	return false
