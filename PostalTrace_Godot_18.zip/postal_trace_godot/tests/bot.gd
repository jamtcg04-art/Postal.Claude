extends SceneTree
## Plays the game headless by picking random options, to shake out runtime errors.
##   godot --headless --path . -s res://tests/bot.gd -- <seed> <steps>
var main: Control
var step := 0
var max_steps := 600
var started := false
var endings := 0
var log_lines: PackedStringArray = []
var rush := false

func _initialize() -> void:
	var args := OS.get_cmdline_user_args()
	var sd := int(args[0]) if args.size() > 0 else 1
	max_steps = int(args[1]) if args.size() > 1 else 600
	rush = args.size() > 2 and args[2] == "rush"
	if rush:
		for i in 7:
			DirAccess.remove_absolute("user://save_%d.json" % i)
	seed(sd)
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)

func _texts(n: Node, out: PackedStringArray) -> void:
	if n is Label and n.is_visible_in_tree():
		out.append(n.text)
	for c in n.get_children():
		_texts(c, out)

func _buttons(n: Node, out: Array) -> void:
	if n is Button and n.is_visible_in_tree() and not n.disabled:
		out.append(n)
	for c in n.get_children():
		_buttons(c, out)

func _process(_d: float) -> bool:
	if step == 0 and not started:
		started = true
		Engine.get_singleton("Engine")
		return false
	step += 1
	if step > max_steps:
		print("BOT: stopped after ", max_steps, " steps; endings=", endings, " phase=", main.phase, " idx=", main.get_node("/root/Game").S.get("idx"))
		return true
	var G = root.get_node("Game")
	if main.modal.visible:
		main.close_modal()
		return false
	if main.beat_btn != null:
		main._reveal_all()
		return false
	var heads: PackedStringArray = []
	_texts(main.page, heads)
	var head := " | ".join(heads.slice(0, 2))
	if head.begins_with("DUTY") or head.begins_with("THE ROAD WINS") or head.begins_with("THE WAR MOVES ON"):
		pass
	var live: Array = main.choices.filter(func(c): return not c[2] and is_instance_valid(c[0]) and c[0].is_visible_in_tree())
	var btns: Array = []
	_buttons(main.page, btns)
	# occasionally open the panels to exercise them
	if randi() % 25 == 0 and main.phase in ["scene", "road", "talk"]:
		var which = ["char", "tin", "bag", "log"][randi() % 4]
		main._on_top(which)
		var mb: Array = []
		_buttons(main.mpage, mb)
		if mb.size() > 1 and randi() % 2 == 0:
			mb[randi() % mb.size()].pressed.emit()
		main.close_modal()
		return false
	if main.phase == "title":
		if step > 5:
			endings += 1
			print("BOT: back at title after an ending; step ", step)
			return true
	var opts: Array = []
	for c in live:
		opts.append(c[1])
	for b in btns:
		if b.text == "Back" or b.text.begins_with("Practice") or b.text.begins_with("Quit") or b.text.begins_with("Load") or b.text.begins_with("Credits") or b.text.begins_with("Back to the scene") and live.size() > 1:
			continue
		opts.append(b)
	if opts.is_empty():
		print("BOT: stuck at ", head)
		return true
	var pick = opts[randi() % opts.size()]
	if rush and main.phase in ["scene", "road"] and live.size() and randi() % 2 == 0:
		pick = live[live.size() - 1][1]
	if rush and main.phase == "talk" and btns.size() and randi() % 3 == 0:
		for b in btns:
			if b.text == "Back to the scene":
				pick = b
	if step % 10 == 0 or main.phase == "other":
		print("BOT ", step, " [", main.phase, "] ", head.substr(0, 90), "  hrs=", G.S.get("hrs"), " hp=", G.S.get("hp"))
	if pick is Callable:
		pick.call()
	else:
		pick.pressed.emit()
	return false
