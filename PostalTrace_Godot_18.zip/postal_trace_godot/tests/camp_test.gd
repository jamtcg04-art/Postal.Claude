extends SceneTree
## Making camp on the road, a patrol finding it, and thieves (the same rules as the browser: campShow, thievesEvent).
##   godot --headless -s res://tests/camp_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t
func _find(nd: Node, name: String) -> Control:
	for ch in nd.get_children():
		var own: String = str(ch.text) if ch is Button else _texts(ch)
		if (ch is Button or ch is PanelContainer) and ch.is_visible_in_tree() and own.to_lower().find(name.to_lower()) >= 0 and (ch is Button or ch.gui_input.get_connections().size() > 0):
			return ch
		var r = _find(ch, name)
		if r: return r
	return null
func _press(name: String) -> bool:
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree() and _texts(c[0]).to_lower().find(name.to_lower()) >= 0:
			var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
			c[0].grab_focus(); c[0].gui_input.emit(e); return true
	var b = _find(main.page, name)
	if b == null: return false
	if b is Button: b.pressed.emit()
	else:
		var e2 = InputEventAction.new(); e2.action = "ui_accept"; e2.pressed = true
		b.grab_focus(); b.gui_input.emit(e2)
	return true
func _t() -> String: return _texts(main.page).to_lower()
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["ford", "mill", "oak"]; G.S.idx = 1; G.S.notice = 2
			main.road([]),
		func(): _check("the road offers Make camp", _press("Make camp")),
		func():
			var t = _t()
			_check("a fire camp, with the odds a patrol sees it (Notice 2: 16%)", t.find("light a fire") >= 0 and t.find("16%") >= 0, t.right(300).replace("\n", " | "))
			_check("or a cold camp (8%)", t.find("cold camp") >= 0 and t.find("8%") >= 0)
			_press("light a fire"),
		func():
			var c = G.S.get("camp")
			_check("the camp is recorded for the road view", c is Dictionary and str(c.kind) == "fire" and str(c.shelter) in ["leanto", "tent"], c)
			G.S.notice = 5
			main.road([]),
		func(): _press("Make camp"),
		func():
			var t = _t()
			_check("Notice 5: only the cold, hidden camp", t.find("a cold camp") >= 0 and t.find("light a fire") < 0)
			G.S.notice = 3
			root.get_node("Bridge").call_js("campFound", ["fire", func(_a = null): main.road([])]),
		func():
			var t = _t()
			_check("found in the night by a patrol", t.find("found in the night") >= 0, t.left(200).replace("\n", " | "))
			_press("Go for the pistol"),
		func():
			var t = _t()
			_check("then a fight with the patrol", t.find("round 1") >= 0 and t.find("provost") >= 0, t.left(160).replace("\n", " | "))
			root.get_node("Bridge").call_js("thievesEvent", [func(_a = null): main.road([])]),
		func():
			var t = _t()
			_check("thieves step out of the hedge", t.find("men from the hedge") >= 0 and t.find("cudgel") >= 0)
			_press("Fight them"),
		func():
			var t = _t()
			_check("they fight hand to hand", t.find("the man with the cudgel") >= 0 and t.find("round 1") >= 0, t.left(200).replace("\n", " | ")),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("CAMP: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	s.call(); wait = 4
	return false
