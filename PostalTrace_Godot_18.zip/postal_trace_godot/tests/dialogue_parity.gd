extends SceneTree
## Replays conversations recorded in the browser build (tools/dialogue/parity_record.js) in this game:
## the same starting state, dice and choices, through the dialogue runner on the game's own rules
## (Game, the browser logic in lib.json). Every screen must match: what was said, which inner voices
## spoke, the dice, and every choice with its state and its odds.
##   godot --headless -s res://tests/dialogue_parity.gd
var runs := 0
var screens := 0
var fails := 0
var report := []
var main

func _initialize() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	var data = JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/browser_talks.json"))
	var G = root.get_node("Game")
	for run in data.runs:
		runs += 1
		G.set_state(G._ints(run.S0))
		G.addr_last = {}
		G.dice_queue = G._ints(run.dice)
		var host = load("res://scripts/dialogue_host.gd").new(main)   # loaded here: it needs the autoloads
		var r := PTDialogueRunner.new(root.get_node("Data").dialogue, host)
		var t: Dictionary = run.talker
		var who := {"id": t.id, "name": t.name, "role": t.role, "mood": t.mood, "hue": t.hue}
		if t.obj: who.obj = true
		var v := r.start(String(run.scene), who)
		var ok := _same(run, 0, _snap(G, v), run.steps[0])
		var i := 0
		while ok and i < run.picks.size():
			v = r.choose(int(run.picks[i]))
			ok = _same(run, i + 1, _snap(G, v), run.steps[i + 1])
			i += 1
	print("DIALOGUE PARITY: %d of %d browser runs match (%d screens compared)" % [runs - fails, runs, screens])
	for x in report.slice(0, 20): print(x)
	quit(1 if fails else 0)

func _snap(G, v: Dictionary) -> Dictionary:
	if v.ended: return {"ended": true}
	var say := []
	var voices := []
	var roll = null
	for e in v.entries:
		match String(e.t):
			"say", "look": say.append_array(e.lines)
			"voice": if not e.get("queued", false): voices.append([e.v, G.voice_text(e.v, e.text)])
			"argue": for l in e.lines: voices.append([l.v, G.voice_text(l.v, l.text)])
			"roll": roll = {"dice": [e.a, e.b], "ok": e.ok}
	var choices := []
	for c in v.choices:
		var ck := ""
		if c.has("check"):
			var k: Dictionary = c.check
			ck = ("Red · " if k.kind == "red" else "") + String(k.voice) + " · " + String(k.difficulty) + " " + str(k.dc) + " · " + str(k.odds) + "%" + (" · retry" if k.retry else "")
		choices.append({"text": c.text, "enabled": c.enabled, "retry": c.get("retry", false), "replay": c.get("replay", false), "kind": c.kind, "ck": ck})
	return {"ended": false, "say": say, "voices": voices, "roll": roll, "choices": choices}

func _same(run: Dictionary, i: int, got: Dictionary, want: Dictionary) -> bool:
	screens += 1
	var why := _diff(want, got)
	if why == "": return true
	fails += 1
	report.append("%s (screen %d, picks %s): %s" % [run.conv, i, str(run.picks.slice(0, i)), why])
	return false

func _diff(w, g, at := "") -> String:
	if w is Dictionary and g is Dictionary:
		for k in w:
			if not g.has(k): return at + "." + k + " missing"
			var d := _diff(w[k], g[k], at + "." + k)
			if d != "": return d
		return ""
	if w is Array and g is Array:
		for i in min(w.size(), g.size()):
			var d := _diff(w[i], g[i], at + "[" + str(i) + "]")
			if d != "": return d
		if w.size() != g.size(): return at + ": browser %d, Godot %d: %s vs %s" % [w.size(), g.size(), str(w).left(240), str(g).left(240)]
		return ""
	if (w is int or w is float) and (g is int or g is float): return "" if float(w) == float(g) else at + ": %s vs %s" % [w, g]
	if typeof(w) != typeof(g) or w != g: return at + ": browser «%s», Godot «%s»" % [str(w).left(200), str(g).left(200)]
	return ""
