extends SceneTree
## Edits files dropped into an edits folder: the browser editor's own Save file (made with the live
## browser game, tests/fixtures/browser_place_edits.json: the well at the crossroads moved, turned and
## darkened, a lantern added) is taken when a place is built; edits made here later win over an older
## file; a newer file wins over them; an unchanged file is not taken twice.
##   godot --headless --path . -s res://tests/drop_edits_test.gd
var f := 0
var results: Array = []
var PE
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func build(file: String) -> Node3D:
	var baked = "res://places/%s.tscn" % file
	var p: Node3D = load(baked).instantiate() if ResourceLoader.exists(baked) else load("res://scripts/world/place_builder.gd").build(file)
	root.add_child(p)
	return p
func well(e) -> Dictionary:
	for q in e.props:
		if q.id == "well@4.60,-1.50#1":
			return q
	return {}
func drop(name: String, at: String, edits: Dictionary) -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path("user://edits"))
	var fl = FileAccess.open("user://edits/" + name, FileAccess.WRITE)
	fl.store_string(JSON.stringify({ "game": "The Postal Trace", "kind": "place edits", "at": at, "edits": edits }))
	fl.close()
func clean() -> void:
	for pth in ["user://place_edits.json", "user://place_edits_meta.json"]:
		if FileAccess.file_exists(pth): DirAccess.remove_absolute(ProjectSettings.globalize_path(pth))
	var da = DirAccess.open("user://edits")
	if da:
		for n in da.get_files(): da.remove(n)
	PE._user = null; PE._baked = null; PE._last_scan = -100000; PE.drop_log = []
func _process(_d: float) -> bool:
	f += 1
	if f < 3:
		return false
	PE = load("res://scripts/world/place_edits.gd")
	clean()
	var src: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tests/fixtures/browser_place_edits.json"))
	drop("postal-trace-place-edits.json", src.at, src.edits)
	var p = build("cross"); var e = PE.attach(p, "cross"); var w = well(e)
	var pos: Vector3 = w.node.position if w else Vector3.ZERO
	# (the node sits at the prop's spot less its model's centring, so compare the moved distance)
	check("the browser's Save file is taken from the edits folder", w and absf(float(w.cur.x) - 6.1) < 0.002 and absf(float(w.cur.z) + 1.5) < 0.002 and absf(pos.x - 6.1) < 0.05, str(pos))
	check("with its turn and colour", w and absf(float(w.cur.get("r", 0)) - 0.262) < 0.002 and w.cur.get("tint") is Array, str(w.cur.get("r")) + " " + str(w.cur.get("tint")))
	var lan = e.props.filter(func(q): return q.add >= 0 and str(q.cur.m) == "lantern")
	check("and the lantern it added, with its light", lan.size() == 1 and lan[0].lights.size() > 0, str(lan.size()))
	p.queue_free()
	var mine = PE.user_all()["cross"].duplicate(true)
	mine.mods["well@4.60,-1.50#1"]["x"] = 2.0
	PE.user_all()["cross"] = mine; PE.save_user()
	drop("older.json", "2026-01-01T00:00:00.000Z", src.edits)
	PE._last_scan = -100000
	p = build("cross"); e = PE.attach(p, "cross"); w = well(e)
	check("edits made here are kept over an older file", w and absf(w.node.position.x - 2.0) < 0.02, str(w.node.position if w else null))
	p.queue_free()
	var future = Time.get_datetime_string_from_unix_time(int(Time.get_unix_time_from_system()) + 3600) + ".000Z"
	var ed2 = src.edits.duplicate(true); ed2.cross.mods["well@4.60,-1.50#1"]["x"] = 7.5
	drop("newer.json", future, ed2)
	PE._last_scan = -100000
	p = build("cross"); e = PE.attach(p, "cross"); w = well(e)
	check("a newer file wins over edits made here", w and absf(w.node.position.x - 7.5) < 0.02, str(w.node.position if w else null))
	p.queue_free()
	var m2 = PE.user_all()["cross"].duplicate(true); m2.mods["well@4.60,-1.50#1"]["x"] = 3.3
	PE.user_all()["cross"] = m2; PE.save_user()
	PE._last_scan = -100000
	var took = PE.refresh_drops(true)
	p = build("cross"); e = PE.attach(p, "cross"); w = well(e)
	check("an unchanged file is not taken twice", took == 0 and w and absf(w.node.position.x - 3.3) < 0.02, "took %d at %s" % [took, str(w.node.position if w else null)])
	p.queue_free()
	var out: Dictionary = JSON.parse_string(PE.export_text())
	check("Save file holds the taken edits in the browser's format", out.kind == "place edits" and out.edits.has("cross") and out.edits.cross.adds.size() == 1)
	var fl = FileAccess.open("user://edits/notes.json", FileAccess.WRITE); fl.store_string("[1,2,3]"); fl.close()
	PE._last_scan = -100000; PE.refresh_drops(true)
	check("a file that is not edits is skipped", PE.drop_log.any(func(l): return str(l).begins_with("notes.json: not")))
	clean()
	for r in results: print(r)
	print("DROP EDITS: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
	quit()
	return true
