extends SceneTree
## Drives the place editor (Dev Mode) the way a person would: select and drag a prop, turn it,
## copy, delete and undo, add a model, move a blocker and add one, move the walkable edge, move and
## re-dress a person, lay a road. Checks the edits land in the browser's format.
##   godot --headless --path . -s res://tests/editor_test.gd      (add a display for a screenshot)
var main
var G
var ed
var f := 0
var results: Array = []
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func click(pos: Vector2, to = null) -> void:
	var d = InputEventMouseButton.new(); d.button_index = MOUSE_BUTTON_LEFT; d.pressed = true; d.position = pos
	ed.pointer(d, pos)
	if to != null:
		for i in 6:
			var m = InputEventMouseMotion.new(); m.position = pos.lerp(to, (i + 1) / 6.0)
			ed.pointer(m, m.position)
	var u = InputEventMouseButton.new(); u.button_index = MOUSE_BUTTON_LEFT; u.pressed = false; u.position = to if to != null else pos
	ed.pointer(u, u.position)
func scr(v: Vector3) -> Vector2:
	return main.world.cam.unproject_position(v)
func E() -> Dictionary:
	return ed.E().E()
func _initialize():
	main = load("res://scenes/main.tscn").instantiate(); root.add_child(main)
func _process(_d):
	f += 1
	if f == 3:
		G = root.get_node("Game")
		var PE = load("res://scripts/world/place_edits.gd")
		PE.user_all().erase("cross"); PE.save_user()
		main.Game_begin()
		G.S.route = ["cross", "market", "ford", "oak", "ridge", "malice"]; G.S.idx = 0; G.S.seen = 0
		main.set_dev(true)
		main.scene()
		ed = main.editor
		return false
	if f == 5:
		check("Dev Mode shows Edit place over the 3D view", ed.toggle.visible and main.world_view.visible)
		ed.start()
		ed.world.edit_cam = Vector3(-2, 0, -3)
		return false
	if f == 8:
		# props: select the toll box by clicking it, drag it a metre east
		var box = ed.E().props.filter(func(p): return p.cur.m == "pt_box")[0]
		var at = Vector3(box.cur.x, float(box.cur.get("y", 0)) + 0.5, box.cur.z)
		var ground = Vector3(box.cur.x, 0, box.cur.z)
		click(scr(at), scr(at + Vector3(1, 0, 0)))
		check("click selects a prop", ed.sel == box, str(ed.sel.cur.m if ed.sel else null))
		var d: Dictionary = E().mods.get(box.id, {})
		check("dragging it moves it, kept as the browser keeps it", d.has("x") and absf(float(d.x) - (float(box.it.x) + 1.0)) < 0.15, str(d))
		ed.act("rl")
		check("turning it", absf(float(E().mods[box.id].r) - (float(box.it.get("r", 0)) + PI / 12)) < 0.01)
		ed.act("clight")
		check("recolouring it", E().mods[box.id].get("tint") is Array)
		ed.act("dup")
		check("copying it adds one beside it", E().adds.size() == 1 and E().adds[0].m == "pt_box")
		ed.act("del")
		check("deleting the copy", E().adds.size() == 0)
		ed.act("undo")
		check("undo brings it back", E().adds.size() == 1)
		ed.add_prop("barrel")
		check("adding any model", E().adds.size() == 2 and E().adds[1].m == "barrel" and E().adds[1].solid == true)
		# blockers
		ed.set_mode("blk")
		ed.blk_act("addring")
		var S: Dictionary = E().solids
		check("adding a ring blocker", S.adds.size() == 1 and S.adds[0].r == 0.5)
		ed.blk_act("grow")
		check("growing it", absf(float(E().solids.adds[0].r) - 0.6) < 1e-6)
		ed.blk_act("b0+")
		check("moving the west edge of the walkable area", E().bounds is Array and absf(float(E().bounds[0]) - (-18.75)) < 1e-6, str(E().get("bounds")))
		# people
		ed.set_mode("ppl")
		var axe = ed.E().people.filter(func(q): return q.pk == "p:axeman")[0]
		var p0 = axe.node.global_position
		click(scr(p0 + Vector3(0, 1.0, 0)), scr(p0 + Vector3(0, 1.0, 1.0)))
		check("click and drag a person", ed.psel == axe and E().people.has("p:axeman") and absf(float(E().people["p:axeman"].z) - (p0.z + 1.0)) < 0.15, str(E().get("people")))
		ed.style_set({ "outfit": "greatcoat", "anim": "arms" })
		check("re-dressing them the browser's way", axe.node.get_meta("look").o.fit.kind == "greatcoat" and E().people["p:axeman"].anim == "arms")
		# ground
		ed.set_mode("gnd")
		ed.gnd_act("gaddr")
		check("laying a road", E().grounds.adds.size() == 1 and E().grounds.adds[0].tex == "mud")
		ed.gnd_act("gl")
		check("turning it", absf(float(E().grounds.adds[0].rot) - PI / 12) < 1e-3)
		ed.set_mode("props")
		ed.sel = ed.E().props.filter(func(p): return p.cur.m == "pt_box")[0]
		ed.refresh_panel()
		return false
	if f == 10:
		if DisplayServer.get_name() != "headless":
			root.get_viewport().get_texture().get_image().save_png("/tmp/editor.png")
		ed.stop()
		check("Done editing hands the view back", not main.world.editing)
		var PE = load("res://scripts/world/place_edits.gd")
		var back = JSON.parse_string(PE.export_text())
		check("Save file holds it all in the browser's format", back.edits.cross.mods.size() >= 1 and back.edits.cross.adds.size() == 2 and back.edits.cross.solids.adds.size() == 1)
		PE.user_all().erase("cross"); PE.save_user()
		for r in results: print(r)
		print("EDITOR: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
		return true
	return false
