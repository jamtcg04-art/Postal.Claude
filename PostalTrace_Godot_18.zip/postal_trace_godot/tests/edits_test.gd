extends SceneTree
## The place editor's layer of changes: every prop, blocker, person and patch of ground is known by
## the same key as in the browser (tests/edit_ids.json, made by tools/edit_ids.js), and a browser
## edits file applies: props moved, turned, recoloured, deleted and added, blockers changed, the
## walkable area, people moved and re-dressed, ground patches changed and laid.
##   godot --headless --path . -s res://tests/edits_test.gd
var f := 0
var results: Array = []
var PE
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func build(file: String) -> Node3D:
	var baked = "res://places/%s.tscn" % file
	var p: Node3D = load(baked).instantiate() if ResourceLoader.exists(baked) else load("res://scripts/world/place_builder.gd").build(file)
	root.add_child(p)
	return p
func _process(_d: float) -> bool:
	f += 1
	if f < 3:
		return false
	PE = load("res://scripts/world/place_edits.gd")
	var ref: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://tests/edit_ids.json"))
	var bad := []
	var total := 0
	for file in ref:
		var r: Dictionary = ref[file]
		var p = build(file)
		var e = PE.attach(p, file)
		total += 1
		var why := []
		if e.key != r.key: why.append("key " + e.key)
		var L: Dictionary = e.L
		var byname := {}
		for q in e.props: byname[q.node.name] = q.id
		for i in L.props.size():
			var nm = "%s_%d" % [L.props[i].m, i]
			if byname.has(nm) and byname[nm] != r.props[i]:
				why.append("prop %d %s != %s" % [i, byname[nm], r.props[i]]); break
		var sids = e.solids.map(func(s): return s.sid)
		for i in r.solids.size():
			if r.solids[i] != null and not sids.has(r.solids[i]):
				why.append("solid " + str(r.solids[i])); break
		var pks = e.people.map(func(q): return q.pk)
		for k in r.people + r.extras:
			if not pks.has(k): why.append("person " + str(k)); break
		var gks = e.grounds.map(func(q): return q.gk)
		for k in r.grounds:
			if not gks.has(k): why.append("ground " + str(k)); break
		if why.size(): bad.append(file + ": " + ", ".join(why))
		p.free()
	check("every place keys its things as the browser does", bad.is_empty(), "%d places; %s" % [total, "; ".join(bad.slice(0, 4))])
	# a browser edits file
	PE.import_text(JSON.stringify({ "game": "The Postal Trace", "kind": "place edits", "edits": { "cross": {
		"mods": { "house@-10.00,10.00#1": { "x": -9.0, "z": 10.0, "y": 0, "r": 0.5, "h": 6.0, "tint": [1.2, 1, 0.8] },
			"tavern@-10.00,-1.00#1": { "x": -10, "z": -1, "y": 0, "r": 0, "h": 7, "del": true } },
		"adds": [{ "m": "lantern", "x": 2.0, "z": 2.0, "y": 0, "r": 0, "h": 1.2, "solid": true }],
		"solids": { "mods": { "b@-13.40,6.80,-6.40,13.40#1": { "del": true } }, "adds": [{ "x": 0.0, "z": 6.0, "r": 0.7 }] },
		"bounds": [-15, -16, 19, 22],
		"people": { "p:axeman": { "x": -3.0, "z": -7.0, "y": 0, "face": 1.0, "anim": "arms", "outfit": "greatcoat" } },
		"grounds": { "mods": { "g1:mud": { "x0": -3, "z0": -91, "x1": 3, "z1": 91, "rot": 0.2, "tex": "gravel", "c": [1, 1, 1], "rep": 3.2, "y": 0.04 } },
			"adds": [{ "x0": 4, "z0": 4, "x1": 7, "z1": 7, "rot": 0, "tex": "mud", "c": [1, 1, 1], "rep": 3, "y": 0.05 }] } } } }))
	var w = load("res://scripts/world/world.gd").new()
	root.add_child(w)
	var G = root.get_node("Game")
	G.begin_run({ "trait": "steady" }); G.S.route = ["cross"]; G.S.idx = 0
	w.enter("cross")
	var props = w.place.get_node("Props")
	var house: Node3D = props.get_node("house_1")
	check("a prop moved and turned", w.fx.spot(house).distance_to(Vector3(-9, 0, 10)) < 0.05 and absf(house.transform.basis.get_euler().y - 0.5) < 0.01, str(w.fx.spot(house)))
	check("a prop deleted", not props.get_node("tavern_0").visible)
	var lan = props.get_node_or_null("Added_0")
	check("a prop added, with its own light and blocker", lan != null and w._blocked(2.0, 2.0, 0.05) and w.place.get_node("Lights").get_children().any(func(n): return n.position.distance_to(Vector3(2, n.position.y, 2)) < 0.01))
	check("a blocker deleted", w.edits.solids.filter(func(q): return q.sid == "b@-13.40,6.80,-6.40,13.40#1")[0].node.get_meta("off", false) and not w.solids.any(func(q): return q.has("x0") and is_equal_approx(q.x0, -13.4) and is_equal_approx(q.z0, 6.8)))
	check("an added ring blocks", w._blocked(0.0, 6.0, 0.05))
	check("the walkable area changed", is_equal_approx(w.bounds.position.x, -15.0))
	var axe: Node3D = w.place.get_node("People").get_children().filter(func(n): return n.get_meta("id", "") == "axeman")[0]
	check("a person moved and turned", axe.position.distance_to(Vector3(-3, 0, -7)) < 0.01 and is_equal_approx(axe.rotation.y, 1.0))
	var look: Dictionary = axe.get_meta("look")
	check("and stands and dresses as the browser works it out", look.want == "arms" and look.o.fit.kind == "greatcoat", str(look.o.get("fit", {}).get("kind")))
	check("a ground patch changed and one laid", w.place.get_node("Ground").get_node_or_null("AddedGround_0") != null)
	# what the browser's Save file writes
	var txt = PE.export_text()
	var back = JSON.parse_string(txt)
	check("Save file writes the browser's format", back.kind == "place edits" and back.edits.cross.adds.size() == 1)
	PE.user_all().erase("cross"); PE.save_user()
	for r in results: print(r)
	print("EDITS: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
	return true
