extends SceneTree
## Runs every zero-argument data function under the states recorded from the browser
## build (tests/equiv_node.json) and writes Godot's results for comparison.
const KEYS := ["show", "when", "say", "mood", "text", "learn", "need", "auto", "hint", "bonus", "dcAdj", "extra"]
var ran := false

func _process(_d: float) -> bool:
	if ran:
		return true
	ran = true
	var data: Node = root.get_node("Data")
	var game: Node = root.get_node("Game")
	var rec: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/equiv_node.json"))
	var out: Array = []
	for r in rec:
		game.set_state(game._ints(r["state"]))
		var res := {}
		for id in data.scenes:
			_walk(data, data.scenes[id], "scenes/" + id, res)
		for k in data.graphs:
			var parts: PackedStringArray = k.split(":")
			_walk(data, data.graphs[k], "graphs/" + parts[0] + "/" + parts[1], res)
		out.append(res)
	var f := FileAccess.open("res://tests/equiv_godot.json", FileAccess.WRITE)
	f.store_string(JSON.stringify(out, "", false))
	f.close()
	print("done")
	return true

func _walk(data: Node, v: Variant, p: String, res: Dictionary) -> void:
	if v is Dictionary:
		for k in v:
			var x: Variant = v[k]
			if x is JsLite.JsFn:
				if x.getter:
					if k in KEYS or k == "fx":
						res[p + "." + k] = _ser(data.js.get_prop(v, k))
				elif k in KEYS:
					data.js._ensure_parsed(x)
					if x.params.size() == 0:
						res[p + "." + k] = _ser(data.js.call_fn(x, []))
			else:
				_walk(data, x, p + "." + str(k), res)
	elif v is Array:
		for i in v.size():
			_walk(data, v[i], p + "." + str(i), res)

func _ser(v: Variant) -> Variant:
	if v is JsLite.JsFn or v is Callable:
		return "<fn>"
	if v is Dictionary:
		var d := {}
		for k in v:
			d[k] = _ser(v[k])
		return d
	if v is Array:
		var a := []
		for x in v:
			a.append(_ser(x))
		return a
	return v
