extends SceneTree
## The ferry house and the new movements (needs a display): godot -s res://tests/ferry_shots.gd -- <outdir>
var main
var G
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/ferry_" + name + ".png")
func at(x: float, z: float, zm: float) -> void:
	var W = main.world
	W.pl = Vector3(x, W.lift_at(x, z), z); W.cam_target = W.pl; W.zoom = zm
func door(id: String) -> void:
	for k in main.world.picks:
		if str(k.id) == id:
			main.world._through_now(k)
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "ford", "oak"]; G.S.idx = 1; G.S.seen = 2
			main.scene(),
		"w60", func(): at(-8.8, 8.3, 4.0),
		"w40", func(): shot("porch"); door("door_ferryhouse"),
		"w60", func(): at(0.6, -0.9, 4.6),
		"w60", func(): shot("room"); at(-1.6, -1.2, 2.4),
		"w60", func(): shot("map"); at(1.2, 0.2, 2.4),
		"w60", func(): shot("tables"); G.S.route = ["malice"]; G.S.idx = 0; main.scene(),
		"w40", func(): door("door_hq"),
		"w60", func(): at(1.2, -0.6, 2.6),
		"w90", func(): shot("corvane"),
	]
func _process(_d):
	if wait > 0:
		wait -= 1
		return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
