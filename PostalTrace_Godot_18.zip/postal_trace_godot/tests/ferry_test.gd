extends SceneTree
## The ferry house at Greywater Ford (browser V184) and the new movements (V185):
## the stair and porch lift the courier, the door opens on the bridge gang's room, who is in it and what they do,
## the things to look at, the courier crouching or reaching to look, NODE_ACTS, and two people talking in turn.
##   godot --headless -s res://tests/ferry_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
var W
var t_until := 0
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _pick(id: String) -> Variant:
	for k in W.picks:
		if str(k.id) == id:
			return k
	return null
func _extras_playing() -> Array:
	var out := []
	var h = W.place.get_node_or_null("Bystanders")
	if h:
		for m in h.get_children():
			for c in m.get_children():
				if c is Figure: out.append(c.current)
	return out

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "ford", "oak"]; G.S.idx = 1; G.S.seen = 2
			main.scene(),
		"wait20",
		func():
			W = main.world
			_check("at the ford, with its raised floors", W.file == "ford" and W.lifts.size() == 4, [W.file, W.lifts.size()])
			_check("the porch is 1.72 up, the foot of the stair near the ground, the yard flat", absf(W.lift_at(-8.8, 8.0) - 1.72) < 0.01 and W.lift_at(-8.8, 10.6) < 0.2 and W.lift_at(-5.0, 10.0) == 0.0)
			_check("the bridge deck still rises in the middle", absf(W.lift_at(6.0, -3.3) - 0.7) < 0.01)
			W.pl = Vector3(-8.8, 0, 11.3)
			W.walk_to(-8.8, 8.2),
		"wait150",
		func():
			_check("up the stair to the porch", W.pl.z < 8.5 and W.pl.y > 1.7, W.pl)
			for i in 40: W._move_to(W.pl.x + 0.05, 8.0)
			_check("the porch rail holds", W.pl.x < -7.85 and W.pl.y > 1.7, W.pl)
			W.pl = Vector3(-6.0, 0, 8.0)
			for i in 40: W._move_to(W.pl.x - 0.05, 8.0)
			_check("no climbing the plinth from the yard", W.pl.x > -7.9 and W.pl.y == 0.0, W.pl)
			var d = _pick("door_ferryhouse")
			_check("the ferry house door is there", d != null)
			W.pl = Vector3(-8.85, 1.72, 7.9)
			if d: W.approach(d),
		"wait60",
		func():
			_check("in through the door", W.file == "ford__ferryhouse", W.file)
			var ids := []
			for t in G.talkers(): ids.append(str(t.id))
			_check("the bridgemaster is here to talk to", ids.has("bmaster"), ids)
			_check("the map, the last peg and the toll shelf can be looked at", _pick("map") != null and _pick("peg") != null and _pick("tolls") != null)
			_check("twenty-two new movements are loaded", Figure.more_animations().size() >= 22, Figure.more_animations().size())
			_check("he leans over his map", W.figures.has("bmaster") and W.figures["bmaster"].current == "leanmap", W.figures.get("bmaster").current if W.figures.has("bmaster") else "")
			var cur = _extras_playing()
			_check("the gang at the tables: cards, a drink, a laugh, talk; a man on the door", cur.has("sitcards") and cur.has("sitdrink") and cur.has("sitlaugh") and cur.has("sittalk") and cur.has("guard"), cur)
			W.approach(_pick("peg")),
		"wait60",
		func():
			_check("looking at the coat on the high peg, the courier reaches", W.player.current == "reachhigh", W.player.current)
			main.scene(),
		"wait10",
		func():
			main._node_act("chapel:x_rope:rung", "x_rope")
			_check("ringing the bell: the courier hauls on the rope", W.player.current == "ringbell", W.player.current),
		"wait10",
		func():
			var d = _pick("door_out")
			W.approach(d),
		"until_ford",
		func():
			_check("out again onto the porch", W.file == "ford" and W.pl.y > 1.7, [W.file, W.pl])
			G.S.route = ["cross", "market", "ford"]; G.S.idx = 1
			main.scene(),
		"wait30",
		func():
			var pairs := 0
			var h = W.place.get_node_or_null("Bystanders")
			for m in h.get_children():
				if m.has_meta("pair"): pairs += 1
			var cur = _extras_playing()
			_check("at the market, people stand in pairs and talk in turn", pairs >= 2 and (cur.has("listen")) and (cur.has("talk") or cur.has("talkgest")), [pairs, cur]),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("FERRY: %d/%d" % [ok, n]); quit(); return true
	if steps[0] is String and steps[0] == "until_ford":
		if W.file == "ford" or Time.get_ticks_msec() - t_until > 8000:
			steps.pop_front()
		return false
	t_until = Time.get_ticks_msec()
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
