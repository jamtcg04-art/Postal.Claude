extends SceneTree
## A fight on the road and a mounted hunting party, in 3D (needs a display): godot -s res://tests/fight_shots.gd -- <outdir>
var main
var G
var f := 0
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/fight_" + name + ".png")
func _press(name: String) -> void:
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree() and str(c[0].get_meta("t", "")) == "" :
			pass
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree():
			var t := ""
			for ch in c[0].find_children("*", "Label", true, false): t += ch.text
			for ch in c[0].find_children("*", "RichTextLabel", true, false): t += ch.get_parsed_text()
			if t.to_lower().find(name.to_lower()) >= 0:
				var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
				c[0].grab_focus(); c[0].gui_input.emit(e); return
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["ford", "mill", "oak"]; G.S.idx = 1
			main.road([]),
		"w30", func(): root.get_node("Bridge").call_js("thievesEvent", [func(_a = null): main.road([])]),
		"w20", func(): _press("Fight them"),
		"w80", func(): shot("thieves"); _press("Fire your pistol"),
		"w60", func(): shot("thieves_round"),
		func(): main.road_on = false; G.S.route = ["cross"]; G.S.idx = 0; main.scene(),
		"w60", func(): root.get_node("Bridge").call_js("nHuntFight", [func(_a = null): main.scene()]),
		"w90", func(): shot("riders"),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
