extends SceneTree
## The road between stops in 3D (road_view.gd): walking, stopping for what the road brings, camp, the voices on the road.
##   godot --headless -s res://tests/road_test.gd   (forces the 3D view on)
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t
func _press(name: String) -> bool:
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree() and _texts(c[0]).to_lower().find(name.to_lower()) >= 0:
			var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
			c[0].grab_focus(); c[0].gui_input.emit(e); return true
	var b = _find(main.page, name)
	if b == null: return false
	if b is Button: b.pressed.emit()
	else:
		var e2 = InputEventAction.new(); e2.action = "ui_accept"; e2.pressed = true
		b.grab_focus(); b.gui_input.emit(e2)
	return true
func _find(nd: Node, name: String) -> Control:
	for ch in nd.get_children():
		var own: String = str(ch.text) if ch is Button else _texts(ch)
		if (ch is Button or ch is PanelContainer) and ch.is_visible_in_tree() and own.to_lower().find(name.to_lower()) >= 0 and (ch is Button or ch.gui_input.get_connections().size() > 0):
			return ch
		var r = _find(ch, name)
		if r: return r
	return null
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			G.S.route = ["ford", "mill", "oak"]; G.S.idx = 1
			main.road([]),
		func(): root.get_node("Bridge").call_js("thievesEvent", [func(_a = null): main.road([])]),
		func(): _press("Fight them"),
		func():
			var st = main.world.stage
			_check("thieves fight in 3D: two or three men round the courier", st.cast.size() >= 2, st.cast.keys())
			var armed := true
			for id in st.cast:
				var w: String = str(st.cast[id].f.look.get("wpn", ""))
				if w in ["pistol", "musket"]: armed = false
			_check("cudgels and knives, no guns", armed)
			_press("Fire your pistol"),
		func():
			var st = main.world.stage
			var moved := false
			for id in st.cast:
				if st.cast[id].goal != null or st.cast[id].down or st.cast[id].flee != null: moved = true
			_check("after a round they close in, reel, fall or run", moved or st.flashes.size() > 0),
		func():
			main.road_on = false
			G.S.route = ["cross"]; G.S.idx = 0
			main.scene(),
		func(): root.get_node("Bridge").call_js("nHuntFight", [func(_a = null): main.scene()]),
		func():
			var st = main.world.stage
			var riders := 0
			for id in st.cast:
				if st.cast[id].mounted: riders += 1
			_check("a hunting party in a place: riders up on horses", riders >= 2, [st.cast.size(), riders]),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("FIGHT: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	s.call(); wait = 4
	return false
