extends SceneTree
## The bridge keepers have their coats off (V186): a flat dark shirt, belts left on; Ostrey's levies keep the blue.
##   godot --headless -s res://tests/gang_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var W
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _flat(fg) -> bool:
	return fg is Figure and fg.look.get("flat") is Dictionary and fg.look.flat.has("Soldat torso") and not (fg.look.get("drop", []) as Array).has("Crosbelt")
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	var G
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "ford", "oak"]; G.S.idx = 1; G.S.seen = 2
			main.scene(),
		"wait20",
		func():
			W = main.world
			var gang := 0
			var blue := 0
			var h = W.place.get_node_or_null("Bystanders")
			for m in h.get_children():
				for c in m.get_children():
					if c is Figure:
						if _flat(c): gang += 1
						elif str(c.look.get("tex", "")) == "blue": blue += 1
			_check("at the ford: the bridge gang (3 at the span) in shirts, Ostrey's blue coats still blue", gang >= 3 and blue >= 3, [gang, blue])
			var br = W.figures.get("bridge")
			_check("the bridge sentry has his coat off", br != null and _flat(br))
			var d = W.picks.filter(func(k): return str(k.id) == "door_ferryhouse")[0]
			W.pl = Vector3(-8.85, 1.72, 7.9)
			W.approach(d),
		"wait60",
		func():
			var gang := 0
			var h = W.place.get_node_or_null("Bystanders")
			for m in h.get_children():
				for c in m.get_children():
					if c is Figure and _flat(c): gang += 1
			_check("in the ferry house: the seven in shirts, belts on", gang >= 7, gang)
			_check("the bridgemaster too", W.figures.has("bmaster") and _flat(W.figures["bmaster"])),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("GANG: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
