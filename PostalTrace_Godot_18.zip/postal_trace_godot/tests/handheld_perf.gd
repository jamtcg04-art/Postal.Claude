extends SceneTree
## How long the slow steps take on this machine (scene draw, place load, opening a conversation, a road leg,
## the world's per-frame work). A Cortex-A53 at 1.5 GHz is roughly 8–10× slower than a desktop core.
##   godot --headless -s res://tests/handheld_perf.gd
var main
var f := 0
func _ms(c: Callable) -> float:
	var t = Time.get_ticks_usec()
	c.call()
	return (Time.get_ticks_usec() - t) / 1000.0

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)

func _process(_d):
	f += 1
	if f != 3:
		return false
	var G = root.get_node("Game")
	var rows: Array = []
	rows.append(["start a run", _ms(func(): main.Game_begin())])
	for stop in ["cross", "market", "ford", "malice"]:
		G.S.route = [stop, "ford"]; G.S.idx = 0; G.S.seen = 0
		main.world.leave(); main.world.place = null if false else main.world.place
		rows.append(["arrive at %s (text + 3D place)" % stop, _ms(func(): main.scene())])
		rows.append(["  draw %s again" % stop, _ms(func(): main.scene())])
		var ts: Array = G.talkers()
		if ts.size():
			rows.append(["  open a conversation (%s)" % ts[0].id, _ms(func(): main.talk(0))])
		main.scene()
		var w = main.world
		var t = Time.get_ticks_usec()
		for i in 60:
			w._process(1.0 / 30.0)
		rows.append(["  world step (per frame, no drawing)", (Time.get_ticks_usec() - t) / 1000.0 / 60.0])
	G.S.route = ["cross", "market", "ford"]; G.S.idx = 0
	rows.append(["a road leg", _ms(func(): main.advance())])
	for r in rows:
		print("PERF %-45s %8.2f ms" % [r[0], r[1]])
	quit()
	return true
