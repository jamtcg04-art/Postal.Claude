extends SceneTree
## Pictures of the handheld layout, driven only by game pad buttons (needs a display):
##   PT_HANDHELD=1 xvfb-run godot --resolution 640x480 -s res://tests/handheld_shots.gd -- <outdir>
var main
var f := 0
var out := "/tmp"
var steps: Array = []
var wait := 0

func _initialize():
	var a = OS.get_cmdline_user_args()
	if a.size(): out = a[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		["shot", "title"],
		["call", func():
			main.Game_begin()
			var G = root.get_node("Game")
			G.S.route = ["cross", "market", "ford"]; G.S.idx = 0; G.S.seen = 0
			main.scene()],
		["wait", 30], ["shot", "scene"],
		["btn", JOY_BUTTON_DPAD_DOWN], ["btn", JOY_BUTTON_DPAD_DOWN], ["wait", 6], ["shot", "scene_focus"],
		["btn", JOY_BUTTON_X], ["wait", 20], ["shot", "walk"],
		["hold", JOY_BUTTON_DPAD_UP, 40], ["wait", 4], ["person"], ["wait", 6], ["shot", "walk_target"],
		["btn", JOY_BUTTON_A], ["wait", 150], ["shot", "talk"],
		["btn", JOY_BUTTON_DPAD_DOWN], ["wait", 4], ["shot", "talk_focus"],
		["btn", JOY_BUTTON_BACK], ["wait", 10], ["shot", "page_char"],
		["btn", JOY_BUTTON_BACK], ["wait", 10], ["shot", "page_thoughts"],
		["btn", JOY_BUTTON_B], ["btn", JOY_BUTTON_START], ["wait", 10], ["shot", "menu"],
		["btn", JOY_BUTTON_START], ["call", func(): main.practice_menu()], ["wait", 10], ["shot", "practice"],
		["btn", JOY_BUTTON_A], ["wait", 20], ["shot", "fight"],
		["call", func(): quit()],
	]

func _pad(btn: int, down: bool) -> void:
	var e = InputEventJoypadButton.new()
	e.button_index = btn
	e.pressed = down
	Input.parse_input_event(e)

func _process(_d):
	f += 1
	if f < 4:
		return false
	if wait > 0:
		wait -= 1
		return false
	if steps.is_empty():
		return true
	var st: Array = steps.pop_front()
	match st[0]:
		"shot":
			root.get_viewport().get_texture().get_image().save_png("%s/hh_%s.png" % [out, st[1]])
			print("shot ", st[1], "  pad mode ", main.pad.mode, "  focus ", root.get_viewport().gui_get_focus_owner())
		"call": st[1].call()
		"wait": wait = st[1]
		"btn":
			_pad(st[1], true); _pad(st[1], false); wait = 2
		"hold":
			_pad(st[1], true)
			var b = st[1]
			steps.push_front(["call", func(): _pad(b, false)])
			wait = st[2]
		"person":
			# R2 until a person is marked
			var w = main.world
			for i in 12:
				if w.pad_target != null and w.pad_target.kind == "person":
					break
				for v in [1.0, 0.0]:
					var e = InputEventJoypadMotion.new()
					e.axis = JOY_AXIS_TRIGGER_RIGHT; e.axis_value = v
					Input.parse_input_event(e)
				Input.flush_buffered_events()
			print("marked ", w.pad_target.name if w.pad_target else null)
		"axis":
			for v in [1.0, 0.0]:
				var e = InputEventJoypadMotion.new()
				e.axis = st[1]; e.axis_value = v
				Input.parse_input_event(e)
			wait = 2
	return false
