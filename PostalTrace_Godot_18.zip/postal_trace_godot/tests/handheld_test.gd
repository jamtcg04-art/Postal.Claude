extends SceneTree
## The handheld layout and the game pad, checked headless:
##   PT_HANDHELD=1 godot --headless -s res://tests/handheld_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var p0 := Vector3.ZERO

func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond:
		ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))

func _pad(b: int) -> void:
	for d in [true, false]:
		var e = InputEventJoypadButton.new()
		e.button_index = b; e.pressed = d
		Input.parse_input_event(e)

func _trig() -> void:
	for v in [1.0, 0.0]:
		var m = InputEventJoypadMotion.new()
		m.axis = JOY_AXIS_TRIGGER_RIGHT; m.axis_value = v
		Input.parse_input_event(m)

func _initialize():
	for i in 7:
		DirAccess.remove_absolute("user://save_%d.json" % i)
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	var G
	steps = [
		func():
			G = root.get_node("Game")
			var G2 = G
			_check("handheld layout is on", main.hh)
			_check("it draws 480 lines high", root.content_scale_size.y == 480, root.content_scale_size)
			_check("the 3D view renders at half size", main.world_shrink == 2)
			_check("Light detail by default (30 frames a second)", main.detail == "light" and Engine.max_fps == 30)
			_check("no top-bar buttons on a handheld", not main.top_buttons["menu"].visible)
			main.Game_begin()
			G2.S.route = ["cross", "market", "ford"]; G2.S.idx = 0; G2.S.seen = 0
			main.scene(),
		func():
			_pad(JOY_BUTTON_DPAD_DOWN),
		func():
			var fo = root.get_viewport().gui_get_focus_owner()
			_check("the d-pad puts focus on an option in the panel", fo != null and main.page.is_ancestor_of(fo))
			_pad(JOY_BUTTON_X),
		func():
			_check("X walks in the place", main.pad.mode == "walk" and main.world.pad_on)
			_check("the text panel steps aside when walking", not main.scroll.visible)
			p0 = main.world.pl
			Input.parse_input_event(_held(JOY_BUTTON_DPAD_UP, true)),
		"wait20",
		func():
			Input.parse_input_event(_held(JOY_BUTTON_DPAD_UP, false))
			_check("the d-pad walks the courier", main.world.pl.distance_to(p0) > 0.3, main.world.pl.distance_to(p0))
			_trig(),
		func():
			_check("R2 marks something to talk to or look at", main.world.pad_target != null, main.world.pad_target.name if main.world.pad_target else "")
			_check("the pad hints show what A does", main.pad_bar.visible and main.pad_bar.text.begins_with("A "), main.pad_bar.text)
			_pad(JOY_BUTTON_B),
		func():
			_check("tapping B goes back to the text", main.pad.mode == "panel" and main.scroll.visible)
			_pad(JOY_BUTTON_BACK),
		func():
			_check("Select opens the character sheet", main.modal.visible and main.modal_tag == "char")
			_pad(JOY_BUTTON_BACK),
		func():
			_check("Select again: Tin Thoughts", main.modal_tag == "tin")
			_pad(JOY_BUTTON_BACK),
		func():
			_pad(JOY_BUTTON_BACK),
		func():
			_check("then Satchel and Journal", main.modal_tag == "log")
			_pad(JOY_BUTTON_BACK),
		func():
			_check("and Select once more closes it", not main.modal.visible)
			_pad(JOY_BUTTON_START),
		func():
			_check("Start opens the menu", main.modal.visible)
			_pad(JOY_BUTTON_B),
		func():
			_check("B closes the menu", not main.modal.visible)
			main.pad.set_swap(true)
			_pad(JOY_BUTTON_START),
		func():
			_pad(JOY_BUTTON_A),
		func():
			_check("swapped: A goes back", not main.modal.visible)
			main.pad.set_swap(false)
			var c = ConfigFile.new(); c.load("user://settings.cfg"); _check("the swap is kept in settings", c.has_section_key("pad", "swap"))
			# the market's walk-out after the Quarter Cut is gone has no roll (a closure's auto() inside an object)
			var D = root.get_node("Data")
			var GG = root.get_node("Game")
			GG.S.done["qc_done"] = true
			var ex = D.call_fn(GG.def("market").extra)
			_check("the market's walk-out is a no-roll choice", ex is Array and ex.size() == 1 and D.truthy(D.call_fn(ex[0].auto))),
	]

func _held(b: int, d: bool) -> InputEventJoypadButton:
	var e = InputEventJoypadButton.new()
	e.button_index = b; e.pressed = d
	return e

func _process(_d):
	f += 1
	Engine.max_fps = 0 if f > 3 else Engine.max_fps
	if f < 3:
		return false
	if wait > 0:
		wait -= 1
		return false
	if steps.is_empty():
		print("HANDHELD: %d/%d" % [ok, n])
		quit()
		return true
	var s = steps.pop_front()
	if s is String:
		wait = int(s.substr(4))
	else:
		s.call()
		wait = 3
	return false
