extends SceneTree
## Pictures of the rigged horse in each movement, side on (needs a display):
##   godot -s res://tests/horse_shots.gd -- <outdir> [rig]
var w
var out := ""
var f := 0
var horses: Array = []
const POSES := [["idle", 0.0], ["walk", 0.0], ["walk", 0.28], ["walk", 0.55], ["trot", 0.0], ["trot", 0.18], ["gallop", 0.0], ["gallop", 0.13], ["gallop", 0.26], ["rear", 0.8], ["shy", 0.6], ["idle", 4.4]]
func _initialize() -> void:
	out = OS.get_cmdline_user_args()[0]
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		var G = root.get_node("Game")
		G.begin_run({ "trait": "steady" })
		G.S.route = ["ford"]; G.S.idx = 0
		var c := SubViewportContainer.new()
		c.stretch = true
		c.size = Vector2(1600, 900)
		root.add_child(c)
		var vp := SubViewport.new()
		c.add_child(vp)
		w = load("res://scripts/world/world.gd").new()
		vp.add_child(w)
	if f == 4:
		w.enter("ford")
		var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
		for i in POSES.size():
			var h: Node3D = PlaceBuilder._prop({ "m": "cp_horse_rig", "x": (i % 6) * 2.6 - 6.5, "z": 0.0 if i < 6 else 40.0, "h": 1.9, "r": PI / 2 }, sizes)
			w.place.add_child(h)
			horses.append(h)
		w.pl = Vector3(0, 0, -30); w.cam_target = Vector3(0.0, 1.0, 0.0); w.zoom = 4.6; w.yaw = 0.0; w.pitch = 0.12
		w.player.visible = false
		w.editing = true; w.edit_cam = Vector3(0.0, 1.0, 0.0)
	if f == 8:
		for i in POSES.size():
			var ap: AnimationPlayer = horses[i].find_child("AnimationPlayer", true, false)
			if ap == null:
				print("no AnimationPlayer"); return true
			ap.play(POSES[i][0]); ap.seek(POSES[i][1], true); ap.pause()
	if f == 20:
		root.get_viewport().get_texture().get_image().save_png(out + "/horse_poses_a.png")
		w.edit_cam = Vector3(0.0, 1.0, 40.0)
	if f == 34:
		root.get_viewport().get_texture().get_image().save_png(out + "/horse_poses_b.png")
		return true
	return false
