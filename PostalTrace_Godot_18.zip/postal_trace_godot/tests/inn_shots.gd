extends SceneTree
## The Keeper's Inn (needs a display): godot -s res://tests/inn_shots.gd -- <outdir>
var main
var G
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/inn_" + name + ".png")
func at(x: float, z: float, zm: float) -> void:
	var W = main.world
	W.pl = Vector3(x, W.lift_at(x, z), z); W.cam_target = W.pl; W.zoom = zm
func door(id: String) -> void:
	for k in main.world.picks:
		if str(k.id) == id:
			main.world._through_now(k)
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "ford"]; G.S.idx = 0; G.S.seen = 1
			main.scene(),
		"w60", func(): at(-4.6, -0.6, 5.5),
		"w40", func(): shot("out"); door("door_taproom"),
		"w60", func(): at(0.0, 0.2, 6.2),
		"w60", func(): shot("ground"); at(4.3, -1.6, 3.0),
		"w60", func(): shot("stair"); main._inn_node("cross", "keeper", "stair"),
		"w400", func(): shot("startle"); door("door_inn1"),
		"w60", func(): at(0.0, 0.0, 6.2),
		"w60", func(): shot("first"); door("door_inn2"),
		"w60", func(): at(3.0, 0.0, 4.6),
		"w60", func(): shot("top"),
	]
func _process(_d):
	if wait > 0:
		wait -= 1
		return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
