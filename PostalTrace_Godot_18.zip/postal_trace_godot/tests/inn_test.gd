extends SceneTree
## The Keeper's Inn at Cross-Pillars (browser V187): three floors you walk between by the stairs, rooms locked and open,
## Netta at the stair window, the children by the fire; the camera on the stair when the Splinter hears someone; pushing past
## the keeper, up the stair, the child starting and the cup going over (from the hall and from the porch); the cup righted.
##   godot --headless -s res://tests/inn_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
var W
var t_until := 0
var until_file := ""
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _pick(id: String) -> Variant:
	for k in W.picks:
		if str(k.id) == id:
			return k
	return null
func _extras_playing() -> Array:
	var out := []
	var h = W.place.get_node_or_null("Bystanders")
	if h:
		for m in h.get_children():
			for c in m.get_children():
				if c is Figure: out.append(c.current)
	return out
func _go(id: String, file: String) -> void:
	var d = _pick(id)
	if d:
		W.approach(d)
	until_file = file

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "ford"]; G.S.idx = 0; G.S.seen = 1
			main.scene(),
		"wait20",
		func():
			W = main.world
			var d = _pick("door_taproom")
			_check("outside: the inn's door is where the house's door is", W.file == "cross" and d != null and absf(d.node.global_position.x + 7.1) < 0.05 and absf(d.node.global_position.z + 1.0) < 0.05, [W.file, d.node.global_position if d else null])
			_check("the keeper beside it on the porch", W.figures.has("keeper") and absf(W.figures["keeper"].global_position.x + 6.7) < 0.05)
			W.pl = Vector3(-5.6, 0, -1.0)
			_go("door_taproom", "cross__taproom"),
		"until",
		func():
			_check("in through the door to the hall", W.file == "cross__taproom", W.file)
			_check("the stair's floors: four lifts", W.lifts.size() == 4, W.lifts.size())
			_check("the short flight rises to the turn, the long one to the floor above", W.lift_at(5.25, -0.6) > 0.1 and W.lift_at(5.25, -0.6) < 0.7 and absf(W.lift_at(4.4, -2.2) - 0.7) < 0.01 and absf(W.lift_at(1.7, -2.25) - 2.1) < 0.01)
			var ids := []
			for tk in G.talkers(): ids.append(str(tk.id))
			_check("the keeper in the hall and the girl on the stair to talk to", ids.has("keeper") and ids.has("netta"), ids)
			var ne: Figure = W.figures.get("netta")
			_check("Netta sits on the turn, small, watching the road", ne != null and absf(ne.global_position.y - 0.7) < 0.05 and ne.current == "sitstep" and ne.scale.x < 0.65, [ne.global_position if ne else null, ne.current if ne else "", ne.scale if ne else null])
			var cur = _extras_playing()
			_check("five children sat by the fire", cur.count("sitfloor") == 5, cur)
			_check("the bow and the back door to look at", _pick("bow") != null and _pick("backdoor") != null)
			W.pl = Vector3(5.25, 0, 0.9)
			W.walk_to(4.45, -2.15),
		"wait150",
		func():
			_check("up the short flight to the turn", W.pl.y > 0.65 and W.pl.z < -1.5, W.pl)
			W.pl = Vector3(1.25, 2.1, -2.2)
			_go("door_inn1", "cross__inn1"),
		"until",
		func():
			_check("up the long flight to the first floor", W.file == "cross__inn1", W.file)
			var obs := []
			for o in G.objects(): obs.append(str(o.id))
			_check("two rooms with coin, three locked doors", obs.has("coin1") and obs.has("coin2") and obs.has("sick") and obs.has("linen") and obs.has("lodger") and not obs.has("bow"), obs)
			_check("the next flight climbs to 2.0", absf(W.lift_at(5.25, 2.3) - 2.0) < 0.01)
			W.pl = Vector3(5.25, 2.0, 2.3)
			_go("door_inn2", "cross__inn2"),
		"until",
		func():
			_check("up to the top floor", W.file == "cross__inn2", W.file)
			var obs := []
			for o in G.objects(): obs.append(str(o.id))
			_check("the keeper's own door, locked; the loose board in the garret", obs.has("keeproom") and obs.has("board"), obs)
			W.enter("cross__taproom", [3.3, 1.0], 0.0),
		"wait10",
		func():
			var z0: float = W.zoom
			main._inn_node("cross", "keeper", "v_stair")
			_check("the Splinter hears someone: the camera goes to the turn of the stair", W.look_here is Vector3 and (W.look_here as Vector3).distance_to(Vector3(3.95, 1.0, -2.3)) < 0.01, W.look_here),
		"wait100",
		func():
			_check("and comes in close", W.zoom < 5.0, W.zoom)
			main._inn_node("cross", "keeper", "stair"),
		"wait30",
		func():
			_check("the courier shoulders past the keeper", W.player.current == "pushpast" or W.pl.z < 0.5, [W.player.current, W.pl]),
		"wait500",
		func():
			var ne: Figure = W.figures.get("netta")
			_check("up the stair two at a time to the turn", W.pl.y > 0.65 and W.pl.distance_to(Vector3(4.45, 0.7, -2.15)) < 0.4, W.pl)
			_check("the child starts and curls up; the cup goes over", G.S.done.get("inn_cup_over", false) and ne.base_want == "sitclutch", [ne.current, ne.base_want])
			var kp: Vector3 = W.figures["keeper"].global_position
			_check("the keeper shoved back a step", Vector2(kp.x, kp.z).distance_to(Vector2(4.15, 1.8)) < 0.1, kp)
			var vis := {}
			for c in W.scenes._inn_cups: vis[str(c.get_meta("model"))] = c.visible
			_check("the cup on the tread is over, with its water", vis.get("inn_cupover", false) and not vis.get("inn_cup", true), vis)
			main._inn_node("cross", "keeper", "hub"),
		"wait600",
		func():
			_check("down on one knee, the cup righted, back down the stair", G.S.done.get("inn_cup_righted", false) and W.pl.z > 0.3 and W.pl.y < 0.05, W.pl)
			for k in ["inn_cup_over", "inn_cup_righted", "netta_scared"]: G.S.done.erase(k)
			W.enter("cross", [-5.6, -0.1], 0.0),
		"wait10",
		func():
			main._inn_node("cross", "keeper", "stair")
			until_file = "cross__taproom",
		"until",
		"wait600",
		func():
			_check("from the porch: through the door and up the stair to her", W.file == "cross__taproom" and G.S.done.get("inn_cup_over", false) and W.pl.y > 0.65, [W.file, W.pl]),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("INN: %d/%d" % [ok, n]); quit(); return true
	if steps[0] is String and steps[0] == "until":
		if W.file == until_file or Time.get_ticks_msec() - t_until > 9000:
			steps.pop_front()
		return false
	t_until = Time.get_ticks_msec()
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
