extends SceneTree
## One on one with the voices (dialogue/inner.pt, data/inner.json): from the satchel, from the ring after something
## happens, and on the way out of a place (the walk to the edge, the fade, the road). Voice sounds play as lines are
## revealed, one at a time; a moment's sounds queue and only the most important plays.
##   PT_CUT=1 godot --headless -s res://tests/inner_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
var Snd
var t0 := 0

func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t
func _press(c: Control) -> void:
	if c is Button:
		c.pressed.emit(); return
	c.grab_focus()
	var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
	c.gui_input.emit(e)
func _find(nd: Node, name: String) -> Control:
	for ch in nd.get_children():
		var own: String = str(ch.text) if ch is Button else _texts(ch)
		if (ch is Button or ch is PanelContainer) and ch.is_visible_in_tree() and own.find(name) >= 0 and (ch is Button or ch.gui_input.get_connections().size() > 0):
			return ch
		var r = _find(ch, name)
		if r: return r
	return null
func _choice(name: String) -> Control:
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree() and _texts(c[0]).find(name) >= 0:
			return c[0]
	return _find(main.page, name)
func _reveal() -> void:
	for i in 12:
		if main.beat_btn and is_instance_valid(main.beat_btn): main._next_beat()

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game"); Snd = root.get_node("Sound")
			main.Game_begin()
			G.S.route = ["redoubt", "wirehut", "cross"]; G.S.idx = 0; G.S.seen = 1
			if not G.S.inv.has("case"): G.S.inv.append("case")
			main.scene(),
		"wait10",
		func():
			_check("eighteen conversations and their triggers", main._inner_list().size() == 18 and main._inner_has("case") and main._inner_has("tired"))
			main.open_item("case"),
		func():
			var b = _find(main.mpage, "Listen to it (The Cipher)")
			_check("the dispatch case: Listen to it (The Cipher)", b != null)
			Snd._vseen.clear()
			if b: _press(b),
		"wait5",
		func():
			var t = _texts(main.page)
			_check("the Cipher takes you aside", not main.modal.visible and t.find("The Cipher") >= 0 and t.find("WITS · THE DISPATCH CASE") >= 0 and main.inner_on != null, t.substr(0, 90).replace("\n", " | "))
			_check("its sound plays as its line shows", Snd._vseen.has("cipher"))
			if OS.get_environment("PT_SHOT") != "":
				await RenderingServer.frame_post_draw
				root.get_viewport().get_texture().get_image().save_png(OS.get_environment("PT_SHOT"))
			_check("the next voice waits for Continue (no sound yet)", not Snd._vseen.has("ledger") and not Snd._vseen.has("ringing") and main.beat_btn != null)
			main._next_beat(),
		"wait3",
		func():
			_check("Continue: the next voice sounds as it appears", Snd._vseen.has("ledger") or Snd._vseen.has("duty") or Snd._vseen.has("ringing"), Snd._vseen.keys())
			_reveal()
			var c = _choice("What does it weigh")
			_check("Disco-style options", c != null)
			if c: _press(c),
		"wait3",
		func():
			_reveal()
			var c = _choice("move it")
			if c: _press(c),
		"wait3",
		func():
			_reveal()
			_check("a new thought to mull over: The Weight of Wax", G.S.loose.has("seal_weight"))
			_check("memory kept under the browser's key", G.S.done.has("gseen_inner_x_in_case_weigh_why"))
			var c = _choice("Go back")
			if c: _press(c),
		"wait3",
		func():
			_reveal()
			var c = _choice("Put it back")
			if c: _press(c),
		"wait5",
		func():
			_check("back to the place", main.inner_on == null and main.phase == "scene" and main.inner_box != null, main.phase)
			if main.world.in_cut(): main.world.cut_skip()
			main.advance(),
		"wait5",
		func():
			var t = _texts(main.page)
			_check("leaving the redoubt: the Mud speaks first", t.find("The Mud") >= 0 and t.find("GRIT · BEFORE YOU GO") >= 0 and not main._cutting, t.substr(0, 60).replace("\n", " | "))
			_reveal()
			var c = _choice("Say nothing")
			if c: _press(c),
		"wait3",
		func():
			_check("then the walk to the edge", main._cutting and main.world.goal != null and main.phase != "road")
			t0 = Time.get_ticks_msec(),
		"until_road",
		func():
			_check("the fade to black, then the road", main.phase == "road" and int(G.S.idx) == 1 and main.cut_fade != null, [main.phase, G.S.idx]),
		"until_clear",
		func():
			_check("the fade lifts", main.cut_fade.visible == false or main.cut_fade.color.a < 0.05)
			G.S.done.in_heard_leave_wirehut = true
			G.S.done.qc_done = true
			main.scene(),
		"wait5",
		func():
			var b = _find(main.inner_box, "wants a word")
			_check("after something happens: a button on the place's screen", b != null, _texts(main.inner_box).replace("\n", " | "))
			_check("and the ring over your head", main.world.vq.any(func(it): return str(it.get("inner", "")) == "after_qc"))
			# the ring keeps its order: anything a voice said before the offer comes first
			for i in 6:
				if main.inner_on != null or not main.vring.open_next(): break,
		"wait5",
		func():
			var t = _texts(main.page)
			_check("the ring opens the Shoulder's word", t.find("Old Shoulder") >= 0 and main.inner_on != null, t.substr(0, 60).replace("\n", " | "))
			_reveal()
			var c = _choice("Leave it")
			if c: _press(c),
		"wait5",
		func():
			_check("heard once: the offer is gone", main.phase == "scene" and _find(main.inner_box, "wants a word") == null and not main.world.vq.any(func(it): return it.has("inner")))
			# a moment's sounds: only the most important one plays
			Snd._keyed.clear()
			Snd.event("pass", 1.0)
			Snd.event("redfail", 2.5)
			Snd.event("leg", 1.5),
		"wait10",
		func():
			_check("one sound per moment, the most important", Snd._keyed.has("redfail") and not Snd._keyed.has("pass") and not Snd._keyed.has("leg"), Snd._keyed.keys())
			Snd._vseen.clear()
			for i in 3: Snd.voice_now("ringing")
			_check("ringing has its own sound, quieter on repeats", Snd._keyed.has("ringing") and int(Snd._vseen.ringing.n) == 3)
			Snd.staged()
			Snd.voice("wire", "a line nobody has heard " + str(randi()))
			Snd.voice("ledger", "another line " + str(randi())),
		"wait10",
		func():
			_check("several voices on one screen: only the first sounds", Snd._vseen.has("wire") and not Snd._vseen.has("ledger"), Snd._vseen.keys()),
	]

func _process(_d):
	f += 1
	Engine.max_fps = 0 if f > 3 else Engine.max_fps
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("INNER VOICES: %d/%d" % [ok, n]); quit(); return true
	var s = steps[0]
	if s is String and s.begins_with("until_"):
		var done: bool = Time.get_ticks_msec() - t0 > 8000
		if s == "until_road": done = done or main.phase == "road"
		if s == "until_clear": done = done or (main.cut_fade and not main.cut_fade.visible)
		if not done: return false
		steps.pop_front(); wait = 2
		return false
	steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
