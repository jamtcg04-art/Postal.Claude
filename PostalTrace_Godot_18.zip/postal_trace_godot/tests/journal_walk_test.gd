extends SceneTree
## Picking someone in the journal: with 3D on, "Walk to and talk to <name>?"; No/Esc leaves things as they were,
## Yes/E walks over and the conversation opens there; with 3D off it opens at once. The right person every time.
##   godot --headless -s res://tests/journal_walk_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var who := ""
var t0 := 0

func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _key(k: int) -> void:
	for d in [true, false]:
		var e = InputEventKey.new(); e.keycode = k; e.physical_keycode = k; e.pressed = d
		Input.parse_input_event(e)
func _pad(b: int) -> void:
	for d in [true, false]:
		var e = InputEventJoypadButton.new(); e.button_index = b; e.pressed = d
		Input.parse_input_event(e)
func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t
func _people_button(name: String) -> Control:
	for c in main.choices:
		if is_instance_valid(c[0]) and _texts(c[0]).find(name) >= 0:
			return c[0]
	return null
func _press(c: Control) -> void:
	c.grab_focus()
	var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
	c.gui_input.emit(e)
func _find(nd: Node, name: String) -> Button:
	for ch in nd.get_children():
		if ch is Button and str(ch.text).find(name) >= 0: return ch
		var r = _find(ch, name)
		if r: return r
	return null

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	var G
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "market", "ford"]; G.S.idx = 0; G.S.seen = 0
			main.scene(),
		"wait20",
		func():
			var ts = root.get_node("Game").talkers()
			who = str(ts[ts.size() - 1].name)
			var b = _people_button(who)
			_check("the journal lists " + who, b != null)
			if b: _press(b),
		func():
			_check("it asks first", main.modal.visible and main.modal_tag == "ask" and _texts(main.mpage).find("Walk to and talk to " + who + "?") >= 0, _texts(main.mpage).split("\n")[0])
			_key(KEY_ESCAPE),
		func():
			_check("Esc backs out, and nobody is talking", not main.modal.visible and _texts(main.page).find("TALKING") < 0 and main.world.goal == null)
			_press(_people_button(who)),
		func():
			_key(KEY_E),
		func():
			_check("E says yes: the courier walks over", not main.modal.visible and main.world.goal != null)
			t0 = Time.get_ticks_msec(),
		"until_talk",
		func():
			var t = _texts(main.page)
			_check("and the conversation opens there, with the right person", t.find(who) >= 0 and (t.to_upper().find("TALKING") >= 0 or main.modal.visible == false), t.substr(0, 120).replace("\n", " | "))
			if main.hh:
				main.scene()
				steps.push_front(func():
					_press(_people_button(who)))
				steps.insert(1, func():
					_pad(JOY_BUTTON_B))
				steps.insert(2, func():
					_check("handheld: B backs out", not main.modal.visible)
					_press(_people_button(who)))
				steps.insert(3, func():
					_check("handheld: the pad's A is offered", _texts(main.mpage).find("Yes  (A)") >= 0, _texts(main.mpage).replace("\n", " | "))
					_pad(JOY_BUTTON_A))
				steps.insert(4, func():
					_check("handheld: A says yes (already beside her, so the talk opens)", not main.modal.visible and (main.world.goal != null or _texts(main.page).to_upper().find("TALKING") >= 0), _texts(main.page).substr(0, 60).replace("\n", " | ")))
				return
			main.three_d = false
			main.scene(),
		"wait10",
		func():
			var b = _people_button(who)
			if b: _press(b),
		func():
			_check("with 3D off it opens at once", not (main.modal.visible and main.modal_tag == "ask") and _texts(main.page).find(who) >= 0, _texts(main.page).substr(0, 80).replace("\n", " | ")),
	]

func _process(_d):
	f += 1
	Engine.max_fps = 0 if f > 3 else Engine.max_fps
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("JOURNAL WALK: %d/%d" % [ok, n]); quit(); return true
	var s = steps[0]
	if s is String and s == "until_talk":
		if main.world.goal == null or Time.get_ticks_msec() - t0 > 30000:
			steps.pop_front()
		return false
	steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
