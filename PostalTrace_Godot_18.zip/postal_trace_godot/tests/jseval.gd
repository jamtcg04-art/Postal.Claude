extends SceneTree
## Runs JavaScript statements against the game's logic, for debugging:
##   godot --headless -s res://tests/jseval.gd -- "statements; return value;"
var done := false
func _process(_d: float) -> bool:
	if done:
		return true
	done = true
	var G = root.get_node("Game")
	G.begin_run({ "trait": "steady", "up": { "arms": 1, "nerve": 1, "wits": 1, "grit": 2 }, "left": 0 })
	G.S.route = ["cross", "market", "ford", "oak", "ridge", "malice"]
	for src in OS.get_cmdline_user_args():
		var f = root.get_node("Data").js.make_fn({ "$js": "function () { " + src + " }" })
		var r = root.get_node("Data").js.call_fn(f, [])
		print("=> ", JSON.stringify(G._plain(r)) if (r is Dictionary or r is Array) else str(r))
	return true
