extends SceneTree
## Living dice in the Godot build (living_dice/, the browser's S.ld):
##   godot --headless -s res://tests/ld_test.gd
var main
var f := 0
var ok := 0
var n := 0

func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)

func _texts(nd: Node, out: Array) -> Array:
	if nd is RichTextLabel: out.append(nd.get_parsed_text())
	elif nd is Button: out.append(nd.text)
	for c in nd.get_children(): _texts(c, out)
	return out

func _process(_d):
	f += 1
	if f != 3: return false
	var G = root.get_node("Game")
	# the creator offers the dice
	main.cc = {}
	main.creator()
	var t = " | ".join(_texts(main.page, []))
	_check("the creator has The dice section", t.contains("Ordinary dice") and t.contains("Living dice"))
	main.cc["ld"] = { "on": true, "snow": false, "lock": true, "blank": false }
	main.creator()
	t = " | ".join(_texts(main.page, []))
	_check("living dice shows its three rules", t.contains("Snowball rule") and t.contains("Lock rule") and t.contains("blank dice"))
	main.cc["left"] = 0
	G.begin_run(main.cc)
	_check("a run with living dice has S.ld", LivingDice.is_on(G.S.ld) and G.S.ld.dice.size() == 2 and G.S.ld.lock)
	var m = { "tot": 1, "dc": 9 }
	var o0 = G.odds(m)
	_check("odds start the same as ordinary dice", o0 == 42, o0)
	# a throw ages the dice: one face up, the opposite face down
	var before = G.S.ld.dice[0].f.duplicate()
	var r = G.roll_dice(m)
	var after = G.S.ld.dice[0].f
	var diff = 0
	for i in 6: diff += abs(int(after[i]) - int(before[i]))
	_check("a roll moves two faces of each die", diff == 2 and int(G.S.ld.dice[0].n) == 1, [before, after])
	_check("the roll says what moved", str(r.note).contains("→"), r.note)
	# overwhelming success: Stamina +1 and 5 XP
	G.S.ld.dice[0].f = [9, 9, 9, 9, 9, 9]; G.S.ld.dice[1].f = [9, 9, 9, 9, 9, 9]
	var st0 = int(G.S.st); var xp0 = int(G.S.xp) + int(G.S.level) * 100
	r = G.roll_dice({ "tot": 0, "dc": 9 })
	_check("double nines: overwhelming success", r.ok and r.sup == "super" and LivingDice.verdict(r, "Success") == "Overwhelming success")
	_check("…and it pays Stamina +1 and 5 XP", int(G.S.st) == mini(st0 + 1, 10) and str(r.fxnote).contains("5 XP"), r.fxnote)
	# catastrophe: both dice below zero
	G.S.ld.dice[0].f = [-3, -3, -3, -3, -3, -3]; G.S.ld.dice[1].f = [-3, -3, -3, -3, -3, -3]
	var hp0 = int(G.S.hp)
	r = G.roll_dice({ "tot": 0, "dc": 9 })
	_check("both dice under zero: catastrophe, Health −1", not r.ok and r.sup == "cata" and int(G.S.hp) == hp0 - 1, r.fxnote)
	# lock rule
	LivingDice.dev_add(G.S.ld, "reset")
	LivingDice.toggle_lock(G.S.ld.dice[0], 0)
	_check("lock holds a pair (faces 1 and 6)", int(G.S.ld.dice[0].lock) == 0)
	# the dice panel and odds in the scene and conversations
	G.S.route = ["cross", "market"]; G.S.idx = 0; G.S.seen = 0
	main.scene()
	t = " | ".join(_texts(main.page, []))
	_check("the scene has a Dice in hand button", t.contains("Dice in hand"))
	main.open_dice()
	t = " | ".join(_texts(main.mpage, []))
	_check("the dice panel shows both dice", main.modal_tag == "dice" and t.contains("Left die") and t.contains("Right die"))
	main.dev = true
	main.open_dice()
	t = " | ".join(_texts(main.mpage, []))
	_check("Dev Mode adds the extra dice buttons", t.contains("Add The Blank") and t.contains("Hangman"))
	LivingDice.dev_add(G.S.ld, "hang")
	main.open_dice()
	t = " | ".join(_texts(main.mpage, []))
	_check("with three dice you choose which to hold", t.contains("Hold in left hand"))
	LivingDice.hold(G.S.ld, 0, 2)
	_check("holding the Hangman's Die raises the odds", G.odds(m) > o0, G.odds(m))
	main.close_modal()
	# saves keep it
	var code = G.save_code() if G.has_method("save_code") else ""
	G.save_slot(1)
	var d = G.read_slot(1)
	_check("a save keeps the dice", d is Dictionary and JSON.stringify(d).contains("Hangman"))
	# without living dice nothing changes
	G.begin_run({})
	_check("ordinary dice: no S.ld, plain odds", G.S.ld == null and G.odds(m) == 42)
	print("LD: %d/%d" % [ok, n])
	quit()
	return true
