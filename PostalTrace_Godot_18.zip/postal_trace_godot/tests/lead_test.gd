extends SceneTree
## The Walking Lead and the Hale fixes. Was: One on one with the voices (dialogue/inner.pt, data/inner.json): from the satchel, from the ring after something
## happens, and on the way out of a place (the walk to the edge, the fade, the road). Voice sounds play as lines are
## revealed, one at a time; a moment's sounds queue and only the most important plays.
##   PT_CUT=1 godot --headless -s res://tests/inner_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
var Snd
var t0 := 0

func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t
func _press(c: Control) -> void:
	if c is Button:
		c.pressed.emit(); return
	c.grab_focus()
	var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
	c.gui_input.emit(e)
func _find(nd: Node, name: String) -> Control:
	for ch in nd.get_children():
		var own: String = str(ch.text) if ch is Button else _texts(ch)
		if (ch is Button or ch is PanelContainer) and ch.is_visible_in_tree() and own.find(name) >= 0 and (ch is Button or ch.gui_input.get_connections().size() > 0):
			return ch
		var r = _find(ch, name)
		if r: return r
	return null
func _choice(name: String) -> Control:
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree() and _texts(c[0]).find(name) >= 0:
			return c[0]
	return _find(main.page, name)
func _reveal() -> void:
	for i in 12:
		if main.beat_btn and is_instance_valid(main.beat_btn): main._next_beat()

func _pick(name: String) -> void:
	_reveal()
	var c = _choice(name)
	if c == null:
		print("  (no choice: " + name + ")  " + _texts(main.page).right(300).replace("\n", " | "))
		return
	_press(c)

func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game"); Snd = root.get_node("Sound")
			main.Game_begin()
			G.S.route = ["oak", "bearers", "malice", "chapel"]; G.S.idx = 0; G.S.seen = 1
			G.S.done["gseen_back_oak_surgeon_eleven"] = true
			G.S.coin = 5
			if not G.S.inv.has("brandy"): G.S.inv.append("brandy")
			_check("eighteen inner conversations", main._inner_list().size() == 18 and main._inner_has("lead_ball") and main._inner_has("pass"))
			root.get_node("Bridge").call_js("revisit", ["oak"]),
		"wait5",
		func():
			_check("back at Oakhaven", G.cur_id() == "back_oak", G.cur_id())
			_pick("The Surgeon"),
		"wait5",
		func(): _pick("Look at the shoulder again"),
		"wait5",
		func():
			_check("the lead is walking", G.is_done("lead_walking"))
			_pick("Can you get it out now"),
		"wait5",
		func(): _pick("What would help"),
		"wait5",
		func():
			_reveal()
			var t = _texts(main.page)
			_check("the surgeon's odds are shown", t.find("Heroic, 12") >= 0, t.right(200).replace("\n", " | "))
			_pick("Pay for the good lamp"),
		"wait5",
		func(): _pick("Go back"),
		"wait5",
		func(): _pick("Give him Venn"),
		"wait5",
		func(): _pick("Go back"),
		"wait5",
		func():
			_check("lamp and brandy count", G.is_done("lead_lamp") and G.is_done("lead_brandy") and not G.S.inv.has("brandy") and int(G.S.coin) == 3)
			_pick("Lie down"),
		"wait5",
		func(): _pick("Look at the canvas"),
		"wait5",
		func(): _pick("Keep looking"),
		"wait5",
		func():
			_reveal()
			var t = _texts(main.page)
			_check("the surgeon rolls, not you", t.find("THE SURGEON’S HAND") >= 0 and G.is_done("lead_tried"), t.right(160).replace("\n", " | "))
			_pick("Open your eyes"),
		"wait5",
		func():
			if G.is_done("lead_out"): _check("success: the lead in your hand", G.S.inv.has("lead_ball"))
			else: _check("failure: it will come out on its own", G.is_done("lead_fated"))
			# Blackthorne's answer, two stops after the letter
			G.S.done["bt_letter_sent"] = true; G.S.done["bt_sent_at"] = -2
			main._inner_check()
			var q: Array = G.S.get("innerQ", [])
			_check("Blackthorne's answer offered", q.has("bt_reply"), q)
			_check("no supper at Oakhaven", not q.has("lead_supper"))
			main.inner_talk("bt_reply"),
		"wait5",
		func():
			_check("the probe arrives", G.S.inv.has("bt_probe"))
			_check("the probe counts in his odds", str(root.get_node("Data").call_fn(G.jsf("leadOddsText"))).find("Blackthorne’s probe +1") >= 0)
			G.S.done["lead_echo"] = true
			G.S.inv.erase("lead_ball")
			_check("the Splinter's echo", G.voice_text("splinter", "A pinch under the scar.").find("pinch") < 0)
			G.S.inv.append("lead_ball")
			_check("carried, it speaks as it used to", G.voice_text("splinter", "A pinch under the scar.").find("pinch") >= 0)
			G.S.done["lead_out"] = false; G.S.done["lead_fated"] = true; G.S.done["lead_fated_at"] = 0
			G.S.idx = 1
			root.get_node("Data").js.set_global("SCX", null)
			main._inner_check()
			_check("the lead comes out at the next stop", (G.S.get("innerQ", []) as Array).has("lead_supper")),
	]
func _process(_d):
	f += 1
	Engine.max_fps = 0 if f > 3 else Engine.max_fps
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("WALKING LEAD: %d/%d" % [ok, n]); quit(); return true
	var s = steps[0]
	if s is String and s.begins_with("until_"):
		var done: bool = Time.get_ticks_msec() - t0 > 8000
		if s == "until_road": done = done or main.phase == "road"
		if s == "until_clear": done = done or (main.cut_fade and not main.cut_fade.visible)
		if not done: return false
		steps.pop_front(); wait = 2
		return false
	steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
