extends SceneTree
## Ostrey's levies, Marsh and the bridge gang at the ford (needs a display): godot -s res://tests/levy_shots.gd -- <outdir>
var main
var G
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/levy_" + name + ".png")
func at(x: float, z: float, zm: float) -> void:
	main.world.pl = Vector3(x, 0, z); main.world.cam_target = main.world.pl; main.world.zoom = zm
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["ford"]; G.S.idx = 0
			main.scene(),
		"w60", func(): at(-1.5, -11.0, 2.6); main.world.look_here = Vector3(-6.4, 0, -14.9),
		"w40", func(): shot("post"); at(-6.2, -12.4, 2.4),
		"w40", func(): shot("six"); at(5.2, 6.5, 3.0),
		"w40", func(): shot("bridge"),
	]
func _process(_d):
	if wait > 0:
		wait -= 1
		return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
