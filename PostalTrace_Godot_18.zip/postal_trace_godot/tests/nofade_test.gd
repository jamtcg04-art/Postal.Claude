extends SceneTree
## No see-through stipple inside rooms or at a road camp (V186); outdoors it still works.
##   godot --headless -s res://tests/nofade_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var W
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	var G
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "ford", "oak"]; G.S.idx = 1; G.S.seen = 2
			main.scene(),
		"wait20",
		func():
			W = main.world
			W.see_through_every = 0.0
			W.pl = Vector3(-8.8, 1.72, 7.9)
			W.approach(W.picks.filter(func(k): return str(k.id) == "door_ferryhouse")[0]),
		"wait60",
		func():
			W._occ_t = 0.0
			W._update_see_through(0.1)
			_check("in the ferry house, nothing is stippled", W.file == "ford__ferryhouse" and W._faded.is_empty(), [W.file, W._faded.size()]),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("NOFADE: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
