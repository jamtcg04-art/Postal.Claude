extends SceneTree
## Plays whole runs with nothing but game pad buttons (d-pad, A, B, X, L2/R2), in the handheld layout.
## Checks that every screen on the way can be worked from the pad, and that runs reach an ending.
##   PT_HANDHELD=1 godot --headless -s res://tests/pad_bot.gd -- <seed> <presses> [runs]
var main
var rng := RandomNumberGenerator.new()
var presses := 0
var max_presses := 4000
var runs := 1
var done_runs := 0
var endings: Array = []
var queue: Array = []        # [button or "axis", down]
var wait := 0
var stuck := 0
var walks := 0
var talks_from_walk := 0
var fail := 0
var _where := ""
var _same := 0

func _initialize():
	var a = OS.get_cmdline_user_args()
	rng.seed = int(a[0]) if a.size() > 0 else 1
	max_presses = int(a[1]) if a.size() > 1 else 4000
	runs = int(a[2]) if a.size() > 2 else 1
	for i in 7:
		DirAccess.remove_absolute("user://save_%d.json" % i)
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)

func _push(b: int) -> void:
	queue.append(b)

func _send(b: int) -> void:
	if b < 0:
		for v in [1.0, 0.0]:
			var m = InputEventJoypadMotion.new()
			m.axis = JOY_AXIS_TRIGGER_RIGHT; m.axis_value = v
			Input.parse_input_event(m)
		return
	for d in [true, false]:
		var e = InputEventJoypadButton.new()
		e.button_index = b; e.pressed = d
		Input.parse_input_event(e)

func _process(_dt):
	if wait > 0:
		wait -= 1
		return false
	if queue.size():
		_send(queue.pop_front())
		wait = 1
		return false
	var f := 0
	Engine.max_fps = 0
	if main.phase == "title":
		main.cc = {}
		main.creator()
		wait = 2
		return false
	if main.phase == "other" and main.last_ending != "" and main.page.get_children().any(func(c): return c is Label and c.text.to_upper() != c.text):
		pass
	if main.last_ending != "":
		endings.append(main.last_ending)
		print("ENDING %s after %d presses (walk mode used %d times, conversations from walking %d)" % [main.last_ending, presses, walks, talks_from_walk])
		done_runs += 1
		if done_runs >= runs:
			_finish()
			return true
		main.last_ending = ""
		main.title_screen()
		presses = 0
		return false
	presses += 1
	var G = root.get_node("Game")
	if presses % 250 == 0:
		print("… %d presses, phase %s, hour %s, stop %s" % [presses, main.phase, G.S.get("hrs"), G.cur_id() if G.S.get("route", []).size() else "-"])
		if OS.get_environment("PADBOT_DUMP") == "1":
			var fo2 = root.get_viewport().gui_get_focus_owner()
			print("   focus: ", _desc(fo2), "  modal ", main.modal.visible, "  beat ", main.beat_btn != null)
			for c in main.pad._all_focusable(main.page):
				print("   - ", _desc(c))
	if presses > max_presses:
		print("FAIL no ending after %d presses, phase %s" % [presses, main.phase])
		fail += 1
		_finish()
		return true
	var fo = root.get_viewport().gui_get_focus_owner()
	if main.pad.mode == "panel" and fo == null and main.beat_btn == null:
		stuck += 1
		if stuck > 40:
			print("FAIL nothing to focus on, phase %s, page: %s" % [main.phase, _first_text()])
			fail += 1
			_finish()
			return true
	else:
		stuck = 0
	# now and then walk to someone and press A, the rest of the time pick from the panel
	if main.pad.mode == "walk":
		if main.world.pad_target != null and rng.randf() < 0.5:
			if main.world.pad_target.kind == "person":
				talks_from_walk += 1
			_push(JOY_BUTTON_A); wait = 120
		elif rng.randf() < 0.3:
			_push(-1)
		else:
			_push(JOY_BUTTON_X)
		return false
	if main.modal.visible:
		_push(JOY_BUTTON_B)
		return false
	if main.pad.can_walk() and rng.randf() < 0.04:
		walks += 1
		_push(JOY_BUTTON_X)
		return false
	# a player skips what they have already heard, and leaves when a place has gone on too long
	var where = str(main.phase) + str(G.S.get("hrs")) + (G.cur_id() if G.S.get("route", []).size() else "")
	if where != _where:
		_where = where
		_same = 0
	_same += 1
	var fo3 = root.get_viewport().gui_get_focus_owner()
	var heard = fo3 != null and _desc(fo3).contains("Already said")
	if _same > 40:
		for i in 14:
			_push(JOY_BUTTON_DPAD_DOWN)
		_same = 60
	elif heard:
		_push(JOY_BUTTON_DPAD_DOWN)
		return false
	else:
		# in a place, the scene's own choices are below the people (a player who has talked moves on)
		var n = rng.randi_range(4, 16) if main.phase == "scene" and G.has_talked(G.cur_id()) else rng.randi_range(0, 5)
		for i in n:
			_push(JOY_BUTTON_DPAD_DOWN if rng.randf() < 0.85 else JOY_BUTTON_DPAD_UP)
	_push(JOY_BUTTON_A)
	wait = 1
	return false

func _desc(c) -> String:
	if c == null:
		return "null"
	if c is Button:
		return "Button " + c.text
	var out: PackedStringArray = []
	for ch in c.find_children("*", "RichTextLabel", true, false):
		out.append(ch.get_parsed_text().substr(0, 60))
	return c.get_class() + " " + " | ".join(out)

func _first_text() -> String:
	for c in main.page.get_children():
		if c is Label:
			return c.text
	return ""

func _finish() -> void:
	print("PADBOT: %d endings %s, %d failures" % [endings.size(), endings, fail])
