extends SceneTree
## Pad buttons moved in Menu > Controls, and the 3D name tags drawn sharp on a handheld:
##   PT_HANDHELD=1 godot --headless -s res://tests/pad_map_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var z0 := 0.0

func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _pad(b: int) -> void:
	for d in [true, false]:
		var e = InputEventJoypadButton.new(); e.button_index = b; e.pressed = d
		Input.parse_input_event(e)
func _axis(a: int, v: float) -> void:
	var m = InputEventJoypadMotion.new(); m.axis = a; m.axis_value = v
	Input.parse_input_event(m)

func _initialize():
	var c = ConfigFile.new(); c.load("user://settings.cfg")
	if c.has_section("padmap"): c.erase_section("padmap")
	c.save("user://settings.cfg")
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			var G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross", "market", "ford"]; G.S.idx = 0; G.S.seen = 0
			main.scene(),
		func():
			main.open_controls(),
		func():
			var txt = _texts(main.mpage)
			_check("Controls lists the pad's actions first on a handheld", txt.find("GAME PAD") >= 0 and txt.find("GAME PAD") < txt.find("Keys") and txt.find("Zoom in") >= 0, "")
			main.pad.start_capture("hh_zin"),
		"wait20",
		func():
			_axis(JOY_AXIS_TRIGGER_LEFT, 1.0); _axis(JOY_AXIS_TRIGGER_LEFT, 0.0),
		func():
			_check("pressing L2 puts Zoom in on it", main.pad.bindings("hh_zin") == ["a4+"], main.pad.bindings("hh_zin"))
			_check("and takes it off what had it", main.pad.bindings("hh_l2").is_empty(), main.pad.bindings("hh_l2"))
			_check("the page shows the new button", _texts(main.mpage).find("L2") >= 0)
			main.pad.start_capture("hh_zout"),
		"wait20",
		func():
			_axis(JOY_AXIS_TRIGGER_RIGHT, 1.0); _axis(JOY_AXIS_TRIGGER_RIGHT, 0.0),
		func():
			main.pad.start_capture("hh_voice"),
		"wait20",
		func():
			_pad(JOY_BUTTON_A),
		func():
			_check("A cannot be taken from Pick while it is Pick's only button", main.pad.bindings("hh_ok") == [JOY_BUTTON_A] and main.pad.bindings("hh_voice") == [JOY_BUTTON_Y], str(main.pad.bindings("hh_voice")))
			main.pad.start_capture("hh_char"),
		"wait20",
		func():
			_pad(JOY_BUTTON_Y),
		func():
			_check("Y can become Character", main.pad.bindings("hh_char") == [JOY_BUTTON_Y] and main.pad.bindings("hh_voice").is_empty())
			main.close_modal(),
		func():
			_pad(JOY_BUTTON_Y),
		func():
			_check("and Y opens the character sheet", main.modal.visible and main.modal_tag == "char")
			main.close_modal()
			_pad(JOY_BUTTON_X),
		func():
			_check("walking", main.pad.mode == "walk")
			z0 = main.world.zoom
			_axis(JOY_AXIS_TRIGGER_LEFT, 1.0),
		"ms700",
		func():
			_axis(JOY_AXIS_TRIGGER_LEFT, 0.0)
			_check("L2 zooms in while walking (and keeps zooming while held)", main.world.zoom < z0 * 0.8, "%.2f -> %.2f" % [z0, main.world.zoom])
			z0 = main.world.zoom
			_axis(JOY_AXIS_TRIGGER_RIGHT, 1.0); _axis(JOY_AXIS_TRIGGER_RIGHT, 0.0),
		func():
			_check("R2 zooms out", main.world.zoom > z0, "%.2f -> %.2f" % [z0, main.world.zoom])
			_check("the walking hints show the zoom buttons", main.pad_bar.text.find("L2/R2 zoom") >= 0, main.pad_bar.text)
			# a name tag over the 3D view: drawn sharp, at full resolution, not in the half-size 3D picture
			main.world.pad_cycle(1),
		func():
			var k = main.world.pad_target
			_check("the name tag is drawn over the 3D view at full size", k != null and main.tag_name.visible and main.tag_name.text.begins_with(str(k.name)) and main.world.label.layers == 0, main.tag_name.text.split("\n")[0])
			var fs = main.tag_name.get_theme_font_size("font_size")
			_check("in the text size from Settings", fs == int(round(18 * main.text_scale)), fs)
			var r = main.world_view.get_global_rect()
			var gp = main.tag_name.global_position + main.tag_name.size / 2
			_check("over the courier", r.has_point(gp), gp)
			main.pad.reset_map(),
		func():
			_check("Pad buttons back to the usual", main.pad.bindings("hh_l2") == ["a4+"] and main.pad.bindings("hh_voice") == [JOY_BUTTON_Y] and main.pad.bindings("hh_zin").is_empty()),
	]

func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t

func _process(_d):
	f += 1
	Engine.max_fps = 0 if f > 3 else Engine.max_fps
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("PAD MAP: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String and s.begins_with("ms"):
		var until = Time.get_ticks_msec() + int(s.substr(2))
		steps.push_front(func(): pass)
		while Time.get_ticks_msec() < until: OS.delay_msec(20); main.pad._process(0.02)
	elif s is String: wait = int(s.substr(4))
	else:
		s.call(); wait = 3
	return false
