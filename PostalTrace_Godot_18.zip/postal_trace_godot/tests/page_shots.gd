extends SceneTree
## Screenshots of screens the browser logic draws (needs a display):
##   godot -s res://tests/page_shots.gd -- <outdir>
var main
var f := 0
var out := "/tmp"
var steps: Array = []
func js(src: String) -> Variant:
	var D = root.get_node("Data")
	return D.js.call_fn(D.js.make_fn({ "$js": "function () { " + src + " }" }), [])
func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	if a.size(): out = a[0]
	seed(4)
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		["gate", func(): main.Game_begin(); var S = root.get_node("Game").S; S.route = ["cross", "checkpoint", "oak", "ridge", "malice"]; S.idx = 1; S.seen = 2; main.scene()],
		["gate_next", func(): main.choices[0][1].call()],
		["fight", func(): main._practice("bearers")],
		["fight_round", func(): main.choices[0][1].call()],
		["market", func(): main.Game_begin(); var S = root.get_node("Game").S; S.route = ["cross", "market", "ford", "oak", "ridge", "malice"]; S.idx = 1; S.seen = 1; main.scene()],
		["market_talk", func(): main.talk_js(0); main._reveal_all()],
		["recruit", func(): main.Game_begin(); var S = root.get_node("Game").S; S.route = ["cross", "chapel", "ford", "oak", "ridge", "malice"]; S.idx = 1; S.seen = 2; S.talked["chapel:ines:g"] = true; main.scene()],
	]
func _process(_d: float) -> bool:
	f += 1
	var i := f / 20
	if f % 20 == 1 and i < steps.size():
		steps[i][1].call()
	if f % 20 == 15 and i < steps.size():
		root.get_viewport().get_texture().get_image().save_png(out + "/page_" + str(i) + "_" + steps[i][0] + ".png")
	return i >= steps.size()
