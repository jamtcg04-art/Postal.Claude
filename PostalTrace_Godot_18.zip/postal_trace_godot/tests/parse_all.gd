extends SceneTree
## Parses every JavaScript snippet in res://data with JsLite. Run:
##   godot --headless -s res://tests/parse_all.gd
var js := JsLite.new()
var n := 0
var bad := 0
func _check(src: String, where: String) -> void:
	n += 1
	var err := js.check(src)
	if err != "":
		bad += 1
		if bad <= 15:
			print("FAIL ", where, ": ", err, "\n   ", src.substr(0, 160))

func _walk(v: Variant, where: String) -> void:
	if v is Dictionary:
		# compiled dialogue (data/dialogue): an expression, as the JavaScript the browser logic is given
		if v.size() == 1 and v.get("x") is Array:
			_check("function () { return " + PTCond.to_js(v.x) + "; }", where)
			return
		if v.get("js") is String:
			_check(str(v.js), where)
			if v.get("closure") is Dictionary: _walk(v.closure, where + ".closure")
			return
		if v.get("__fn") is String:
			_check(str(v.__fn), where)
			if v.get("__closure") is Dictionary: _walk(v.__closure, where + ".__closure")
			return
		if v.has("$js"):
			n += 1
			var err := js.check(str(v["$js"]))
			if err != "":
				bad += 1
				if bad <= 15:
					print("FAIL ", where, ": ", err, "\n   ", str(v["$js"]).substr(0, 160))
			if v.has("$env"):
				_walk(v["$env"], where + ".$env")
			return
		for k in v:
			_walk(v[k], where + "." + str(k))
	elif v is Array:
		for x in v.size():
			_walk(v[x], where + "[" + str(x) + "]")
func _files(dir: String, out: Array) -> void:
	var d := DirAccess.open(dir)
	for f in d.get_files():
		if f.ends_with(".json"):
			out.append(dir + "/" + f)
	for s in d.get_directories():
		_files(dir + "/" + s, out)
func _init() -> void:
	var files: Array = []
	_files("res://data", files)
	for f in files:
		_walk(JSON.parse_string(FileAccess.get_file_as_string(f)), f.get_file())
	print("parsed ", n, " snippets, ", bad, " failed")
	quit(1 if bad else 0)
