extends SceneTree
## Screenshots a list of places in 3D (needs a display):
##   godot -s res://tests/place_shots.gd -- <outdir> cross ford oak ...
var w
var vp: SubViewport
var files: Array = []
var out := "user://"
var i := 0
var f := 0
func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	out = a[0]
	files = a.slice(1)
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		root.get_node("Game").begin_run({ "trait": "steady", "up": { "arms": 1, "nerve": 1, "wits": 1, "grit": 2 }, "left": 0 })
		var c := SubViewportContainer.new()
		c.stretch = true
		c.stretch_shrink = 2
		c.size = Vector2(1280, 800)
		c.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		root.add_child(c)
		vp = SubViewport.new()
		c.add_child(vp)
		w = load("res://scripts/world/world.gd").new()
		vp.add_child(w)
		return false
	if f < 3:
		return false
	if i >= files.size():
		return true
	if f % 20 == 3:
		var G = root.get_node("Game")
		G.S.route = [OS.get_environment("ROUTE") if OS.get_environment("ROUTE") != "" else str(files[i]).split("__")[0]]
		if OS.get_environment("DONE") != "":
			for kv in OS.get_environment("DONE").split(","): G.S.done[kv] = true
		G.S.idx = 0
		w.enter(files[i])
		w.zoom = float(OS.get_environment("ZOOM")) if OS.get_environment("ZOOM") != "" else 11.0
		if OS.get_environment("AT") != "":
			var p = OS.get_environment("AT").split(",")
			w.pl = Vector3(float(p[0]), 0, float(p[1]))
			w.cam_target = w.pl
	if f % 20 == 18:
		root.get_viewport().get_texture().get_image().save_png(out + "/place_" + str(files[i]) + ".png")
		i += 1
	return false
