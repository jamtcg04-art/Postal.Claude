extends SceneTree
## Builds every place (and every inside area) and walks the courier to each person and thing.
var w
var files: Array = []
var i := 0
var f := 0
var out := ""
func _initialize() -> void:
	out = OS.get_cmdline_user_args()[0] if OS.get_cmdline_user_args().size() else ""
	var idx: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/places/index.json")).places
	for id in idx:
		for a in idx[id]:
			files.append(id + ("__" + a if a != "" else ""))
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		var G = root.get_node("Game")
		G.begin_run({ "trait": "steady", "up": { "arms": 1, "nerve": 1, "wits": 1, "grit": 2 }, "left": 0 })
		var vp := SubViewport.new()
		vp.size = Vector2i(426, 266)
		root.add_child(vp)
		w = load("res://scripts/world/world.gd").new()
		vp.add_child(w)
		return false
	if f < 3:
		return false
	if i >= files.size():
		print("PLACES OK ", files.size())
		return true
	if f % 12 == 3:
		var file: String = files[i]
		var G = root.get_node("Game")
		G.S.route = [file.split("__")[0]]
		G.S.idx = 0
		w.enter(file)
		var props = w.place.get_node("Props").get_child_count()
		var stand = w.place.get_node("Props").get_children().filter(func(n): return n.has_meta("standin")).size()
		print("%-20s props %3d (stand-ins %3d) people %d picks %d solids %d" % [file, props, stand, w.figures.size(), w.picks.size(), w.solids.size()])
		var got := []
		w.interact.connect(func(k, id): got.append(k + ":" + id))
		for k in w.picks:
			if k.kind != "door":
				w.approach(k)
				for s in 400:
					w._process(0.05)
					if w.goal == null:
						break
		print("    reached: ", got.size(), "/", w.picks.filter(func(k): return k.kind != "door").size())
		if out != "" and i % 4 == 0:
			pass
		i += 1
	return false
