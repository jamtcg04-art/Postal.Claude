extends SceneTree
## The riding pose, side on and from the front (needs a display): godot -s res://tests/ride_shots.gd -- <outdir>
var w
var out := ""
var f := 0
var riders: Array = []
var horses: Array = []
func _initialize() -> void:
	out = OS.get_cmdline_user_args()[0]
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		var G = root.get_node("Game")
		G.begin_run({ "trait": "steady" })
		G.S.route = ["ford"]; G.S.idx = 0
		var c := SubViewportContainer.new()
		c.stretch = true
		c.size = Vector2(1400, 800)
		root.add_child(c)
		var vp := SubViewport.new()
		c.add_child(vp)
		w = load("res://scripts/world/world.gd").new()
		vp.add_child(w)
	if f == 4:
		w.enter("ford")
		var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
		var poses := [["idle", PI / 2], ["walk", PI / 2], ["gallop", PI / 2], ["idle", 0.0]]
		for i in poses.size():
			var h: Node3D = PlaceBuilder._prop({ "m": "cp_horse_rig", "x": i * 3.3 - 5.0, "z": 40.0, "h": 1.9, "r": poses[i][1] }, sizes)
			w.place.add_child(h)
			h.set_meta("rig", h)
			var ap: AnimationPlayer = h.find_child("AnimationPlayer", true, false)
			ap.play(poses[i][0]); ap.seek(0.1, true); ap.pause()
			var r := Figure.new()
			r.dress(Figure.courier_look())
			w.place.add_child(r)
			r.mount(h)
			riders.append(r)
			horses.append(h)
		w.player.visible = false
		w.editing = true; w.edit_cam = Vector3(0.0, 1.4, 40.0); w.zoom = 3.6; w.yaw = 0.0; w.pitch = 0.15
	if f == 24:
		root.get_viewport().get_texture().get_image().save_png(out + "/ride.png")
		return true
	return false
