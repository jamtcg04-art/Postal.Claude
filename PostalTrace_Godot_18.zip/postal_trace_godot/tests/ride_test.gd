extends SceneTree
## Riding: on the road the courier is in the saddle; into a place he rides in; he gets down to talk and up again.
##   godot --headless -s res://tests/ride_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
var w
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			G.S.route = ["ford", "cross", "oak"]; G.S.idx = 1
			G.S.horse = { "id": "grey", "fed": 0, "lent": false, "since": 0 }
			main.road([]),
		func():
			w = main.world
			_check("on the road: in the saddle", w.road != null and w.player.riding == w.road.horse and w.road.horse != null)
			_check("the horse walks the road under him", PropMotion.horse_anim(w.road.horse).current_animation == "walk"),
		func(): main.road_on = true; main.scene(),
		func():
			_check("into Cross-Pillars in the saddle", w.file == "cross" and w.my_horse != null and w.mounted(), [w.file, w.my_horse, w.mounted()])
			var p0: Vector3 = w.pl
			w.walk_to(w.pl.x + 3.0, w.pl.z)
			set_meta("p0", p0),
		"w40",
		func():
			var hs = PropMotion.spot(w.my_horse)
			_check("riding about: the horse goes where he goes", Vector2(hs.x - w.pl.x, hs.z - w.pl.z).length() < 0.3 and w.pl.distance_to(get_meta("p0")) > 1.0, [hs, w.pl])
			var k = null
			for q in w.picks:
				if q.kind == "person": k = q; break
			if k: w.approach(k)
			set_meta("k", k)
			set_meta("t0", Time.get_ticks_msec()),
		"until_down",
		func():
			_check("he gets down to talk", not w.mounted() and w.player.riding == null)
			var hk = null
			for q in w.picks:
				if q.kind == "horse": hk = q
			_check("the horse waits, and can be ridden again", hk != null)
			if hk: w.approach(hk)
			set_meta("t0", Time.get_ticks_msec()),
		"until_up",
		func():
			_check("back in the saddle", w.mounted()),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("RIDE: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String and s.begins_with("until_"):
		var waiting: bool = w.mounted() if s == "until_down" else not w.mounted()
		if waiting and Time.get_ticks_msec() - int(get_meta("t0")) < 8000:
			steps.push_front(s)
		return false
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 4
	return false
