extends SceneTree
## Pictures of the road between stops (needs a display):  godot -s res://tests/road_shots.gd -- <outdir> [horse]
var main
var G
var f := 0
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/road_" + name + ".png")
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	var horse := OS.get_cmdline_user_args().size() > 1
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["ford", "mill", "oak"]; G.S.idx = 1; G.S.notice = 2
			if horse: G.S.horse = { "id": "grey", "fed": 0, "lent": false, "since": 0 }
			G.S.idx = 0
			main.scene(),
		"w90", func(): shot("place"); G.S.idx = 1; main.road([]),
		"w90", func():
			var w = main.world
			print("three_d ", main.three_d, " view ", main.world_view.visible, " active ", w.active, " place ", w.place, " road ", w.road, " file ", w.file)
			if w.road: print(" props ", w.road.get_node("Props").get_child_count(), " cam ", w.cam.global_position, " size ", w.cam.size, " current ", w.cam.current, " player ", w.player.global_position, " vis ", w.player.visible)
			var vp: SubViewport = main.world_view.get_child(0)
			vp.get_texture().get_image().save_png(out + "/road_vp.png")
			print("vp size ", vp.size, " upd ", vp.render_target_update_mode, " mod ", main.world_view.modulate, " wv rect ", main.world_view.get_global_rect())
			shot("walk" + ("_h" if horse else "")),
		func(): root.get_node("Bridge").call_js("thievesEvent", [func(_a = null): main.road([])]),
		"w120", func(): shot("thieves"),
		func(): G.S.camp = { "kind": "fire", "shelter": "tent" if horse else "leanto", "horse": horse, "idx": G.S.idx }; main._world_road("camp", G.S.camp),
		"w150", func(): shot("camp_fire" + ("_h" if horse else "")),
		func(): G.S.camp = { "kind": "cold", "shelter": "hide", "horse": horse, "idx": G.S.idx }; main._world_road("camp", G.S.camp),
		"w150", func(): shot("camp_cold"),
		func(): main._world_road("camp_found"),
		"w120", func(): shot("camp_found"),
		func(): main._world_road("rider"),
		"w90", func(): shot("rider"),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
