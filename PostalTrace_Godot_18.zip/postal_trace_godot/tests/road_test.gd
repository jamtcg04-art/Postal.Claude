extends SceneTree
## The road between stops in 3D (road_view.gd): walking, stopping for what the road brings, camp, the voices on the road.
##   godot --headless -s res://tests/road_test.gd   (forces the 3D view on)
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var wait := 0
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(nd: Node) -> String:
	var t := ""
	for ch in nd.get_children():
		if ch is Label or ch is Button: t += str(ch.text) + "\n"
		elif ch is RichTextLabel: t += ch.get_parsed_text() + "\n"
		t += _texts(ch)
	return t
func _press(name: String) -> bool:
	for c in main.choices:
		if is_instance_valid(c[0]) and c[0].is_visible_in_tree() and _texts(c[0]).to_lower().find(name.to_lower()) >= 0:
			var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
			c[0].grab_focus(); c[0].gui_input.emit(e); return true
	var b = _find(main.page, name)
	if b == null: return false
	if b is Button: b.pressed.emit()
	else:
		var e2 = InputEventAction.new(); e2.action = "ui_accept"; e2.pressed = true
		b.grab_focus(); b.gui_input.emit(e2)
	return true
func _find(nd: Node, name: String) -> Control:
	for ch in nd.get_children():
		var own: String = str(ch.text) if ch is Button else _texts(ch)
		if (ch is Button or ch is PanelContainer) and ch.is_visible_in_tree() and own.to_lower().find(name.to_lower()) >= 0 and (ch is Button or ch.gui_input.get_connections().size() > 0):
			return ch
		var r = _find(ch, name)
		if r: return r
	return null
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			G.S.route = ["ford", "mill", "oak"]; G.S.idx = 1; G.S.notice = 3
			G.S.horse = { "id": "grey", "fed": 0, "lent": false, "since": 0 }
			main.road([]),
		func():
			var w = main.world
			_check("the road is up behind the road screen", main.world_view.visible and w.road != null and w.place == w.road)
			_check("the courier walks, the country moves", w.road.mode == "walk" and w.road.want > 0.0)
			_check("with a horse: she walks beside him", w.road.horse != null and PropMotion.horse_anim(w.road.horse).current_animation == "walk")
			var t = _texts(main.page).to_lower()
			_check("voices want a word on the road (Long Road, Wire, Battery)", t.find("the long road wants a word") >= 0 and t.find("the wire wants a word") >= 0 and t.find("third battery wants a word") >= 0, t.left(400).replace("\n", " | "))
			_press("The Long Road wants a word"),
		func():
			_check("the talk opens with the road still up", main.inner_on != null and main.world.road != null and main.world_view.visible, [main.inner_on, main.world.road, main.world_view.visible, main.phase, _texts(main.page).left(200).replace("\n", " | ")]),
		func():
			for i in 12:
				if main.beat_btn and is_instance_valid(main.beat_btn): main._next_beat()
			_press("Walk on"),
		func():
			_check("and comes back to the road", main.phase == "road" and main.world.road != null, [main.phase, main.world.road]),
		func(): root.get_node("Bridge").call_js("thievesEvent", [func(_a = null): main.road([])]),
		func():
			_check("thieves: the road stops and they step out", main.world.road.mode == "thieves" and main.world.road.want == 0.0 and main.world.road.set_nodes.size() >= 2),
		func(): main.road([]),
		func(): _press("Make camp"),
		func(): _press("cold camp"),
		func():
			_check("a cold camp stands by the road: hidden shelter, no fire", main.world.road.mode == "camp" and str(main.world.road.camp.get("shelter")) == "hide" and main.world.road.night, main.world.road.mode)
			_check("the horse is tethered at the camp", PropMotion.horse_anim(main.world.road.horse).current_animation == "idle"),
		func(): _press("Continue"),
		func():
			var t = _texts(main.page).to_lower()
			_check("back on the road, the Mud has a word about the cold camp", t.find("the mud wants a word") >= 0 or t.find("found in the night") >= 0, t.left(300).replace("\n", " | "))
			main.scene(),
		func():
			_check("the next place: the road is gone", main.world.road == null and not main.road_on, [main.world.road, main.road_on, main.world.file]),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		print("ROAD: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	s.call(); wait = 4
	return false
