extends SceneTree
## Saves in the browser's format: slots, save codes, save files, the sync folder (newest copy
## wins), older Godot saves, and carrying on from a road leg or a revisit.
##   godot --headless --path . -s res://tests/saves_test.gd
var main
var G
var f := 0
var results: Array = []
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func start(route: Array, idx: int) -> void:
	main.Game_begin()
	G.S.route = route; G.S.idx = idx; G.S.seen = idx
func _initialize():
	main = load("res://scenes/main.tscn").instantiate(); root.add_child(main)
func _process(_d):
	f += 1
	if f < 3:
		G = root.get_node("Game"); return false
	if f > 3:
		return true
	var sync = OS.get_user_data_dir().path_join("sync_test")
	DirAccess.make_dir_recursive_absolute(sync)
	G.set_sync_dir("")
	start(["cross", "market", "ford", "oak", "ridge", "malice"], 1)
	main.scene()
	check("a scene snaps a checkpoint", G.cp is Dictionary and G.cp.kind == "scene")
	var p = JSON.parse_string(G.pack_save())
	check("a save is in the browser's format", p.v == 1 and p.cp.s is String and p.at > 1e12 and str(p.where).find("hour") >= 0, str(p.where))
	check("the autosave was written", G.read_slot(0) is Dictionary)
	G.S.hrs = 7
	main.scene()
	G.save_slot(2)
	var hrs_saved = G.S.hrs
	G.S.hrs = 30
	var c = G.load_slot(2)
	check("a slot loads back", c is Dictionary and int(G.S.hrs) == hrs_saved, "hrs=" + str(G.S.hrs))
	# a save code
	var code = G.save_code()
	G.S.hrs = 31
	check("a save code loads", main._resume(G.apply_pack(G.read_pack(code))) and int(G.S.hrs) == hrs_saved)
	# a save file, as the browser writes it
	var path = OS.get_user_data_dir().path_join(G.file_name())
	check("save to a file", G.save_file(path) and path.get_file().begins_with("postal-trace-linden-market"), path.get_file())
	G.S.hrs = 32
	check("load from a file", main._resume(G.apply_pack(G.read_pack(FileAccess.get_file_as_string(path)))) and int(G.S.hrs) == hrs_saved)
	# an older Godot save
	var old = JSON.stringify({ "where": "old", "at": "2026-10-29 10:00", "s": G.S })
	check("an older Godot save still loads", G.apply_pack(G.read_pack(old)) is Dictionary)
	# the sync folder: the newer copy wins
	G.set_sync_dir(sync)
	check("choosing a folder copies the slots there", FileAccess.file_exists(sync.path_join("postal-trace-slot2.json")))
	var far = JSON.parse_string(FileAccess.get_file_as_string(sync.path_join("postal-trace-slot2.json")))
	var fs = JSON.parse_string(far.cp.s); fs.hrs = 44
	far.cp.s = JSON.stringify(fs); far.at = float(far.at) + 60000.0
	var fw = FileAccess.open(sync.path_join("postal-trace-slot2.json"), FileAccess.WRITE); fw.store_string(JSON.stringify(far)); fw.close()
	G.load_slot(2)
	check("the newer copy in the sync folder wins", int(G.S.hrs) == 44, "hrs=" + str(G.S.hrs))
	G.save_slot(3)
	check("saving writes to the sync folder too", FileAccess.file_exists(sync.path_join("postal-trace-slot3.json")))
	G.set_sync_dir("")
	# carrying on from the road
	start(["cross", "market", "ford", "oak", "ridge", "malice"], 2)
	main.road([])
	G.save_slot(4)
	main.title_screen()
	main._load_and_go(4)
	check("a road save carries on on the road", G.cp.kind == "road" and main.phase != "title", "phase=" + str(main.phase))
	# a save made in the browser (tests/browser_save.json, made by tools/browser_save.js)
	var bs = FileAccess.get_file_as_string("res://tests/browser_save.json")
	if bs != "":
		check("a save from the browser loads", main._resume(G.apply_pack(G.read_pack(bs))) and main.phase != "title", "phase=" + str(main.phase))
	# every save in one file, both ways with the browser
	var n_all = G.save_all_file(OS.get_user_data_dir().path_join("all.json"))
	var back_all = JSON.parse_string(FileAccess.get_file_as_string(OS.get_user_data_dir().path_join("all.json")))
	check("all saves go in one file in the browser's format", n_all >= 2 and back_all.kind == "saves" and back_all.saves.has("auto"), "%d saves" % n_all)
	var r_all = G.load_all_text(FileAccess.get_file_as_string(OS.get_user_data_dir().path_join("all.json")))
	check("opening it again keeps slots that are as new", r_all is Dictionary and r_all.put == 0 and r_all.kept == n_all)
	main.open_menu()
	var labels = main.find_children("*", "Button", true, false).map(func(b): return b.text)
	check("the menu offers files, codes and a sync folder", "Save to a file" in labels and "Copy save code" in labels and "Save all saves to one file" in labels and "Choose a save file" in labels and "Choose a sync folder" in labels, str(labels))
	main.close_modal()
	main.title_screen()
	main.open_load()
	main.close_modal()
	for r in results: print(r)
	print("SAVES: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
	return true
