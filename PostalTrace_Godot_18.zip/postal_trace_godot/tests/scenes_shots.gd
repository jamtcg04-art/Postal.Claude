extends SceneTree
## The quick draw at Cross-Pillars and the Oakhaven surgery (needs a display): godot -s res://tests/scenes_shots.gd -- <outdir>
var main
var G
var f := 0
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/scene_" + name + ".png")
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross"]; G.S.idx = 0
			main.scene(),
		"w60", func():
			print("figures ", main.world.figures.keys())
			var v = main.world.figures.get("vane")
			if v:
				print("vane at ", v.global_position, " visible ", v.is_visible_in_tree())
				main.world.pl = v.global_position + Vector3(1.8, 0, 2.2); main.world.cam_target = main.world.pl
				main.world.look_here = v.global_position + Vector3(0.9, 0, 1.1)
			main.world.zoom = 5.0,
		"w30", func(): main.world.scenes.quickdraw(true),
		"w70", func(): shot("draw_fire"),
		"w120", func(): shot("draw_after"),
		func(): main.world.look_here = null; G.S.route = ["oak"]; G.S.idx = 0; main.scene(),
		"w20", func(): root.get_node("Bridge").call_js("revisit", ["oak"]),
		"w30", func():
			for c in main.choices:
				var t := ""
				for ch in c[0].find_children("*", "Label", true, false): t += ch.text
				for ch in c[0].find_children("*", "RichTextLabel", true, false): t += ch.get_parsed_text()
				if t.find("Surgeon") >= 0:
					var e = InputEventAction.new(); e.action = "ui_accept"; e.pressed = true
					c[0].grab_focus(); c[0].gui_input.emit(e); break,
		"w60", func():
			var sg = main.world.figures.get("surgeon")
			if sg: main.world.cam_target = sg.global_position
			main.world.zoom = 4.0
			main.world.scenes.surgery("lie"),
		"w90", func(): main.world.look_here = main.world.figures.surgeon.global_position + Vector3(-0.8, 0, -0.4); shot("surgery_lie"),
		func(): main.world.scenes.surgery("out"),
		"w40", func(): shot("surgery_out"),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if wait > 0:
		wait -= 1; return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call(); wait = 2
	return false
