extends SceneTree
## The quick draw at Cross-Pillars and the Oakhaven surgery, played in the place (scenes3d.gd).
##   godot --headless -s res://tests/scenes_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			G.S.route = ["cross"]; G.S.idx = 0
			main.scene(),
		func():
			_check("Cross-Pillars: Vane is there", main.world.figures.has("vane"))
			main.world.scenes.quickdraw(true)
			set_meta("t0", Time.get_ticks_msec()),
		"t2500",
		func():
			var v: Figure = main.world.figures.vane
			_check("the draw: Vane goes down", v.current == "death", v.current)
			var ax: Figure = main.world.figures.axeman
			_check("his men run for the spruce", ax.has_meta("run_to") or not ax.visible, ax.current),
		func():
			G.S.route = ["oak"]; G.S.idx = 0
			main.scene(),
		func(): root.get_node("Bridge").call_js("revisit", ["oak"]),
		func():
			main._cine_node("lead_go"),
		"t900",
		func():
			var me: Figure = main.world.player
			_check("the surgery: the courier lies on a cot under the canvas", me.has_meta("lying") and me.current == "death" and main.world.scenes.made.size() >= 1)
			main._cine_node("lead_ok"),
		func():
			_check("the ball held up: the surgeon nods", main.world.figures.surgeon.current == "yes", main.world.figures.surgeon.current)
			main._cine_node("hub"),
		func():
			_check("and up again after", not main.world.player.has_meta("lying") and main.world.scenes.made.is_empty()),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if has_meta("until"):
		if Time.get_ticks_msec() < int(get_meta("until")): return false
		remove_meta("until")
	if steps.is_empty():
		print("SCENES: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String:
		set_meta("until", Time.get_ticks_msec() + int(s.substr(1)))
	else:
		s.call()
		set_meta("until", Time.get_ticks_msec() + 80)
	return false
