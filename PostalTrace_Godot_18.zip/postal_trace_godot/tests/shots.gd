extends SceneTree
## Saves screenshots of the main screens (needs a display): godot -s res://tests/shots.gd -- <outdir>
var main
var f := 0
var out := "user://"
var steps: Array = []

func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	if a.size():
		out = a[0]
	seed(3)
	for i in 7:
		DirAccess.remove_absolute("user://save_%d.json" % i)
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		["title", func(): pass],
		["creator", func(): main.cc = {}; main.creator()],
		["intro", func(): main.Game_begin(); main.intro(1)],
		["scene", func(): main.feeling_pick(0)],
		["walk", func(): main.world.pl = Vector3(0.5, 0, -3.5); main.world.cam_target = main.world.pl; main.world.face = PI],
		["talk", func(): main.talk(0)],
		["talk_graph", func(): main.choices[0][1].call()],
		["talk_reveal", func(): main._reveal_all()],
		["talk_option", func(): main.choices[min(2, main.choices.size() - 1)][1].call(); main._reveal_all()],
		["thoughts", func(): root.get_node("Game").new_thought("quiet"); root.get_node("Game").new_thought("finger"); root.get_node("Game").pin_thought("quiet"); main.open_thoughts()],
		["character", func(): main.open_char()],
		["road", func(): main.close_modal(); main.road([])],
		["fight", func(): main._practice("bearers")],
		["fight_round", func(): main.choices[0][1].call()],
		["fight_round2", func(): main.choices[1][1].call()],
	]

func _process(_d: float) -> bool:
	f += 1
	var i := f / 20
	if f % 20 == 1 and i < steps.size():
		steps[i][1].call()
	if f % 20 == 15 and i < steps.size():
		var img := root.get_viewport().get_texture().get_image()
		img.save_png(out + "/" + str(i) + "_" + steps[i][0] + ".png")
	return i >= steps.size()
