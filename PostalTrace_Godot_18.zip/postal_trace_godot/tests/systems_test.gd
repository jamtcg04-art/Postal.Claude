extends SceneTree
## Checks the systems that run on the browser's own logic: a companion joining, the market's
## fight, the Provost's Gate and its fight, going back to a place, and a revolver in a fight.
##   godot --headless --path . -s res://tests/systems_test.gd
var main
var G
var D
var f := 0
var results: Array = []
func js(src: String) -> Variant:
	return D.js.call_fn(D.js.make_fn({ "$js": "function () { " + src + " }" }), [])
func _texts(n: Node, out: PackedStringArray) -> void:
	if n.is_queued_for_deletion(): return
	if (n is Label or n is RichTextLabel) and n.is_visible_in_tree(): out.append(n.text)
	for c in n.get_children(): _texts(c, out)
func page() -> String:
	var t := PackedStringArray(); _texts(main.page, t); return "\n".join(t)
func pick(word: String) -> bool:
	for c in main.choices:
		if c[0].is_queued_for_deletion(): continue
		var t := PackedStringArray(); _texts(c[0], t)
		if " ".join(t).to_lower().find(word.to_lower()) >= 0 and not c[2]:
			c[1].call(); return true
	for b in main.page.find_children("*", "Button", true, false):
		if not b.is_queued_for_deletion() and b.text.to_lower().find(word.to_lower()) >= 0 and not b.disabled and b.is_visible_in_tree():
			b.pressed.emit(); return true
	return false
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func fight_out(max_rounds := 40) -> String:
	for i in max_rounds:
		if main.phase != "page" or page().to_lower().find("· round") < 0:
			break
		var live = main.choices.filter(func(c): return not c[2])
		if live.is_empty(): break
		live[randi() % live.size()][1].call()
	return page().substr(0, 200)
func start(route: Array, idx: int) -> void:
	main.Game_begin()
	G.S.route = route; G.S.idx = idx; G.S.seen = idx
	G.S.pw = 4; G.S.hp = 8
func _initialize():
	seed(11)
	main = load("res://scenes/main.tscn").instantiate(); root.add_child(main)
func _process(_d):
	f += 1
	if f < 3:
		G = root.get_node("Game"); D = root.get_node("Data"); return false
	if f > 3:
		return true
	# 1. a companion: Wick at Linden Market
	start(["cross", "market", "ford", "oak", "ridge", "malice"], 1)
	G.S.talked["market:milky:g"] = true
	main.scene()
	var asked := pick("walk the road with you") or pick("Wick")
	check("Wick can be asked along", asked, "")
	if asked:
		pick("walk") ; pick("Come") ; pick("yes")
	check("Wick walks with you", str(G.S.get("comp")) == "wick", "comp=" + str(G.S.get("comp")))
	check("a companion adds to a skill", G.skill_parts("wits").any(func(p): return str(p[0]).find("Wick") >= 0), str(G.skill_parts("wits")))
	# 2. the market's fight (the Quarter Cut's yard)
	start(["cross", "market", "ford", "oak", "ridge", "malice"], 1)
	js("qcFight('called');")
	check("the Quarter Cut fight starts", page().to_lower().find("· round") >= 0, page().substr(0, 80).replace("\n", " | "))
	check("the Quarter Cut fight ends", fight_out().to_lower().find("· round") < 0, page().substr(0, 120).replace("\n", " | "))
	# 3. the Provost's Gate, and drawing on Lisle
	start(["cross", "checkpoint", "oak", "ridge", "malice"], 1)
	main.scene()
	check("the gate opens its standoff", page().find("Provost") >= 0, page().substr(0, 80).replace("\n", " | "))
	js("if (!S.cp) cpStart(); S.cp.sus = 7; cpFight('dev');")
	check("the gate fight starts", page().to_lower().find("· round") >= 0, page().substr(0, 80).replace("\n", " | "))
	check("the gate fight ends", fight_out().to_lower().find("· round") < 0, page().substr(0, 120).replace("\n", " | "))
	# 4. going back along the road
	start(["cross", "mill", "ford", "oak", "ridge", "malice"], 2)
	G.S.seen = 3
	js("backMenu();")
	check("the going-back menu", page().to_lower().find("back") >= 0, page().substr(0, 80).replace("\n", " | "))
	var went := pick("Cross-Pillars")
	check("walk back to Cross-Pillars", went and page().find("Cross-Pillars") >= 0, page().substr(0, 100).replace("\n", " | "))
	# 5. a revolver in a fight
	start(["cross", "bearers", "ford", "oak", "ridge", "malice"], 1)
	G.gain("revolver_a")
	js("if (typeof rvKitApply === 'function') rvKitApply();")
	main.resolve(D.scenes.bearers.choices[2], 2)
	var p := page()
	check("a revolver shows in a fight", p.to_lower().find("revolver") >= 0 or p.find("chamber") >= 0, "")
	fight_out()
	for r in results: print(r)
	print("WARNINGS:", D.js.warned.keys().filter(func(k): return not str(k).begins_with("m:test")))
	return false
