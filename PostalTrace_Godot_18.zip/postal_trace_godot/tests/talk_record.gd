extends SceneTree
## Plays every conversation with a seeded random state, seeded dice and seeded choices, and writes what
## was on the page at every step. Run it before and after a change to the dialogue code and compare.
##   godot --headless -s res://tests/talk_record.gd -- out.json [runs per conversation] [steps] [only-prefix]
var main
var out := []

func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	var path := a[0] if a.size() else "user://talk_record.json"
	var runs := int(a[1]) if a.size() > 1 else 2
	var steps := int(a[2]) if a.size() > 2 else 10
	var only := a[3] if a.size() > 3 else ""
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	var G = root.get_node("Game")
	var D = root.get_node("Data")
	var ids: Array = D.graphs.keys() if D.get("graphs") is Dictionary and not D.graphs.is_empty() else D.dialogue_ids()
	ids.sort()
	var rnd := RandomNumberGenerator.new()
	rnd.seed = 4242
	for id in ids:
		if only != "" and not String(id).begins_with(only): continue
		var parts: PackedStringArray = String(id).split(":")
		var scene: String = parts[0]
		var tid: String = parts[1]
		if scene.begins_with("back_") or scene.begins_with("fun_"): continue
		for k in runs:
			rnd.seed = hash(String(id)) + k   # each run on its own, so one run's length can't shift the next
			var s: Dictionary = G.new_state()
			s.trait = "steady"
			s.route = [scene]
			s.idx = 0
			for sk in ["arms", "nerve", "wits", "grit"]: s.up[sk] = rnd.randi_range(-1, 3)
			for v in ["ledger", "wire", "cipher", "parade", "bluff", "battery", "shoulder", "ramrod", "splinter", "longroad", "mud", "ringing"]:
				if rnd.randf() < 0.2: s.vr[v] = 1
			s.duty = rnd.randi_range(-2, 2); s.trust = rnd.randi_range(-2, 2); s.coin = rnd.randi_range(0, 7)
			if rnd.randf() < 0.3: s.inv.append("hat")
			if rnd.randf() < 0.2: s.done["cock_" + scene] = true
			for t in D.T.THOUGHTS:
				if rnd.randf() < 0.06: s.thoughts.append(t)
			G.set_state(s)
			G.rng.seed = 1000 + k
			G.addr_last = {}
			main.seen_lines = {}
			var ti: Variant
			if tid.begins_with("x_"):
				ti = tid.substr(2)
			else:
				ti = -1
				var ts: Array = G.talkers()
				for i in ts.size():
					if str(ts[i].id) == tid: ti = i
				if ti == -1: continue
			var hub: String = main.conversation_hub(scene, tid)
			main.graph_show(ti, hub, {})
			var run := {"conv": id, "k": k, "steps": [_snap()], "picks": []}
			for st in steps:
				if main.phase != "talk": break
				var live: Array = []
				for i in main.choices.size():
					var c: Array = main.choices[i]
					if not c[2] and is_instance_valid(c[0]): live.append(i)
				if live.is_empty(): break
				var pick: int = live[rnd.randi_range(0, live.size() - 1)]
				run.picks.append(pick)
				main.choices[pick][1].call()
				for f in 2: await process_frame
				run.steps.append(_snap())
			out.append(run)
	var f := FileAccess.open(path, FileAccess.WRITE)
	f.store_string(JSON.stringify(out, " "))
	f.close()
	print("talk_record: %d runs written to %s" % [out.size(), path])
	quit()

func _snap() -> Dictionary:
	var t: Array = []
	_texts(main.page, t)
	return {"phase": main.phase, "page": t}

func _texts(n: Node, out2: Array) -> void:
	if n.is_queued_for_deletion(): return
	if n is Button: out2.append("[B] " + n.text + (" (off)" if n.disabled else ""))
	elif n is RichTextLabel: out2.append(n.get_parsed_text())
	elif n is Label: out2.append(n.text)
	for c in n.get_children(): _texts(c, out2)
