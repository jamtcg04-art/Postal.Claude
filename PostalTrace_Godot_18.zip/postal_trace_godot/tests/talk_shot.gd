extends SceneTree
## A picture of a conversation: xvfb-run godot -s res://tests/talk_shot.gd -- <scene> <who> out.png [picks…]
func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	root.size = Vector2i(1400, 860)
	var main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	for i in 5: await process_frame
	var G = root.get_node("Game")
	G.begin_run({"trait": "steady", "up": {"arms": 1, "nerve": 2, "wits": 2, "grit": 2}, "arch": "gunner", "left": 0})
	G.S.route = [a[0]]; G.S.idx = 0
	var ti = -1
	var ts: Array = G.talkers()
	for i in ts.size(): if str(ts[i].id) == a[1]: ti = i
	main.graph_show(ti, main.conversation_hub(a[0], a[1]), {})
	for p in a.slice(3):
		await _beats(main)
		main.choices[int(p)][1].call()
	await _beats(main)
	for i in 10: await process_frame
	main.scroll.scroll_vertical = int(main.scroll.get_v_scroll_bar().max_value * float(OS.get_environment("SHOT_SCROLL") if OS.get_environment("SHOT_SCROLL") != "" else "0"))
	for i in 20: await process_frame
	root.get_texture().get_image().save_png(a[2])
	print("saved ", a[2])
	quit()
func _beats(main) -> void:
	for i in 10: await process_frame
	if main.beat_btn != null: main._reveal_all()
	for i in 10: await process_frame
