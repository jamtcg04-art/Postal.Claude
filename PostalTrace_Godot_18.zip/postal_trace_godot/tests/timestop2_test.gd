extends SceneTree
## The quick draw played with the story put away, time stopping before the shot, and the voices weighing in after.
##   PT_CUT=1 godot --headless -s res://tests/timestop_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(c: Node) -> String:
	var t := ""
	if c is RichTextLabel: t += c.get_parsed_text() + " | "
	elif c is Label or c is Button: t += str(c.text) + " | "
	for k in c.get_children(): t += _texts(k)
	return t
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			var h: String = str(root.get_node("Bridge").call_js("smallVerdict", [{ "t": "Throw them a coin and walk on" }, false]))
			_check("a small choice gets the voices' word (shared code)", h.find("fair toll") >= 0, h.substr(0, 120))
			G.S.route = ["oak"]; G.S.idx = 0; G.S.pw = 3
			main.scene(),
		func(): main._choose(root.get_node("Data").scenes.oak.choices[3], 3),
		"t2800",
		func():
			_check("oak: time stops before the shot over their heads", main.ts_box != null and not main.scroll.visible)
			for i in 3: main.ts_step(),
		"t200",
		func():
			var t: String = _texts(main.ts_box) if main.ts_box else ""
			_check("oak: the Ramrod and the Battery", t.find("RAMROD") >= 0 and t.find("THIRD BATTERY") >= 0, t.substr(0, 100))
			for i in 8: main.ts_step(),
		"t1600",
		func():
			for i in 8:
				if main.beat_btn != null: main._next_beat()
			var t: String = _texts(main.page)
			_check("oak: the result, and the voices on it", main.scroll.visible and (t.find("Over their heads, not into them") >= 0 or t.find("Ragged") >= 0), t.substr(0, 160))
			G.S.route = ["bearers"]; G.S.idx = 0
			main.scene(),
		func(): main._choose(root.get_node("Data").scenes.bearers.choices[2], 2),
		"t3000",
		"t3000",
		"t3000",
		"t3000",
		"t1500",
		func():
			var t: String = _texts(main.ts_box) if main.ts_box else ""
			_check("bearers: time stops as the treeline moves", main.ts_box != null and t.find("TREELINE") >= 0, t.substr(0, 80))
			for i in 8: main.ts_step(),
		"t800",
		func():
			var t: String = _texts(main.page)
			_check("bearers: then the fight", t.to_lower().find("round 1") >= 0, t.substr(0, 120)),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if has_meta("until"):
		if Time.get_ticks_msec() < int(get_meta("until")): return false
		remove_meta("until")
	if steps.is_empty():
		print("TIMESTOP 2: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String:
		set_meta("until", Time.get_ticks_msec() + int(s.substr(1)))
	else:
		s.call()
		set_meta("until", Time.get_ticks_msec() + 80)
	return false
