extends SceneTree
## The quick draw's stand-off, the stopped moment and the shot (needs a display): godot -s res://tests/timestop_shots.gd -- <outdir>
var main
var G
var f := 0
var out := ""
var steps: Array = []
var wait := 0
func shot(name: String) -> void:
	root.get_viewport().get_texture().get_image().save_png(out + "/ts_" + name + ".png")
func _initialize():
	out = OS.get_cmdline_user_args()[0]
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.Game_begin()
			G.S.route = ["cross"]; G.S.idx = 0; G.S.pw = 3
			main.scene(),
		"w60", func(): main._choose(root.get_node("Data").scenes.cross.choices[0], 0),
		"w60", func(): shot("standoff"),
		"w400", func(): shot("stop1"); for i in 7: main.ts_step(),
		"w30", func(): shot("stop_all"); main.ts_step(),
		"w25", func(): shot("shot"),
		"w300", func(): shot("result"),
	]
func _process(_d):
	f += 1
	if wait > 0:
		wait -= 1
		return false
	if steps.is_empty():
		quit(); return true
	var s = steps.pop_front()
	if s is String: wait = int(s.substr(1))
	else: s.call()
	return false
