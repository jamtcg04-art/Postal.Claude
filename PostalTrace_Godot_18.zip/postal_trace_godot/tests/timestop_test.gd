extends SceneTree
## The quick draw played with the story put away, time stopping before the shot, and the voices weighing in after.
##   PT_CUT=1 godot --headless -s res://tests/timestop_test.gd
var main
var f := 0
var ok := 0
var n := 0
var steps: Array = []
var G
func _check(name: String, cond: bool, note: Variant = "") -> void:
	n += 1
	if cond: ok += 1
	print(("PASS " if cond else "FAIL ") + name + ("  " + str(note) if str(note) != "" else ""))
func _texts(c: Node) -> String:
	var t := ""
	if c is RichTextLabel: t += c.get_parsed_text() + " | "
	elif c is Label or c is Button: t += str(c.text) + " | "
	for k in c.get_children(): t += _texts(k)
	return t
func _initialize():
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
	steps = [
		func():
			G = root.get_node("Game")
			main.three_d = true
			main.Game_begin()
			G.S.route = ["cross"]; G.S.idx = 0; G.S.pw = 3
			main.scene(),
		func():
			var ch: Dictionary = root.get_node("Data").scenes.cross.choices[0]
			main._choose(ch, 0),
		"t300",
		func():
			_check("the story is put away for the stand-off", not main.scroll.visible and main._cine_bars.size() == 2 and main._cine_bars[0].visible),
		"t1500",
		func(): print("DBG ", main.world.scenes._so, " pl=", main.world.pl, " goal=", main.world.goal, " active=", main.world.active, " t=", main.world.scenes.t),
		"t6500",
		func():
			_check("time stops: the world is still and grey", main.ts_box != null and main.world.process_mode == Node.PROCESS_MODE_DISABLED and main.world_view.material != null)
			for i in 7: main.ts_step(),
		"t200",
		func():
			var t: String = _texts(main.ts_box) if main.ts_box else ""
			_check("the Ramrod, the Cockade and the Battery speak", t.find("RAMROD") >= 0 and t.find("COCKADE") >= 0 and t.find("THIRD BATTERY") >= 0, t.substr(0, 120))
			_check("the last button pulls the trigger", t.find("Pull the trigger") >= 0)
			main.ts_step(),
		"t300",
		func():
			_check("the shot plays with the story still away", main.ts_box == null and main.world.process_mode == Node.PROCESS_MODE_INHERIT and not main.scroll.visible),
		"t4800",
		func():
			for i in 8:
				if main.beat_btn != null: main._next_beat()
			var t: String = _texts(main.page)
			_check("then the result comes back, and the voices weigh in", main.scroll.visible and (t.find("Clean. Now reload") >= 0 or t.find("skipped the breath") >= 0), t.substr(0, 200)),
	]
func _process(_d):
	f += 1
	if f < 3: return false
	if has_meta("until"):
		if Time.get_ticks_msec() < int(get_meta("until")): return false
		remove_meta("until")
	if steps.is_empty():
		print("TIMESTOP: %d/%d" % [ok, n]); quit(); return true
	var s = steps.pop_front()
	if s is String:
		set_meta("until", Time.get_ticks_msec() + int(s.substr(1)))
	else:
		s.call()
		set_meta("until", Time.get_ticks_msec() + 80)
	return false
