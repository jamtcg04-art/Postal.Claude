extends SceneTree
## Touch and comfort: voice lines wait in the ring and open with V or the voice button; pinch zooms and
## a two-finger twist turns the view; a second tap runs; the phone layout; text size, colours and button
## size settings; remapping a key.
##   godot --headless --path . -s res://tests/touch_test.gd
var main
var G
var f := 0
var results: Array = []
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func key(k: int) -> void:
	var e = InputEventKey.new(); e.keycode = k; e.physical_keycode = k; e.pressed = true
	Input.parse_input_event(e)
	var u = InputEventKey.new(); u.keycode = k; u.physical_keycode = k; u.pressed = false
	Input.parse_input_event(u)
func touch(i: int, pos: Vector2, down: bool) -> void:
	var e = InputEventScreenTouch.new(); e.index = i; e.position = pos; e.pressed = down
	main.world.pointer(e, pos)
func drag(i: int, pos: Vector2) -> void:
	var e = InputEventScreenDrag.new(); e.index = i; e.position = pos
	main.world.pointer(e, pos)
func _initialize():
	main = load("res://scenes/main.tscn").instantiate(); root.add_child(main)
func _process(_d):
	f += 1
	if f == 3:
		G = root.get_node("Game")
		main.Game_begin()
		G.S.route = ["cross", "market", "ford"]; G.S.idx = 0; G.S.seen = 0
		main.scene()
		return false
	if f == 6:
		var w = main.world
		# a voice's line about someone waits in the ring instead of being spoken over them
		w.barks = { "fowler": [{ "v": "splinter", "min": 0, "text": "A pinch under the scar." }] }
		w.bark_seen.clear()
		for k in w.picks:
			if k.id == "fowler":
				w.pl = k.node.global_position + Vector3(1.0, 0, 0)
		w.bark_t = 0.0
		w._update_barks(0.1)
		check("a voice's bark waits in the ring", w.vq.size() == 1 and w.vq[0].v == "splinter" and not w.bark_label.visible, str(w.vq))
		main.vring._refresh()
		check("the ring shows over the courier", main.vring.ring.visible)
		main.vring.show_button = "on"
		main.vring._refresh()
		check("the voice button shows when asked for", main.vring.button.visible and main.vring.button.text.contains("has something to say"))
		main.vring.show_button = "off"
		main.vring._refresh()
		check("and not when turned off", not main.vring.button.visible)
		key(KEY_V)
		return false
	if f == 8:
		check("V opens the line", main.vring.say.visible and main.vring.say_text.text.contains("pinch under the scar") and main.world.vq.is_empty())
		check("the same line does not come back", (func():
			main.world.bark_seen.clear(); main.world._update_barks(0.1); return main.world.vq.is_empty()).call())
		# pinch and twist
		var w = main.world
		var z0 = w.zoom; var y0 = w.yaw
		touch(0, Vector2(100, 100), true)
		touch(1, Vector2(200, 100), true)
		drag(1, Vector2(200, 100))
		drag(1, Vector2(150, 150))
		check("pinching the fingers together zooms out", w.zoom > z0, "%.2f -> %.2f" % [z0, w.zoom])
		check("twisting two fingers turns the view", absf(wrapf(w.yaw - y0, -PI, PI)) > 0.3, "%.2f" % wrapf(w.yaw - y0, -PI, PI))
		check("the first finger's tap does not walk", w.goal == null)
		touch(1, Vector2(150, 150), false); touch(0, Vector2(100, 100), false)
		# a second tap soon after runs
		w.input_locked = false
		w._last_click = 0
		w._path(Vector2(w.pl.x, w.pl.z), Vector2(w.pl.x + 3, w.pl.z))   # the place's walking grid is built once, on the first walk
		w._click(Vector2(60, 60))
		w._click(Vector2(60, 60))
		check("a second tap runs", w.goal != null and w.goal.get("run", false), "hover=%s mouse=%s goal=%s" % [w.hover, w._mouse, w.goal])
		# settings
		main._display_set("text", 1.3)
		return false
	if f == 10:
		check("text size scales the fonts", main.fs(20) == 26 and main.theme.default_font_size == 25)
		main._display_set("palette", "contrast")
		return false
	if f == 12:
		check("colours change", main.COL.text == Color("ffffff"))
		main._display_set("buttons", "on")
		return false
	if f == 14:
		check("large buttons", main.big_buttons and main.theme.get_stylebox("normal", "Button").content_margin_top >= 14)
		main._display_set("text", 1.0); main._display_set("palette", "parchment"); main._display_set("buttons", "auto")
		# remap the voice key
		Controls.set_key("voice", KEY_B)
		check("a key can be remapped", Controls.key_of("voice") == KEY_B and Controls.key_name("voice") == "B")
		Controls.reset()
		check("and reset", Controls.key_of("voice") == KEY_V)
		for r in results: print(r)
		print("TOUCH: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
		return true
	return false
