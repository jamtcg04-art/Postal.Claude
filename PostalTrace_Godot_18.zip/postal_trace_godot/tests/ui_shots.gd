extends SceneTree
## Screenshots of the phone layout, the voice ring and button, and the settings (needs a display):
##   godot --resolution 390x844 -s res://tests/ui_shots.gd -- <outdir> <name>
var main
var f := 0
var out := "/tmp"
var name := "ui"
func _initialize():
	var a = OS.get_cmdline_user_args()
	if a.size(): out = a[0]
	if a.size() > 1: name = a[1]
	main = load("res://scenes/main.tscn").instantiate(); root.add_child(main)
func _process(_d):
	f += 1
	var G = root.get_node("Game")
	if f == 3:
		main.Game_begin()
		G.S.route = ["cross", "market", "ford"]; G.S.idx = 0; G.S.seen = 0
		main.scene()
	if f == 8:
		main.world.pl = Vector3(-2, 0, -4)
		main.vring.show_button = "on"
		main.world.ring_push("splinter", "A pinch under the scar. His barrels are on you, but his eyes keep going to the tavern. Not the porch. The window.", "t1")
		main.world.ring_push("duty", "The toll is not lawful. Note it.", "t2")
	if f == 30:
		root.get_viewport().get_texture().get_image().save_png(out + "/" + name + "_ring.png")
		main.vring.open_next()
	if f == 40:
		root.get_viewport().get_texture().get_image().save_png(out + "/" + name + "_say.png")
		main.open_menu()
	if f == 50:
		root.get_viewport().get_texture().get_image().save_png(out + "/" + name + "_menu.png")
		for c in main.mpage.get_children():
			if c is Label and c.text == "TEXT AND BUTTONS":
				main.mscroll.scroll_vertical = int(c.position.y) - 10
	if f == 54:
		root.get_viewport().get_texture().get_image().save_png(out + "/" + name + "_settings.png")
		main._display_set("text", 1.3)
	if f == 62:
		main.close_modal()
	if f == 70:
		root.get_viewport().get_texture().get_image().save_png(out + "/" + name + "_large.png")
		main._display_set("text", 1.0)
		return true
	return false
