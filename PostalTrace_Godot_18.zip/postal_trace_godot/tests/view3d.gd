extends SceneTree
## Renders a few converted models and the person, for a quick look: needs a display.
var f := 0
var out := ""
func _initialize() -> void:
	out = OS.get_cmdline_user_args()[0] if OS.get_cmdline_user_args().size() else "user://"
	var w := Node3D.new()
	root.add_child(w)
	var env := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.12, 0.15, 0.17)
	e.ambient_light_color = Color(0.6, 0.6, 0.6)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.environment = e
	w.add_child(env)
	var sun := DirectionalLight3D.new()
	sun.rotation = Vector3(-0.9, 0.6, 0)
	w.add_child(sun)
	var x := -9.0
	for n in ["mvh_house1", "mm_stall_meat", "tent", "barrel", "rp_s0", "mn_wall_a", "palisade", "well"]:
		var p := "res://assets/3d/models/%s.glb" % n
		if not ResourceLoader.exists(p):
			print("missing ", n)
			continue
		var inst: Node3D = load(p).instantiate()
		w.add_child(inst)
		var aabb := _aabb(inst)
		var s: float = 2.5 / max(0.01, max(aabb.size.x, max(aabb.size.y, aabb.size.z)))
		inst.scale = Vector3.ONE * s
		inst.position = Vector3(x, 0, 0) - aabb.position * s - Vector3(aabb.size.x * s / 2, 0, aabb.size.z * s / 2)
		x += 3.0
	var person: Node3D = load("res://assets/3d/people/person.glb").instantiate()
	w.add_child(person)
	person.position = Vector3(0, 0, 3)
	for c in person.find_children("*", "MeshInstance3D", true, false):
		c.visible = c.name == "Figure" or c.name == "part_hat" or c.name == "part_skirt"
	var ap: AnimationPlayer = person.find_child("AnimationPlayer", true, false)
	if ap:
		print("animations: ", ap.get_animation_list().size())
		ap.play("walk")
	var soldier: Node3D = load("res://assets/3d/people/person.glb").instantiate()
	w.add_child(soldier)
	soldier.position = Vector3(2, 0, 3)
	for c in soldier.find_children("*", "MeshInstance3D", true, false):
		c.visible = c.name == "Body_soldier_g"
	var ap2: AnimationPlayer = soldier.find_child("AnimationPlayer", true, false)
	if ap2:
		ap2.play("talk")
	var cam := Camera3D.new()
	w.add_child(cam)
	cam.position = Vector3(0, 6, 13)
	cam.look_at(Vector3(0, 1, 0))

func _aabb(n: Node) -> AABB:
	var box := AABB()
	var first := true
	for m in n.find_children("*", "MeshInstance3D", true, false):
		var b: AABB = m.get_aabb()
		if first:
			box = b
			first = false
		else:
			box = box.merge(b)
	return box

func _process(_d: float) -> bool:
	f += 1
	if f == 40:
		root.get_viewport().get_texture().get_image().save_png(out + "/view3d.png")
		return true
	return false
