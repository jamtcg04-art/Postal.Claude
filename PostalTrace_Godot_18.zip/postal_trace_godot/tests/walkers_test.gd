extends SceneTree
## Linden's townsfolk walk the streets and stop to look at you; Goodwife Marl walks her stalls and
## comes back; old people stoop.
##   godot --headless --path . -s res://tests/walkers_test.gd
var w
var f := 0
var results: Array = []
var start: Dictionary = {}
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		var G = root.get_node("Game")
		G.begin_run({ "trait": "steady" }); G.S.route = ["cross", "market"]; G.S.idx = 1
		w = load("res://scripts/world/world.gd").new()
		root.add_child(w)
		return false
	if f == 3:
		w.enter("market")
		w.pl = Vector3(0, 0, -30)
		return false
	if f == 5:
		var fx = w.fx
		check("seven townsfolk out on the streets", fx.walkers.size() == 7 and fx.spots.size() > 10, "%d walkers, %d spots" % [fx.walkers.size(), fx.spots.size()])
		check("dressed by the browser's clothing code", fx.walkers.all(func(e): return e.node.get_meta("look").o.get("fit") is Dictionary))
		check("the old one stoops", fx.walkers.any(func(e): return e.w.get("old") and e.node.get_meta("look").o.get("stoop") == 1))
		for e in fx.walkers: start[e.k] = e.node.position
		return false
	if f > 5 and f < 400:
		w.fx._process(0.05)
		if f == 7:
			w.fx.marl.t = 0.0
		if f == 140:
			var n: Node3D = w.fx.marl.node
			check("Marl leaves her board for another stall", w.fx.marl.st in ["walk", "stop"] and Vector2(n.position.x, n.position.z).distance_to(Vector2(8.2, 24.6)) > 0.5, "%s at %s" % [w.fx.marl.st, n.position])
			check("and you can walk through her place while she is away", not w._blocked(8.2, 24.6, 0.0))
		return false
	if f == 400:
		var fx = w.fx
		var moved = fx.walkers.filter(func(e): return e.node.position.distance_to(start[e.k]) > 2.0).size()
		check("they walk about", moved >= 4, "%d of 7 moved" % moved)
		check("they keep off the walls", fx.walkers.all(func(e): return not w._blocked(e.node.position.x, e.node.position.z, -0.05)))
		var n: Node3D = fx.marl.node
		check("and comes back to it", fx.marl.st == "home" and Vector2(n.position.x, n.position.z).distance_to(Vector2(8.2, 24.6)) < 0.05 and w._blocked(8.2, 24.6, 0.0), "%s at %s" % [fx.marl.st, n.position])
		# come close to a walker: they stop and look
		var e = fx.walkers[0]
		e.seen_t = -99.0
		w.pl = e.node.position + Vector3(1.0, 0, 0)
		fx._process(0.05)
		check("come close and they stop and look at you", e.stop_t > 0.0 and e.goal == null and absf(wrapf(e.node.rotation.y - atan2(1.0, 0.0), -PI, PI)) < 0.2)
		for r in results: print(r)
		print("WALKERS: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
		return true
	return false
