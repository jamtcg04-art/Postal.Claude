extends SceneTree
## Walks the courier to each person in Cross-Pillars through the 3D view and checks the conversation opens.
var main
var f := 0
var picks: Array = []
var k := 0
var waiting := 0
var ok := 0
func _initialize() -> void:
	main = load("res://scenes/main.tscn").instantiate()
	root.add_child(main)
func _process(_d: float) -> bool:
	f += 1
	if f == 3:
		main.Game_begin()
		main.feeling_pick(0)
		picks = main.world.picks.filter(func(p): return p.kind == "person")
		print("phase ", main.phase, " world file ", main.world.file, " people ", picks.size())
		return false
	if f < 4:
		return false
	if waiting == 0:
		if k >= picks.size():
			print("CLICK TEST: ", ok, "/", picks.size(), " conversations opened from the 3D view")
			return true
		main.scene()
		main.world.approach(picks[k])
		waiting = 1
		return false
	waiting += 1
	if main.phase == "talk" or (main.phase == "other" and main.page.get_child_count() > 0 and waiting > 2 and main.world.goal == null):
		print("  ", picks[k].id, " -> ", main.phase)
		if main.phase in ["talk", "other"]:
			ok += 1
		k += 1
		waiting = 0
	elif waiting > 20000:
		print("  ", picks[k].id, " -> timed out, phase ", main.phase)
		k += 1
		waiting = 0
	return false
