These Node scripts produced data/ from the browser build (index.html). You only need them to re-export
after changing the browser version, which keeps the two builds the same. They need Node 18+ and the
acorn and acorn-walk packages.

  SRC=path/to/index.html node tools/export.js data          # tables, scenes, portraits (its graphs/ output is
                                                             # no longer used: conversations live in dialogue/*.pt)
  SRC=path/to/index.html node tools/scope.js                 # lists the game's names (for the next step)
  SRC=path/to/index.html node tools/export_lib.js data      # data/lib.json: all the game logic that is not 3D
  SRC=path/to/index.html node tools/equiv_node.js tests/equiv_node.json
  SRC=path/to/index.html W3D_DIR=path/to/w3d_files node tools/edit_ids.js tests/edit_ids.json   # how the browser's editor keys each place's things
  SRC=path/to/index.html node tools/browser_save.js tests/browser_save.json [a Godot save]   # a save made by the browser; checks it loads a Godot save

The 3D export (needs the original's assets/w3d_*.js files in one folder):

  SRC=path/to/index.html W3D_DIR=path/to/w3d_files node tools/places_export.js .
  godot --headless -s res://tools/bake_places.gd        # rebuilds places/*.tscn (overwrites edits)

Conversations (dialogue/*.pt) have their own tools in tools/dialogue/ (Node 18+; extract and the browser checks
also need Playwright with Chromium):

  node tools/dialogue/compile.js --godot . [--browser path/to/index.html] [--svg]   # check, compile, report
  node tools/dialogue/patch_browser.js index.html .dialogue_build/browser/pt_dialogue.gen.js out.html
  node tools/dialogue/roundtrip.js .dialogue_build/compiled_all.json      # scripts read back exactly
  node tools/dialogue/equiv_browser.js index.html .dialogue_build/compiled_all.json 150   # compiled = original logic
  node tools/dialogue/parity_record.js index.html tests/fixtures/browser_talks.json 3 12  # record browser play
  node tools/dialogue/port_import.js . out.json    # read old data/graphs files into scripts (done once)
