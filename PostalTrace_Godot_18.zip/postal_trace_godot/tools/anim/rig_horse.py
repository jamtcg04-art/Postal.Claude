#!/usr/bin/env python3
"""Give the game's own horse (assets/3d/models/cp_horse*.glb) a skeleton and movements.

The source model is one mesh with no bones. This writes cp_horse_rig.glb (and the grey one) with the same
mesh, textures and materials, plus:
  - a skeleton: root, hips, chest, two neck bones, head, two tail bones, and three bones per leg;
  - skin weights worked out from where each vertex sits (legs by column and height, neck and head by
    distance along the neck, tail behind the rump), blended at the joints;
  - movements: idle, walk, trot, gallop, rear, pull (walk in harness), and stand_shy (a startled step back).

It is plain glTF, so Blender opens it to repaint weights or re-key movements; Godot imports it as a
Skeleton3D with an AnimationPlayer.   python3 tools/anim/rig_horse.py [project dir]
"""
import json, math, struct, sys, os
import numpy as np

ROOT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', '..')
MODELS = os.path.join(ROOT, 'assets', '3d', 'models')

CT = {5126: np.float32, 5123: np.uint16, 5125: np.uint32, 5121: np.uint8}
NC = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}


def read_glb(p):
    b = open(p, 'rb').read()
    ln = struct.unpack('<I', b[12:16])[0]
    j = json.loads(b[20:20 + ln])
    off = 20 + ln
    bl = struct.unpack('<I', b[off:off + 4])[0]
    return j, bytearray(b[off + 8:off + 8 + bl])


def write_glb(p, j, binb):
    while len(binb) % 4:
        binb.append(0)
    j['buffers'] = [{'byteLength': len(binb)}]
    js = json.dumps(j, separators=(',', ':')).encode()
    while len(js) % 4:
        js += b' '
    total = 12 + 8 + len(js) + 8 + len(binb)
    with open(p, 'wb') as f:
        f.write(struct.pack('<III', 0x46546C67, 2, total))
        f.write(struct.pack('<II', len(js), 0x4E4F534A)); f.write(js)
        f.write(struct.pack('<II', len(binb), 0x004E4942)); f.write(binb)


def acc_read(j, binb, i):
    a = j['accessors'][i]; bv = j['bufferViews'][a['bufferView']]
    o = bv.get('byteOffset', 0) + a.get('byteOffset', 0); n = a['count'] * NC[a['type']]
    arr = np.frombuffer(bytes(binb), dtype=CT[a['componentType']], count=n, offset=o)
    return arr.reshape(a['count'], NC[a['type']]) if NC[a['type']] > 1 else arr


def add_acc(j, binb, arr, ctype, atype, target=None, minmax=False):
    while len(binb) % 4:
        binb.append(0)
    data = np.ascontiguousarray(arr.astype(CT[ctype])).tobytes()
    bv = {'buffer': 0, 'byteOffset': len(binb), 'byteLength': len(data)}
    if target:
        bv['target'] = target
    binb.extend(data)
    j['bufferViews'].append(bv)
    a = {'bufferView': len(j['bufferViews']) - 1, 'componentType': ctype, 'count': int(arr.shape[0]), 'type': atype}
    if minmax:
        flat = arr.reshape(arr.shape[0], -1)
        a['min'] = [float(x) for x in flat.min(0)]; a['max'] = [float(x) for x in flat.max(0)]
    j['accessors'].append(a)
    return len(j['accessors']) - 1


def quat_axis(axis, ang):
    ax = np.array(axis, float); ax /= np.linalg.norm(ax)
    s = math.sin(ang / 2)
    return [ax[0] * s, ax[1] * s, ax[2] * s, math.cos(ang / 2)]


def qmul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return [aw * bx + ax * bw + ay * bz - az * by, aw * by - ax * bz + ay * bw + az * bx,
            aw * bz + ax * by - ay * bx + az * bw, aw * bw - ax * bx - ay * by - az * bz]


def rotx(a): return quat_axis([1, 0, 0], a)
def roty(a): return quat_axis([0, 1, 0], a)
def rotz(a): return quat_axis([0, 0, 1], a)


def qrot(q, v):
    x, y, z, w = q
    u = np.array([x, y, z]); v = np.array(v, float)
    return v + 2 * np.cross(u, np.cross(u, v) + w * v)


# ---------------------------------------------------------------- the skeleton (the model's own units: about 1 = 1 cm)
X0 = 271.0
LEGS = {   # name: (x, z, top y, parent)
    'fl': (285.0, 10.4, 70.0, 'chest'), 'fr': (257.7, 10.6, 70.0, 'chest'),
    'hl': (291.9, -74.0, 84.0, 'hips'), 'hr': (249.0, -73.5, 84.0, 'hips'),
}
J = [  # name, parent, position (model space)
    ('root', None, (X0, 70.0, -30.0)),
    ('hips', 'root', (X0, 88.0, -72.0)),
    ('chest', 'root', (X0, 88.0, 8.0)),
    ('neck1', 'chest', (X0, 100.0, 26.0)),
    ('neck2', 'neck1', (X0, 122.0, 40.0)),
    ('head', 'neck2', (X0, 140.0, 50.0)),
    ('tail1', 'hips', (X0, 95.0, -106.0)),
    ('tail2', 'tail1', (X0, 62.0, -113.0)),
]
for k, (x, z, top, par) in LEGS.items():
    J += [(k + '_up', par, (x, top, z)), (k + '_knee', k + '_up', (x, 24.0, z)), (k + '_fet', k + '_knee', (x, -9.0, z))]
JI = {n: i for i, (n, _, _) in enumerate(J)}
JP = {n: np.array(p) for n, _, p in J}
SADDLE = (X0, 104.0, -34.0)


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def weights(P):
    """Up to four (joint, weight) pairs for every vertex."""
    n = len(P); W = np.zeros((n, len(J)))
    x, y, z = P[:, 0], P[:, 1], P[:, 2]
    # body: hips behind, chest in front, blended across the barrel
    fr = smooth(-55.0, -5.0, z)
    W[:, JI['hips']] = 1 - fr; W[:, JI['chest']] = fr
    # neck and head, along the neck from the withers to the poll
    neckzone = (z > 14.0) & (y > 86.0)
    s = np.where(neckzone, 1.0, 0.0)
    a1 = smooth(14.0, 30.0, z); a2 = smooth(32.0, 44.0, z); a3 = smooth(44.0, 54.0, z)
    wn1 = s * a1 * (1 - a2); wn2 = s * a2 * (1 - a3); wh = s * a3
    body = 1 - s * a1
    W *= body[:, None]
    W[:, JI['neck1']] += wn1; W[:, JI['neck2']] += wn2; W[:, JI['head']] += wh
    # tail, behind the rump
    tz = smooth(-100.0, -108.0, z)
    t2 = tz * smooth(80.0, 64.0, y)
    W *= (1 - tz)[:, None]
    W[:, JI['tail1']] += tz - t2; W[:, JI['tail2']] += t2
    # legs: the nearest column below the belly
    for k, (lx, lz, top, par) in LEGS.items():
        d = np.hypot(x - lx, z - lz)
        inleg = (d < 19.0) & (y < top + 2.0)
        # where the leg joins the body, share with the body
        joinw = smooth(top + 2.0, top - 14.0, y)
        m = np.where(inleg, joinw, 0.0)
        up = smooth(14.0, 32.0, y); kn = smooth(-16.0, -2.0, y) * (1 - up)
        ft = 1 - smooth(-16.0, -2.0, y)
        W *= (1 - m)[:, None]
        W[:, JI[k + '_up']] += m * up; W[:, JI[k + '_knee']] += m * kn; W[:, JI[k + '_fet']] += m * ft
    # keep the four largest, normalised
    idx = np.argsort(-W, axis=1)[:, :4]
    wv = np.take_along_axis(W, idx, axis=1)
    wv = np.where(wv < 1e-3, 0, wv)
    sm = wv.sum(1, keepdims=True); sm[sm == 0] = 1
    wv = wv / sm
    idx = np.where(wv > 0, idx, 0)
    return idx.astype(np.uint8), wv.astype(np.float32)


# ---------------------------------------------------------------- movements
def gait(T, ph, amp, knee, bob, nod, pitch=0.0, frames=24, tail=0.15):
    """A looping gait: leg phases ph (fraction of the cycle), swing amplitude, knee lift, body bob and head nod."""
    keys = {}
    ts = [T * i / frames for i in range(frames + 1)]
    for t in ts:
        f = {}
        for k in LEGS:
            phi = 2 * math.pi * (t / T + ph[k])
            sw = -amp * math.sin(phi)               # negative = reaching forward
            lift = max(0.0, math.cos(phi)) ** 1.5    # the leg is in the air while it swings forward
            hind = k[0] == 'h'
            f[k + '_up'] = rotx(sw)
            f[k + '_knee'] = rotx((-1 if hind else 1) * knee * lift)
            f[k + '_fet'] = rotx((1 if hind else -1) * knee * 0.6 * lift)
        root_y = bob * math.sin(4 * math.pi * t / T)
        f['root_t'] = (0.0, root_y, 0.0)
        f['root'] = rotx(pitch * math.sin(2 * math.pi * t / T))
        f['neck1'] = rotx(nod * math.sin(4 * math.pi * t / T + 0.6))
        f['head'] = rotx(-nod * 0.5 * math.sin(4 * math.pi * t / T + 0.6))
        f['tail1'] = qmul(rotx(-0.25), roty(tail * math.sin(2 * math.pi * t / T)))
        f['tail2'] = roty(tail * 1.3 * math.sin(2 * math.pi * t / T - 0.8))
        keys[t] = f
    return keys


def idle():
    keys = {}
    T = 6.0
    for i in range(61):
        t = T * i / 60
        f = {}
        br = math.sin(2 * math.pi * t / 3.0)
        f['root_t'] = (0.0, 0.25 * br, 0.0)
        f['chest'] = rotx(0.01 * br)
        toss = math.sin(math.pi * min(1.0, max(0.0, (t - 1.0) / 1.2)))   # a toss of the head, once a cycle
        graze = math.sin(math.pi * min(1.0, max(0.0, (t - 3.4) / 2.0)))   # then the head goes down a little
        f['neck1'] = rotx(-0.10 * toss + 0.35 * graze)
        f['neck2'] = rotx(0.12 * graze)
        f['head'] = qmul(rotx(0.08 * toss - 0.10 * graze), roty(0.06 * math.sin(2 * math.pi * t / 6.0)))
        sw = math.sin(2 * math.pi * t / 2.0) * (0.5 + 0.5 * math.sin(2 * math.pi * t / 6.0))
        f['tail1'] = qmul(rotx(-0.15), roty(0.28 * sw))
        f['tail2'] = roty(0.35 * sw)
        rest = 0.12 * max(0.0, math.sin(2 * math.pi * t / 6.0))       # resting one hind hoof
        f['hl_up'] = rotx(0.02); f['hl_knee'] = rotx(-0.25 * rest); f['hl_fet'] = rotx(0.35 * rest)
        for k in LEGS:
            f.setdefault(k + '_up', rotx(0)); f.setdefault(k + '_knee', rotx(0)); f.setdefault(k + '_fet', rotx(0))
        keys[t] = f
    return keys


def rear():
    """Up on the hind legs and down again (2 s): an ambush, a shot, a horse refusing."""
    keys = {}
    pivot = np.array([X0, -25.0, -74.0])     # the hind hooves stay on the ground
    r0 = JP['root']
    for i in range(41):
        t = 2.0 * i / 40
        up = math.sin(math.pi * min(1.0, t / 1.6)) if t < 1.6 else 0.0
        ang = -0.62 * up
        q = rotx(ang)
        moved = qrot(q, r0 - pivot) + pivot - r0
        f = {'root': q, 'root_t': tuple(moved)}
        f['fl_up'] = rotx(-0.9 * up); f['fl_knee'] = rotx(1.4 * up); f['fl_fet'] = rotx(-0.5 * up)
        f['fr_up'] = rotx(-0.7 * up); f['fr_knee'] = rotx(1.6 * up); f['fr_fet'] = rotx(-0.4 * up)
        f['hl_up'] = rotx(0.55 * up); f['hr_up'] = rotx(0.5 * up)
        f['hl_knee'] = rotx(-0.35 * up); f['hr_knee'] = rotx(-0.3 * up)
        f['neck1'] = rotx(0.25 * up); f['head'] = rotx(-0.35 * up)
        f['tail1'] = rotx(-0.2 * up); f['tail2'] = rotx(0.0)
        for k in LEGS:
            f.setdefault(k + '_fet', rotx(0))
        keys[t] = f
    return keys


def shy():
    """A startled half-step back with the head thrown up (1.2 s)."""
    keys = {}
    for i in range(25):
        t = 1.2 * i / 24
        a = math.sin(math.pi * t / 1.2)
        f = {'root_t': (0.0, 1.5 * a, -14.0 * a), 'root': rotx(-0.06 * a)}
        f['neck1'] = rotx(-0.3 * a); f['head'] = rotx(0.25 * a)
        f['fl_up'] = rotx(0.25 * a); f['fr_up'] = rotx(-0.15 * a); f['fl_knee'] = rotx(0.5 * a)
        f['hl_up'] = rotx(0.18 * a); f['hr_up'] = rotx(-0.1 * a)
        f['tail1'] = rotx(-0.45 * a)
        for k in LEGS:
            f.setdefault(k + '_up', rotx(0)); f.setdefault(k + '_knee', rotx(0)); f.setdefault(k + '_fet', rotx(0))
        keys[t] = f
    return keys


ANIMS = {
    'idle': idle(),
    'walk': gait(1.1, {'hl': 0.0, 'fl': 0.25, 'hr': 0.5, 'fr': 0.75}, 0.30, 0.55, 0.9, 0.06),
    'pull': gait(1.25, {'hl': 0.0, 'fl': 0.25, 'hr': 0.5, 'fr': 0.75}, 0.24, 0.45, 0.6, 0.10, pitch=0.01),
    'trot': gait(0.7, {'fl': 0.0, 'hr': 0.0, 'fr': 0.5, 'hl': 0.5}, 0.38, 0.95, 2.4, 0.05, tail=0.1),
    'gallop': gait(0.52, {'hl': 0.0, 'hr': 0.09, 'fl': 0.42, 'fr': 0.52}, 0.62, 1.1, 3.2, 0.12, pitch=0.07, frames=20, tail=0.05),
    'rear': rear(),
    'shy': shy(),
}


def build(src, dst):
    j, binb = read_glb(src)
    mesh_node = 0
    # joints become nodes under one armature node
    base = len(j['nodes'])
    for n, par, p in J:
        rel = np.array(p) - (np.array(JP[par]) if par else 0)
        j['nodes'].append({'name': n, 'translation': [float(v) for v in rel]})
    for i, (n, par, p) in enumerate(J):
        if par:
            j['nodes'][base + JI[par]].setdefault('children', []).append(base + i)
    arm = len(j['nodes'])
    j['nodes'].append({'name': 'Armature', 'children': [base + JI['root']]})
    # the saddle: where a rider sits (a child of the root so it moves with the body)
    j['nodes'].append({'name': 'saddle', 'translation': [float(v) for v in np.array(SADDLE) - JP['root']]})
    j['nodes'][base + JI['root']].setdefault('children', []).append(len(j['nodes']) - 1)
    j['scenes'][0]['nodes'] = [mesh_node, arm]
    ibm = np.zeros((len(J), 16), np.float32)
    for i, (n, _, p) in enumerate(J):
        m = np.eye(4); m[:3, 3] = -np.array(p)
        ibm[i] = m.T.reshape(-1)    # column-major
    ib = add_acc(j, binb, ibm, 5126, 'MAT4')
    j['skins'] = [{'name': 'horse', 'joints': [base + i for i in range(len(J))], 'inverseBindMatrices': ib, 'skeleton': arm}]
    j['nodes'][mesh_node]['skin'] = 0
    for prim in j['meshes'][0]['primitives']:
        P = acc_read(j, binb, prim['attributes']['POSITION'])
        ji, wv = weights(P)
        prim['attributes']['JOINTS_0'] = add_acc(j, binb, ji, 5121, 'VEC4', 34962)
        prim['attributes']['WEIGHTS_0'] = add_acc(j, binb, wv, 5126, 'VEC4', 34962)
    anims = []
    for name, keys in ANIMS.items():
        ts = sorted(keys)
        tacc = add_acc(j, binb, np.array(ts, np.float32).reshape(-1, 1), 5126, 'SCALAR', minmax=True)
        samplers, channels = [], []
        # key every bone in every movement, so a bone one movement leaves alone does not keep another's pose
        names = ['root_t'] + [n for n, _, _ in J]
        for jn in names:
            if jn == 'root_t':
                rest = JP['root'] - 0
                out = np.array([np.array(rest) + np.array(keys[t].get('root_t', (0, 0, 0))) for t in ts], np.float32)
                samplers.append({'input': tacc, 'output': add_acc(j, binb, out, 5126, 'VEC3'), 'interpolation': 'LINEAR'})
                channels.append({'sampler': len(samplers) - 1, 'target': {'node': base + JI['root'], 'path': 'translation'}})
                continue
            out = np.array([keys[t].get(jn, [0, 0, 0, 1]) for t in ts], np.float32)
            samplers.append({'input': tacc, 'output': add_acc(j, binb, out, 5126, 'VEC4'), 'interpolation': 'LINEAR'})
            channels.append({'sampler': len(samplers) - 1, 'target': {'node': base + JI[jn], 'path': 'rotation'}})
        anims.append({'name': name, 'samplers': samplers, 'channels': channels})
    j['animations'] = anims
    j['nodes'][mesh_node]['name'] = os.path.basename(dst)[:-4]
    write_glb(dst, j, binb)
    return dst


if __name__ == '__main__':
    for m in ['cp_horse', 'cp_horse_grey']:
        out = build(os.path.join(MODELS, m + '.glb'), os.path.join(MODELS, m + '_rig.glb'))
        print('wrote', out, os.path.getsize(out))
