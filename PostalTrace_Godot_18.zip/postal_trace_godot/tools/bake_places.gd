extends SceneTree
## Saves every place as places/<id>.tscn, built from data/places/<id>.json.
##   godot --headless -s res://tools/bake_places.gd
## Open the .tscn files in the editor to move, add or remove props, people, things and the
## solid blocks you cannot walk through. Rerun this only to start a place again from its layout
## (it overwrites your edits to that place).
var done := false
func _process(_d: float) -> bool:
	if done:
		return true
	done = true
	var PB = load("res://scripts/world/place_builder.gd")
	var only := OS.get_cmdline_user_args()
	var idx: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://data/places/index.json")).places
	DirAccess.make_dir_recursive_absolute("res://places")
	var n := 0
	for id in idx:
		for a in idx[id]:
			var file: String = id + ("__" + a if a != "" else "")
			if only.size() and not only.has(file) and not only.has(id):
				continue
			var err: int = PB.bake(file, "res://places/%s.tscn" % file)
			print(file, " -> ", "ok" if err == OK else "error %d" % err)
			n += 1
	print("baked ", n)
	return true
