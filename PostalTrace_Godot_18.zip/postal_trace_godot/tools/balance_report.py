#!/usr/bin/env python3
"""Turns the runs recorded by tests/balance.gd into a balance report (Markdown).

    python3 tools/balance_report.py <folder of run .json files> > report.md

Each run file holds: policy, seed, ending, every check (where, difficulty, the courier's total,
passed or not, the odds shown), supplies at each stop, fights met, and the final state.
"""
import json, os, sys, collections, statistics

ENDING_NAMES = {
    "depot": "Duty done", "truth": "Duty reconsidered", "ashes": "Duty abandoned", "sold": "Duty sold",
    "arrest": "Duty questioned (arrested)", "death": "The road wins (dead)", "late": "Too late",
    "gate": "The price at the gate", "unfinished": "Not finished in the step limit", "title": "Back at the title",
}

def load(folder):
    runs = []
    for f in sorted(os.listdir(folder)):
        if f.endswith(".json"):
            try:
                runs.append(json.load(open(os.path.join(folder, f))))
            except Exception:
                pass
    return runs

def pct(a, b):
    return "%d%%" % round(100.0 * a / b) if b else "–"

def main():
    runs = load(sys.argv[1] if len(sys.argv) > 1 else "/tmp/bal")
    by_policy = collections.defaultdict(list)
    for r in runs:
        by_policy[r.get("policy", "random")].append(r)
    out = []
    w = out.append
    w("# The Postal Trace: balance report")
    w("")
    w("From %d whole runs played by the bot in the Godot build (the same rules and numbers as the browser version). "
      "**random** picks any option it is offered; **careful** does the same but rests and eats when health or stamina is low. "
      "Neither plays like a person who reads the story, so read the numbers as pressure points, not as how players will fare." % len(runs))
    w("")
    # endings
    w("## How runs end")
    w("")
    pols = sorted(by_policy)
    w("| Ending | " + " | ".join(pols) + " |")
    w("|---|" + "---|" * len(pols))
    endings = sorted({r.get("ending", "?") for r in runs}, key=lambda e: -sum(1 for r in runs if r.get("ending") == e))
    for e in endings:
        w("| %s | %s |" % (ENDING_NAMES.get(e, e), " | ".join("%d (%s)" % (sum(1 for r in by_policy[p] if r.get("ending") == e), pct(sum(1 for r in by_policy[p] if r.get("ending") == e), len(by_policy[p]))) for p in pols)))
    w("")
    # how far they got
    w("## How far they get")
    w("")
    for p in pols:
        rs = by_policy[p]
        reached = [len(r.get("stops", [])) for r in rs]
        hrs = [r.get("final", {}).get("hrs") or 0 for r in rs]
        w("- **%s**: %d runs; stops reached median %s (max %s); hours used median %s." % (p, len(rs), statistics.median(reached) if reached else 0, max(reached) if reached else 0, statistics.median(hrs) if hrs else 0))
    w("")
    # checks
    w("## Checks")
    w("")
    checks = [c for r in runs for c in r.get("checks", [])]
    if checks:
        ok = sum(1 for c in checks if c["ok"])
        w("%d checks rolled; %s passed. The game showed odds that averaged %s." % (len(checks), pct(ok, len(checks)), "%d%%" % round(statistics.mean(c.get("odds", 0) for c in checks))))
        w("")
        w("### By difficulty")
        w("")
        w("| Difficulty | Rolled | Passed | Average shown odds |")
        w("|---|---|---|---|")
        by_dc = collections.defaultdict(list)
        for c in checks:
            by_dc[c["dc"]].append(c)
        for dc in sorted(by_dc):
            cs = by_dc[dc]
            w("| %d | %d | %s | %d%% |" % (dc, len(cs), pct(sum(1 for c in cs if c["ok"]), len(cs)), round(statistics.mean(c.get("odds", 0) for c in cs))))
        w("")
        w("### Hardest places (at least 5 checks rolled there)")
        w("")
        by_place = collections.defaultdict(list)
        for c in checks:
            by_place[c["where"]].append(c)
        rows = [(pl, cs) for pl, cs in by_place.items() if len(cs) >= 5]
        rows.sort(key=lambda q: sum(1 for c in q[1] if c["ok"]) / len(q[1]))
        w("| Place | Rolled | Passed | Average difficulty | Average total before the dice |")
        w("|---|---|---|---|---|")
        for pl, cs in rows[:12]:
            w("| %s | %d | %s | %.1f | %+.1f |" % (pl, len(cs), pct(sum(1 for c in cs if c["ok"]), len(cs)), statistics.mean(c["dc"] for c in cs), statistics.mean(c["tot"] for c in cs)))
        w("")
    # supplies
    w("## Supplies")
    w("")
    w("Median on arriving at each place along the route (1 is Cross-Pillars; the route has 15 places, and its order differs between runs):")
    w("")
    w("| Place no. | Runs there | Health | Stamina | Powder | Rations | Coin | Hours | Notice |")
    w("|---|---|---|---|---|---|---|---|---|")
    by_stop = collections.defaultdict(list)
    for r in runs:
        for i, s in enumerate(r.get("stops", [])):
            by_stop[i].append(s)
    for i in sorted(by_stop):
        ss = by_stop[i]
        med = lambda k: statistics.median([s.get(k) or 0 for s in ss])
        w("| %d | %d | %s | %s | %s | %s | %s | %s | %s |" % (i + 1, len(ss), med("hp"), med("st"), med("pw"), med("ra"), med("coin"), med("hrs"), med("notice")))
    w("")
    outs = collections.Counter()
    for r in runs:
        for s in r.get("stops", []):
            for k, name in [("ra", "rations"), ("pw", "powder"), ("coin", "coin")]:
                if (s.get(k) or 0) <= 0:
                    outs[name] += 1
    if outs:
        w("Stops reached with nothing left: " + ", ".join("%s %d" % (k, v) for k, v in outs.most_common()) + " (out of %d stop arrivals)." % sum(len(v) for v in by_stop.values()))
        w("")
    # fights
    fights = [f for r in runs for f in r.get("fights", [])]
    if fights:
        w("## Fights")
        w("")
        w("| Where | Fights | Health lost (median) | Ended at 0 health |")
        w("|---|---|---|---|")
        by_f = collections.defaultdict(list)
        for f in fights:
            by_f[f["where"]].append(f)
        for wh, fs in sorted(by_f.items(), key=lambda q: -len(q[1])):
            lost = [max(0, (f.get("hp_before") or 0) - (f.get("hp_after") if f.get("hp_after") is not None else 0)) for f in fs]
            dead = sum(1 for f in fs if (f.get("hp_after") if f.get("hp_after") is not None else 0) <= 0)
            w("| %s | %d | %s | %d |" % (wh, len(fs), statistics.median(lost), dead))
        w("")
    print("\n".join(out))

if __name__ == "__main__":
    main()
