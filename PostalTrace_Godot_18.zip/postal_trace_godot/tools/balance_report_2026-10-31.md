# The Postal Trace: balance report

From 78 whole runs played by the bot in the Godot build (the same rules and numbers as the browser version). **random** picks any option it is offered; **careful** does the same but rests and eats when health or stamina is low. Neither plays like a person who reads the story, so read the numbers as pressure points, not as how players will fare.

## How runs end

| Ending | careful | random |
|---|---|---|
| Too late | 24 (60%) | 8 (21%) |
| Duty questioned (arrested) | 8 (20%) | 13 (34%) |
| The road wins (dead) | 7 (18%) | 8 (21%) |
| Duty abandoned | 1 (2%) | 5 (13%) |
| Duty sold | 0 (0%) | 4 (11%) |

## How far they get

- **careful**: 40 runs; stops reached median 8.0 (max 14); hours used median 70.5.
- **random**: 38 runs; stops reached median 8.0 (max 16); hours used median 57.0.

## Checks

801 checks rolled; 58% passed. The game showed odds that averaged 59%.

### By difficulty

| Difficulty | Rolled | Passed | Average shown odds |
|---|---|---|---|
| 6 | 8 | 88% | 94% |
| 7 | 168 | 81% | 77% |
| 8 | 236 | 64% | 68% |
| 9 | 202 | 52% | 54% |
| 10 | 118 | 39% | 37% |
| 11 | 53 | 34% | 30% |
| 12 | 15 | 27% | 20% |
| 13 | 1 | 0% | 17% |

### Hardest places (at least 5 checks rolled there)

| Place | Rolled | Passed | Average difficulty | Average total before the dice |
|---|---|---|---|---|
| checkpoint | 5 | 20% | 10.4 | +0.8 |
| pit | 21 | 38% | 8.7 | +1.3 |
| malice | 13 | 38% | 8.5 | +2.3 |
| ridge | 42 | 48% | 9.7 | +2.3 |
| venn | 92 | 49% | 9.0 | +1.4 |
| oak | 43 | 53% | 9.7 | +1.8 |
| siblings | 20 | 55% | 8.0 | +1.4 |
| chapel | 105 | 56% | 9.0 | +2.4 |
| mill | 44 | 57% | 8.0 | +2.0 |
| market | 60 | 58% | 8.8 | +1.9 |
| bearers | 5 | 60% | 8.0 | +2.0 |
| hermits | 41 | 63% | 8.2 | +1.6 |

## Supplies

Median on arriving at each place along the route (1 is Cross-Pillars; the route has 15 places, and its order differs between runs):

| Place no. | Runs there | Health | Stamina | Powder | Rations | Coin | Hours | Notice |
|---|---|---|---|---|---|---|---|---|
| 1 | 78 | 6.0 | 8.0 | 4.0 | 4.0 | 3.0 | 0.0 | 0.0 |
| 2 | 72 | 6.0 | 5.0 | 4.0 | 3.0 | 3.0 | 11.0 | 0.0 |
| 3 | 68 | 6.0 | 6.0 | 4.0 | 3.0 | 3.0 | 16.5 | 0.0 |
| 4 | 63 | 6 | 7 | 4 | 3 | 3 | 21 | 1 |
| 5 | 59 | 6 | 6 | 4 | 1 | 3 | 27 | 0 |
| 6 | 56 | 6.0 | 7.0 | 4.0 | 1.0 | 2.0 | 32.0 | 0.0 |
| 7 | 55 | 6 | 7 | 4 | 1 | 2 | 36 | 1 |
| 8 | 42 | 5.5 | 7.0 | 4.0 | 1.0 | 2.0 | 40.0 | 1.0 |
| 9 | 33 | 5 | 7 | 4 | 1 | 2 | 44 | 1 |
| 10 | 28 | 5.0 | 7.0 | 4.0 | 1.0 | 2.5 | 49.5 | 1.0 |
| 11 | 25 | 5 | 8 | 4 | 2 | 3 | 52 | 2 |
| 12 | 21 | 6 | 9 | 4 | 2 | 2 | 56 | 2 |
| 13 | 12 | 4.5 | 9.0 | 4.0 | 1.0 | 2.0 | 61.0 | 2.0 |
| 14 | 10 | 3.5 | 9.0 | 4.0 | 0.5 | 1.5 | 66.5 | 1.5 |
| 15 | 4 | 4.5 | 10.0 | 4.5 | 1.0 | 5.0 | 65.0 | 1.5 |
| 16 | 2 | 5.5 | 9.5 | 3.5 | 0.5 | 2.5 | 69.5 | 2.0 |

Stops reached with nothing left: rations 158, coin 96, powder 3 (out of 628 stop arrivals).

## Fights

| Where | Fights | Health lost (median) | Ended at 0 health |
|---|---|---|---|
| checkpoint | 16 | 2.5 | 1 |
| cp_rider | 7 | 1 | 0 |
| ridge | 3 | 2 | 0 |
| oak | 3 | 2 | 0 |
| venn | 1 | 2 | 0 |
| mine | 1 | 4 | 0 |
| siblings | 1 | 1 | 0 |

