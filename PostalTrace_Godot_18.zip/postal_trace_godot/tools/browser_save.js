// Makes a save the way the browser does (tests/browser_save.json), and checks the browser can load a Godot save.
const fs=require('fs');const st=require('./extract_run.js');const ev=st.ev;
const out=process.argv[2], godot=process.argv[3];
const txt=ev("(S = fresh(), S.trait='steady', S.route=['cross','market','ford','oak','ridge','malice'], S.idx=2, S.seen=2, S.hrs=9, S.done.stable=true, snap('scene'), packSave())");
fs.writeFileSync(out,txt);console.log('browser save',txt.length,JSON.parse(txt).where);
if(godot){const g=fs.readFileSync(godot,'utf8');let ok;try{ok=ev('loadPack')(g)}catch(e){ok='threw after load: '+e.message.slice(0,60)}
 console.log('browser loads Godot save:',ok,'hrs',ev('S.hrs'),'route',ev('S.route').join(','),'kind',ev('CP.kind'))}
