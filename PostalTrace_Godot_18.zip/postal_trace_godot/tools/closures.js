// Reads a function's closure variables through the V8 inspector, so wrapped conditions keep their captured values.
const inspector=require('inspector');const session=new inspector.Session();session.connect();
function post(m,p){let r,e;session.post(m,p,(err,res)=>{e=err;r=res});if(e)throw e;if(r===undefined)throw new Error('async '+m);return r}
function objOf(remote){if(!remote)return undefined;if(!('objectId' in remote))return remote.value;post('Runtime.callFunctionOn',{objectId:remote.objectId,functionDeclaration:'function(){globalThis.__got=this}'});return globalThis.__got}
// returns {name:value} for closure scopes inside the outermost IIFE closure
function scopes(fn){globalThis.__f=fn;const r=post('Runtime.evaluate',{expression:'globalThis.__f'});const props=post('Runtime.getProperties',{objectId:r.result.objectId,ownProperties:true});
 const sc=(props.internalProperties||[]).find(p=>p.name==='[[Scopes]]');if(!sc)return [];const list=post('Runtime.getProperties',{objectId:sc.value.objectId,ownProperties:true}).result.filter(x=>/^\d+$/.test(x.name));
 const out=[];for(const s of list){const desc=s.value.description||'';const vars=post('Runtime.getProperties',{objectId:s.value.objectId,ownProperties:true}).result;out.push({desc,vars:Object.fromEntries(vars.map(v=>[v.name,v.value]))})}return out}
module.exports={scopes,objOf};
