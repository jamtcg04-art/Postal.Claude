// Proves the compiled conversations behave like the originals inside the real browser build.
// Loads the game, builds a second GRAPH from the compiled JSON (via the JS emitter), then calls every
// condition / computed text in both, over many random game states, and compares results and state writes.
// usage: node tools/equiv_browser.js index.html compiled.json [states]
'use strict';
// find a package locally, then in the usual global folders
function req(n) { for (const p of [n, '/opt/node-tools/node_modules/' + n, '/opt/node22/lib/node_modules/' + n, require('path').join(require('child_process').execSync('npm root -g').toString().trim(), n)]) { try { return require(p); } catch (e) {} } throw new Error('Install ' + n + ': npm i ' + n); }
const fs = require('fs'), path = require('path');
const { chromium } = req('playwright');
const P = require('./ptc');

(async () => {
  const [src, compiledPath, nStates] = process.argv.slice(2);
  const convs = JSON.parse(fs.readFileSync(compiledPath, 'utf8'));
  const emitted = P.emitJS(convs);
  // what the conditions look at, to make interesting random states
  const paths = new Set(), strs = new Set(), items = new Set();
  JSON.stringify(convs, (k, v) => {
    if (Array.isArray(v) && v[0] === 'v' && typeof v[1] === 'string') paths.add(v[1]);
    if (Array.isArray(v) && v[0] === 's' && typeof v[1] === 'string' && v[1].length < 30) strs.add(v[1]);
    if (Array.isArray(v) && v[0] === 'call' && v[1] === 'has' && v[2][0] && v[2][0][0] === 's') items.add(v[2][0][1]);
    return v;
  });
  let html = fs.readFileSync(src, 'utf8');
  html = html.replace('  cloudInit();\n  start();', '  window.__EVAL = function (src) { return eval(src); };\n  cloudInit();\n  start();');
  html = html.replace(/<script (async )?src="assets\/w3d_[a-z]+\.js"><\/script>/g, '');
  html = html.replace('<script>\n(function () {', '<script>window.W3D=(function(){var f=function(){return P};var P=new Proxy(f,{get:function(t,k){if(k===Symbol.toPrimitive)return function(){return 0};if(k==="then")return undefined;return P},apply:function(){return P},construct:function(){return P}});return P})();</script>\n<script>\n(function () {');
  const tmp = path.join(path.dirname(path.resolve(compiledPath)), '_eq.html'); fs.writeFileSync(tmp, html);
  const br = await chromium.launch(); const p = await br.newPage();
  await p.goto('file://' + tmp, { waitUntil: 'load', timeout: 120000 });
  await p.waitForFunction(() => window.__EVAL, null, { timeout: 60000 });
  const res = await p.evaluate(({ emitted, paths, strs, items, n }) => {
    const E = window.__EVAL;
    E('var __G2 = {}; (function (GRAPH) {\n' + emitted + '\n})(__G2); window.__G2 = __G2;');
    const G1 = E('GRAPH'), G2 = window.__G2;
    // pair up every function in the two graphs
    const pairs = [], shape = [];
    (function walk(a, b, at) {
      if (typeof a === 'function' || typeof b === 'function') {
        if (typeof a !== 'function' || typeof b !== 'function') {   // a function that always gives the same value may have become that value
          const f = typeof a === 'function' ? a : b, v = typeof a === 'function' ? b : a;
          pairs.push([f, function () { return v; }, at]); return;
        }
        pairs.push([a, b, at]); return;
      }
      if (a && typeof a === 'object') {
        if (!b || typeof b !== 'object') { shape.push(at + ': missing'); return; }
        const ka = Object.keys(a).filter(k => a[k] !== undefined).sort().join(','), kb = Object.keys(b).filter(k => b[k] !== undefined).sort().join(',');
        if (ka !== kb) shape.push(at + ': keys ' + ka + ' vs ' + kb);
        for (const k of Object.keys(a)) walk(a[k], b[k], at + '.' + k);
        return;
      }
      if (a !== b) shape.push(at + ': ' + JSON.stringify(a) + ' vs ' + JSON.stringify(b));
    })(G1, G2, 'GRAPH');
    const skip = pairs.filter(x => /\.run$/.test(x[2]));   // actions are the same source, run only in play
    const test = pairs.filter(x => !/\.run$/.test(x[2]));
    let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
    const pick = a => a[Math.floor(rnd() * a.length)];
    const strList = [...strs], itemList = [...items], pathList = [...paths];
    const ITEMS = E('ITEMS'), THOUGHTS = E('THOUGHTS'), allItems = Object.keys(ITEMS), allTh = Object.keys(THOUGHTS);
    const mism = {}; let calls = 0;
    function setPath(S, pth, v) { const ps = pth.split('.'); let o = S; for (let i = 0; i < ps.length - 1; i++) { if (o[ps[i]] === null || typeof o[ps[i]] !== 'object') o[ps[i]] = {}; o = o[ps[i]]; } o[ps[ps.length - 1]] = v; }
    for (let s = 0; s < n; s++) {
      const S0 = E('fresh()');
      S0.route = E('typeof ROUTE !== "undefined" ? ROUTE.slice() : null') || S0.route;
      for (const pth of pathList) {
        const r = rnd();
        if (r < 0.45) continue;
        const kind = rnd();
        setPath(S0, pth, kind < 0.6 ? true : kind < 0.8 ? Math.floor(rnd() * 9) - 3 : kind < 0.9 ? pick(strList) : false);
      }
      ['coin', 'duty', 'trust', 'notice', 'hp', 'st', 'ra', 'pw', 'level'].forEach(k => { S0[k] = Math.floor(rnd() * 9) - (k === 'level' ? -1 : 3); });
      S0.inv = allItems.filter(() => rnd() < 0.25).concat(itemList.filter(() => rnd() < 0.4));
      S0.thoughts = allTh.filter(() => rnd() < 0.15); S0.mull = {};
      S0.idx = Math.floor(rnd() * 12);
      const base = JSON.stringify(S0);
      for (const [f1, f2, at] of test) {
        let a, b, sa, sb;
        const isShow = /\.show$/.test(at), J = v => isShow ? String(!!v) : JSON.stringify(v);
        E('S = JSON.parse(' + JSON.stringify(base) + ')'); try { a = J(f1()); } catch (e) { a = 'ERR ' + e.message; } sa = E('JSON.stringify(S)');
        E('S = JSON.parse(' + JSON.stringify(base) + ')'); try { b = J(f2()); } catch (e) { b = 'ERR ' + e.message; } sb = E('JSON.stringify(S)');
        calls++;
        if (a !== b || sa !== sb) { if (!mism[at]) mism[at] = { want: String(a).slice(0, 200), got: String(b).slice(0, 200), state: sa !== sb }; }
      }
    }
    return { functions: test.length, actions: skip.length, calls, shape: shape.slice(0, 20), shapeCount: shape.length, mismatches: mism };
  }, { emitted, paths: [...paths], strs: [...strs], items: [...items], n: Number(nStates || 60) });
  fs.unlinkSync(tmp); await br.close();
  const bad = Object.keys(res.mismatches);
  console.log(JSON.stringify({ functions: res.functions, actions: res.actions, calls: res.calls, shapeProblems: res.shapeCount, mismatching: bad.length }, null, 1));
  res.shape.forEach(s => console.log('SHAPE', s));
  bad.slice(0, 15).forEach(k => console.log('DIFF', k, '\n  want', res.mismatches[k].want, '\n  got ', res.mismatches[k].got, res.mismatches[k].state ? '(state writes differ)' : ''));
  process.exit(bad.length || res.shapeCount ? 1 : 0);
})().catch(e => { console.error(e); process.exit(2); });
