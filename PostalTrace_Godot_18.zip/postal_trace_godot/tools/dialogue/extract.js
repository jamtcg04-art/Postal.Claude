// Loads the browser build in Chromium and dumps every GRAPH conversation.
// Functions are kept as source; for functions that were wrapped at runtime (show: function () { return !S.done[met]; })
// the captured locals are read through the DevTools protocol, so the decompiler can inline them.
// usage: node tools/extract.js index.html out.json
'use strict';
// find a package locally, then in the usual global folders
function req(n) { for (const p of [n, '/opt/node-tools/node_modules/' + n, '/opt/node22/lib/node_modules/' + n, require('path').join(require('child_process').execSync('npm root -g').toString().trim(), n)]) { try { return require(p); } catch (e) {} } throw new Error('Install ' + n + ': npm i ' + n); }
const fs = require('fs'), path = require('path');
const { chromium } = req('playwright');
const acorn = req('acorn');
const walk = req('acorn-walk');

function freeNames(src, top) {
  const out = new Set(), decl = new Set();
  let ast; try { ast = acorn.parse('(' + src + ')', { ecmaVersion: 2020 }); } catch (e) { return out; }
  walk.full(ast, n => { if (n.type === 'VariableDeclarator' && n.id.type === 'Identifier') decl.add(n.id.name); if (/Function/.test(n.type)) n.params.forEach(p => p.type === 'Identifier' && decl.add(p.name)); });
  walk.full(ast, (n, st, type) => {
    if (n.type === 'MemberExpression' && !n.computed) n.property.__skip = true;
    if (n.type === 'Property' && !n.computed) n.key.__skip = true;
  });
  walk.full(ast, n => { if (n.type === 'Identifier' && !n.__skip && !decl.has(n.name) && !(n.name in globalThis) && n.name !== 'S' && n.name !== 'arguments' && n.name !== 'undefined') out.add(n.name); });
  return out;
}

(async () => {
  const src = process.argv[2], out = process.argv[3];
  let html = fs.readFileSync(src, 'utf8');
  const hook = "window.__PT = { GRAPH: GRAPH, VOICES: VOICES, VOICE: VOICE, SKILLS: SKILLS, THOUGHTS: THOUGHTS, TALK: TALK, OBJECTS: OBJECTS, DEF_VOICE: DEF_VOICE, TALLY_TAGS: TALLY_TAGS, BANTER: BANTER, MANNER: MANNER, FAIL_REM: FAIL_REM, V_RULES: V_RULES, TRAITS: TRAITS, PATTERN: PATTERN, PATTERN_LINE: PATTERN_LINE, DIFFN: DIFFN, TEMP_CAP: TEMP_CAP, ITEMS: ITEMS, V_OF: V_OF, VPERK: VPERK, ADDR: typeof ADDR !== 'undefined' ? ADDR : null, ADDR_V: ADDR_V };\n  cloudInit();\n  start();";
  if (html.indexOf('  cloudInit();\n  start();') < 0) throw new Error('hook point missing');
  html = html.replace('  cloudInit();\n  start();', hook);
  // 3D isn't needed to read conversations: stand in a do-nothing W3D
  html = html.replace(/<script (async )?src="assets\/w3d_[a-z]+\.js"><\/script>/g, '');
  html = html.replace('<script>\n(function () {', '<script>window.W3D=(function(){var f=function(){return P};var P=new Proxy(f,{get:function(t,k){if(k===Symbol.toPrimitive)return function(){return 0};if(k==="then")return undefined;return P},apply:function(){return P},construct:function(){return P}});return P})();</script>\n<script>\n(function () {');
  const tmp = path.join(path.dirname(out), '_page.html'); fs.writeFileSync(tmp, html);

  // top-level names of the game script, so we know which identifiers are the game's own functions
  const a = html.indexOf('<script>\n(function () {') + 8, b = html.lastIndexOf('</script>');
  const prog = acorn.parse(html.slice(a, b), { ecmaVersion: 2020 }).body[0].expression.callee.body.body;
  const top = new Set();
  for (const s of prog) { if (s.type === 'FunctionDeclaration') top.add(s.id.name); if (s.type === 'VariableDeclaration') s.declarations.forEach(d => d.id.name && top.add(d.id.name)); }

  const br = await chromium.launch(); const p = await br.newPage();
  p.on('pageerror', e => console.error('pageerror:', String(e).slice(0, 200)));
  await p.goto('file://' + path.resolve(tmp), { waitUntil: 'load', timeout: 120000 });
  await p.waitForFunction(() => window.__PT, null, { timeout: 60000 });
  const data = JSON.parse(await p.evaluate(() => {
    const seen = new WeakSet(); window.__FNS = [];
    function ser(v) {
      if (v instanceof RegExp) return { __re: v.source, flags: v.flags };
      if (typeof v === 'function') { window.__FNS.push(v); return { __fn: v.toString(), __id: window.__FNS.length - 1 }; }
      if (v && typeof v === 'object') {
        if (seen.has(v)) return { __ref: true }; seen.add(v);
        let o;
        if (Array.isArray(v)) o = v.map(ser); else { o = {}; for (const k of Object.keys(v)) o[k] = ser(v[k]); }
        seen.delete(v); return o;
      }
      return v;
    }
    const P = window.__PT, r = {};
    for (const k of Object.keys(P)) r[k] = ser(P[k]);
    return JSON.stringify(r);
  }));

  const cdp = await p.context().newCDPSession(p);
  async function scopeVars(objectId, want, depth) {
    const r = await cdp.send('Runtime.getProperties', { objectId, ownProperties: false });
    const sc = (r.internalProperties || []).find(x => x.name === '[[Scopes]]');
    if (!sc) return {};
    const scopes = await cdp.send('Runtime.getProperties', { objectId: sc.value.objectId, ownProperties: true });
    const vars = {};
    for (const s of scopes.result) {
      if (!s.value || !s.value.objectId) continue;
      const props = await cdp.send('Runtime.getProperties', { objectId: s.value.objectId, ownProperties: true });
      if (props.result.some(x => x.name === 'GRAPH')) break;   // reached the game's top level
      for (const v of props.result) if (want.has(v.name) && !(v.name in vars) && v.value) vars[v.name] = await valueOf(v.value, depth);
    }
    return vars;
  }
  async function valueOf(rv, depth) {
    if (rv.type === 'function') {
      const src = (await cdp.send('Runtime.callFunctionOn', { objectId: rv.objectId, functionDeclaration: 'function(){return this.toString()}', returnByValue: true })).result.value;
      const want = freeNames(src, top);
      return { __fn: src, __closure: depth < 4 && want.size ? await scopeVars(rv.objectId, want, depth + 1) : {} };
    }
    if (rv.type === 'object' && rv.objectId) {
      const r = await cdp.send('Runtime.callFunctionOn', { objectId: rv.objectId, functionDeclaration: 'function(){try{var s=JSON.stringify(this,function(k,v){return typeof v==="function"?{__fn:String(v)}:v});return s.length<20000?JSON.parse(s):{__opaque:true}}catch(e){return {__opaque:true}}}', returnByValue: true });
      return r.result.value;
    }
    if (rv.type === 'undefined') return { __undef: true };
    return rv.value;
  }
  const closures = {};
  const fnSrc = [];
  (function w(v) { if (v && v.__fn !== undefined && v.__id !== undefined) { fnSrc[v.__id] = v.__fn; return; } if (v && typeof v === 'object') for (const k in v) w(v[k]); })(data.GRAPH);
  for (let i = 0; i < fnSrc.length; i++) {
    if (fnSrc[i] === undefined) continue;
    const want = freeNames(fnSrc[i], top);
    if (!want.size) continue;
    const r = await cdp.send('Runtime.evaluate', { expression: 'window.__FNS[' + i + ']' });
    closures[i] = await scopeVars(r.result.objectId, want, 0);
  }
  data.CLOSURES = closures;
  data.TOP = [...top];
  fs.writeFileSync(out, JSON.stringify(data)); fs.unlinkSync(tmp);
  await br.close();
})().catch(e => { console.error(e); process.exit(1); });
