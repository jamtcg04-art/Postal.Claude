// Turns the browser build's small JavaScript functions (show:, say:, mood: …) into expression ASTs.
// Anything outside the safe subset returns null, and the caller keeps the original JavaScript instead.
'use strict';
// find a package locally, then in the usual global folders
function req(n) { for (const p of [n, '/opt/node-tools/node_modules/' + n, '/opt/node22/lib/node_modules/' + n, require('path').join(require('child_process').execSync('npm root -g').toString().trim(), n)]) { try { return require(p); } catch (e) {} } throw new Error('Install ' + n + ': npm i ' + n); }
const acorn = req('acorn');

function fnBody(src) {
  const ast = acorn.parse('(' + src + ')', { ecmaVersion: 2020 });
  const f = ast.body[0].expression;
  if (f.params.length) return null;
  return f.body.type === 'BlockStatement' ? f.body.body : [{ type: 'ReturnStatement', argument: f.body }];
}

class Unsupported extends Error {}
const no = (why) => { throw new Unsupported(why); };

function expr(n, env) {
  switch (n.type) {
    case 'Literal':
      if (n.regex) no('regex');
      if (typeof n.value === 'number') return ['n', n.value];
      if (typeof n.value === 'string') return ['s', n.value];
      if (typeof n.value === 'boolean') return ['b', n.value];
      if (n.value === null) return ['null'];
      return no('literal');
    case 'Identifier': {
      if (n.name === 'undefined') return ['null'];
      if (env.vars[n.name]) return env.vars[n.name];
      if (env.closure && n.name in env.closure) return lit(env.closure[n.name]);
      return no('free identifier ' + n.name);
    }
    case 'MemberExpression': {
      const path = [];
      let m = n;
      while (m.type === 'MemberExpression') {
        if (m.computed) {
          const k = expr(m.property, env);
          if (k[0] !== 's' && k[0] !== 'n') return no('computed key');
          path.unshift(String(k[1]));
        } else path.unshift(m.property.name);
        m = m.object;
      }
      if (m.type === 'Identifier' && m.name === 'S' && !(env.closure && 'S' in env.closure)) { if (!path.length) no('bare S'); if (path[path.length - 1] === 'length') no('length'); return ['v', path.join('.')]; }
      if (m.type === 'Identifier' && env.vars[m.name] && env.vars[m.name][0] === 'v') return ['v', env.vars[m.name][1] + '.' + path.join('.')];
      if (m.type === 'Identifier' && env.closure && m.name in env.closure) {   // a captured constant: x[0], cfg.name
        let v = env.closure[m.name];
        for (const k of path) { if (v === null || typeof v !== 'object' || v.__fn || v.__opaque || !(k in v)) return no('captured member'); v = v[k]; }
        return lit(v);
      }
      return no('member of non-S');
    }
    case 'CallExpression': {
      // f.apply(this, arguments) on a captured function is the same as calling it
      if (n.callee.type === 'MemberExpression' && !n.callee.computed && n.callee.property.name === 'apply' && n.callee.object.type === 'Identifier' && env.closure && env.closure[n.callee.object.name] && env.closure[n.callee.object.name].__fn)
        return inline(env.closure[n.callee.object.name], env);
      if (n.callee.type === 'MemberExpression' && !n.callee.computed) {
        const meth = n.callee.property.name;
        if (meth === 'concat') return n.arguments.reduce((acc, a) => ['cat', acc, listOf(expr(a, env))], expr(n.callee.object, env));
        if (meth === 'slice' && !n.arguments.length) return expr(n.callee.object, env);
      }
      if (n.callee.type !== 'Identifier') return no('method call');
      if (env.closure && n.callee.name in env.closure) {
        const f = env.closure[n.callee.name];
        if (!f || !f.__fn || n.arguments.length) return no('captured call');
        return inline(f, env);
      }
      if (!env.top.has(n.callee.name)) return no('unknown function ' + n.callee.name);
      if (env.effects.has(n.callee.name)) return no('side effect ' + n.callee.name);
      return ['call', n.callee.name, n.arguments.map(a => expr(a, env))];
    }
    case 'UnaryExpression':
      if (n.operator === '!') { const a = expr(n.argument, env), c = constOf(a); return c !== undefined ? ['b', !truthy(c)] : ['!', a]; }
      if (n.operator === 'typeof' && n.argument.type === 'Identifier' && env.top.has(n.argument.name)) return ['s', 'function'];
      if (n.operator === '-') { const a = expr(n.argument, env); return a[0] === 'n' ? ['n', -a[1]] : ['neg', a]; }
      return no('unary ' + n.operator);
    case 'LogicalExpression': {
      if (n.operator === '??') return no('??');
      const l = expr(n.left, env), c = constOf(l);
      if (c !== undefined) { const t = truthy(c); if (n.operator === '||' ? t : !t) return l; return expr(n.right, env); }
      if (n.operator === '||' && n.right.type === 'ObjectExpression' && !n.right.properties.length) return l;   // (S.out.cross || {}).i
      const r = expr(n.right, env);
      // S.perc && S.perc.bearers  ->  S.perc.bearers (paths read safely anyway)
      if (n.operator === '&&' && l[0] === 'v' && r[0] === 'v' && r[1].indexOf(l[1] + '.') === 0) return r;
      return [n.operator, l, r];
    }
    case 'BinaryExpression': {
      const op = { '===': '==', '!==': '!=', '<': '<', '<=': '<=', '>': '>', '>=': '>=', '+': '+', '-': '-', '*': '*', '/': '/', '%': '%' }[n.operator];
      if (!op) return no('binary ' + n.operator);
      return [op, expr(n.left, env), expr(n.right, env)];
    }
    case 'ConditionalExpression': return ['?:', expr(n.test, env), expr(n.consequent, env), expr(n.alternate, env)];
    case 'ArrayExpression': return ['arr'].concat(n.elements.map(e => expr(e, env)));
    case 'TemplateLiteral': return no('template');
  }
  return no(n.type);
}

function constOf(a) { if (a[0] === 'b' || a[0] === 'n' || a[0] === 's') return a[1]; if (a[0] === 'null') return null; return undefined; }
function truthy(v) { return !(v === undefined || v === null || v === false || v === 0 || v === ''); }
function listOf(a) { return a[0] === 'arr' || a[0] === 'cat' || a[0] === '?:' ? a : ['arr', a]; }

// a captured value as a literal; a captured function, when not called, only counts as "there"
function lit(v) {
  if (v === null) return ['null'];
  if (v && v.__undef) return ['null'];
  if (v && v.__fn) return ['b', true];
  if (typeof v === 'number') return ['n', v];
  if (typeof v === 'string') return ['s', v];
  if (typeof v === 'boolean') return ['b', v];
  if (Array.isArray(v) && v.every(x => typeof x === 'string' || typeof x === 'number')) return ['arr'].concat(v.map(lit));
  return no('captured object');
}
function inline(f, env) {
  const body = fnBody(f.__fn);
  if (!body) return no('inline params');
  const e2 = { vars: {}, top: env.top, effects: env.effects, closure: f.__closure || {}, sets: env.sets };
  return stmts(body, e2);
}

// if (a) return X; if (b) { return Y; } return Z;   ->   a ? X : (b ? Y : Z)
function stmts(list, env) {
  if (!list.length) return ['null'];
  const s = list[0], rest = list.slice(1);
  if (s.type === 'ReturnStatement') return s.argument ? expr(s.argument, env) : ['null'];
  if (s.type === 'VariableDeclaration') {
    for (const d of s.declarations) {
      if (d.id.type !== 'Identifier' || !d.init) no('var form');
      env.vars[d.id.name] = expr(d.init, env);
    }
    return stmts(rest, env);
  }
  if (s.type === 'ExpressionStatement') { effect(s.expression, env); return stmts(rest, env); }
  if (s.type === 'IfStatement' && !returns(s)) {
    // if (c) l.push(x);  ->  l = c ? l + [x] : l
    const test = expr(s.test, env);
    const yes = Object.assign({}, env.vars), nov = Object.assign({}, env.vars);
    const run = (st, vars, g) => { const e2 = Object.assign({}, env, { vars, guard: env.guard ? ['&&', env.guard, g] : g }); (st.type === 'BlockStatement' ? st.body : [st]).forEach(x => { if (x.type !== 'ExpressionStatement') no('if body'); effect(x.expression, e2); }); };
    run(s.consequent, yes, test); if (s.alternate) run(s.alternate, nov, ['!', test]);
    for (const k of new Set(Object.keys(yes).concat(Object.keys(nov)))) if (yes[k] !== nov[k]) env.vars[k] = ['?:', test, yes[k] || ['null'], nov[k] || ['null']];
    return stmts(rest, env);
  }
  if (s.type === 'IfStatement') {
    const c = s.consequent.type === 'BlockStatement' ? s.consequent.body : [s.consequent];
    if (!c.length || c[c.length - 1].type !== 'ReturnStatement') no('if without return');
    const yes = stmts(c, Object.assign({}, env, { vars: Object.assign({}, env.vars) }));
    let alt;
    if (s.alternate) {
      const a = s.alternate.type === 'BlockStatement' ? s.alternate.body : [s.alternate];
      alt = stmts(a.concat(rest), env);
    } else alt = stmts(rest, env);
    return ['?:', expr(s.test, env), yes, alt];
  }
  return no(s.type);
}

function returns(s) {
  const c = s.consequent.type === 'BlockStatement' ? s.consequent.body : [s.consequent];
  return c.some(x => x.type === 'ReturnStatement');
}
// the only statements allowed: l.push(…) and l = expr on locals
function effect(e, env) {
  if (e.type === 'CallExpression' && e.callee.type === 'MemberExpression' && !e.callee.computed && e.callee.property.name === 'push' && e.callee.object.type === 'Identifier' && env.vars[e.callee.object.name]) {
    const k = e.callee.object.name;
    env.vars[k] = ['cat', env.vars[k], ['arr'].concat(e.arguments.map(a => expr(a, env)))];
    return;
  }
  if (e.type === 'AssignmentExpression' && e.operator === '=' && e.left.type === 'Identifier' && env.vars[e.left.name]) { env.vars[e.left.name] = expr(e.right, env); return; }
  // S.done.x = value: a write to the game state, done when the line is read (kept in order)
  if (e.type === 'AssignmentExpression' && e.operator === '=' && e.left.type === 'MemberExpression') {
    const t = expr(e.left, env);
    if (t[0] !== 'v') no('assign target');
    env.sets.push(['set', t[1], expr(e.right, env), env.guard || null]);
    return;
  }
  no('statement');
}

function toAst(src, top, effects, closure) {
  try {
    const body = fnBody(src);
    if (!body) return null;
    const env = { vars: {}, top, effects, closure: closure || {}, sets: [] };
    const a = stmts(body, env);
    // a write followed by a read of the same flag inside one function would need ordering we don't model
    return env.sets.length ? ['do', env.sets, a] : a;
  } catch (e) {
    if (e instanceof Unsupported) return null;
    throw e;
  }
}

module.exports = { toAst };
