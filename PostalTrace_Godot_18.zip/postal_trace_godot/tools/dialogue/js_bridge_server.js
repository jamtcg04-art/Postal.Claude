// Test helper: serves the browser build's JavaScript scope over HTTP, so Godot tests can run the
// PTJsLiteHost against the real browser rules. POST /eval with a JS expression; the answer is its JSON value.
// usage: node tools/js_bridge_server.js index.html [port]
'use strict';
// find a package locally, then in the usual global folders
function req(n) { for (const p of [n, '/opt/node-tools/node_modules/' + n, '/opt/node22/lib/node_modules/' + n, require('path').join(require('child_process').execSync('npm root -g').toString().trim(), n)]) { try { return require(p); } catch (e) {} } throw new Error('Install ' + n + ': npm i ' + n); }
const fs = require('fs'), path = require('path'), http = require('http');
const { chromium } = req('playwright');
(async () => {
  const [src, port] = process.argv.slice(2);
  let html = fs.readFileSync(src, 'utf8');
  html = html.replace('  cloudInit();\n  start();', '  window.__EVAL = function (src) { return eval(src); };\n  cloudInit();\n  start();');
  html = html.replace(/<script (async )?src="assets\/w3d_[a-z]+\.js"><\/script>/g, '');
  html = html.replace('<script>\n(function () {', '<script>window.W3D=(function(){var f=function(){return P};var P=new Proxy(f,{get:function(t,k){if(k===Symbol.toPrimitive)return function(){return 0};if(k==="then")return undefined;return P},apply:function(){return P},construct:function(){return P}});return P})();</script>\n<script>\n(function () {');
  const tmp = path.resolve('/tmp/_bridge.html'); fs.writeFileSync(tmp, html);
  const br = await chromium.launch(); const p = await br.newPage();
  await p.goto('file://' + tmp, { waitUntil: 'load', timeout: 120000 });
  await p.waitForFunction(() => window.__EVAL, null, { timeout: 60000 });
  await p.evaluate(() => {
    const E = window.__EVAL;
    E('scene = function () { phase = "scene"; }; ending = function () {}; wEnter = function () {}; wLeave = function () {}; wAfterShow = function () {}; SCX = null; S = fresh();');
    window.__J = function (code) {
      try { const v = E(code); return JSON.stringify(v === undefined ? null : v, (k, x) => typeof x === 'function' ? undefined : x); }
      catch (e) { return JSON.stringify({ __error: String(e) }); }
    };
  });
  http.createServer((req, res) => {
    let body = ''; req.on('data', d => body += d);
    req.on('end', async () => {
      const out = await p.evaluate(c => window.__J(c), body);
      res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(out);
    });
  }).listen(Number(port || 8765), '127.0.0.1', () => console.log('bridge ready'));
})();
