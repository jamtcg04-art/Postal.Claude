// browser dump (functions as source) -> compiled conversation JSON (functions as ASTs, or kept JS)
'use strict';
const { toAst } = require('./js2ast');
const { canon, truthCtx } = require('./ptexpr');
// calls that change the game and so can never be part of a condition
const EFFECTS = new Set(['applyFx', 'renderLedger', 'lose', 'gain', 'scene', 'show', 'mkGo', 'mkBuy', 'ending', 'checkEnd', 'mkThrow', 'mkCellarEnter', 'sntLeave', 'compLeave', 'addXp', 'newThought', 'vqPush', 'tallyAdd', 'sideAdd', 'addTemp', 'graphShow', 'graphGo', 'fightStart', 'snap']);
function normalize(dump) {
  const top = new Set(dump.TOP), stats = { x: 0, js: 0, run: 0 };
  function conv(v, key) {
    if (v && v.__fn !== undefined) {
      const clo = dump.CLOSURES[v.__id] || {};
      const a = key === 'run' ? null : toAst(v.__fn, top, EFFECTS, clo);
      if (a) {
        stats.x++;
        const c = key === 'show' ? truthCtx(canon(a)) : canon(a);
        // a function that always gives the same text is just that text
        if (key === 'say' && c[0] === 'arr' && c.slice(1).every(e => e[0] === 's')) return c.slice(1).map(e => e[1]);
        return { x: c };
      }
      stats[key === 'run' ? 'run' : 'js']++;
      const o = { js: require('./ptc').dedent(v.__fn) }; if (Object.keys(clo).length) o.closure = clo; return o;
    }
    if (Array.isArray(v)) return v.map(x => conv(x, key));
    if (v && typeof v === 'object') { const o = {}; for (const k in v) o[k] = conv(v[k], isNaN(k) ? k : key); return o; }
    return v;
  }
  const out = {};
  for (const id of Object.keys(dump.GRAPH)) out[id] = conv(dump.GRAPH[id], '');
  return { convs: out, stats };
}
module.exports = { normalize };
