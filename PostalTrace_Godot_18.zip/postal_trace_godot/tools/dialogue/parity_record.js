// Records conversations played in the real browser build, for the Godot runner to replay and match.
// For each run: a random starting state, seeded dice, and seeded choices; at every screen it notes what
// was said, which inner voices spoke, the dice, and every choice with its state and check odds.
// usage: node tools/parity_record.js index.html out.json [runsPerConversation] [steps]
'use strict';
// find a package locally, then in the usual global folders
function req(n) { for (const p of [n, '/opt/node-tools/node_modules/' + n, '/opt/node22/lib/node_modules/' + n, require('path').join(require('child_process').execSync('npm root -g').toString().trim(), n)]) { try { return require(p); } catch (e) {} } throw new Error('Install ' + n + ': npm i ' + n); }
const fs = require('fs'), path = require('path');
const { chromium } = req('playwright');

(async () => {
  // with a fixture as the 5th argument, replay its states, dice and choices instead of making new ones
  const [src, out, runsArg, stepsArg, replayPath] = process.argv.slice(2);
  const replay = replayPath ? JSON.parse(fs.readFileSync(replayPath, 'utf8')).runs : null;
  let html = fs.readFileSync(src, 'utf8');
  html = html.replace('  cloudInit();\n  start();', '  window.__EVAL = function (src) { return eval(src); };\n  cloudInit();\n  start();');
  html = html.replace(/<script (async )?src="assets\/w3d_[a-z]+\.js"><\/script>/g, '');
  html = html.replace('<script>\n(function () {', '<script>window.W3D=(function(){var f=function(){return P};var P=new Proxy(f,{get:function(t,k){if(k===Symbol.toPrimitive)return function(){return 0};if(k==="then")return undefined;return P},apply:function(){return P},construct:function(){return P}});return P})();</script>\n<script>\n(function () {');
  const tmp = path.resolve(path.dirname(out), '_parity.html'); fs.writeFileSync(tmp, html);
  const br = await chromium.launch(); const p = await br.newPage();
  p.on('pageerror', e => console.error('pageerror:', String(e).slice(0, 160)));
  await p.goto('file://' + tmp, { waitUntil: 'load', timeout: 120000 });
  await p.waitForFunction(() => window.__EVAL, null, { timeout: 60000 });
  await p.evaluate(() => { window.__replay = function (run) {
    const E = window.__EVAL;
    E('scene = function () { phase = "scene"; screen.innerHTML = "<p>scene</p>"; }; ending = function (e) { phase = "end"; screen.innerHTML = "<p>end " + e + "</p>"; }; wEnter = function () {}; wLeave = function () {}; wAfterShow = function () {};');
    E('S = ' + JSON.stringify(run.S0) + '; SCX = null; DLG.key = null; CURG = null; addrLast = {}; window.__DQ = ' + JSON.stringify(run.dice) + '; d6 = function () { return window.__DQ.length ? window.__DQ.shift() : 1; };');
    const GRAPH = E('GRAPH');
    let ti; const tid = run.talker.id;
    if (/^x_/.test(tid)) ti = tid.slice(2); else ti = E('talkers()').findIndex(t => t.id === tid);
    const snapDom = window.__snapDom;
    const outRun = Object.assign({}, run, { steps: [] });
    E('graphShow')(ti, GRAPH[run.conv].hub, {});
    outRun.steps.push(snapDom());
    for (const pick of run.picks) { document.querySelectorAll('#screen .choices button.choice')[pick].click(); outRun.steps.push(snapDom()); }
    return outRun;
  }; });
  await p.evaluate(() => { window.__setup = function (runsPer, steps, only) {
    const E = window.__EVAL;
    const GRAPH = E('GRAPH'), THOUGHTS = E('THOUGHTS');
    let seed = 99; const rnd = () => (seed = (Math.imul(seed, 1103515245) + 12345) >>> 0) / 4294967296;
    // seeded dice, logged so Godot can throw the same ones
    E('window.__DICE = []; var __d6seed = 1; d6 = function () { __d6seed = (Math.imul(__d6seed, 48271) + 11) >>> 0; var v = 1 + (__d6seed >>> 8) % 6; window.__DICE.push(v); return v; };');
    E('SCX = null; S = fresh();');
    // leaving a conversation draws the 3D scene, which this test has no use for
    E('scene = function () { phase = "scene"; screen.innerHTML = "<p>scene</p>"; }; ending = function (e) { phase = "end"; screen.innerHTML = "<p>end " + e + "</p>"; }; wEnter = function () {}; wLeave = function () {}; wAfterShow = function () {};');
    const out = [];
    window.__snapDom = snapDom;
    function snapDom() {
      const sc = document.getElementById('screen'), b = sc.querySelector('.dbeats');
      if (!b || E('phase') !== 'talk') return { ended: true };
      const voices = [...b.querySelectorAll('.voice')].filter(el => !el.closest('.vq')).map(el => [el.querySelector('b').getAttribute('data-vi'), el.querySelector('span').textContent]);
      const say = [...b.querySelectorAll('.saying .reply p, .prose.look p')].map(x => x.textContent);
      const r = b.querySelector('.roll'), dice = r ? [...r.querySelectorAll('.die')].map(d => +d.textContent) : null;
      const verdict = r ? r.querySelector('.verdict').classList.contains('ok') : null;
      const choices = [...sc.querySelectorAll('.choices button.choice')].map(btn => ({
        text: btn.querySelector('.t').textContent, enabled: !btn.disabled, retry: btn.classList.contains('retry'), replay: btn.classList.contains('replay'),
        kind: btn.hasAttribute('data-va') ? 'ask' : btn.hasAttribute('data-vn') ? 'no' : 'opt',
        ck: (btn.querySelector('.tag.ck') || { textContent: '' }).textContent
      }));
      return { ended: false, say, voices, roll: dice ? { dice, ok: verdict } : null, choices };
    }
    for (const id of Object.keys(GRAPH).filter(x => x === only)) {
      const [scene, tid] = id.split(':');
      if (/^(back_|fun_)/.test(scene)) continue;   // return visits are opened by the scene code, not a talker list
      for (let k = 0; k < runsPer; k++) {
        // a random starting state
        E('S = fresh(); S.route = [' + JSON.stringify(scene) + ']; S.idx = 0; SCX = null; DLG.key = null; CURG = null;');
        const S = E('S');
        ['arms', 'nerve', 'wits', 'grit'].forEach(sk => { S.up[sk] = Math.floor(rnd() * 5) - 1; });
        S.vr = {}; ['ledger', 'wire', 'cipher', 'parade', 'bluff', 'battery', 'shoulder', 'ramrod', 'splinter', 'longroad', 'mud', 'ringing'].forEach(v => { if (rnd() < 0.2) S.vr[v] = 1; });
        S.duty = Math.floor(rnd() * 5) - 2; S.trust = Math.floor(rnd() * 5) - 2; S.coin = Math.floor(rnd() * 8);
        if (rnd() < 0.3) S.inv.push('hat');
        if (rnd() < 0.2) S.done['cock_' + scene] = true;
        Object.keys(THOUGHTS).forEach(t => { if (rnd() < 0.06) S.thoughts.push(t); });
        const flags = new Set(); JSON.stringify(GRAPH[id], (kk, v) => v); // flags read by this conversation's conditions
        const srcs = []; (function w(v) { if (typeof v === 'function') srcs.push(v.toString()); else if (v && typeof v === 'object') for (const x in v) w(v[x]); })(GRAPH[id]);
        srcs.join(' ').replace(/S\.done\.([A-Za-z_][\w]*)/g, (m, f) => { flags.add(f); return m; });
        [...flags].forEach(f => { if (!/^(gseen|gmet|gu|gox|vgo|vno|gret)_/.test(f) && rnd() < 0.3) S.done[f] = true; });
        const S0 = JSON.parse(JSON.stringify(S));
        // which talker is this
        let ti;
        if (/^x_/.test(tid)) ti = tid.slice(2);
        else { const list = E('talkers()'); ti = list.findIndex(t => t.id === tid); if (ti < 0) continue; }
        let who; try { who = E('whoAt')(ti); } catch (e) { continue; }
        if (!who) continue;
        window.__DICE = [];
        const run = { conv: id, scene, talker: { id: tid, name: who.name, role: who.role || '', mood: who.mood, hue: who.hue || '', obj: !!who.obj }, S0, picks: [], steps: [] };
        try { E('graphShow')(ti, GRAPH[id].hub, {}); } catch (e) { run.error = String(e); out.push(run); continue; }
        run.steps.push(snapDom());
        for (let s = 0; s < steps; s++) {
          const last = run.steps[run.steps.length - 1];
          if (last.ended) break;
          const open = last.choices.map((c, i) => [c, i]).filter(x => x[0].enabled);
          if (!open.length) break;
          const pick = open[Math.floor(rnd() * open.length)][1];
          run.picks.push(pick);
          const btns = document.querySelectorAll('#screen .choices button.choice');
          try { btns[pick].click(); } catch (e) { run.error = String(e); break; }
          run.steps.push(snapDom());
        }
        run.dice = window.__DICE.slice();
        out.push(run);
      }
    }
    return out;
  }; });
  const ids = await p.evaluate(() => Object.keys(window.__EVAL('GRAPH')));
  const runs = [];
  if (replay) {
    await p.evaluate(() => window.__setup(0, 0, ''));   // defines the screen reader
    for (const run of replay) runs.push(await p.evaluate(r => window.__replay(r), run));
    ids.length = 0;
  }
  for (const id of ids) {
    process.stdout.write(id + ' ');
    const r = await p.evaluate(({ a, b, id }) => window.__setup(a, b, id), { a: Number(runsArg || 3), b: Number(stepsArg || 12), id });
    runs.push(...r);
  }
  console.log();
  fs.unlinkSync(tmp); await br.close();
  fs.writeFileSync(out, JSON.stringify({ format: 'postal-trace-parity', runs }));
  const steps = runs.reduce((a, r) => a + r.steps.length, 0), errs = runs.filter(r => r.error).length;
  console.log('recorded ' + runs.length + ' runs, ' + steps + ' screens, ' + errs + ' with browser errors');
})().catch(e => { console.error(e); process.exit(1); });
