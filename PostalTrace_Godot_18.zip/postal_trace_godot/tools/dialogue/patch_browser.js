// Puts the compiled conversations into the browser build, so both builds read the same dialogue scripts.
// The block goes just before the game starts, after every older GRAPH definition and patch, and replaces
// those entries; running it again swaps the old block for the new one.
// usage: node tools/patch_browser.js index.html build/browser/pt_dialogue.gen.js out.html
'use strict';
const fs = require('fs');
const [src, gen, out] = process.argv.slice(2);
let html = fs.readFileSync(src, 'utf8');
const code = fs.readFileSync(gen, 'utf8');
const A = '  // <pt-dialogue> conversations compiled from dialogue/*.pt by tools/compile.js: edit the scripts, not this block\n';
const B = '  // </pt-dialogue>\n';
const i = html.indexOf(A), j = html.indexOf(B);
if (i >= 0 && j > i) html = html.slice(0, i) + html.slice(j + B.length);
const hook = '  cloudInit();\n  start();';
if (html.indexOf(hook) < 0) throw new Error('could not find the start of the game');
html = html.replace(hook, A + code.split('\n').map(l => l ? '  ' + l : l).join('\n').replace(/\s+$/, '') + '\n' + B + hook);
fs.writeFileSync(out, html);
console.log('wrote ' + out + ' (' + Math.round(code.length / 1024) + ' KB of conversations)');
