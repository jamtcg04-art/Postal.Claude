// Reads the Godot port's conversations (data/graphs/<scene>/<who>.json, with {"$js", "$env"} logic)
// into the compiled form, so they can be written out as .pt scripts.
// usage: node tools/port_import.js <godot project> out.json
'use strict';
const fs = require('fs'), path = require('path');
const { normalize } = require('./normalize');
const [proj, out] = process.argv.slice(2);
const root = path.join(proj, 'data', 'graphs');
const GRAPH = {}, CLOSURES = {};
let n = 0;
function conv(v) {
  if (v && typeof v === 'object' && !Array.isArray(v)) {
    if ('$js' in v) {
      const id = n++;
      if (v.$env && Object.keys(v.$env).length) CLOSURES[id] = env(v.$env);
      return { __fn: v.$js, __id: id };
    }
    if ('$re' in v) return { __re: v.$re, flags: v.flags || '' };
    const o = {}; for (const k in v) o[k] = conv(v[k]); return o;
  }
  if (Array.isArray(v)) return v.map(conv);
  return v;
}
// captured values: functions inside keep their own captured values
function env(e) {
  const o = {};
  for (const k in e) o[k] = envVal(e[k]);
  return o;
}
function envVal(v) {
  if (v === null) return { __undef: true };
  if (v && typeof v === 'object' && !Array.isArray(v) && '$js' in v) return { __fn: v.$js, __closure: v.$env ? env(v.$env) : {} };
  if (Array.isArray(v)) return v.map(envVal);
  if (v && typeof v === 'object') { const o = {}; for (const k in v) o[k] = envVal(v[k]); return o; }
  return v;
}
for (const s of fs.readdirSync(root).sort())
  for (const f of fs.readdirSync(path.join(root, s)).sort())
    if (f.endsWith('.json')) GRAPH[s + ':' + f.slice(0, -5)] = conv(JSON.parse(fs.readFileSync(path.join(root, s, f), 'utf8')));
// names the logic can call: the game's own functions (lib.json) and the browser's top level
const lib = JSON.parse(fs.readFileSync(path.join(proj, 'data', 'lib.json'), 'utf8'));
const TOP = new Set(Object.keys(lib.functions || {}).concat(Object.keys(lib.data || {})));
try { require(path.resolve(__dirname, '..', 'work', 'browser_dump.json')).TOP.forEach(t => TOP.add(t)); } catch (e) {}
['has', 'pastN', 'thoughtDone', 'crossState', 'mareKnow'].forEach(t => TOP.add(t));
const { convs, stats } = normalize({ GRAPH, CLOSURES, TOP: [...TOP] });
fs.writeFileSync(out, JSON.stringify(convs));
console.log(Object.keys(convs).length + ' conversations; ' + JSON.stringify(stats));
