// The Postal Trace dialogue compiler.
//   .pt script  <->  compiled conversation JSON (read by Godot)  ->  browser JS (GRAPH entries)
//
// Compiled JSON keeps the browser's own field names (say, mood, voices, opts, check …) so both builds
// share one model. A field that was a function in the browser becomes one of:
//   { "x": AST }                    computed (conditions, text that changes) – see ptexpr.js
//   { "js": "function () {…}", "closure": {…} }   kept as JavaScript (actions like starting a fight)
'use strict';
const E = require('./ptexpr');

const NODE_PROPS = ['mood', 'by', 'ban', 'flag', 'learn', 'temp', 'temp2', 'fx', 'give', 'take', 'xp', 'log', 'thought', 'tally', 'failLine'];
const PROP_ALIAS = { failLine: 'fail' };
const ALIAS_PROP = { fail: 'failLine' };
const OPT_TAGS = ['once', 'off'];

// ======================================================================================
// .pt writer
// ======================================================================================
function isX(v) { return v && typeof v === 'object' && !Array.isArray(v) && 'x' in v; }
function isJs(v) { return v && typeof v === 'object' && !Array.isArray(v) && 'js' in v; }
function esc(line) { return /^(\s|[@>*~={\\#]|-{2})/.test(line) || line === '' ? '\\' + line : line; }
function cond(v) { return isX(v) ? '{' + E.print(v.x) + '}' : null; }

function textOrX(v) {
  if (isX(v)) return '{= ' + E.print(v.x) + '}';
  if (typeof v === 'string') return v;
  throw new Error('text expected: ' + JSON.stringify(v).slice(0, 80));
}

function jsBlock(field, v, ind) {
  const out = [ind + '@js ' + field];
  v.js.split('\n').forEach(l => out.push(ind + '    ' + l));
  if (v.closure && Object.keys(v.closure).length) out.push(ind + '    @closure ' + JSON.stringify(v.closure));
  return out;
}

// say: an array of paragraphs, or a computed value. Computed say is shown as variants and conditional lines.
function sayLines(say, out) {
  if (Array.isArray(say)) { say.forEach(p => out.push(esc(textOrX(p)))); return; }
  if (isJs(say)) { out.push(...jsBlock('say', say, '')); return; }
  if (!isX(say)) throw new Error('say?');
  const variants = [];
  let a = say.x;
  while (a[0] === '?:' && listy(a[2])) { variants.push([a[1], a[2]]); a = a[3]; }
  if (variants.length && listy(a)) {
    variants.forEach(([c, body]) => { out.push('@say {' + E.print(c) + '}'); paras(body, out); });
    out.push('@say'); paras(a, out); return;
  }
  if (listy(say.x)) { paras(say.x, out); return; }
  out.push('@say = ' + E.print(say.x));
}
function listy(a) {
  if (a[0] === 'arr') return a.slice(1).every(x => x[0] === 's' || !listLike(x));
  if (a[0] === 'cat') return listy(a[1]) && (listy(a[2]) || isCondList(a[2]));
  return false;
}
function listLike(x) { return x[0] === 'arr' || x[0] === 'cat'; }
function isCondList(a) { return a[0] === '?:' && a[2][0] === 'arr' && a[3][0] === 'arr' && a[3].length === 1 && a[2].slice(1).every(x => !listLike(x)); }
// one line per paragraph; "{cond} text" for a paragraph added only sometimes
function paras(a, out) {
  if (a[0] === 'arr') { a.slice(1).forEach(x => out.push(x[0] === 's' ? esc(x[1]) : '{= ' + E.print(x) + '}')); return; }
  if (a[0] === 'cat') {
    paras(a[1], out);
    if (isCondList(a[2])) a[2][2].slice(1).forEach(x => out.push('{' + E.print(a[2][1]) + '} ' + (x[0] === 's' ? x[1] : '{= ' + E.print(x) + '}')));
    else paras(a[2], out);
  }
}

function range(e) {
  if (e.min !== undefined && e.max !== undefined) return ' ' + e.min + '..' + e.max;
  if (e.min !== undefined) return ' ' + e.min + '+';
  if (e.max !== undefined) return ' ..' + e.max;
  return '';
}

function writeConv(id, G) {
  const out = ['=== ' + id + (G.hub !== 'hub' ? ' hub=' + G.hub : '')];
  for (const nid of Object.keys(G.nodes)) {
    const N = G.nodes[nid];
    out.push('', '~ ' + nid);
    for (const k of NODE_PROPS) {
      if (!(k in N)) continue;
      const v = N[k], name = PROP_ALIAS[k] || k;
      if (v === null) { out.push('@' + name + ' null'); continue; }
      if (isJs(v)) { out.push(...jsBlock(name, v, '')); continue; }
      if (k === 'mood' && isX(v)) {
        let a = v.x; const vs = [];
        while (a[0] === '?:' && a[2][0] === 's') { vs.push('@mood ' + a[2][1] + ' {' + E.print(a[1]) + '}'); a = a[3]; }
        if (a[0] === 's') { out.push(...vs, '@mood ' + a[1]); continue; }
        out.push('@mood {= ' + E.print(v.x) + '}'); continue;
      }
      out.push('@' + name + ' ' + propText(k, v));
    }
    sayLines(N.say, out);
    (N.argue ? argNorm(N.argue) : null || []).forEach(a => {
      let h = '@argue' + (a.show ? ' ' + condOrJs(a.show) : '');
      if (a.min) h += ' min=' + Object.keys(a.min).map(k => k + ':' + a.min[k]).join(',');
      out.push(h);
      if (isJs(a.show)) out.push(...jsBlock('show', a.show, '  '));
      a.lines.forEach(l => out.push('  ' + l[0] + ' | ' + textOrX(l[1])));
    });
    if (N.argue && !Array.isArray(N.argue)) out.push('@argue-single');
    if (N.argue && Array.isArray(N.argue) && N.argue.length && Array.isArray(N.argue[0])) out.push('@argue-flat');
    (N.voices || []).forEach(e => {
      let h = '> ' + (e.v !== undefined ? e.v : e.sk) + (e.v !== undefined && e.sk !== undefined ? ' sk=' + e.sk : '') + range(e);
      if (e.show) h += ' ' + condOrJs(e.show);
      if (e.go !== undefined || e.q !== undefined) h += ' ask ' + JSON.stringify(e.q === undefined ? null : e.q) + ' -> ' + (e.go === undefined ? '?' : e.go);
      if (e.no !== undefined) h += ' / ' + JSON.stringify(e.no);
      out.push(h + ' | ' + textOrX(e.text));
      if (isJs(e.show)) out.push(...jsBlock('show', e.show, '  '));
    });
    (N.opts || []).forEach(o => {
      let h = '*';
      if (o.show) h += ' ' + condOrJs(o.show);
      h += ' ' + (isX(o.q) ? '{= ' + E.print(o.q.x) + '}' : isJs(o.q) ? '{js}' : escOpt(o.q));
      if ('to' in o) h += ' -> ' + (o.to === null ? 'null' : o.to);
      OPT_TAGS.forEach(t => { if (o[t] !== undefined) h += o[t] === true ? ' #' + t : ' #' + t + ':' + JSON.stringify(o[t]); });
      ['tally', 'side', 'think', 'past'].forEach(t => { if (o[t] !== undefined) h += ' #' + t + ':' + o[t]; });
      out.push(h);
      if (isJs(o.show)) out.push(...jsBlock('show', o.show, '  '));
      if (isJs(o.q)) out.push(...jsBlock('q', o.q, '  '));
      if (o.check) {
        const c = o.check;
        let ch = '  @check ' + c.sk + ' ' + c.dc + ' -> ' + c.pass + ' / ' + c.fail;
        if (c.red) ch += ' #red';
        if (c.v) ch += ' v=' + c.v;
        if (c.with) ch += ' with=' + c.with.sk + (c.with.v ? '/' + c.with.v : '');
        out.push(ch);
      }
      ['flag', 'temp', 'temp2', 'fx', 'xp', 'give', 'take', 'learn', 'thought', 'log'].forEach(k => { if (k in o) out.push('  @' + k + ' ' + propText(k, o[k])); });
      if (o.run) out.push(...jsBlock('run', o.run, '  '));
      const known = ['q', 'to', 'show', 'check', 'run', 'flag', 'temp', 'temp2', 'fx', 'xp', 'give', 'take', 'learn', 'thought', 'log'].concat(OPT_TAGS, ['tally', 'side', 'think', 'past']);
      Object.keys(o).forEach(k => { if (known.indexOf(k) < 0) throw new Error('option field ' + k + ' in ' + id + ':' + nid); });
    });
    const knownN = NODE_PROPS.concat(['say', 'argue', 'voices', 'opts']);
    Object.keys(N).forEach(k => { if (knownN.indexOf(k) < 0) throw new Error('node field ' + k + ' in ' + id + ':' + nid); });
  }
  return out.join('\n') + '\n';
}
function escOpt(q) { return /^[{\\]/.test(q) || / -> |\s#[a-z]/.test(q) ? '\\' + q : q; }
function condOrJs(v) { return isJs(v) ? '{js}' : cond(v); }
function argNorm(a) { if (!Array.isArray(a)) return [a]; if (a.length && Array.isArray(a[0])) return [{ lines: a }]; return a; }

function propText(k, v) {
  if (isX(v)) return '{= ' + E.print(v.x) + '}';
  switch (k) {
    case 'temp': case 'temp2': return v[0] + ' ' + v[1] + ' ' + v[2];
    case 'fx': return Object.keys(v).length ? Object.keys(v).map(x => x + ' ' + v[x]).join(', ') : '{}';
    case 'give': case 'take': return v.join(', ');
    default:
      if (typeof v === 'string') return v === '' ? '""' : v;
      return JSON.stringify(v);
  }
}

// ======================================================================================
// .pt reader
// ======================================================================================
function parseText(s) { return s.startsWith('{= ') && s.endsWith('}') ? { x: E.canon(E.parse(s.slice(3, -1))) } : s; }
function X(a) { return { x: E.canon(a) }; }
function unesc(l) { return l.startsWith('\\') ? l.slice(1) : l; }
function scalar(k, s) {
  if (s.startsWith('{= ')) return parseText(s);
  if (s === 'null') return null;
  switch (k) {
    case 'temp': case 'temp2': { const m = s.match(/^(\S+) (-?\d+) (.*)$/); return [m[1], Number(m[2]), m[3]]; }
    case 'fx': if (s === '{}') return {}; { const o = {}; s.split(', ').forEach(p => { const m = p.match(/^(\S+) (.*)$/); o[m[1]] = isNaN(Number(m[2])) ? JSON.parse(m[2]) : Number(m[2]); }); return o; }
    case 'give': case 'take': return s.split(', ');
    case 'xp': return Number(s);
    default:
      if (s === '""') return '';
      if (/^(true|false|-?\d+(\.\d+)?|".*"|\[.*\]|\{.*\})$/.test(s)) return JSON.parse(s);
      return s;
  }
}
// read "{cond}" (balanced braces, strings respected) from the start of s
function takeBraces(s) {
  if (s[0] !== '{') return null;
  let d = 0, q = null;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (q) { if (c === '\\') { i++; continue; } if (c === q) q = null; continue; }
    if (c === '"' || c === "'") q = c;
    else if (c === '{') d++;
    else if (c === '}') { d--; if (!d) return [s.slice(1, i), s.slice(i + 1).replace(/^ /, '')]; }
  }
  throw new Error('Unclosed { in: ' + s);
}
function condOf(inner) { return inner === 'js' ? 'JS' : { x: E.truthCtx(E.canon(E.parse(inner))) }; }

function parse(src, file) {
  const lines = src.split('\n');
  const convs = {};
  let G = null, N = null, nid = null, say = null, variants = null, lastOpt = null, lastArg = null, lastVoice = null, js = null, moods = null;
  const err = (i, m) => { throw new Error((file || 'script') + ':' + (i + 1) + ': ' + m); };
  function flushNode() {
    if (!N) return;
    if (js) endJs();
    if (moods) {
      let x = moods.def !== undefined ? ['s', moods.def] : ['null'];
      for (let i = moods.list.length - 1; i >= 0; i--) x = ['?:', moods.list[i][1], ['s', moods.list[i][0]], x];
      N.mood = X(x); moods = null;
    }
    if (say.js) N.say = say.js;
    else if (say.whole) N.say = say.whole;
    else if (variants) {
      let x = build(variants.def || []);
      for (let i = variants.list.length - 1; i >= 0; i--) x = ['?:', variants.list[i][0], build(variants.list[i][1]), x];
      N.say = X(x); variants = null;
    } else if (say.computed) N.say = X(build(say.items));
    else N.say = say.items.map(it => it.text);
    if (!N.say) N.say = [];
    if (N.argue) { if (N.argue.__single) { N.argue = N.argue[0]; } else if (N.argue.__flat) { N.argue = N.argue[0].lines; } }
    G.nodes[nid] = N; N = null;
  }
  // a list of paragraphs (text, "{cond} text", "{= expr}") as one AST
  function build(items) {
    let acc = ['arr'];
    for (const it of items) {
      const val = typeof it.text === 'string' ? ['s', it.text] : it.text.x;
      if (it.cond) acc = ['cat', acc, ['?:', it.cond, ['arr', val], ['arr']]];
      else if (acc[0] === 'arr') acc.push(val);
      else acc = ['cat', acc, ['arr', val]];
    }
    return acc;
  }
  function endJs() {
    const src = js.lines.join('\n');
    const val = { js: src };
    if (js.closure) val.closure = js.closure;
    if (js.field === 'say' && js.target === N) say.js = val;
    else js.target[ALIAS_PROP[js.field] || js.field] = val;
    js = null;
  }
  for (let i = 0; i < lines.length; i++) {
    const raw = lines[i];
    if (js) {
      if (raw.startsWith(js.ind + '    ')) {
        const l = raw.slice(js.ind.length + 4);
        if (l.startsWith('@closure ')) js.closure = JSON.parse(l.slice(9)); else js.lines.push(l);
        continue;
      }
      endJs();
    }
    if (!raw.trim() || raw.startsWith('//')) continue;
    if (raw.startsWith('=== ')) {
      flushNode();
      const m = raw.match(/^=== (\S+)(?: hub=(\S+))?$/); if (!m) err(i, 'bad conversation line');
      G = { hub: m[2] || 'hub', nodes: {} }; convs[m[1]] = G; continue;
    }
    if (raw.startsWith('~ ')) {
      if (!G) err(i, 'node outside a conversation');
      flushNode(); nid = raw.slice(2).trim(); N = {}; say = { items: [], computed: false }; lastOpt = lastArg = lastVoice = null; continue;
    }
    if (!N) err(i, 'text outside a node');
    if (raw.startsWith('  ') && !raw.startsWith('  \\')) {
      const l = raw.slice(2);
      if (lastOpt) {
        if (l.startsWith('@js ')) { js = { field: l.slice(4).trim(), target: lastOpt, lines: [], ind: '  ' }; continue; }
        if (l.startsWith('@check ')) {
          const m = l.match(/^@check (\S+) (-?\d+) -> (\S+) \/ (\S+)((?: \S+)*)$/); if (!m) err(i, 'bad @check');
          const c = { sk: m[1], dc: Number(m[2]), pass: m[3], fail: m[4] };
          (m[5] || '').trim().split(/\s+/).filter(Boolean).forEach(t => {
            if (t === '#red') c.red = true;
            else if (t.startsWith('v=')) c.v = t.slice(2);
            else if (t.startsWith('with=')) { const w = t.slice(5).split('/'); c.with = { sk: w[0] }; if (w[1]) c.with.v = w[1]; }
            else err(i, 'unknown check part ' + t);
          });
          lastOpt.check = c; continue;
        }
        const m = l.match(/^@(\w+) (.*)$/); if (!m) err(i, 'bad option line');
        lastOpt[m[1]] = scalar(m[1], m[2]); continue;
      }
      if (lastArg) {
        if (l.startsWith('@js ')) { js = { field: 'show', target: lastArg, lines: [], ind: '  ' }; continue; }
        const m = l.match(/^(\S+) \| (.*)$/); if (!m) err(i, 'argue line should be "voice | text"');
        lastArg.lines.push([m[1], parseText(m[2])]); continue;
      }
      if (lastVoice) { if (l.startsWith('@js ')) { js = { field: 'show', target: lastVoice, lines: [], ind: '  ' }; continue; } }
      err(i, 'indented line with nothing above it');
    }
    if (raw.startsWith('@js ')) { lastOpt = lastArg = lastVoice = null; js = { field: raw.slice(4).trim(), target: N, lines: [], ind: '' }; continue; }
    if (raw.startsWith('@say = ')) { say.whole = X(E.parse(raw.slice(7))); continue; }
    if (raw.startsWith('@say')) {
      lastOpt = lastArg = lastVoice = null;
      if (!variants) variants = { list: [] };
      const rest = raw.slice(4).trim();
      if (rest) { const b = takeBraces(rest); variants.list.push([E.parse(b[0]), []]); variants.cur = variants.list[variants.list.length - 1][1]; }
      else { variants.def = []; variants.cur = variants.def; }
      continue;
    }
    if (raw.startsWith('@argue')) {
      lastOpt = lastVoice = null;
      if (raw === '@argue-single') { N.argue.__single = true; continue; }
      if (raw === '@argue-flat') { N.argue.__flat = true; continue; }
      const a = { lines: [] }; let rest = raw.slice(6).trim();
      if (rest.startsWith('{')) { const b = takeBraces(rest); a.show = condOf(b[0]); rest = b[1].trim(); }
      if (rest.startsWith('min=')) { a.min = {}; rest.slice(4).split(',').forEach(p => { const q = p.split(':'); a.min[q[0]] = Number(q[1]); }); }
      if (a.show === 'JS') delete a.show;
      (N.argue = N.argue || []).push(a); lastArg = a; continue;
    }
    if (raw.startsWith('@')) {
      lastOpt = lastArg = lastVoice = null;
      const m = raw.match(/^@(\w+) (.*)$/); if (!m) err(i, 'bad property line');
      const k = ALIAS_PROP[m[1]] || m[1];
      if (k === 'mood' && !m[2].startsWith('{= ')) {
        const mm = m[2].match(/^(\S+)(?: \{(.*)\})?$/);
        if (mm[2] !== undefined) { moods = moods || { list: [] }; moods.list.push([mm[1], E.parse(mm[2])]); continue; }
        if (moods) { moods.def = mm[1]; continue; }
      }
      N[k] = scalar(k, m[2]); continue;
    }
    if (raw.startsWith('> ')) {
      lastOpt = lastArg = null;
      const bar = raw.indexOf(' | '); if (bar < 0) err(i, 'voice line needs " | text"');
      let h = raw.slice(2, bar).trim(); const e = {}; const text = raw.slice(bar + 3);
      const who = h.match(/^(\S+)/)[1]; h = h.slice(who.length).trim();
      const skillNames = { arms: 1, nerve: 1, wits: 1, grit: 1 };
      if (skillNames[who]) e.sk = who; else e.v = who;
      let m;
      if ((m = h.match(/^sk=(\S+)\s*/))) { e.sk = m[1]; h = h.slice(m[0].length); }
      if ((m = h.match(/^(-?\d+)\.\.(-?\d+)\s*/))) { e.min = Number(m[1]); e.max = Number(m[2]); h = h.slice(m[0].length); }
      else if ((m = h.match(/^(-?\d+)\+\s*/))) { e.min = Number(m[1]); h = h.slice(m[0].length); }
      else if ((m = h.match(/^\.\.(-?\d+)\s*/))) { e.max = Number(m[1]); h = h.slice(m[0].length); }
      if (h.startsWith('{')) { const b = takeBraces(h); const c = condOf(b[0]); if (c !== 'JS') e.show = c; h = b[1].trim(); }
      if ((m = h.match(/^ask (null|"(?:\\.|[^"\\])*") -> (\S+)\s*/))) { const q = JSON.parse(m[1]); if (q !== null) e.q = q; if (m[2] !== '?') e.go = m[2]; h = h.slice(m[0].length); }
      if ((m = h.match(/^\/ ("(?:\\.|[^"\\])*")\s*/))) { e.no = JSON.parse(m[1]); h = h.slice(m[0].length); }
      if (h) err(i, 'cannot read voice header near: ' + h);
      e.text = parseText(text);
      (N.voices = N.voices || []).push(e); lastVoice = e; continue;
    }
    if (raw.startsWith('* ')) {
      lastArg = lastVoice = null;
      let h = raw.slice(2); const o = {};
      if (h.startsWith('{') && !h.startsWith('{= ') && !h.startsWith('{js}')) { const b = takeBraces(h); o.show = condOf(b[0]); h = b[1]; }
      else if (h.startsWith('{js} ') && (h.slice(5).startsWith('{') || true)) {
        // "{js} text": condition kept as JavaScript, or "{js}" alone as the text
        if (h.length > 4 && h[4] === ' ') { o.show = 'JS'; h = h.slice(5); }
      }
      // tags and arrow from the end
      let m;
      const tags = [];
      while ((m = h.match(/ #(\w+)(?::(\S+))?$/))) { tags.unshift([m[1], m[2]]); h = h.slice(0, m.index); }
      if ((m = h.match(/ -> (\S+)$/))) { o.to = m[1] === 'null' ? null : m[1]; h = h.slice(0, m.index); }
      if (h === '{js}') o.q = 'JS';
      else if (h.startsWith('{= ')) o.q = parseText(h);
      else o.q = unesc(h);
      tags.forEach(([k, v]) => {
        if (v === undefined) o[k] = true;
        else if (k === 'past') o[k] = Number(v);
        else if (OPT_TAGS.indexOf(k) >= 0) o[k] = JSON.parse(v);
        else o[k] = v;
      });
      if (o.show === 'JS') delete o.show;
      if (o.q === 'JS') delete o.q;
      (N.opts = N.opts || []).push(o); lastOpt = o; continue;
    }
    // a paragraph
    lastOpt = lastArg = lastVoice = null;
    let line = unesc(raw), item;
    if (!raw.startsWith('\\') && raw.startsWith('{= ') && raw.endsWith('}')) { item = { text: parseText(raw) }; say.computed = true; }
    else if (!raw.startsWith('\\') && raw.startsWith('{')) { const b = takeBraces(raw); item = { cond: E.parse(b[0]), text: parseText(b[1]) }; say.computed = true; }
    else item = { text: line };
    if (variants) variants.cur.push(item); else say.items.push(item);
  }
  if (js) endJs();
  flushNode();
  for (const c in convs) for (const n in convs[c].nodes) if (!convs[c].nodes[n].opts) convs[c].nodes[n].opts = [];
  return convs;
}

// ======================================================================================
// compiled JSON -> browser JavaScript (GRAPH entries)
// ======================================================================================
function emitVal(v, ind) {
  if (isX(v)) return 'function () { return ' + E.js(v.x) + '; }';
  if (isJs(v)) {
    if (v.closure && Object.keys(v.closure).length) {
      const names = Object.keys(v.closure);
      return '(function (' + names.join(', ') + ') { return ' + v.js + '; })(' + names.map(n => emitVal(closureVal(v.closure[n]), ind)).join(', ') + ')';
    }
    return v.js;
  }
  if (Array.isArray(v)) return '[' + v.map(x => emitVal(x, ind)).join(', ') + ']';
  if (v && typeof v === 'object') return '{ ' + Object.keys(v).map(k => JSON.stringify(k) + ': ' + emitVal(v[k], ind)).join(', ') + ' }';
  return v === undefined ? 'undefined' : JSON.stringify(v);
}
// captured values stored in a closure: functions inside are { __fn, __closure }
function closureVal(c) {
  if (c && c.__undef) return undefined;
  if (c && c.__fn) return { js: c.__fn, closure: c.__closure || {} };
  if (Array.isArray(c)) return c.map(closureVal);
  if (c && typeof c === 'object') { const o = {}; for (const k in c) o[k] = closureVal(c[k]); return o; }
  return c;
}
function emitJS(convs) {
  return Object.keys(convs).map(id => 'GRAPH[' + JSON.stringify(id) + '] = ' + emitVal(convs[id], '') + ';').join('\n');
}

// a function's source with its later lines brought back to the left margin
function dedent(src) {
  const lines = src.split('\n'), later = lines.slice(1).filter(l => l.trim());
  if (!later.length) return src;
  const cut = Math.min(...later.map(l => l.match(/^ */)[0].length)) - 2;
  if (cut <= 0) return src;
  return lines.map((l, i) => i === 0 ? l : l.slice(Math.min(cut, l.match(/^ */)[0].length))).join('\n');
}

module.exports = { dedent, writeConv, parse, emitJS, emitVal, isX, isJs };
