// The Postal Trace dialogue: the small expression language used for conditions and computed text.
// One AST, shared by the compiler (Node), the browser build (compiled back to JS) and Godot (walked by cond.gd).
//
// AST nodes are JSON arrays:
//   ["n", 3]  ["s", "text"]  ["b", true]  ["null"]
//   ["v", "done.vane_scorn"]          a path into the game state S (first part is the S field)
//   ["call", "has", [args]]           a named game query (has, pastN, mkPrice …), answered by the host
//   ["arr", a, b, …]                  a list (used for lines that are computed)
//   ["!", a] ["neg", a]
//   ["&&", a, b] ["||", a, b]          JavaScript semantics: return an operand, not a bool
//   ["==", a, b] ["!=", a, b]          strict equality (=== / !==)
//   ["<"|"<="|">"|">=", a, b]  ["+"|"-"|"*"|"/"|"%", a, b]
//   ["?:", c, a, b]
//   ["cat", a, b]                     join two lists
//   ["do", [["set", path, value, guard|null], …], result]   write to S when read, then give result
'use strict';

const BIN = {
  '||': 1, '&&': 2, '==': 3, '!=': 3, '<': 4, '<=': 4, '>': 4, '>=': 4, '+': 5, '-': 5, '++': 5, '*': 6, '/': 6, '%': 6
};

// ---------- .pt text -> AST ----------
function tokenize(src) {
  const t = []; let i = 0;
  const re = /\s*(?:(\d+(?:\.\d+)?)|('(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"|“[^”]*”)|(===|!==|==|!=|<=|>=|&&|\|\||\+\+|[()\[\],.!<>+\-*\/%?:])|([A-Za-z_$][\w$]*))/y;
  while (i < src.length) {
    if (/^\s*$/.test(src.slice(i))) break;
    re.lastIndex = i; const m = re.exec(src);
    if (!m) throw new Error('Cannot read expression near: ' + src.slice(i, i + 20));
    i = re.lastIndex;
    if (m[1] !== undefined) t.push({ k: 'n', v: Number(m[1]) });
    else if (m[2] !== undefined) {
      const q = m[2];
      t.push({ k: 's', v: q[0] === '“' ? q.slice(1, -1) : JSON.parse(q[0] === "'" ? '"' + q.slice(1, -1).replace(/\\'/g, "'").replace(/"/g, '\\"') + '"' : q) });
    } else if (m[3] !== undefined) t.push({ k: 'p', v: m[3] === '===' ? '==' : m[3] === '!==' ? '!=' : m[3] });
    else {
      const w = m[4];
      if (w === 'and') t.push({ k: 'p', v: '&&' }); else if (w === 'or') t.push({ k: 'p', v: '||' });
      else if (w === 'not') t.push({ k: 'p', v: '!' }); else t.push({ k: 'id', v: w });
    }
  }
  return t;
}

function parse(src) {
  const t = tokenize(src); let p = 0;
  const peek = () => t[p], eat = (v) => { const x = t[p]; if (!x || (v && x.v !== v)) throw new Error('Expected ' + v + ' in: ' + src); p++; return x; };
  function primary() {
    const x = t[p++];
    if (!x) throw new Error('Unexpected end of expression: ' + src);
    if (x.k === 'n') return ['n', x.v];
    if (x.k === 's') return ['s', x.v];
    if (x.k === 'p' && x.v === '(') { const e = expr(0); eat(')'); return e; }
    if (x.k === 'p' && x.v === '[') { const a = ['arr']; if (peek() && peek().v !== ']') { do a.push(expr(0)); while (peek() && peek().v === ',' && eat(',')); } eat(']'); return a; }
    if (x.k === 'p' && x.v === '!') return ['!', unary()];
    if (x.k === 'p' && x.v === '-') { const u = unary(); return u[0] === 'n' ? ['n', -u[1]] : ['neg', u]; }
    if (x.k === 'id') {
      if (x.v === 'true') return ['b', true]; if (x.v === 'false') return ['b', false];
      if (x.v === 'null' || x.v === 'undefined') return ['null'];
      if (x.v === 'do' && peek() && peek().v === '(') {
        eat('('); const sets = []; let last;
        for (;;) {
          if (t[p].k === 'id' && t[p].v === 'set' && t[p + 1] && t[p + 1].v === '(') {
            p += 2; const path = eat().v; eat(','); const val = expr(0); let g = null;
            if (peek().v === ',') { eat(','); g = expr(0); }
            eat(')'); sets.push(['set', path, val, g]);
          } else { last = expr(0); break; }
          eat(',');
        }
        eat(')'); return ['do', sets, last];
      }
      if (peek() && peek().v === '(') {
        eat('('); const args = [];
        if (peek().v !== ')') { do args.push(expr(0)); while (peek().v === ',' && eat(',')); }
        eat(')'); return ['call', x.v, args];
      }
      let path = x.v;
      for (;;) {
        if (peek() && peek().v === '.') { eat('.'); path += '.' + eat().v; }
        else if (peek() && peek().v === '[') { eat('['); const k = eat(); if (k.k !== 's' && k.k !== 'n') throw new Error('Only fixed keys in []: ' + src); path += '.' + k.v; eat(']'); }
        else break;
      }
      return ['v', path];
    }
    throw new Error('Unexpected ' + x.v + ' in: ' + src);
  }
  function unary() { return primary(); }
  function expr(minP) {
    let l = unary();
    for (;;) {
      const o = peek();
      if (!o || o.k !== 'p') break;
      if (o.v === '?' && minP === 0) { eat('?'); const a = expr(0); eat(':'); const b = expr(0); l = ['?:', l, a, b]; continue; }
      const pr = BIN[o.v]; if (!pr || pr <= minP - 1 || pr < minP) break;
      eat(); const r = expr(pr + 1); l = [o.v === '++' ? 'cat' : o.v, l, r];
    }
    return l;
  }
  const e = expr(0);
  if (p < t.length) throw new Error('Unexpected ' + t[p].v + ' in: ' + src);
  return e;
}

// ---------- AST -> .pt text ----------
const ID = /^[A-Za-z_$][\w$]*$/;
function pathText(path) {
  return path.split('.').map((s, i) => i === 0 ? s : (ID.test(s) ? '.' + s : '[' + JSON.stringify(s) + ']')).join('');
}
function str(s) { return JSON.stringify(s); }
function print(a, ctx) {
  ctx = ctx || 0;
  switch (a[0]) {
    case 'n': return String(a[1]);
    case 's': return str(a[1]);
    case 'b': return String(a[1]);
    case 'null': return 'null';
    case 'v': return pathText(a[1]);
    case 'call': return a[1] + '(' + a[2].map(x => print(x)).join(', ') + ')';
    case 'arr': return '[' + a.slice(1).map(x => print(x)).join(', ') + ']';
    case 'cat': return print(a[1], 5) + ' ++ ' + print(a[2], 6);
    case 'do': return 'do(' + a[1].map(s => 'set(' + JSON.stringify(s[1]) + ', ' + print(s[2]) + (s[3] ? ', ' + print(s[3]) : '') + ')').join(', ') + ', ' + print(a[2]) + ')';
    case '!': { const inner = print(a[1], 9); return ctx >= 9 ? '!' + inner : 'not ' + inner; }
    case 'neg': return '-' + print(a[1], 9);
    case '?:': { const s = print(a[1], 1) + ' ? ' + print(a[2]) + ' : ' + print(a[3]); return ctx > 0 ? '(' + s + ')' : s; }
    default: {
      const pr = BIN[a[0]];
      const op = a[0] === '&&' ? 'and' : a[0] === '||' ? 'or' : a[0];
      const s = print(a[1], pr) + ' ' + op + ' ' + print(a[2], pr + 1);
      return ctx > pr ? '(' + s + ')' : s;
    }
  }
}

// ---------- AST -> JavaScript (for the browser build) ----------
function js(a) {
  switch (a[0]) {
    case 'n': return String(a[1]);
    case 's': return JSON.stringify(a[1]);
    case 'b': return String(a[1]);
    case 'null': return 'null';
    case 'v': {
      const parts = a[1].split('.');
      let out = 'S'; const acc = [];
      for (let i = 0; i < parts.length; i++) { out += ID.test(parts[i]) ? '.' + parts[i] : '[' + JSON.stringify(parts[i]) + ']'; acc.push(out); }
      // S.done.x is always safe to read; other paths are read the way the original code did (S.a && S.a.b)
      if (parts.length === 1 || (parts.length === 2 && parts[0] === 'done')) return out;
      return '(' + acc.join(' && ') + ')';
    }
    case 'call': return a[1] + '(' + a[2].map(js).join(', ') + ')';
    case 'arr': return '[' + a.slice(1).map(js).join(', ') + ']';
    case 'cat': return '(' + js(a[1]) + ').concat(' + js(a[2]) + ')';
    case 'do': return '(' + a[1].map(s => (s[3] ? '(' + js(s[3]) + ') && ' : '') + '(' + jsSet(s[1]) + ' = ' + js(s[2]) + ')').join(', ') + ', ' + js(a[2]) + ')';
    case '!': return '!(' + js(a[1]) + ')';
    case 'neg': return '-(' + js(a[1]) + ')';
    case '?:': return '(' + js(a[1]) + ' ? ' + js(a[2]) + ' : ' + js(a[3]) + ')';
    case '==': return '(' + js(a[1]) + (a[1][0] === 'null' || a[2][0] === 'null' ? ' == ' : ' === ') + js(a[2]) + ')';
    case '!=': return '(' + js(a[1]) + (a[1][0] === 'null' || a[2][0] === 'null' ? ' != ' : ' !== ') + js(a[2]) + ')';
    default: return '(' + js(a[1]) + ' ' + a[0] + ' ' + js(a[2]) + ')';
  }
}

function jsSet(path) { return 'S' + path.split('.').map(p => ID.test(p) ? '.' + p : '[' + JSON.stringify(p) + ']').join(''); }

// ---------- evaluate with JavaScript semantics (Node runner and tests; cond.gd mirrors this) ----------
function truthy(v) { return !(v === undefined || v === null || v === false || v === 0 || v === '' || (typeof v === 'number' && isNaN(v))); }
function evaluate(a, host) {
  switch (a[0]) {
    case 'n': case 's': case 'b': return a[1];
    case 'null': return null;
    case 'v': return host.get(a[1]);
    case 'call': return host.call(a[1], a[2].map(x => evaluate(x, host)));
    case 'arr': return a.slice(1).map(x => evaluate(x, host));
    case 'cat': return [].concat(evaluate(a[1], host), evaluate(a[2], host));
    case 'do': for (const s of a[1]) if (!s[3] || truthy(evaluate(s[3], host))) host.set(s[1], evaluate(s[2], host)); return evaluate(a[2], host);
    case '!': return !truthy(evaluate(a[1], host));
    case 'neg': return -evaluate(a[1], host);
    case '&&': { const l = evaluate(a[1], host); return truthy(l) ? evaluate(a[2], host) : l; }
    case '||': { const l = evaluate(a[1], host); return truthy(l) ? l : evaluate(a[2], host); }
    case '?:': return truthy(evaluate(a[1], host)) ? evaluate(a[2], host) : evaluate(a[3], host);
    case '==': return same(evaluate(a[1], host), evaluate(a[2], host));
    case '!=': return !same(evaluate(a[1], host), evaluate(a[2], host));
    case '<': return evaluate(a[1], host) < evaluate(a[2], host);
    case '<=': return evaluate(a[1], host) <= evaluate(a[2], host);
    case '>': return evaluate(a[1], host) > evaluate(a[2], host);
    case '>=': return evaluate(a[1], host) >= evaluate(a[2], host);
    case '+': { const l = evaluate(a[1], host), r = evaluate(a[2], host); return (typeof l === 'string' || typeof r === 'string') ? jsStr(l) + jsStr(r) : (l || 0) + (r || 0); }
    case '-': return (evaluate(a[1], host) || 0) - (evaluate(a[2], host) || 0);
    case '*': return (evaluate(a[1], host) || 0) * (evaluate(a[2], host) || 0);
    case '/': return evaluate(a[1], host) / evaluate(a[2], host);
    case '%': return evaluate(a[1], host) % evaluate(a[2], host);
  }
  throw new Error('Unknown expression node ' + a[0]);
}
function same(a, b) { if (a === undefined) a = null; if (b === undefined) b = null; return a === b; }
function jsStr(v) { return v === null || v === undefined ? 'undefined' : String(v); }

module.exports = { parse, print, js, evaluate, truthy, pathText };

// one spelling for lists, so a script and its compiled form compare equal
function canon(a) {
  if (!Array.isArray(a)) return a;
  if (a[0] === 'v' || a[0] === 's' || a[0] === 'n' || a[0] === 'b' || a[0] === 'null') return a;
  if (a[0] === 'call') return ['call', a[1], a[2].map(canon)];
  if (a[0] === 'do') return ['do', a[1].map(s => ['set', s[1], canon(s[2]), s[3] ? canon(s[3]) : null]), canon(a[2])];
  const b = [a[0]].concat(a.slice(1).map(canon));
  if (b[0] === 'cat') {
    let [, l, r] = b;
    if (l[0] === 'arr' && l.length === 1 && (r[0] === 'arr' || r[0] === 'cat')) return r;
    if (l[0] === 'arr' && r[0] === 'arr') return l.concat(r.slice(1));
    if (l[0] === 'cat' && l[2][0] === 'arr' && r[0] === 'arr') return ['cat', l[1], l[2].concat(r.slice(1))];
    if (r[0] === 'cat') return canon(['cat', ['cat', l, r[1]], r[2]]);
  }
  return b;
}
module.exports.canon = canon;

// where only true/false matters (a condition), !!x is x, and the same holds inside not / and / or / ?: tests
function truthCtx(a) {
  if (!Array.isArray(a)) return a;
  if (a[0] === '!' && Array.isArray(a[1]) && a[1][0] === '!') return truthCtx(a[1][1]);
  if (a[0] === '!') return ['!', truthCtx(a[1])];
  if (a[0] === '&&' || a[0] === '||') return [a[0], truthCtx(a[1]), truthCtx(a[2])];
  if (a[0] === '?:') return ['?:', truthCtx(a[1]), truthCtx(a[2]), truthCtx(a[3])];
  return a;
}
module.exports.truthCtx = truthCtx;
