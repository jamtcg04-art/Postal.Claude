// write every conversation as .pt, read it back, and compare with the compiled reference
'use strict';
const P = require('./ptc'), fs = require('fs');
const convs = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
function sortK(v) { if (Array.isArray(v)) return v.map(sortK); if (v && typeof v == 'object') { const o = {}; Object.keys(v).sort().forEach(k => o[k] = sortK(v[k])); return o; } return v; }
let ok = 0, bad = 0;
for (const id in convs) {
  let back;
  try { back = P.parse(P.writeConv(id, convs[id]), id)[id]; } catch (e) { console.log('FAIL', id, e.message.slice(0, 300)); bad++; continue; }
  const A = JSON.stringify(sortK(convs[id])), B = JSON.stringify(sortK(back));
  if (A === B) ok++; else {
    bad++;
    let i = 0; while (A[i] === B[i]) i++;
    console.log('DIFF', id, '\n  want', A.slice(Math.max(0, i - 120), i + 120), '\n  got ', B.slice(Math.max(0, i - 120), i + 120));
  }
}
console.log(ok + ' of ' + (ok + bad) + ' conversations round-trip exactly');
process.exit(bad ? 1 : 0);
