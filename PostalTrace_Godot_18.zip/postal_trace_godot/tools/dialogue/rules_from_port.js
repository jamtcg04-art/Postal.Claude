// Builds data/dialogue_rules.json (what the compiler checks names against, and what PTNativeHost reads)
// from the Godot port's tables and scenes.
// usage: node tools/rules_from_port.js <godot project> data/dialogue_rules.json
'use strict';
const fs = require('fs'), path = require('path');
function rulesFrom(proj) {
const T = JSON.parse(fs.readFileSync(path.join(proj, 'data', 'tables.json'), 'utf8'));
const noFn = v => { if (Array.isArray(v)) return v.map(noFn); if (v && typeof v === 'object') { if ('$js' in v) return undefined; const o = {}; for (const k in v) { const x = noFn(v[k]); if (x !== undefined) o[k] = x; } return o; } return v; };
const r = {};
for (const k of ['VOICES', 'SKILLS', 'THOUGHTS', 'DEF_VOICE', 'TALLY_TAGS', 'FAIL_REM', 'TRAITS', 'PATTERN', 'PATTERN_LINE', 'DIFFN', 'TEMP_CAP', 'V_OF', 'VPERK', 'ADDR', 'ADDR_V']) r[k] = noFn(T[k]);
r.V_RULES = (T.V_RULES || []).map(x => [x[0], x[1], x[2] && x[2].$re !== undefined ? { __re: x[2].$re, flags: x[2].flags || '' } : x[2]]);
r.BANTER = noFn(T.BANTER || {}); for (const k in (T.MORE_BANTER || {})) r.BANTER[k] = (r.BANTER[k] || []).concat(noFn(T.MORE_BANTER[k]));
r.MANNER = noFn(T.MANNER || {}); for (const k in (T.MORE_MANNER || {})) r.MANNER[k] = (r.MANNER[k] || []).concat(noFn(T.MORE_MANNER[k]));
r.ITEMS = {}; for (const k in T.ITEMS) r.ITEMS[k] = { name: T.ITEMS[k].name, kind: T.ITEMS[k].kind };
r.TALKERS = {}; r.OBJECTS = {};
for (const f of fs.readdirSync(path.join(proj, 'data', 'scenes'))) {
  const id = f.replace('.json', ''), sc = JSON.parse(fs.readFileSync(path.join(proj, 'data', 'scenes', f), 'utf8'));
  r.TALKERS[id] = {}; (sc.talk || []).forEach(t => { r.TALKERS[id][t.id] = { name: t.name, role: t.role, mood: t.mood, hue: t.hue }; });
}
for (const id in (T.OBJECTS || {})) { r.OBJECTS[id] = {}; T.OBJECTS[id].forEach(o => { r.OBJECTS[id]['x_' + o.id] = { name: o.name, role: typeof o.blurb === 'string' ? o.blurb : 'Something here' }; }); }
return r;
}
module.exports = { rulesFrom };
if (require.main === module) {
  const [proj, out] = process.argv.slice(2);
  const r = rulesFrom(proj);
  fs.writeFileSync(out, JSON.stringify(r, null, 1));
  console.log('rules: ' + Object.keys(r.VOICES).length + ' voices, ' + Object.keys(r.THOUGHTS).length + ' thoughts, ' + Object.keys(r.ITEMS).length + ' items');
}
