// Lists how the browser's place editor knows every prop, blocker, person and patch of ground in each
// place, so tests/edits_test.gd can check the Godot build keys them the same way (edits files then
// apply the same in both builds).
//   SRC=index.html W3D_DIR=dir/with/w3d_files node tools/edit_ids.js tests/edit_ids.json
'use strict';
const fs = require('fs');
const st = require('./extract_run.js'); const ev = st.ev;
ev(`wBuf = function (P, N, U) { return { P: P, N: N, U: U, k: P.length / 3 }; }`);
ev(`wTex = function (key) { return { key: key, ok: false }; }`);
ev(`W.gl = W.gl || {}`);
ev(`(function () { var real = wModel; wModel = function (name) { if (W3D.models[name] || PROC[name]) { try { return real(name); } catch (e) {} } return { parts: [], h: 1, w: 1, d: 1, mn: [-0.5, 0, -0.5], sz: [1, 1, 1], missing: true }; }; })()`);
const LAYOUT = ev('LAYOUT'), out = {};
for (const id of Object.keys(LAYOUT)) {
  const L0 = LAYOUT[id], areas = L0.areas ? [null].concat(Object.keys(L0.areas)) : [null];
  for (const area of areas) {
    ev(`S = fresh(); S.trait = 'steady'; S.route = ['cross', ${JSON.stringify(id)}]; S.idx = 1; S.seen = 2; W.areas = {}; W.areas[${JSON.stringify(id)}] = ${JSON.stringify(area)};`);
    if (id === 'cross') ev(`S.route = ['cross']; S.idx = 0;`);
    let sc; try { sc = ev(`wBuild(${JSON.stringify(id)}, LAYOUT[${JSON.stringify(id)}])`); } catch (e) { continue; }
    if (!sc) continue;
    out[id + (area ? '__' + area : '')] = {
      key: ev('edPlaceKey')(id, area),
      props: sc.props.map(it => it._edId || null),
      solids: (sc.solid || []).map(s => s._sid || null),
      people: (sc.people || []).map(p => p._pk), extras: (sc.extras || []).map(p => p._pk),
      grounds: (sc.grounds || []).map(g => g._gk)
    };
  }
}
fs.writeFileSync(process.argv[2], JSON.stringify(out));
console.log('places', Object.keys(out).length);
