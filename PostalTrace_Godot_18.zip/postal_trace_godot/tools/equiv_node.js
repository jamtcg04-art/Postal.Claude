// Evaluates every zero-argument data function under a few test states, for comparison with Godot.
const fs=require('fs');const st=require('./extract_run.js');const ev=st.ev;
const KEYS=new Set(['show','when','say','mood','text','learn','need','auto','hint','bonus','dcAdj','extra']);
const SC=ev('SCENES'),ENC=ev('ENC'),TALK=ev('TALK'),G=ev('GRAPH');
// gather all S.done.<name> names to build a flag-heavy state
const names=new Set();
function scan(v,p,out,seen){if(v&&typeof v==='object'){if(seen.has(v))return;seen.add(v);for(const k of Object.keys(v)){const d=Object.getOwnPropertyDescriptor(v,k);if(d.get){if(KEYS.has(k)||k==='fx')out.push([p+'.'+k,d.get,true]);continue}scan(v[k],p+'.'+k,out,seen)}}else if(typeof v==='function'&&v.length===0){const k=p.split('.').pop();if(KEYS.has(k))out.push([p,v,false])}}
const fns=[];
for(const id of Object.keys(SC))scan(Object.assign({},SC[id],{talk:TALK[id]||[]}),'scenes/'+id,fns,new Set());
for(const id of Object.keys(ENC))scan(Object.assign({},ENC[id],{talk:TALK[id]||[]}),'scenes/'+id,fns,new Set());
for(const k of Object.keys(G)){const [s,t]=k.split(':');scan(G[k],'graphs/'+s+'/'+t,fns,new Set())}
for(const [p,f] of fns){const m=f.toString().match(/S\.done\.([A-Za-z_0-9]+)/g)||[];m.forEach(x=>names.add(x.slice(7)))}
function h(s){let x=0;for(const c of s)x=(x*31+c.charCodeAt(0))>>>0;return x}
const base=()=>Object.assign(ev('fresh()'),{trait:'steady',route:['cross','mill','pit','ford','siblings','hermits','oak','bearers','venn','ridge','chapel','mine','malice'],idx:0});
const states=[];
let s1=base();states.push(s1);
let s2=base();s2.idx=3;s2.inv=['case','hat','map','flour','note'];s2.worn={hat:true};s2.duty=2;s2.trust=-2;s2.hp=3;s2.past={n:3,view:null,last:-9};s2.thoughts=['quiet','finger'];s2.mull={finger:1};s2.up={arms:2,nerve:1,wits:3,grit:0};s2.vr={ledger:2,cipher:1,wire:1};
for(const n of names)if(h(n)%2===0)s2.done[n]=true;states.push(s2);
let s3=base();s3.idx=9;s3.trust=2;s3.duty=-2;s3.inv=['case','orders','tea','receipt'];s3.read=true;s3.sealBroken=true;s3.past={n:6,view:'hand',last:-9};s3.out={cross:{i:3,ok:true}};s3.relay={ford:'full',oak:'partial'};
for(const n of names)if(h(n)%3!==0)s3.done[n]=true;states.push(s3);
const out=[];
for(const s of states){ev('S = '+JSON.stringify(s));const res={};
 for(const [p,f,isGet] of fns){let r;try{r=f()}catch(e){r={err:String(e.message||e)}};if(typeof r==='function')r='<fn>';try{res[p]=JSON.parse(JSON.stringify(r===undefined?null:r,(k,v)=>typeof v==='function'?'<fn>':v))}catch(e){res[p]='<unser>'}}
 out.push({state:s,res})}
fs.writeFileSync(process.argv[2],JSON.stringify(out));console.log('fns',fns.length,'flags',names.size);
