// Exports The Postal Trace's data tables to JSON for the Godot project.
const fs=require('fs'),path=require('path');const st=require('./extract_run.js');const ev=st.ev;
const OUT=process.argv[2];
const {scopes,objOf}=require('./closures.js');const acorn=require('acorn'),walk=require('acorn-walk');
function refs(src){const ids=new Set();const ast=acorn.parse('('+src+')',{ecmaVersion:2020});walk.ancestor(ast,{Identifier(x,anc){const par=anc[anc.length-2];if(par&&par.type==='MemberExpression'&&par.property===x&&!par.computed)return;if(par&&par.type==='Property'&&par.key===x&&!par.computed)return;ids.add(x.name)}});return ids}
let envCount=0;
function serFn(fn,seen){const src=fn.toString();const o={$js:src};const ids=refs(src);const sc=scopes(fn);const env={};
 for(const s of sc){if(!s.desc.startsWith('Closure')&&!s.desc.startsWith('Block'))continue;if('GRAPH' in s.vars)break;for(const k of Object.keys(s.vars)){if(ids.has(k)&&!(k in env)){env[k]=ser(objOf(s.vars[k]),seen)}}}
 if(Object.keys(env).length){o.$env=env;envCount++}return o}
function ser(v,seen){
  if(v===null||v===undefined)return null;
  if(typeof v==='function')return serFn(v,seen);
  if(require("util").types.isRegExp(v))return {$re:v.source,flags:v.flags};
  if(typeof v!=='object')return (typeof v==='number'&&!isFinite(v))?null:v;
  if(seen.includes(v))return null; seen=seen.concat([v]);
  if(Array.isArray(v))return v.map(x=>ser(x,seen));
  const o={};for(const k of Object.keys(v)){const d=Object.getOwnPropertyDescriptor(v,k);if(d.get){o[k]=serFn(d.get,seen);o[k].$get=true;continue}o[k]=ser(v[k],seen)}return o;
}
const CORE=['SKILLS','TRAITS','SKILL_INFO','V_OF','V_PTS','V_RULES','VOICES','DEF_VOICE','VPERK','FAIL_REM','PERKS','THOUGHTS','ITEMS','NAMES','LIM','STOPS','DEADLINE','XP_PER_POINT','MAX_UP','TEMP_CAP','MAX_HOLES','POOL','CC_MAX','HARD_RULES','ARCHES','INTRO_PAGES','FLAVOR','FLAVOR_MORE','FLAVOR_PAIN','FLAVOR_TIRED','ENDINGS','END_V','COURIER','AFTER','AFTER_RELAY','ENDAFTER','RELAY_V','OFF','DUTY_INTRO','DUTY_TIP','TALLY_TAGS','PATTERN','PATTERN_LINE','CHOICE_TALLY','CROWN','OFF_LINES','HAT_LINES','SEAL_V','DIFFN','MEM','SCENE_VOICE','OBJECTS','ORDERS_TEXT','TIN_TIP','CASE_TIP','ROADV','DUTY_REACT','HAT_DUTY','WIRE_HEARD','MANNER','MORE_MANNER','BANTER','MORE_BANTER','BEAT','BEAT2','COMP','COMP_MEET','ERRANDS','ERRAND_REWARD','CREDITS','CREDIT','CREDIT2','CREDIT3','CREDIT4','DUTY_TALLY','HAT_TALLY','ADDR','ADDR_V','OSTREY_HAND','SEAL_V'];
fs.mkdirSync(path.join(OUT,'graphs'),{recursive:true});fs.mkdirSync(path.join(OUT,'scenes'),{recursive:true});
const core={},missing=[];for(const n of CORE){const v=ev(n);if(v===undefined){missing.push(n);continue}core[n]=ser(v,[])}
fs.writeFileSync(path.join(OUT,'tables.json'),JSON.stringify(core,null,1));
// scenes: main stops and road meetings, one file each, with their talkers
const SC=ev('SCENES'),ENC=ev('ENC'),TALK=ev('TALK'),G=ev('GRAPH');
const idx={main:Object.keys(SC),road:Object.keys(ENC)};
for(const [kind,tab] of [['main',SC],['road',ENC]])for(const id of Object.keys(tab)){const o=ser(tab[id],[]);o.kind=kind;o.talk=ser(TALK[id]||[],[]);fs.writeFileSync(path.join(OUT,'scenes',id+'.json'),JSON.stringify(o,null,1))}
const gl=[];for(const k of Object.keys(G)){const [s,t]=k.split(':');fs.mkdirSync(path.join(OUT,'graphs',s),{recursive:true});fs.writeFileSync(path.join(OUT,'graphs',s,t+'.json'),JSON.stringify(ser(G[k],[]),null,1));gl.push(k)}
idx.graphs=gl;idx.talk_only=Object.keys(TALK).filter(k=>!SC[k]&&!ENC[k]);
fs.writeFileSync(path.join(OUT,'index.json'),JSON.stringify(idx,null,1));
console.log('closures with env',envCount);console.log('missing',missing.join(','));console.log('main',idx.main.join(','));console.log('road',idx.road.join(','));console.log('graphs',gl.length,'talkOnly',idx.talk_only.join(','));
// portraits
const PORT=ev('PORT');fs.mkdirSync(path.join(OUT,'..','assets','portraits'),{recursive:true});for(const k of Object.keys(PORT)){const m=/^data:image\/png;base64,(.*)$/.exec(PORT[k]);if(m)fs.writeFileSync(path.join(OUT,'..','assets','portraits',k+'.png'),Buffer.from(m[1],'base64'))}
console.log('portraits',Object.keys(PORT).join(','));
