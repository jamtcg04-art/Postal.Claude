// Exports every function and data table of the browser game that is not 3D, editor or already in tables.json,
// so Godot can run the same logic for companions, the market, the gate, errands, horses and the rest.
const fs=require('fs');const st=require('./extract_run.js');const ev=st.ev;
const {scopes,objOf}=require('./closures.js');const acorn=require('acorn'),walk=require('acorn-walk');
const OUT=process.argv[2];const util=require('util');
const rows=JSON.parse(fs.readFileSync(require('os').tmpdir()+'/scope.json'));
const tables=JSON.parse(fs.readFileSync(OUT+'/tables.json'));
const SKIP_DATA=new Set(['PORT','PK','ML','UIK','LAYOUT','WORLDS','GND','drops','W','GRAPH','SCENES','ENC','TALK','screen','modal','tip','rc','rx','CLOUD','PROC','EDM','PPL','CITY','TOWN','GROW','STONE','RG_PEOPLE','RG_MEN','RG_WOMEN','RG_QC','RG_TRADE','RG_FIT_NAMES','RG_UNI','RG_OFFICER','RG_WPN','RG_KIDS','RG_OLD','RG_REBEL','RG_MOURN','RG_FARM','RG_RIVER','RG_COLD','RG_LOOP','GND_TEX','BLK_CV','ED_PICK','AUD','sfxCache','DLG','CKT','MOVE','STOPS_XY','STOP_XY','MK_WALKERS','FOL_WAIT','VCOL','PACK_NEED','NOFADE','AUTO','BLD','LAMP_HEAD']);
const is3D=n=>/^(w[A-Z]|W_|rg[A-Z]|RG_|_w[A-Z]|m(Tri|Mul|Mound|Quad|Box|TRS|Rock|New)$|gnd|ppl|blk|ed[A-Z]|ED_|open(Dev|Panel)|dev[A-Z]|map|nodeXY|legendHtml|playScroll|rain|sizeRain|dlgStage|dlgBeats|bindTextTip|bindVoiceTips|showTip|showTextTip|hideTip|cloud|slot|latestSave|loadPack|snap|autoSave|uiDecor|uik|ico$|portrait$|sfx|fx$|fxp$)/.test(n);
function refs(src){const ids=new Set();const ast=acorn.parse('('+src+')',{ecmaVersion:2020});walk.ancestor(ast,{Identifier(x,anc){const par=anc[anc.length-2];if(par&&par.type==='MemberExpression'&&par.property===x&&!par.computed)return;if(par&&par.type==='Property'&&par.key===x&&!par.computed)return;ids.add(x.name)}});return ids}
function serFn(fn,depth){depth=depth||0;const src=fn.toString();const o={$js:src};let ids;try{ids=refs(src)}catch(e){o.$bad=String(e.message);return o}const sc=scopes(fn);const env={};
 for(const s of sc){if(!s.desc.startsWith('Closure')&&!s.desc.startsWith('Block'))continue;if('GRAPH' in s.vars)break;for(const k of Object.keys(s.vars))if(ids.has(k)&&!(k in env))env[k]=ser(objOf(s.vars[k]),[],depth+1)}
 if(Object.keys(env).length)o.$env=env;return o}
function ser(v,seen,depth){
  depth=depth||0; if(depth>14)return null;
  if(v===null||v===undefined)return null;
  if((typeof v==='object'||typeof v==='function')&&util.types.isProxy(v))return null;
  if(typeof v==='function')return depth>6?null:serFn(v,depth);
  if(require("util").types.isRegExp(v))return {$re:v.source,flags:v.flags};
  if(typeof v!=='object')return (typeof v==='number'&&!isFinite(v))?null:v;
  if(seen.includes(v))return null; seen=seen.concat([v]);
  if(Array.isArray(v))return v.map(x=>ser(x,seen,depth+1));
  if(v.nodeType||v===ev('screen'))return null;
  const o={};for(const k of Object.keys(v)){const d=Object.getOwnPropertyDescriptor(v,k);if(d.get){o[k]=serFn(d.get);o[k].$get=true;continue}o[k]=ser(v[k],seen,depth+1)}return o;
}
const lib={functions:{},data:{}};let bad=[];
for(const [n,t] of rows){
  if(is3D(n))continue;
  const v=ev(n);
  if(t==='function'){const s=serFn(v);if(s.$bad)bad.push(n);lib.functions[n]=s}
  else{ if(SKIP_DATA.has(n)||n in tables)continue; try{const s=ser(v,[]);const len=JSON.stringify(s).length;if(len>200000){console.log('big data skipped',n,len);continue}lib.data[n]=s}catch(e){bad.push(n+'(data)')} }
}
// the clothes people wear, so the place editor can change an outfit the way the browser does
{const names=new Set(rows.map(r=>r[0])),q=['wFitFor','wRigHash','wPlaceId','PPL_ANIMS','RG_FIT_NAMES','MK_WALKERS','mkWalkLines'],done=new Set();
 while(q.length){const n=q.shift();if(done.has(n)||n==='W')continue;done.add(n);if(!is3D(n)&&(n in lib.functions||n in lib.data))continue;const v=ev(n);
  if(typeof v==='function'){lib.functions[n]=serFn(v);const js=[];(function walkJs(o){if(o&&typeof o==='object'){if(typeof o.$js==='string')js.push(o.$js);for(const k in o)walkJs(o[k])}})(lib.functions[n]);for(const src of js)for(const r of refs(src))if(names.has(r)&&!done.has(r))q.push(r)}else if(v!==undefined)lib.data[n]=ser(v,[])}}
for(const f of Object.values(lib.functions))if(f.$env&&f.$env.W!==undefined)delete f.$env.W;   // Godot supplies W (the place you are in)
fs.writeFileSync(OUT+'/lib.json',JSON.stringify(lib));
console.log('functions',Object.keys(lib.functions).length,'data',Object.keys(lib.data).length,'bad',bad.join(','),'size',fs.statSync(OUT+'/lib.json').size);
