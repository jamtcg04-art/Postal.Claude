// Runs the game's inline script with a stub DOM and dumps chosen globals.
const fs=require('fs'),vm=require('vm');
const html=fs.readFileSync(process.env.SRC||'index.html','utf8');
const lines=html.split('\n');
let s=lines.findIndex(l=>l.trim()==='<script>');
let e=lines.length-1; while(!lines[e].includes('</script>')) e--;
let body=lines.slice(s+1,e).join('\n');
body=body.replace(/cloudInit\(\);\s*start\(\);\s*\}\)\(\);\s*$/, '__EXPORT(function(n){try{return eval(n)}catch(x){return undefined}});})();');
if(!body.includes('__EXPORT')) throw 'no tail';
function stub(name){const f=function(){return stub(name+'()')};return new Proxy(f,{get(t,k){if(k===Symbol.toPrimitive)return()=>0;if(k==='length')return 0;if(k===Symbol.iterator)return function*(){};if(k==='then')return undefined;if(k in t&&k!=='name'&&k!=='prototype')return t[k];return stub(name+'.'+String(k))},set(){return true},apply(){return stub(name+'()')},construct(){return stub('new '+name)}})}
const store={};const atob=s=>Buffer.from(s,'base64').toString('binary'),btoa=s=>Buffer.from(s,'binary').toString('base64');
const ctx={console,Math,JSON,Date,Object,Array,String,Number,Boolean,RegExp,Error,Map,Set,parseInt,parseFloat,atob,btoa,isNaN,isFinite,Float32Array,Uint8Array,Uint16Array,Int16Array,Uint32Array,Int32Array,ArrayBuffer,DataView,Promise,Symbol,setTimeout:()=>0,clearTimeout:()=>0,setInterval:()=>0,clearInterval:()=>0,requestAnimationFrame:()=>0,cancelAnimationFrame:()=>0,performance:{now:()=>0},innerWidth:800,innerHeight:600,devicePixelRatio:1,
 document:stub('document'),navigator:stub('navigator'),location:stub('location'),localStorage:{getItem:()=>null,setItem(){},removeItem(){}},matchMedia:()=>({matches:false,addEventListener(){}}),addEventListener(){},removeEventListener(){},Image:function(){return stub('img')},Audio:function(){return stub('audio')},fetch:()=>new Promise(()=>{}),
 __EXPORT:(ev)=>{store.ev=ev}};
if(process.env.W3D_DIR){const W={models:{},tex:{}};ctx.W3D=W;}else ctx.W3D=stub('W3D'); ctx.window=ctx; ctx.self=ctx; ctx.globalThis=ctx;
vm.createContext(ctx);
if(process.env.W3D_DIR){const d=process.env.W3D_DIR;const order=['w3d_core.js','w3d_mv.js','w3d_rig.js','w3d_market.js','w3d_mine.js','w3d_rocks.js'];store.packs=[];
 for(const f of order){const p=require('path').join(d,f);if(fs.existsSync(p)){vm.runInContext(fs.readFileSync(p,'utf8'),ctx,{filename:f});store.packs.push(f)}}
 if(!ctx.W3D.models)ctx.W3D.models={};if(!ctx.W3D.tex)ctx.W3D.tex={};}
try{vm.runInContext(body,ctx,{filename:'game.js'})}catch(err){console.error('RUN ERR',err&&err.stack&&err.stack.split('\n').slice(0,4).join('\n'))}
store.ctx=ctx;module.exports=store;
if(require.main===module){console.log('export ok:',!!store.ev); if(store.ev){for(const n of ['GRAPH','THOUGHTS','VOICES','SKILLS','TALK','SCENES','ITEMS','ENDINGS','ARCHES','COMP','MEM','ERRANDS'])console.log(n,typeof store.ev(n),store.ev(n)&&Object.keys(store.ev(n)).length)}}
