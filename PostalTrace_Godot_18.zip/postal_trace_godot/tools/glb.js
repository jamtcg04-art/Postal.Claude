// A small glTF 2.0 (GLB) writer: meshes with several primitives, materials with
// external textures, and optionally a skin with animations.
'use strict';

class Glb {
  constructor() {
    this.json = { asset: { version: '2.0', generator: 'postal-trace w3d_export' }, scene: 0, scenes: [{ nodes: [] }], nodes: [],
      meshes: [], materials: [], buffers: [{ byteLength: 0 }], bufferViews: [], accessors: [], textures: [], images: [], samplers: [] };
    this.chunks = []; this.len = 0; this.acache = new Map(); this.texIndex = {}; this.extUsed = new Set();
  }
  _view(buf, target) {
    const pad = (4 - (this.len % 4)) % 4; if (pad) { this.chunks.push(Buffer.alloc(pad)); this.len += pad; }
    const v = { buffer: 0, byteOffset: this.len, byteLength: buf.length }; if (target) v.target = target;
    this.chunks.push(buf); this.len += buf.length; this.json.bufferViews.push(v); return this.json.bufferViews.length - 1;
  }
  accessor(arr, type, opts) {
    opts = opts || {};
    if (this.acache.has(arr)) return this.acache.get(arr);
    const idx = this._accessor(arr, type, opts); this.acache.set(arr, idx); return idx;
  }
  _accessor(arr, type, opts) {
    const ct = arr instanceof Float32Array ? 5126 : arr instanceof Uint32Array ? 5125 : arr instanceof Uint16Array ? 5123 : arr instanceof Uint8Array ? 5121 : 5126;
    const comps = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 }[type];
    const view = this._view(Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength), opts.target);
    const a = { bufferView: view, componentType: ct, count: arr.length / comps, type };
    if (opts.normalized) a.normalized = true;
    if (opts.minmax) { const mn = [], mx = []; for (let c = 0; c < comps; c++) { mn[c] = Infinity; mx[c] = -Infinity; } for (let i = 0; i < arr.length; i++) { const c = i % comps; if (arr[i] < mn[c]) mn[c] = arr[i]; if (arr[i] > mx[c]) mx[c] = arr[i]; } a.min = mn; a.max = mx; }
    this.json.accessors.push(a); return this.json.accessors.length - 1;
  }
  texture(key, uri) {
    if (this.texIndex[key] !== undefined) return this.texIndex[key];
    if (!this.json.samplers.length) this.json.samplers.push({ magFilter: 9728, minFilter: 9986, wrapS: 10497, wrapT: 10497 });
    this.json.images.push({ uri, name: key }); this.json.textures.push({ source: this.json.images.length - 1, sampler: 0 });
    return (this.texIndex[key] = this.json.textures.length - 1);
  }
  material(m) {
    const mat = { name: m.name, doubleSided: true, pbrMetallicRoughness: { baseColorFactor: (m.color || [1, 1, 1]).concat([1]), metallicFactor: 0, roughnessFactor: 1 } };
    if (m.tex) { mat.pbrMetallicRoughness.baseColorTexture = { index: this.texture(m.tex, m.uri) }; mat.alphaMode = 'MASK'; mat.alphaCutoff = 0.5; }
    if (m.unlit) { mat.extensions = { KHR_materials_unlit: {} }; this.extUsed.add('KHR_materials_unlit'); }
    this.json.materials.push(mat); return this.json.materials.length - 1;
  }
  // prims: [{P, N, U, I?, J?, Wt?, mat}] -> mesh index
  mesh(name, prims) {
    const out = [];
    for (const p of prims) {
      const at = { POSITION: this.accessor(p.P, 'VEC3', { minmax: true, target: 34962 }), NORMAL: this.accessor(p.N, 'VEC3', { target: 34962 }) };
      if (p.U) at.TEXCOORD_0 = this.accessor(p.U, 'VEC2', { target: 34962 });
      if (p.J) { at.JOINTS_0 = this.accessor(p.J, 'VEC4', { target: 34962 }); at.WEIGHTS_0 = this.accessor(p.Wt, 'VEC4', { target: 34962 }); }
      const prim = { attributes: at, material: this.material(p.mat), mode: 4 };
      if (p.I) prim.indices = this.accessor(p.I, 'SCALAR', { target: 34963 });
      out.push(prim);
    }
    this.json.meshes.push({ name, primitives: out }); return this.json.meshes.length - 1;
  }
  node(n) { this.json.nodes.push(n); return this.json.nodes.length - 1; }
  write(file) {
    const j = this.json; j.buffers[0].byteLength = this.len;
    for (const k of ['textures', 'images', 'samplers']) if (!j[k].length) delete j[k];
    if (this.extUsed.size) j.extensionsUsed = [...this.extUsed];
    if (j.animations && !j.animations.length) delete j.animations;
    let js = Buffer.from(JSON.stringify(j)); const jp = (4 - js.length % 4) % 4; js = Buffer.concat([js, Buffer.alloc(jp, 0x20)]);
    let bin = Buffer.concat(this.chunks); const bp = (4 - bin.length % 4) % 4; bin = Buffer.concat([bin, Buffer.alloc(bp)]);
    const head = Buffer.alloc(12); head.writeUInt32LE(0x46546C67, 0); head.writeUInt32LE(2, 4); head.writeUInt32LE(12 + 8 + js.length + 8 + bin.length, 8);
    const c1 = Buffer.alloc(8); c1.writeUInt32LE(js.length, 0); c1.writeUInt32LE(0x4E4F534A, 4);
    const c2 = Buffer.alloc(8); c2.writeUInt32LE(bin.length, 0); c2.writeUInt32LE(0x004E4942, 4);
    require('fs').writeFileSync(file, Buffer.concat([head, c1, js, c2, bin]));
  }
}
module.exports = Glb;
