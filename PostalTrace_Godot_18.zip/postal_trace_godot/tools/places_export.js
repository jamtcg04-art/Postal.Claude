// Second half of the 3D export: every place, as the game itself lays it out, to data/places/<id>.json.
'use strict';
const fs = require('fs'), path = require('path');
const X = require('./w3d_export.js'); const { ev, W3D, sizes } = X;
const OUT = process.argv[2];
const missing = new Set();
// run the game's own builder with the drawing calls replaced by recorders
ev(`wBuf = function (P, N, U) { return { P: P, N: N, U: U, k: P.length / 3 }; }`);
ev(`wTex = function (key) { return { key: key, ok: false }; }`);
ev(`W.gl = W.gl || {}`);
ev(`(function () { var real = wModel; wModel = function (name) { if (W3D.models[name] || PROC[name]) { try { return real(name); } catch (e) {} } __miss(name); return { parts: [], h: 1, w: 1, d: 1, mn: [-0.5, 0, -0.5], sz: [1, 1, 1], missing: true }; }; })()`);
X.st.ctx.__miss = n => missing.add(n);
ev(`wRigDraw = function (p, x, y, z, face, want, o) { __rig = { want: (p && p.want && !W.rigFight) ? p.want : want, o: o }; return true; }`);
const plain = (v, depth) => {
  if (v === null || v === undefined) return null;
  if (typeof v === 'function') return undefined;
  if (typeof v !== 'object') return typeof v === 'number' && !isFinite(v) ? null : v;
  if (depth > 6) return undefined;
  if (Array.isArray(v) || ArrayBuffer.isView(v)) return Array.from(v).map(x => plain(x, depth + 1));
  const o = {}; for (const k of Object.keys(v)) { if (k[0] === '_') continue; const x = plain(v[k], depth + 1); if (x !== undefined) o[k] = x; } return o;
};
function outfit(p, kind) {
  X.st.ctx.__rig = null;
  try { ev('W.rigFight = false'); X.st.ctx.__p = p; ev(kind === 'person' ? 'wRigPerson(__p, 0, __p.face || 0, false, false, 0.016)' : 'wRigExtra(__p, 0, __p.face || 0, 0.016)'); } catch (e) {}
  const r = X.st.ctx.__rig; if (!r) return null;
  const o = plain(r.o, 0); delete o.sel; delete o.rate;
  return { want: r.want, o };
}
const LAYOUT = ev('LAYOUT'), PLACES = Object.keys(LAYOUT), index = {};
const serBarks = (b) => { if (!b) return null; const o = {}; for (const k of Object.keys(b)) { const v = b[k]; o[k] = typeof v === 'function' ? { $js: v.toString() } : plain(v, 0); } return o; };
for (const id of PLACES) {
  const L0 = LAYOUT[id], areas = L0.areas ? [null].concat(Object.keys(L0.areas)) : [null];
  for (const area of areas) {
    ev(`S = fresh(); S.trait = 'steady'; S.route = ['cross', ${JSON.stringify(id)}]; S.idx = 1; S.seen = 2; W.areas = {}; W.areas[${JSON.stringify(id)}] = ${JSON.stringify(area)};`);
    if (id === 'cross') ev(`S.route = ['cross']; S.idx = 0;`);
    let sc; try { sc = ev(`wBuild(${JSON.stringify(id)}, LAYOUT[${JSON.stringify(id)}])`); } catch (e) { console.log('build failed', id, area, e.message); continue; }
    if (!sc) { console.log('build failed', id, area); continue; }
    const L = area && L0.areas[area] ? L0.areas[area] : L0;
    const grounds = (L.grounds || []).map((g, gi) => {
      const r = gi === 0 ? [-150, -150, 150, 150] : g.slice(0, 4).map(v => Math.abs(v) === 26 ? v * 3.5 : v);
      return { r, rep: g[4], y: g[5] || 0, tex: g[6], c: g[7] || [1, 1, 1], flow: g[8] || null };
    });
    const people = sc.people.map(p => Object.assign(plain(p, 0), { look: outfit(p, 'person') }));
    const extras = sc.extras.map((p, i) => { const q = Object.assign({ id: id + '_x' + i }, p); return Object.assign(plain(q, 0), { look: outfit(q, 'extra') }); });
    const doorDefs = (() => { try { return typeof L.doors === 'function' ? ev(`(function(){ var L0 = LAYOUT[${JSON.stringify(id)}]; var L = ${area ? `L0.areas[${JSON.stringify(area)}]` : 'L0'}; return L.doors(${JSON.stringify(id)}); })()`) : (L.doors || []); } catch (e) { return []; } })();
    const things = sc.things.map(t => {
      const o = plain(t, 0); delete o.prop;
      if (t.door) { o.door = true; const d = doorDefs.find(d => 'door_' + (d.to || 'out') === t.id); if (d) { o.to = d.to || null; o.at = d.at || null; o.toFace = d.face === undefined ? null : d.face; o.note = d.note || (d.to ? 'Go inside' : 'Go back outside'); } }
      else { try { o.note = t.note(); } catch (e) {} }
      return o;
    });
    const rec = {
      id, area, props: sc.props.map(it => plain(it, 0)), grounds, lights: plain(sc.lights, 0), people, extras, things,
      solid: plain(sc.solid, 0), bounds: sc.bounds || null, start: sc.start, enter: sc.enter || null, exit: sc.exit || null,
      face: sc.pl.face, fog: sc.fog, fogR: sc.fogR, light: sc.light, zoom: sc.zoomIn || null, camOff: sc.camOff || null,
      doors: things.filter(t => t.door).map(t => t.id), barks: serBarks(L.barks),
      lifts: plain(L.lifts || null, 0), liftTop: L.liftTop || null
    };
    const file = id + (area ? '__' + area : '') + '.json';
    fs.writeFileSync(path.join(OUT, 'data', 'places', file), JSON.stringify(rec, null, 1));
    (index[id] = index[id] || []).push(area || '');
  }
}
fs.writeFileSync(path.join(OUT, 'data', 'places', 'index.json'), JSON.stringify({ places: index, missing: [...missing].sort() }, null, 1));
console.log('places', Object.keys(index).map(k => k + (index[k].length > 1 ? '(' + index[k].length + ')' : '')).join(' '));
console.log('models used but not available (w3d_core.js):', missing.size, [...missing].sort().join(' '));
