const st=require('./extract_run.js');const {scopes}=require('./closures.js');const ev=st.ev;
const sc=scopes(ev('scene'));const iife=sc.find(s=>'GRAPH' in s.vars);
const names=Object.keys(iife.vars);const rows=[];
for(const n of names){let v;try{v=ev(n)}catch(e){continue}const t=typeof v;let size=0;try{size=t==='function'?v.toString().length:JSON.stringify(v,(k,x)=>typeof x==='function'?'<fn '+x.toString().length+'>':x).length}catch(e){size=-1}rows.push([n,t,size])}
const fns=rows.filter(r=>r[1]==='function'),data=rows.filter(r=>r[1]!=='function');
console.log('names',rows.length,'functions',fns.length,'fnchars',fns.reduce((a,r)=>a+r[2],0),'data',data.length,'datachars',data.reduce((a,r)=>a+Math.max(0,r[2]),0));
console.log('biggest data', data.sort((a,b)=>b[2]-a[2]).slice(0,25).map(r=>r[0]+':'+r[2]).join(' '));
require('fs').writeFileSync(require('os').tmpdir()+'/scope.json',JSON.stringify(rows));
