// Converts The Postal Trace's 3D assets (assets/w3d_*.js and the procedural models in index.html)
// into files Godot imports: textures as PNG/JPG, every model as a .glb, the rigged people as a
// skinned .glb with all their movements, and each place as a JSON layout.
//   SRC=index.html W3D_DIR=dir/with/w3d_files node w3d_export.js <godot project dir>
'use strict';
const fs = require('fs'), path = require('path');
const Glb = require('./glb.js');
const st = require('./extract_run.js'); const ev = st.ev, W3D = st.ctx.W3D;
const OUT = process.argv[2];
const D3 = path.join(OUT, 'assets', '3d'), TEX = path.join(D3, 'tex'), MOD = path.join(D3, 'models');
for (const d of [TEX, MOD, path.join(D3, 'people'), path.join(OUT, 'data', 'places')]) fs.mkdirSync(d, { recursive: true });
const b64 = (s, T) => { const b = Buffer.from(s, 'base64'); return new T(b.buffer, b.byteOffset, b.byteLength / T.BYTES_PER_ELEMENT); };
const report = { packs: st.packs, textures: [], models: [], proc: [], missingTex: new Set(), missingModels: new Set() };

// ---------- textures ----------
const texFile = {};
function saveTex(key, uri) {
  const m = /^data:image\/(png|jpe?g);base64,(.*)$/.exec(uri || ''); if (!m) return null;
  const ext = m[1] === 'png' ? 'png' : 'jpg', f = key + '.' + ext;
  fs.writeFileSync(path.join(TEX, f), Buffer.from(m[2], 'base64')); texFile[key] = f; report.textures.push(key); return f;
}
for (const k of Object.keys(W3D.tex)) saveTex(k, W3D.tex[k]);
function texUri(key) { if (!key) return null; if (texFile[key]) return '../tex/' + texFile[key]; report.missingTex.add(key); return null; }

// ---------- static models ----------
const sizes = {};
function matFor(name, i, t, c, unlit) {
  const uri = texUri(t);
  return { name: name + '_' + i + (t ? '_' + t : ''), color: c || [1, 1, 1], tex: uri ? t : null, uri, unlit: !!unlit };
}
function decodePart(M, pt) {
  let q = b64(pt.p, Int16Array), n = b64(pt.n, Int8Array), u = b64(pt.u, Int16Array);
  if (pt.i) {
    const ix = b64(pt.i, pt.iw === 4 ? Uint32Array : Uint16Array), q2 = new Int16Array(ix.length * 3), n2 = new Int8Array(ix.length * 3), u2 = new Int16Array(ix.length * 2);
    for (let a = 0; a < ix.length; a++) { const v = ix[a]; for (let k = 0; k < 3; k++) { q2[a * 3 + k] = q[v * 3 + k]; n2[a * 3 + k] = n[v * 3 + k]; } u2[a * 2] = u[v * 2]; u2[a * 2 + 1] = u[v * 2 + 1]; }
    q = q2; n = n2; u = u2;
  }
  const P = new Float32Array(q.length), N = new Float32Array(n.length), U = new Float32Array(u.length);
  for (let i = 0; i < q.length; i++) { const a = i % 3; P[i] = (q[i] + 32768) / 65535 * M.sz[a] + M.mn[a]; }
  for (let i = 0; i < n.length; i += 3) { const l = Math.hypot(n[i], n[i + 1], n[i + 2]) || 1; N[i] = n[i] / l; N[i + 1] = n[i + 1] / l; N[i + 2] = n[i + 2] / l; }
  for (let j = 0; j < u.length; j++) U[j] = j % 2 ? 1 - u[j] / 4096 : u[j] / 4096;
  return { P, N, U };
}
function writeModel(name, parts, mn, sz) {
  const g = new Glb();
  const prims = parts.filter(p => p.P.length).map((p, i) => Object.assign({}, p, { mat: matFor(name, i, p.t, p.c, p.unlit) }));
  if (!prims.length) return false;
  const mesh = g.mesh(name, prims); g.json.scenes[0].nodes.push(g.node({ name, mesh }));
  g.write(path.join(MOD, name + '.glb'));
  sizes[name] = { mn, sz }; return true;
}
for (const name of Object.keys(W3D.models)) {
  const M = W3D.models[name];
  const parts = M.parts.map(pt => Object.assign(decodePart(M, pt), { t: pt.t, c: pt.c, unlit: pt.unlit }));
  if (writeModel(name, parts, M.mn, M.sz)) report.models.push(name);
}
// procedural models: built by code in the game, so run that code
const PROC = ev('PROC');
for (const name of Object.keys(PROC)) {
  if (W3D.models[name]) continue;
  let parts; try { parts = PROC[name](); } catch (e) { report.proc.push(name + ' (failed: ' + e.message + ')'); continue; }
  const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
  const out = parts.map(p => {
    const P = new Float32Array(p.m.P), N = new Float32Array(p.m.N), U = new Float32Array(p.m.U);
    for (let i = 0; i < P.length; i++) { const a = i % 3; mn[a] = Math.min(mn[a], P[i]); mx[a] = Math.max(mx[a], P[i]); }
    return { P, N, U, t: p.t, c: p.c || [1, 1, 1], unlit: p.unlit };
  });
  if (writeModel(name, out, mn, [mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]])) report.proc.push(name);
}

// ---------- people: one skeleton, the plain figure, the soldier bodies, every movement ----------
function writeRig() {
  const R = W3D.rig, NJ = R.joints.length, g = new Glb();
  const verts = (D) => {
    const q = b64(D.p, Int16Array), n = b64(D.n, Int8Array), nv = q.length / 3, P = new Float32Array(q.length), N = new Float32Array(n.length);
    for (let i = 0; i < q.length; i++) { const a = i % 3; P[i] = (q[i] + 32768) / 65535 * D.sz[a] + D.mn[a]; }
    for (let i = 0; i < n.length; i += 3) { const l = Math.hypot(n[i], n[i + 1], n[i + 2]) || 1; N[i] = n[i] / l; N[i + 1] = n[i + 1] / l; N[i + 2] = n[i + 2] / l; }
    const jw = b64(D.jw, Uint8Array), J = new Uint8Array(nv * 4), Wt = new Float32Array(nv * 4);
    for (let v = 0; v < nv; v++) { let s = 0; for (let k = 0; k < 4; k++) { J[v * 4 + k] = jw[v * 8 + k]; Wt[v * 4 + k] = jw[v * 8 + 4 + k] / 255; s += Wt[v * 4 + k]; } if (s > 0) for (let k = 0; k < 4; k++) Wt[v * 4 + k] /= s; else Wt[v * 4] = 1; }
    let U = null; if (D.u) { const u = b64(D.u, Int16Array); U = new Float32Array(u.length); for (let j = 0; j < u.length; j++) U[j] = j % 2 ? 1 - u[j] / 4096 : u[j] / 4096; }
    return { P, N, J, Wt, U, nv };
  };
  // the joint nodes, at the first frame of the idle as their rest pose
  const clipQ = {}; for (const k of Object.keys(R.clips)) { const c = R.clips[k]; clipQ[k] = { n: c.n, d: c.d, q: b64(c.q, Int16Array), t: b64(c.t, Int16Array) }; }
  const quat = (c, f, j) => { const o = (f * NJ + j) * 3; const x = c.q[o] / 32767, y = c.q[o + 1] / 32767, z = c.q[o + 2] / 32767; const w = Math.sqrt(Math.max(0, 1 - x * x - y * y - z * z)); const l = Math.hypot(x, y, z, w) || 1; return [x / l, y / l, z / l, w / l]; };
  const idle = clipQ.idle, jn = [];
  for (let j = 0; j < NJ; j++) {
    const t = R.par[j] < 0 ? [idle.t[0] / 8000, idle.t[1] / 8000, idle.t[2] / 8000] : R.bt[j];
    jn.push(g.node({ name: R.joints[j], translation: t, rotation: quat(idle, 0, j) }));
  }
  for (let j = 0; j < NJ; j++) { const p = R.par[j]; if (p >= 0) (g.json.nodes[jn[p]].children = g.json.nodes[jn[p]].children || []).push(jn[j]); }
  const root = g.node({ name: 'Skeleton', children: [jn[R.par.indexOf(-1)]] });
  g.json.skins = [{ name: 'body', joints: jn, inverseBindMatrices: g.accessor(new Float32Array(R.ibm), 'MAT4'), skeleton: root }];
  const meshNodes = [], info = { plain: [], bodies: {}, parts: {} };
  // the plain figure: its coloured regions (coat, breeches, skin, boots...) and the extra pieces (hats, coats, weapons)
  const V = verts(R), I = b64(R.i, Uint16Array);
  const sub = (start, count) => I.slice(start, start + count);
  const prims = [];
  R.groups.forEach(gr => { prims.push({ P: V.P, N: V.N, J: V.J, Wt: V.Wt, I: sub(gr[1], gr[2]), mat: { name: 'slot' + gr[0], color: [0.6, 0.6, 0.6] } }); info.plain.push('slot' + gr[0]); });
  meshNodes.push(g.node({ name: 'Figure', mesh: g.mesh('Figure', prims), skin: 0 }));
  for (const nm of Object.keys(R.parts)) {
    const pr = R.parts[nm];
    meshNodes.push(g.node({ name: 'part_' + nm, mesh: g.mesh('part_' + nm, [{ P: V.P, N: V.N, J: V.J, Wt: V.Wt, I: sub(pr[1], pr[2]), mat: { name: 'part_' + nm, color: [0.5, 0.5, 0.5] } }]), skin: 0 }));
    info.parts[nm] = 1;
  }
  // the soldier bodies, each region its own surface; textured regions use the body's uniform texture
  for (const bk of Object.keys(W3D.rigBodies || {})) {
    const B = W3D.rigBodies[bk], BV = verts(B), big = BV.nv > 65535, BI = b64(B.i, big ? Uint32Array : Uint16Array), texKeys = Object.keys(B.tex || {});
    for (const t of texKeys) saveTex('rig_' + bk + '_' + t, B.tex[t]);
    const texSrc = B.texOf || bk, defTex = 'rig_' + texSrc + '_' + (Object.keys((W3D.rigBodies[texSrc] || {}).tex || {})[0] || '');
    const bp = B.groups.map(gr => ({ P: BV.P, N: BV.N, U: BV.U, J: BV.J, Wt: BV.Wt, I: BI.slice(gr[1], gr[1] + gr[2]),
      mat: gr[4] ? { name: bk + '_' + gr[0], color: [1, 1, 1], tex: defTex, uri: texUri(defTex) } : { name: bk + '_' + gr[0], color: gr[3] || [0.3, 0.3, 0.3] } }));
    meshNodes.push(g.node({ name: 'Body_' + bk, mesh: g.mesh('Body_' + bk, bp), skin: 0 }));
    info.bodies[bk] = { groups: B.groups.map(gr => [gr[0], gr[3], gr[4]]), tex: texKeys.length ? texKeys : Object.keys((W3D.rigBodies[texSrc] || {}).tex || {}), texOf: texSrc };
  }
  g.json.scenes[0].nodes.push(g.node({ name: 'Person', children: [root].concat(meshNodes) }));
  // every movement: joint turns per frame, and the hips' position
  g.json.animations = [];
  for (const k of Object.keys(clipQ)) {
    const c = clipQ[k], times = new Float32Array(c.n); for (let f = 0; f < c.n; f++) times[f] = f / R.fps;
    const tin = g.accessor(times, 'SCALAR', { minmax: true }), samplers = [], channels = [];
    for (let j = 0; j < NJ; j++) {
      const out = new Float32Array(c.n * 4); let prev = null;
      for (let f = 0; f < c.n; f++) { let q = quat(c, f, j); if (prev && q[0] * prev[0] + q[1] * prev[1] + q[2] * prev[2] + q[3] * prev[3] < 0) q = q.map(v => -v); out.set(q, f * 4); prev = q; }
      samplers.push({ input: tin, output: g.accessor(out, 'VEC4'), interpolation: 'LINEAR' }); channels.push({ sampler: samplers.length - 1, target: { node: jn[j], path: 'rotation' } });
    }
    const T = new Float32Array(c.n * 3); for (let i = 0; i < c.n * 3; i++) T[i] = c.t[i] / 8000;
    samplers.push({ input: tin, output: g.accessor(T, 'VEC3'), interpolation: 'LINEAR' }); channels.push({ sampler: samplers.length - 1, target: { node: jn[R.par.indexOf(-1)], path: 'translation' } });
    g.json.animations.push({ name: k, samplers, channels });
  }
  g.write(path.join(D3, 'people', 'person.glb'));
  info.clips = Object.fromEntries(Object.keys(clipQ).map(k => [k, { d: clipQ[k].d, frames: clipQ[k].n }]));
  info.joints = R.joints;
  return info;
}
const rigInfo = W3D.rig ? writeRig() : null;

// ---------- the clothes table: colours and fits the game uses for people ----------
const dress = {};
for (const n of ['RG_SKIN', 'RG_BOOT', 'RG_HAT', 'RG_IRON', 'RG_WPN', 'RG_KIT', 'RG_UNI', 'RG_OFFICER', 'RG_PEOPLE', 'RG_LINEN', 'RG_WOOL', 'RG_SCARF', 'RG_QC_RED', 'RG_FIT_ID', 'RG_FITS_MEN', 'RG_FITS_WOMEN']) { try { dress[n] = ev(n); } catch (e) {} }

fs.writeFileSync(path.join(OUT, 'data', 'models.json'), JSON.stringify({ sizes, rig: rigInfo, dress }, null, 1));
module.exports = { st, ev, W3D, sizes, report, saveTex, texFile };
if (require.main === module) {
  console.log('packs', report.packs.join(' '));
  console.log('textures', report.textures.length, 'models', report.models.length, 'procedural', report.proc.length);
  console.log('textures missing (in w3d_core.js?):', [...report.missingTex].join(' '));
  console.log('rig', rigInfo ? Object.keys(rigInfo.clips).length + ' movements, bodies ' + Object.keys(rigInfo.bodies).join(' ') : 'none');
}
