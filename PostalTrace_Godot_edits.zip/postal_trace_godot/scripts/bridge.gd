## Bridge: what the browser version's own logic (data/lib.json) needs from the page.
##
## Most of the game's systems (companions, Linden Market, the Provost's Gate, errands,
## going back, horses, revolvers, fights, road events) run as the original JavaScript
## through JsLite, so both builds keep exactly the same rules. That code builds screens
## with show(html) and wires them with screen.querySelectorAll(...).addEventListener(...).
## This script answers those calls: it keeps the current page as Html elements and asks
## main.gd to draw it, and it routes the flow functions (scene, talk, road...) to main.gd.
extends Node

var main: Node = null                 # main.gd sets itself here
var page: Html.Element = Html.Element.new()
var modal_page: Html.Element = Html.Element.new()
var modal_open := false
var rolls: Array = []                 # rollHtml() results, drawn by marker
var _later: Array = []                # setTimeout callbacks

class Proxy extends RefCounted:
	## Stands in for `screen`, `modal` and `document`.
	var kind := ""
	func js_get(key: String) -> Variant:
		var b: Node = Bridge
		var root: Html.Element = b.modal_page if kind == "modal" else b.page
		match key:
			"querySelectorAll": return func(a): return b.query_all(str(a[0]), kind)
			"querySelector": return func(a): var l: Array = b.query_all(str(a[0]), kind); return l[0] if l.size() else null
			"getElementById": return func(a): return b.by_id(str(a[0]))
			"createElement": return func(a): var e := Html.Element.new(); e.tag = str(a[0]); return e
			"addEventListener", "removeEventListener", "focus", "blur", "scrollIntoView", "scrollTo", "appendChild", "removeChild":
				return func(_a): return null
			"hidden": return not b.modal_open if kind == "modal" else false
			"firstChild": return root.children[0] if root.children.size() else null
			"innerHTML": return ""
			"body", "documentElement": return { "classList": { "add": func(_a): return null, "remove": func(_a): return null, "contains": func(_a): return false, "toggle": func(_a): return null },
				"style": { "setProperty": func(_a): return null }, "appendChild": func(_a): return null }
			"activeElement": return null
			"onclick", "onkeydown": return null
		return null
	func js_set(key: String, v: Variant) -> void:
		var b: Node = Bridge
		match key:
			"innerHTML":
				if kind == "modal":
					b.modal_page = Html.parse(str(v))
					if b.main: b.main.show_modal_html()
				else:
					b.main.show_html(str(v))
			"hidden":
				if kind == "modal":
					b.modal_open = not JsLite.truthy(v)
					if b.main:
						if b.modal_open: b.main.show_modal_html()
						else: b.main.close_modal()

func _ready() -> void:
	_register()
	# the 3D-only parts of the browser logic (staging a fight in the 3D street, the rigged
	# people's poses) have their own Godot versions in scripts/world; here they do nothing
	var noop := func(_a): return null
	var re3d := RegEx.create_from_string("^(w[A-Z]|rg[A-Z]|_w[A-Z]|W3D)")
	Data.js.fallback = func(n: String): return noop if re3d.search(n) != null else null

func query_all(sel: String, kind: String) -> Array:
	if kind == "modal":
		return Html.query(modal_page, sel)
	if kind == "document":
		return Html.query(page, sel) + (Html.query(modal_page, sel) if modal_open else [])
	return Html.query(page, sel)

func by_id(id: String) -> Variant:
	for root in [page, modal_page]:
		var l := Html.query(root, "#" + id)
		if l.size():
			return l[0]
	return null

func js(name: String) -> Variant:
	return Data.js.globals.vars.get(name)

## Call a function of the browser logic by name ("" if it does not exist).
func call_js(name: String, args: Array = []) -> Variant:
	var f: Variant = js(name)
	if f == null:
		return null
	return Data.js.call_fn(f, args)

func has_js(name: String) -> bool:
	return js(name) != null

func _process(_d: float) -> void:
	if _later.is_empty():
		return
	var run := _later.duplicate()
	_later.clear()
	for f in run:
		Data.js.call_fn(f, [])

# ================================================================ the names

func _p(n: String, v: Variant) -> void:
	Data.js.set_global(n, v)

func _register() -> void:
	var sp := Proxy.new(); sp.kind = "screen"
	var mp := Proxy.new(); mp.kind = "modal"
	var dp := Proxy.new(); dp.kind = "document"
	_p("screen", sp)
	_p("modal", mp)
	_p("document", dp)
	_p("window", { "matchMedia": func(_a): return { "matches": false }, "addEventListener": func(_a): return null })
	_p("tip", { "hidden": true })
	_p("W", { "stage": {}, "areas": {}, "FX": {}, "keep": null })
	_p("CKT", [])
	_p("localStorage", { "getItem": func(_a): return null, "setItem": func(_a): return null, "removeItem": func(_a): return null })
	_p("DEV", false)
	# ---- the page
	_p("show", func(a): main.show_html(str(a[0])); return null)
	_p("closeModal", func(_a): main.close_modal(); return null)
	_p("bindChoices", func(a):
		var fn: Variant = a[0]
		var bs := Html.query(page, ".choice")
		for i in bs.size():
			var el: Html.Element = bs[i]
			var idx := i
			if not el.listeners.has("click"):
				el.listeners["click"] = []
			el.listeners["click"].append(func(_ev): if not el.attrs.has("disabled"): Data.js.call_fn(fn, [idx]))
		return null)
	_p("renderLedger", func(_a): Game.ledger_changed.emit(); return null)
	for n in ["bindCk", "bindTextTip", "bindVoiceTips", "hideTip", "dlgStage", "sfxPreload", "sfxStaged", "rerenderLedger", "cloudSave", "autoSave", "wSync", "fStageSel"]:
		_p(n, func(_a): return null)
	_p("snap", func(a): Game.snap(str(a[0]) if a.size() and a[0] != null else "scene"); return null)
	_p("saveNote", func(_a): return "")
	_p("uiDecor", func(a): return a[0] if a.size() else "")
	_p("portrait", func(a): return Markup.portrait(str(a[0]) if a.size() and a[0] != null else "calm", a[1] if a.size() > 1 else null))
	_p("rollHtml", func(a):
		var r: Dictionary = a[0] if a[0] is Dictionary else {}
		var m: Dictionary = a[1] if a.size() > 1 and a[1] is Dictionary else {}
		var label := str(a[2]) if a.size() > 2 and a[2] != null else ""
		rolls.append([r, m, label])
		if r.get("crit") == "lo": Sound.play("redfail")
		elif r.get("crit") == "hi": Sound.play("redpass")
		else: Sound.play("pass" if JsLite.truthy(r.get("ok")) else "fail")
		return Markup.roll(rolls.size() - 1))
	_p("voiceBlock", func(a):
		var v := str(a[0])
		if not Data.T.VOICES.has(v):
			return ""
		var t := Game.voice_text(v, a[1] if a.size() > 1 else "")
		Sound.voice(v)
		return Markup.voice(v, t, str(a[3]) if a.size() > 3 and a[3] != null else ""))
	# ---- sound
	_p("sfx", func(a): Sound.play(str(a[0])); return null)
	_p("sfxEvent", func(a): Sound.play(str(a[0])); return null)
	_p("sfxVoice", func(a): Sound.voice(str(a[0])); return null)
	_p("sfxBeat", func(_a): return null)
	_p("fx", func(a): Sound.play(str(a[0]), float(a[1]) if a.size() > 1 and a[1] != null else -1.0); return null)
	_p("fxp", func(a): return str(a[0]) + str(Game.rng.randi_range(1, int(a[1]) if a.size() > 1 else 1)))
	_p("AUD", { "play": func(a): Sound.play(str(a[0]), float(a[1]) if a.size() > 1 and a[1] != null else -1.0); return null,
		"music": func(a): Sound.music(str(a[0]) if a.size() and a[0] != null else ""); return null,
		"babble": func(_a): return null, "door": func(_a): return null, "world": func(_a): return null, "pick": func(_a): return null, "VOL": {} })
	# ---- time
	_p("setTimeout", func(a): if a.size(): _later.append(a[0]); return 0)
	_p("clearTimeout", func(_a): return null)
	_p("requestAnimationFrame", func(a): if a.size(): _later.append(a[0]); return 0)
	_p("confirm", func(_a): return true)
	_p("alert", func(_a): return null)
	# ---- the flow: these screens are drawn by main.gd
	_p("scene", func(_a): main.scene(); return null)
	_p("road", func(a): main.road(a[0] if a.size() and a[0] is Array else []); return null)
	_p("talk", func(a): main.talk_js(a[0], a[1] if a.size() > 1 else null, a[2] if a.size() > 2 else null); return null)
	_p("graphShow", func(a): main.graph_show(a[0], str(a[1]), a[2] if a.size() > 2 and a[2] is Dictionary else {}); return null)
	_p("graphGo", func(a): main._graph_go(a[0], str(a[1]), a[2] if a.size() > 2 and a[2] is Dictionary else {}); return null)
	_p("resolve", func(a): main.resolve(a[0], int(a[1]) if a.size() > 1 else 0, a[2] if a.size() > 2 and a[2] is Dictionary else {}); return null)
	_p("relay", func(a): main.relay(str(a[0]), a[1]); return null)
	_p("advance", func(_a): main.advance(); return null)
	_p("ending", func(a): main.ending(str(a[0])); return null)
	_p("start", func(_a): main.title_screen(); return null)
	_p("intro", func(_a): main.intro(0); return null)
	_p("openChar", func(_a): main.open_char(); return null)
	_p("openThoughts", func(_a): main.open_thoughts(); return null)
	_p("openSatchel", func(a): main.open_satchel(); return null)
	_p("openMap", func(_a): main.open_journal(); return null)
	_p("wExitThen", func(a): Data.js.call_fn(a[0], []); return null)
	_p("rerender", func(_a): main._rerender(); return null)
