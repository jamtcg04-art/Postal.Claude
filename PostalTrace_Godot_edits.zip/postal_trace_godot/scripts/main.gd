## Main: draws every screen of The Postal Trace and runs the flow between them.
##
## The browser version built HTML strings; here each screen is built from a few
## widget helpers (_prose, _voice, _choice ...) into the page column. Game rules
## live in Game (scripts/game.gd); all text and logic comes from Data (res://data).
extends Control

var COL := {
	"bg": Color("17140f"), "page": Color("1f1b15"), "panel": Color("29231b"), "panel2": Color("332b20"),
	"line": Color("4c4233"), "text": Color("e6dcc6"), "dim": Color("a39780"), "brass": Color("c9a45c"),
	"good": Color("8bb871"), "bad": Color("d9695f"), "you": Color("d8c9a6"),
	"arms": Color("c0392f"), "nerve": Color("cfa74b"), "wits": Color("7fa3b8"), "grit": Color("6f9a5a"),
	"duty": Color("5b7bd5"), "hat": Color("a08463"), "trace": Color("6d8c87"),
}
## Settings > Colours: the parchment the game was made in, a high-contrast set, and a softer one.
const PALETTES := {
	"parchment": {},
	"contrast": { "bg": Color("000000"), "page": Color("0a0908"), "panel": Color("15120e"), "panel2": Color("221c14"), "line": Color("8c7a55"),
		"text": Color("ffffff"), "dim": Color("d6cdb9"), "brass": Color("ffd27a"), "you": Color("fff0cc") },
	"soft": { "bg": Color("1d1a16"), "page": Color("24201a"), "panel": Color("2c271f"), "panel2": Color("352e24"), "line": Color("4a4132"),
		"text": Color("cdc2a9"), "dim": Color("8e8470"), "brass": Color("b89a5c") },
}
var COL0: Dictionary = {}
var palette := "parchment"
var big_pref := "auto"           # "auto" (large on touch screens), "on", "off"

const NAME_COL := { "arms": Color("d9695f"), "nerve": Color("cfa74b"), "wits": Color("7fa3b8"), "grit": Color("8bb871"),
	"duty": Color("93a9ee"), "hat": Color("c9a77f"), "trace": Color("9bbab4") }
const TOWN := ["cross", "oak", "malice", "venn"]
const BODY_SIZE := 19
var text_scale := 1.0           # Settings > Text size
var big_buttons := false        # Settings > Button size (on by itself on touch screens)

var f_body: Font
var f_italic: Font
var f_bold: Font
var f_mono: Font
var f_mono_b: Font
var hue_shader: Shader

var scroll: ScrollContainer
var margin: MarginContainer
var world: World
var world_view: SubViewportContainer
var editor: PlaceEditor
var vring: VoiceRing
var modal_panel: PanelContainer
var dev := false
var panel_bg: Panel
var three_d := true                 # 3D places on (Menu > 3D places)
const WORLD_SHRINK := 3             # the 3D renders at a third of the window size, like the original
const SIDE_W := 470
const HH_SIDE := 400                # handheld: the text panel's width (of 640)
var world_shrink := WORLD_SHRINK    # 2 on a handheld (a 320×240 view at 640×480)
var hh := false                     # the handheld layout (Settings > Layout; on by itself on a 640×480 screen)
var layout_pref := "auto"           # "auto", "desktop", "handheld"
var detail := "full"                # Settings > Detail: "full" or "light" (30 frames a second, fewer checks)
var pad: Pad
var modal_tag := ""                 # which page the modal shows ("char", "tin", "bag", "log"), for Select
var pad_bar: Label                  # pad hints over the 3D view
var page: VBoxContainer
var target: Container          # where widgets go (page, or the modal)
var ledger: HFlowContainer
var ledger_labels: Dictionary = {}
var top_buttons: Dictionary = {}
var modal: Control
var mpage: VBoxContainer
var mscroll: ScrollContainer

var phase = "title"
var cur_g: Dictionary = {}         # the open conversation: {ti, node}
var choices: Array = []            # [control, callable, disabled] in order, for number keys
var beats: Array = []              # widgets waiting to be revealed with Continue
var beat_i = 0
var beat_btn: Button = null
var beat_after: Control = null     # the choices block, shown once all beats are out
var seen_lines: Dictionary = {}
var voice_stung: Dictionary = {}
var cc: Dictionary = {}            # character creation in progress

# ================================================================ setup

func _ready():
	Controls.setup()
	pad = Pad.new()
	pad.name = "Pad"
	pad.main = self
	add_child(pad)
	pad.mode_changed.connect(func(_m): _apply_pad_mode())
	_load_display()
	_fit_window()
	f_body = load("res://assets/fonts/Caladea-Regular.ttf")
	f_italic = load("res://assets/fonts/Caladea-Italic.ttf")
	f_bold = load("res://assets/fonts/Caladea-Bold.ttf")
	f_mono = load("res://assets/fonts/LiberationMono-Regular.ttf")
	f_mono_b = load("res://assets/fonts/LiberationMono-Bold.ttf")
	hue_shader = load("res://shaders/hue.gdshader")
	_build_frame()
	Bridge.main = self
	Game.ledger_changed.connect(_render_ledger)
	title_screen()

func _build_frame():
	var th = Theme.new()
	th.default_font = f_body
	th.default_font_size = fs(BODY_SIZE)
	th.set_color("font_color", "Label", COL.text)
	th.set_color("default_color", "RichTextLabel", COL.text)
	th.set_font("bold_font", "RichTextLabel", f_bold)
	th.set_font("italics_font", "RichTextLabel", f_italic)
	th.set_font("mono_font", "RichTextLabel", f_mono)
	th.set_stylebox("normal", "Button", _box(COL.panel2, COL.brass, 1, 6))
	th.set_stylebox("hover", "Button", _box(Color("4a3b25"), COL.brass, 1, 6))
	th.set_stylebox("pressed", "Button", _box(Color("5a4628"), COL.brass, 1, 6))
	th.set_stylebox("focus", "Button", _box(Color(0, 0, 0, 0), Color("f0d38a"), 2, 6))
	th.set_stylebox("disabled", "Button", _box(COL.panel, COL.line, 1, 6))
	th.set_color("font_color", "Button", Color("f4e9d0"))
	th.set_color("font_disabled_color", "Button", COL.dim)
	th.set_color("font_hover_color", "Button", Color("fff6e0"))
	th.set_font_size("font_size", "Button", fs(19 if big_buttons else 17))
	if big_buttons:
		for st in ["normal", "hover", "pressed", "disabled"]:
			var sb: StyleBoxFlat = th.get_stylebox(st, "Button")
			sb.content_margin_top = 14; sb.content_margin_bottom = 14; sb.content_margin_left = 18; sb.content_margin_right = 18
	theme = th

	var bg = ColorRect.new()
	bg.color = COL.bg
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var root = VBoxContainer.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 0)
	add_child(root)

	var bar = PanelContainer.new()
	bar.add_theme_stylebox_override("panel", _box(Color("120f0b"), COL.line, 0, 0, Vector4(14, 8, 14, 8)))
	root.add_child(bar)
	var barrow = HFlowContainer.new()
	barrow.add_theme_constant_override("h_separation", 16)
	barrow.add_theme_constant_override("v_separation", 6)
	bar.add_child(barrow)
	ledger = HFlowContainer.new()
	ledger.add_theme_constant_override("h_separation", 14)
	ledger.alignment = FlowContainer.ALIGNMENT_BEGIN
	ledger.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	barrow.add_child(ledger)
	for k in ["hp", "st", "pw", "ra", "hrs", "notice", "trust", "coin", "duty", "lvl"]:
		var l = Label.new()
		l.add_theme_font_override("font", f_mono)
		l.add_theme_font_size_override("font_size", 11 if hh else fs(12 if _narrow() else 14))
		ledger.add_child(l)
		ledger_labels[k] = l
	var nar = _narrow()
	if nar:
		barrow.add_theme_constant_override("h_separation", 6)
		ledger.add_theme_constant_override("h_separation", 10)
		ledger.custom_minimum_size.x = get_viewport_rect().size.x - 30
	if hh:
		bar.add_theme_stylebox_override("panel", _box(Color("120f0b"), COL.line, 0, 0, Vector4(8, 3, 8, 3)))
		ledger.add_theme_constant_override("h_separation", 9)
	for b in [["char", "Character [C]", "Character"], ["tin", "Tin Thoughts [T]", "Thoughts"], ["bag", "Satchel [I]", "Satchel"], ["log", "Journal [J]", "Journal"], ["menu", "Menu", "Menu"]]:
		var btn = Button.new()
		btn.text = b[2] if nar else b[1]
		btn.focus_mode = Control.FOCUS_NONE
		btn.add_theme_font_size_override("font_size", fs(14))
		if nar:
			# the bar's buttons stay compact on a phone, so the 3D view keeps its room
			var cs = _box(COL.panel2, COL.brass, 1, 6, Vector4(9, 9, 9, 9))
			btn.add_theme_stylebox_override("normal", cs)
			btn.add_theme_stylebox_override("hover", cs)
			btn.add_theme_stylebox_override("pressed", _box(Color("5a4628"), COL.brass, 1, 6, Vector4(9, 9, 9, 9)))
		btn.pressed.connect(_on_top.bind(b[0]))
		barrow.add_child(btn)
		top_buttons[b[0]] = btn

	# the body of the window: the 3D place (when there is one) behind the text panel
	var body = Control.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.clip_contents = true
	root.add_child(body)
	world_view = SubViewportContainer.new()
	world_view.set_anchors_preset(Control.PRESET_FULL_RECT)
	world_view.stretch = true
	world_view.stretch_shrink = world_shrink
	world_view.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	world_view.visible = false
	body.add_child(world_view)
	var vp = SubViewport.new()
	vp.handle_input_locally = false
	vp.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	world_view.add_child(vp)
	world = World.new()
	vp.add_child(world)
	world.interact.connect(_on_world_interact)
	world.see_through_every = 0.25 if detail == "light" else 0.08
	world_view.gui_input.connect(func(ev):
		if ev is InputEventScreenTouch or ev is InputEventScreenDrag or ev is InputEventGesture:
			# pinch to zoom and two fingers to turn, walking or editing
			world.pointer(ev, ev.position / float(world_shrink))
		elif ev is InputEventMouse:
			if editor and editor.on:
				editor.pointer(ev, ev.position / float(world_shrink))
			else:
				world.pointer(ev, ev.position / float(world_shrink)))
	panel_bg = Panel.new()
	panel_bg.add_theme_stylebox_override("panel", _box(Color(0.09, 0.08, 0.06, 0.9), COL.line, 0, 0))
	panel_bg.visible = false
	body.add_child(panel_bg)
	scroll = ScrollContainer.new()
	scroll.set_anchors_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.follow_focus = true
	body.add_child(scroll)
	# what the pad's buttons do, over the 3D view (scripts/pad.gd)
	pad_bar = Label.new()
	pad_bar.add_theme_font_override("font", f_mono)
	pad_bar.add_theme_font_size_override("font_size", fs(11 if hh else 13))
	pad_bar.add_theme_color_override("font_color", Color("f1e6cc"))
	pad_bar.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	pad_bar.add_theme_constant_override("outline_size", 4)
	pad_bar.anchor_left = 0.0; pad_bar.anchor_right = 1.0; pad_bar.anchor_top = 1.0; pad_bar.anchor_bottom = 1.0
	pad_bar.offset_left = 8; pad_bar.offset_right = -8; pad_bar.offset_top = -24 if hh else -30; pad_bar.offset_bottom = -4
	pad_bar.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	pad_bar.vertical_alignment = VERTICAL_ALIGNMENT_BOTTOM
	pad_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pad_bar.visible = false
	body.add_child(pad_bar)
	# the place editor (Dev Mode) over the 3D view
	editor = PlaceEditor.new(world, float(world_shrink))
	body.add_child(editor)
	vring = VoiceRing.new(world, float(world_shrink), world_view)
	vring.area_fn = view_rect
	var dc = ConfigFile.new()
	dc.load("user://settings.cfg")
	vring.show_button = str(dc.get_value("display", "voice_button", "auto"))
	body.add_child(vring)
	if not get_viewport().size_changed.is_connected(_on_resized):
		get_viewport().size_changed.connect(_on_resized)
	_load_dev()
	var center = HBoxContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	scroll.add_child(center)
	margin = MarginContainer.new()
	margin.custom_minimum_size = Vector2(minf(780, get_viewport_rect().size.x - 36), 0)
	margin.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	margin.add_theme_constant_override("margin_top", 18)
	margin.add_theme_constant_override("margin_bottom", 60)
	center.add_child(margin)
	page = VBoxContainer.new()
	page.add_theme_constant_override("separation", 12)
	margin.add_child(page)
	target = page

	modal = Control.new()
	modal.set_anchors_preset(Control.PRESET_FULL_RECT)
	modal.visible = false
	add_child(modal)
	var dim = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.gui_input.connect(func(ev): if ev is InputEventMouseButton and ev.pressed: close_modal())
	modal.add_child(dim)
	var mp = PanelContainer.new()
	mp.add_theme_stylebox_override("panel", _box(COL.page, COL.brass, 1, 8, Vector4(22, 18, 22, 18)))
	mp.set_anchors_preset(Control.PRESET_CENTER)
	mp.anchor_left = 0.5; mp.anchor_right = 0.5; mp.anchor_top = 0.05; mp.anchor_bottom = 0.95
	mp.offset_left = -430; mp.offset_right = 430; mp.offset_top = 0; mp.offset_bottom = 0
	if _narrow():
		# a phone: the panel fills the screen, less a thin edge
		mp.anchor_left = 0.0; mp.anchor_right = 1.0; mp.anchor_top = 0.0; mp.anchor_bottom = 1.0
		mp.offset_left = 6; mp.offset_right = -6; mp.offset_top = 6; mp.offset_bottom = -6
		mp.add_theme_stylebox_override("panel", _box(COL.page, COL.brass, 1, 8, Vector4(12, 12, 12, 12)))
	modal.add_child(mp)
	modal_panel = mp
	mscroll = ScrollContainer.new()
	mscroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	mscroll.follow_focus = true
	mp.add_child(mscroll)
	mpage = VBoxContainer.new()
	mpage.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mpage.add_theme_constant_override("separation", 10)
	mscroll.add_child(mpage)
	_render_ledger()

func _box(bg: Color, border: Color, bw: int, radius: int, pad: Vector4 = Vector4(14, 10, 14, 10)) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.content_margin_left = pad.x
	s.content_margin_top = pad.y
	s.content_margin_right = pad.z
	s.content_margin_bottom = pad.w
	return s

# ================================================================ ledger

func _render_ledger():
	var S = Game.S
	var on = phase != "title" and S.get("route", []).size() > 0
	ledger.visible = on
	for k in ["char", "tin", "bag", "log"]:
		top_buttons[k].visible = on and not hh
	top_buttons["menu"].visible = not hh
	if not on:
		return
	var N: Dictionary = Data.T["NAMES"]
	var L: Dictionary = Data.T["LIM"]
	var sh = _narrow()     # a phone: the short names, so the ledger fits in two lines (one on a handheld)
	ledger_labels["hp"].text = ("HP %d/%d" if sh else "Health %d/%d") % [S.hp, L.hp[1]]
	ledger_labels["st"].text = ("St %d/%d" if sh else "Stamina %d/%d") % [S.st, L.st[1]]
	ledger_labels["pw"].text = ("Pw %d%s" if sh else "Powder %d%s") % [S.pw, " (wet)" if S.wet else ""]
	ledger_labels["ra"].text = ("Ra %d" if sh else "Rations %d") % S.ra
	ledger_labels["hrs"].text = ("Hr %d/%d" if sh else "Hours %d/%d") % [S.hrs, Game.dline()]
	ledger_labels["notice"].text = ("Nt %d" if sh else "Notice %d") % S.notice
	ledger_labels["trust"].text = ("Tr %s" if sh else "Trust %s") % Game.signed(S.trust)
	ledger_labels["coin"].text = ("$ %d" if sh else "Coin %d") % S.coin
	ledger_labels["duty"].text = ("Du %s" if sh else "Duty %s") % Game.signed(S.duty)
	ledger_labels["lvl"].text = ("Lv %d%s" % [S.level, " •" if int(S.points) > 0 else ""]) if hh else "Lv %d · XP %d/%d%s" % [S.level, S.xp, Data.T["XP_PER_POINT"], (" · %d pts" % S.points) if int(S.points) > 0 else ""]
	ledger_labels["hp"].add_theme_color_override("font_color", COL.bad if int(S.hp) <= 3 else COL.text)
	ledger_labels["st"].add_theme_color_override("font_color", COL.bad if int(S.st) <= 3 else COL.text)
	ledger_labels["hrs"].add_theme_color_override("font_color", COL.bad if int(S.hrs) >= Game.dline() - 12 else COL.text)
	var loose: int = S.get("loose", []).size()
	top_buttons["tin"].text = ("Thoughts" if _narrow() else "Tin Thoughts [T]") + (" •%d" % loose if loose else "")
	top_buttons["char"].text = ("Character" if _narrow() else "Character [C]") + (" •" if int(S.points) > 0 else "")

func _on_top(which: String):
	match which:
		"char": open_char()
		"tin": open_thoughts()
		"bag": open_satchel()
		"log": open_journal()
		"menu": open_menu()

# ================================================================ widgets

func _esc(t: Variant) -> String:
	return str(t).replace("[", "[lb]")

## A font size under Settings > Text size.
func fs(n: Variant) -> int:
	return int(round(float(n) * text_scale))

static var _fsz_re: RegEx

func _scale_bb(bb: String) -> String:
	if text_scale == 1.0 or not bb.contains("[font_size="):
		return bb
	if _fsz_re == null:
		_fsz_re = RegEx.create_from_string("\\[font_size=(\\d+)\\]")
	var out = ""
	var at = 0
	for m in _fsz_re.search_all(bb):
		out += bb.substr(at, m.get_start() - at) + "[font_size=%d]" % fs(int(m.get_string(1)))
		at = m.get_end()
	return out + bb.substr(at)

func _rtl(bb: String, size: int = BODY_SIZE, col: Color = COL.text) -> RichTextLabel:
	bb = _scale_bb(bb)
	var r = RichTextLabel.new()
	r.bbcode_enabled = true
	r.fit_content = true
	r.scroll_active = false
	r.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	r.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	r.add_theme_font_size_override("normal_font_size", fs(size))
	r.add_theme_font_size_override("bold_font_size", fs(size))
	r.add_theme_font_size_override("italics_font_size", fs(size))
	r.add_theme_color_override("default_color", col)
	r.text = bb
	return r

func _add(c: Control) -> Control:
	target.add_child(c)
	return c

var _fade_tw: Tween
var _world_off_at := -10.0
var _world_tw: Tween

func _clear():
	_world_off()
	Bridge.page = Html.Element.new()
	Bridge.page.tag = "root"
	for c in page.get_children():
		c.queue_free()
	target = page
	choices.clear()
	beats.clear()
	beat_i = 0
	beat_btn = null
	beat_after = null
	voice_stung.clear()
	scroll.scroll_vertical = 0
	# each new screen of text fades in rather than snapping
	scroll.modulate.a = 0.0
	if _fade_tw and _fade_tw.is_valid():
		_fade_tw.kill()
	_fade_tw = create_tween()
	_fade_tw.tween_property(scroll, "modulate:a", 1.0, 0.22)

func _eyebrow(t: String):
	var l = Label.new()
	l.text = t.to_upper()
	l.add_theme_font_override("font", f_mono)
	l.add_theme_font_size_override("font_size", fs(13))
	l.add_theme_color_override("font_color", COL.brass)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_add(l)

func _title(t: String, big := false):
	var l = Label.new()
	l.text = t
	l.add_theme_font_override("font", f_bold)
	l.add_theme_font_size_override("font_size", fs(46 if big else 32))
	l.add_theme_color_override("font_color", Color("f1e6cc"))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_add(l)

func _prose(t: Variant, col: Color = COL.text, italic := false) -> Control:
	var parts: PackedStringArray = []
	for p in str(t).split("\n\n"):
		var s = _esc(p.strip_edges())
		parts.append("[i]" + s + "[/i]" if italic else s)
	return _add(_rtl("\n\n".join(parts), BODY_SIZE, col))

func _hint(t: String):
	_add(_rtl("[i]" + _esc(t) + "[/i]", 16, COL.dim))

func _prompt(t: String):
	var l = Label.new()
	l.text = t
	l.add_theme_font_override("font", f_mono_b)
	l.add_theme_font_size_override("font_size", fs(14))
	l.add_theme_color_override("font_color", COL.dim)
	_add(l)

func _voice_color(v: String) -> Color:
	var k = Game.voice_kind(v)
	return COL.get(k, COL.line)

## A line from one of the voices in your head. `passive` is the Disco-style check tag ("Medium: Success").
func _voice(v: String, text: Variant, big := false, beat := true, passive := "") -> Control:
	if not Data.T["VOICES"].has(v):
		return null
	var line = Game.voice_text(v, text)
	var k = Game.voice_kind(v)
	var p = PanelContainer.new()
	var sb = _box(COL.panel, _voice_color(v), 0, 2, Vector4(14, 8, 12, 8))
	sb.border_width_left = 3
	p.add_theme_stylebox_override("panel", sb)
	var nc: Color = NAME_COL.get(k, COL.brass)
	var tag := ("  [color=#%s]‹%s›[/color]" % [COL.dim.to_html(false), _esc(passive)]) if passive != "" else ""
	var bb = "[font_size=14][color=#%s][b]%s[/b][/color]%s[/font_size]\n%s" % [nc.to_html(false), _esc(Game.voice_head(v)).to_upper(), tag, _esc(line)]
	p.add_child(_rtl(bb, 21 if big else 18))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_add(p)
	if beat:
		_beat(p, line)
	if not voice_stung.has(v) and not seen_lines.has(line.hash()):
		voice_stung[v] = true
		Sound.voice(v)
	return p

func _portrait(mood: String, hue: Variant, size: int = 96) -> Control:
	var path = "res://assets/portraits/%s.png" % mood
	if not ResourceLoader.exists(path):
		path = "res://assets/portraits/calm.png"
	var frame = PanelContainer.new()
	frame.add_theme_stylebox_override("panel", _box(Color("0f0d0a"), COL.line, 1, 4, Vector4(3, 3, 3, 3)))
	var tr = TextureRect.new()
	tr.texture = load(path)
	tr.custom_minimum_size = Vector2(size, size)
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var deg = float(str(hue).replace("deg", "")) if hue != null and str(hue) != "" else 0.0
	if deg != 0.0:
		var mat = ShaderMaterial.new()
		mat.shader = hue_shader
		mat.set_shader_parameter("hue", deg_to_rad(deg))
		tr.material = mat
	frame.add_child(tr)
	return frame

func _speaker(name: String, role: String, mood: Variant, hue: Variant, obj := false):
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	if not obj:
		row.add_child(_portrait(str(mood) if mood else "calm", hue))
	var col = VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	var n = Label.new()
	n.text = name
	n.add_theme_font_override("font", f_bold)
	n.add_theme_font_size_override("font_size", fs(30))
	n.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	n.custom_minimum_size = Vector2(120, 0)
	col.add_child(n)
	var r = Label.new()
	r.text = role
	r.add_theme_color_override("font_color", COL.dim)
	r.add_theme_font_size_override("font_size", fs(16))
	r.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	r.custom_minimum_size = Vector2(120, 0)
	col.add_child(r)
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(col)
	_add(row)

func _you(text: String):
	var c = _rtl("[i]— " + _esc(text) + "[/i]", BODY_SIZE, COL.you)
	_add(c)

func _roll(r: Dictionary, m: Dictionary, label := "", sound := true):
	if sound:
		Sound.play("redfail" if r.crit == "lo" else ("redpass" if r.crit == "hi" else ("pass" if r.ok else "fail")))
	var verdict = "Double six: success" if r.crit == "hi" else ("Double one: setback" if r.crit == "lo" else ("Success" if r.ok else "Setback"))
	if r.has("sup"):
		verdict = LivingDice.verdict(r, verdict)
	if m.get("vn") and (label == "" or label == Data.T["SKILLS"].get(Data.T["VOICES"].get(str(m.get("v")), {}).get("sk", ""), "")):
		label = m.vn
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _box(Color("14110d"), COL.line, 1, 4))
	var vc: Color = COL.good if r.ok else COL.bad
	var bb = "[font=res://assets/fonts/LiberationMono-Regular.ttf][font_size=16]%s   [b]%d + %d[/b]   %s = %d vs %d   [color=#%s][b]%s[/b][/color][/font_size][/font]\n[font_size=14][color=#%s]%s[/color][/font_size]" % [
		_esc(label), r.a, r.b, Game.signed(m.tot), r.total, m.dc, vc.to_html(false), verdict.to_upper(), COL.dim.to_html(false), _esc(" · ".join(PackedStringArray(m.list)))]
	if str(r.get("note", "")) != "":
		bb += "\n[font_size=14][color=#%s][i]%s[/i][/color][/font_size]" % [COL.brass.to_html(false), _esc(str(r.note) + (" · " + str(r.fxnote) if str(r.get("fxnote", "")) != "" else ""))]
	p.add_child(_rtl(bb))
	_add(p)

func _chips(list: Array):
	if list.is_empty():
		return
	var flow = HFlowContainer.new()
	flow.add_theme_constant_override("h_separation", 8)
	flow.add_theme_constant_override("v_separation", 6)
	for c in list:
		if typeof(c) == TYPE_STRING:
			c = { "t": RegEx.create_from_string("<[^>]+>").sub(str(c), "", true), "k": "up" if str(c).find("chip up") >= 0 else ("down" if str(c).find("chip down") >= 0 else "") }
		var kind: String = c.get("k", "")
		var col: Color = COL.good if kind == "up" else (COL.bad if kind == "down" else (COL.brass if kind == "info" else COL.dim))
		var p = PanelContainer.new()
		p.add_theme_stylebox_override("panel", _box(Color(0, 0, 0, 0), col, 1, 3, Vector4(8, 2, 8, 3)))
		var l = Label.new()
		l.text = str(c.get("t", ""))
		l.add_theme_color_override("font_color", col)
		l.add_theme_font_size_override("font_size", fs(15))
		p.add_child(l)
		flow.add_child(p)
	_add(flow)

func _tag_bb(text: String, kind: String = "") -> String:
	var col: Color = COL.good if kind == "go" else (COL.bad if kind == "warn" else (Color("e07a6a") if kind == "red" else COL.dim))
	return "[color=#%s]‹%s›[/color]" % [col.to_html(false), _esc(text)]

## A choice the player can click (or press its number for).
func _choice(title: String, hint: String = "", tags: Array = [], disabled := false, cb: Callable = Callable(), style := "", numbered := true) -> Control:
	var n = choices.size() + 1
	var p = PanelContainer.new()
	var base_col: Color = COL.line
	if style.begins_with("v:"):
		base_col = _voice_color(style.substr(2))
	var cpad = Vector4(16, 14, 16, 14) if big_buttons else Vector4(14, 10, 14, 10)
	var normal = _box(COL.panel if not disabled else Color("1c1813"), base_col, 1, 5, cpad)
	var hover = _box(Color("3a3023"), COL.brass, 1, 5, cpad)
	p.add_theme_stylebox_override("panel", normal)
	p.focus_mode = Control.FOCUS_ALL if not disabled else Control.FOCUS_NONE
	var v = VBoxContainer.new()
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	v.add_theme_constant_override("separation", 2)
	var tcol: Color = COL.dim if disabled else Color("f1e6cc")
	var num = ("[color=#%s]%d.[/color] " % [COL.brass.to_html(false), n]) if not disabled and numbered else ""
	v.add_child(_rtl(num + _esc(title), BODY_SIZE, tcol))
	if hint != "":
		v.add_child(_rtl("[i]" + _esc(hint) + "[/i]", 15, COL.dim))
	if tags.size():
		var tb: PackedStringArray = []
		for t in tags:
			tb.append(_tag_bb(t[0], t[1] if t.size() > 1 else ""))
		v.add_child(_rtl("[font_size=14]" + "  ".join(tb) + "[/font_size]", 14, COL.dim))
	p.add_child(v)
	if not disabled:
		p.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		p.mouse_entered.connect(func(): p.add_theme_stylebox_override("panel", hover))
		p.mouse_exited.connect(func(): if not p.has_focus(): p.add_theme_stylebox_override("panel", normal))
		p.focus_entered.connect(func(): p.add_theme_stylebox_override("panel", hover))
		p.focus_exited.connect(func(): p.add_theme_stylebox_override("panel", normal))
		# picked when the press is let go where it started, so a finger can scroll the list without choosing
		p.mouse_filter = Control.MOUSE_FILTER_PASS
		p.gui_input.connect(func(ev):
			if ev is InputEventMouseButton and ev.button_index == MOUSE_BUTTON_LEFT:
				if ev.pressed:
					p.set_meta("down", ev.global_position)
				elif p.has_meta("down"):
					var d: Vector2 = p.get_meta("down")
					p.remove_meta("down")
					if d.distance_to(ev.global_position) < 14.0:
						p.accept_event()
						_pick(cb)
			elif ev.is_action_pressed("ui_accept"):
				p.accept_event()
				_pick(cb))
	_add(p)
	if numbered:
		choices.append([p, cb, disabled])
	return p

func _pick(cb: Callable):
	Sound.play("blip", 0.25)
	if cb.is_valid():
		cb.call()

func _button(text: String, cb: Callable, parent: Control = null, disabled := false) -> Button:
	var b = Button.new()
	b.text = text
	b.disabled = disabled
	b.mouse_filter = Control.MOUSE_FILTER_PASS
	if big_buttons:
		b.custom_minimum_size = Vector2(0, 52)
	if _narrow():
		# long labels wrap on a phone rather than pushing the column off the screen
		b.autowrap_mode = TextServer.AUTOWRAP_WORD
		b.custom_minimum_size.x = minf(get_viewport_rect().size.x - 60, 120)
	b.pressed.connect(func(): Sound.play("blip", 0.2); cb.call())
	if parent:
		parent.add_child(b)
	else:
		_add(b)
	return b

func _actions() -> HFlowContainer:
	var f = HFlowContainer.new()
	f.add_theme_constant_override("h_separation", 10)
	f.add_theme_constant_override("v_separation", 8)
	_add(f)
	return f

func _thought_card(tid: String, done := false, extra: Callable = Callable()):
	var th: Dictionary = Data.T["THOUGHTS"][tid]
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _box(Color("231d14"), COL.brass, 1, 6))
	var v = VBoxContainer.new()
	var mull = int(Game.S["mull"].get(tid, 0))
	var text: String = th["concl"] if done and th.get("concl") else th["text"]
	v.add_child(_rtl("[b]" + _esc(th["name"]) + "[/b]\n" + _esc(text), 18))
	v.add_child(_rtl("[font_size=14]" + _thought_fx(th, done) + "[/font_size]", 14, COL.dim))
	if extra.is_valid():
		extra.call(v, mull)
	p.add_child(v)
	_add(p)

func _thought_fx(th: Dictionary, done: Variant) -> String:
	var fx: PackedStringArray = []
	var SK: Dictionary = Data.T["SKILLS"]
	for sk in th.get("bonus", {}):
		fx.append(_tag_bb(SK[sk] + " +" + str(th["bonus"][sk]) + (" when it sinks in" if done == false else ""), "go"))
	if done != true:
		for sk in th.get("cost", {}):
			fx.append(_tag_bb(SK[sk] + " " + str(th["cost"][sk]) + " while it sinks in", "warn"))
	if th.get("perk") and Data.T["PERKS"].has(th["perk"]):
		fx.append(_tag_bb(Data.T["PERKS"][th["perk"]] + (" (when it sinks in)" if done == false else ""), "go"))
	if th.get("mute") and Data.T["VOICES"].has(th["mute"]):
		fx.append(_tag_bb(Data.T["VOICES"][th["mute"]]["name"] + " falls quiet" + (" (when it sinks in)" if done == false else ""), ""))
	return "  ".join(fx)

## Show the queued voice lines and thought notices.
func _drain():
	if Bridge.has_js("drainVoices"):
		_html_fragment(str(Bridge.call_js("drainVoices")))
		return
	for x in Game.drain():
		if x[0] == "_th":
			var th: Variant = Data.T["THOUGHTS"].get(x[1])
			if th:
				_eyebrow("Thought internalized")
				_thought_card(x[1], true)
			continue
		if str(x[3]) != "":
			_beat(_prose(x[3], COL.dim, true), str(x[3]))
		_voice(x[0], x[1])

# ---------------------------------------------------------------- staged reveal (one beat at a time)

func _beat(c: Control, key: String = ""):
	if c == null:
		return
	beats.append([c, key])

func _stage(after: Control):
	beat_after = after
	# lines already heard show at once; new ones wait for Continue
	var first_new = -1
	for i in beats.size():
		var key: String = beats[i][1]
		if key != "" and seen_lines.has(key.hash()):
			continue
		if first_new < 0:
			first_new = i
	if first_new < 0 or beats.size() - first_new <= 1:
		_reveal_all()
		return
	for i in range(first_new + 1, beats.size()):
		beats[i][0].visible = false
	beat_i = first_new + 1
	_mark_seen(first_new)
	if after:
		after.visible = false
	beat_btn = Button.new()
	beat_btn.text = "Continue  (A)" if pad and pad.used else "Continue  [Space]"
	beat_btn.pressed.connect(_next_beat)
	page.add_child(beat_btn)
	page.move_child(beat_btn, beats[beat_i - 1][0].get_index() + 1)
	beat_btn.call_deferred("grab_focus")

func _mark_seen(i: int):
	var key: String = beats[i][1]
	if key != "":
		seen_lines[key.hash()] = true

func _next_beat():
	if beat_i >= beats.size():
		return
	beats[beat_i][0].visible = true
	_mark_seen(beat_i)
	beat_i += 1
	while beat_i < beats.size() and seen_lines.has(str(beats[beat_i][1]).hash()) and beats[beat_i][1] != "":
		beats[beat_i][0].visible = true
		beat_i += 1
	if beat_i >= beats.size():
		_reveal_all()
	else:
		page.move_child(beat_btn, beats[beat_i - 1][0].get_index() + 1)
		_scroll_to(beat_btn)

func _reveal_all():
	for b in beats:
		b[0].visible = true
		if b[1] != "":
			seen_lines[str(b[1]).hash()] = true
	beat_i = beats.size()
	if beat_btn:
		beat_btn.queue_free()
		beat_btn = null
	if beat_after:
		beat_after.visible = true
	_focus_first_choice()

func _focus_first_choice():
	for c in choices:
		if not c[2] and is_instance_valid(c[0]) and c[0].is_visible_in_tree():
			c[0].call_deferred("grab_focus")
			return

func _scroll_to(c: Control):
	await get_tree().process_frame
	if is_instance_valid(c):
		scroll.ensure_control_visible(c)

# ---------------------------------------------------------------- input

func _unhandled_input(ev: InputEvent):
	if not (ev is InputEventKey) or not ev.pressed or ev.echo:
		return
	var k: int = ev.keycode
	if world and world.in_cut() and k in [KEY_SPACE, KEY_ESCAPE, KEY_ENTER]:
		world.cut_skip()
		get_viewport().set_input_as_handled()
		return
	if k == KEY_ESCAPE:
		if modal.visible:
			close_modal()
		elif phase != "title":
			open_menu()
		get_viewport().set_input_as_handled()
		return
	if modal.visible:
		return
	if (k == KEY_SPACE or k == KEY_ENTER) and beat_btn != null:
		_next_beat()
		get_viewport().set_input_as_handled()
		return
	if k >= KEY_1 and k <= KEY_9 and beat_btn == null:
		var n = k - KEY_1
		var live: Array = choices.filter(func(c): return not c[2] and is_instance_valid(c[0]) and c[0].is_visible_in_tree())
		if n < live.size():
			_pick(live[n][1])
			get_viewport().set_input_as_handled()
		return
	if ev.is_action_pressed("voice") and vring and vring.open_next():
		get_viewport().set_input_as_handled()
		return
	if phase in ["scene", "talk", "road"]:
		if ev.is_action_pressed("character"): open_char()
		elif ev.is_action_pressed("thoughts"): open_thoughts()
		elif ev.is_action_pressed("satchel"): open_satchel()
		elif ev.is_action_pressed("journal"): open_journal()

# ================================================================ title, creation, intro

func title_screen():
	phase = "title"
	Sound.music("")
	Sound.ambience("rain_out", 0.3)
	_clear()
	_render_ledger()
	_add(Control.new()).custom_minimum_size = Vector2(0, 80)
	_eyebrow("A dispatch in four copies")
	_title("The Postal Trace", true)
	_hint("The front has come apart, and you have been given a sealed tin case.")
	var a = _actions()
	var latest = _latest_slot()
	if latest >= 0:
		_button("Continue", func(): _load_and_go(latest), a)
	_button("New game", func(): cc = {}; creator(), a)
	_button("Load game", func(): open_load(), a)
	_button("Practice a fight", practice_menu, a)
	_button("Credits", func(): open_credits(), a)
	_button("Quit", func(): get_tree().quit(), a)

func creator():
	phase = "other"
	if cc.is_empty():
		cc = { "trait": "steady", "up": { "arms": 1, "nerve": 1, "wits": 1, "grit": 1 }, "arch": null, "hard": false, "vary": false }
	var T: Dictionary = Data.T
	var spent = 0
	for k in cc.up:
		spent += int(cc.up[k])
	var left: int = int(T["POOL"]) - spent
	_clear()
	_eyebrow("New game")
	_title("Who are you?")
	_hint("Pick an archetype for a quick start, or build your own. Everyone also carries a veteran’s endurance (Grit +1).")
	_prompt("ARCHETYPE")
	for ar in T["ARCHES"]:
		_choice(ar["name"] + ("  ✓" if cc.arch == ar["id"] else ""), ar["text"], [], false, func():
			cc.arch = ar["id"]; cc.trait = ar["trait"]; cc.up = ar["up"].duplicate(); creator())
	_choice("Custom" + ("  ✓" if cc.arch == null else ""), "Spend the points yourself.", [], false, func(): cc.arch = null; creator())
	_prompt("WHAT THE THIRD BATTERY TAUGHT YOU (+2)")
	for t in T["TRAITS"]:
		_choice(T["TRAITS"][t][1] + ("  ✓" if cc.trait == t else ""), T["SKILLS"][T["TRAITS"][t][0]] + " +2", [], false, func():
			cc.trait = t; cc.arch = null; creator())
	_prompt("SKILL POINTS · %d LEFT" % left)
	for sk in T["SKILLS"]:
		var tot: int = int(cc.up[sk]) + (1 if sk == "grit" else 0) + (2 if T["TRAITS"][cc.trait][0] == sk else 0)
		var row = HBoxContainer.new()
		row.add_theme_constant_override("separation", 10)
		var names: PackedStringArray = []
		for v in T["V_OF"][sk]:
			names.append(T["VOICES"][v]["name"])
		var info = _rtl("[b]%s[/b]  [color=#%s]total %s[/color]\n[font_size=15][i]%s[/i]\n%s: each starts at %s and can be trained %d more.[/font_size]" % [
			T["SKILL_INFO"][sk][0], COL.brass.to_html(false), Game.signed(tot), _esc(T["SKILL_INFO"][sk][1]), " · ".join(names), Game.signed(tot), max(0, tot)], 18)
		row.add_child(info)
		var minus = Button.new()
		minus.text = " − "
		minus.disabled = int(cc.up[sk]) <= 0
		minus.pressed.connect(func(): cc.up[sk] = int(cc.up[sk]) - 1; cc.arch = null; creator())
		row.add_child(minus)
		var val = Label.new()
		val.text = str(cc.up[sk])
		val.custom_minimum_size = Vector2(24, 0)
		val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		row.add_child(val)
		var plus = Button.new()
		plus.text = " + "
		plus.disabled = left <= 0 or int(cc.up[sk]) >= int(T["CC_MAX"])
		plus.pressed.connect(func(): cc.up[sk] = int(cc.up[sk]) + 1; cc.arch = null; creator())
		row.add_child(plus)
		_add(row)
	_hint("Each skill can start at +%d at most. A skill sets where its voices start and how far each can be trained; later points train one voice at a time, or raise the cap for all of a skill’s voices. Points you leave over are kept for later." % int(T["CC_MAX"]))
	_prompt("HOW HARD IS THE ROAD?")
	_choice("Standard" + ("" if cc.hard else "  ✓"), "The road as it was meant to be walked. Failed checks can be tried again when you have grown.", [], false, func(): cc.hard = false; creator())
	_choice("Hardcore" + ("  ✓" if cc.hard else ""), " · ".join(PackedStringArray(T["HARD_RULES"])), [], false, func(): cc.hard = true; creator())
	_prompt("WHICH ROAD?")
	_choice("The whole road" + ("" if cc.vary else "  ✓"), "Every meeting on the trace, in a new order each time.", [], false, func(): cc.vary = false; creator())
	_choice("A different road" + ("  ✓" if cc.vary else ""), "Two of the road meetings are left out, so no two runs meet the same people.", [], false, func(): cc.vary = true; creator())
	_prompt("THE DICE")
	var ldo: Dictionary = cc.get("ld", {})
	_choice("Ordinary dice" + ("" if ldo.get("on", false) else "  ✓"), "Two plain d6, as the road was always walked.", [], false, func(): cc["ld"] = {}; creator())
	_choice("Living dice" + ("  ✓" if ldo.get("on", false) else ""), "Every throw wears your dice: the face that lands gains a pip and the face across from it loses one.", [], false, func():
		var o: Dictionary = cc.get("ld", {}).duplicate(); o["on"] = true; cc["ld"] = o; creator())
	if ldo.get("on", false):
		for opt in [["snow", "Snowball rule", "Higher faces land more often."], ["lock", "Lock rule", "Hold one pair of faces on each die still."], ["blank", "Hard mode: blank dice", "Every face starts at 1."]]:
			_choice(opt[1] + ("  ✓" if ldo.get(opt[0], false) else ""), opt[2], [], false, func():
				var o2: Dictionary = cc.get("ld", {}).duplicate(); o2[opt[0]] = not o2.get(opt[0], false); cc["ld"] = o2; creator())
	var a = _actions()
	_button("Begin the road", func():
		Sound.play("road")
		cc["left"] = left
		Game.begin_run(cc)
		seen_lines.clear()
		intro(0), a)
	_button("Back", title_screen, a)

func intro(n: int):
	phase = "other"
	var pages: Array = Data.T["INTRO_PAGES"]
	var last = n >= pages.size() - 1
	_clear()
	if n == 0:
		_eyebrow("A dispatch in four copies")
		_title("The Postal Trace", true)
	else:
		_eyebrow("Redoubt Nine · %d of %d" % [n + 1, pages.size()])
	_prose(pages[n])
	var a = _actions()
	_button("Take the first step" if last else "Continue", func(): _road_start() if last else intro(n + 1), a)
	if not last:
		_button("Skip the opening", _road_start, a)

func _road_start():
	if Bridge.has_js("redoubtStart"):
		Bridge.call_js("redoubtStart")
	else:
		feeling()

func feeling():
	_clear()
	_eyebrow("The tin case")
	_title("How do you carry it?")
	_prose("It is an exit, and it is a reprieve, and it is also a tether. You were thrown out of the line, and now the same machine wants your legs for its errands. The case weighs less than a sidearm and holds more than any of the men who put it in your hands will admit.\n\nYou are not sure what you feel. Whatever it is, it comes with reluctance.")
	var opts = [["Relieved, and ashamed of it", "Duty +1. You are out of the trench, and you hate how much that matters."],
		["Resentful of the tether", "Duty −1. You will deliver, if you deliver, on your own terms."],
		["Numb", "Duty 0, Stamina +1. You walk because the road goes that way."]]
	for i in opts.size():
		_choice(opts[i][0], opts[i][1], [], false, func():
			var S = Game.S
			if i == 0: S.duty = 1
			elif i == 1: S.duty = -1
			else: S.st = min(10, int(S.st) + 1)
			var di: Dictionary = Data.T["DUTY_INTRO"]
			Game.vq_push("duty", di["lines"][i], "force", str(di.get("beat", "")))
			if i == 0: _tally("frightened")
			elif i == 1: _tally("cynical")
			S.route = Game.build_route()
			S.idx = 0
			Game.ledger_changed.emit()
			scene())

# ================================================================ the scene

func _sound_for_scene(id: String):
	Sound.music("")
	Sound.ambience("rain_town" if id in TOWN else "rain_out", 0.35)

func scene():
	Game.pending = []
	var S = Game.S
	# the browser's turns in the road: an extra area being visited, the Provost's Gate, the
	# rider carrying Lisle's report, the hunt after a fight at the gate
	var scx: Variant = Bridge.js("SCX")
	if scx is Dictionary and scx.get("back") != null:
		Data.call_fn(scx.back)
		return
	var cid := Game.cur_id()
	if cid == "checkpoint" and Bridge.has_js("cpScene"):
		_world_off()
		Bridge.call_js("cpScene")
		return
	if cid == "cp_rider" and Bridge.has_js("cpRider"):
		Bridge.call_js("cpRider")
		return
	if Bridge.has_js("cartReportDue") and Data.truthy(Bridge.call_js("cartReportDue")):
		Bridge.call_js("cartReport")
		return
	if Bridge.has_js("cpHuntDue") and Data.truthy(Bridge.call_js("cpHuntDue")):
		Bridge.call_js("cpHunt")
		return
	var id = Game.cur_id()
	var sc: Variant = Game.def(id)
	if sc == null:
		return advance()
	phase = "scene"
	_sound_for_scene(id)
	var first_here: bool = int(S.seen) < int(S.idx) + 1
	S.seen = max(int(S.seen), int(S.idx) + 1)
	var arr: Array = []
	if first_here:
		if Game.is_main(id):
			if Game.vperk("arrive_quiet") and int(S.notice) > 0:
				S.notice = int(S.notice) - 1; arr.append(Game.chip("Notice −1: a forgettable face", "up"))
			if Game.vperk("stop_coin"):
				S.coin = int(S.coin) + 1; Game.clamp_k("coin"); arr.append(Game.chip("+1 coin: an expense chit", "up"))
			if Game.vperk("stop_ration"):
				S.ra = int(S.ra) + 1; Game.clamp_k("ra"); arr.append(Game.chip("+1 ration: a quartermaster’s habit", "up"))
			var wh: Variant = Data.T["WIRE_HEARD"].get(id)
			if Game.vperk("overheard") and wh and not S.learned.any(func(l): return l.text == wh):
				S.learned.append({ "from": "The Wire", "where": sc.title, "text": wh })
				arr.append(Game.chip("Overheard: " + str(wh), "info"))
		Game.ledger_changed.emit()
	_clear()
	_world("walk")
	_eyebrow(str(sc.get("eyebrow", "")))
	_title(str(sc.title))
	_prose(Data.val(sc.text))
	_perception(sc, id)
	_chips(arr)
	_drain()
	_arrival_voices(id)
	if Bridge.has_js("compArrive"):
		_html_fragment(str(Bridge.call_js("compArrive", [id])))
	_memory_prompt(id)
	var ts = Game.talkers()
	var locked = ts.size() > 0 and not Game.has_talked(id)
	if ts.size():
		_banter(id, "late" if Game.has_talked(id) else "enter")
		_prompt("TALK FIRST" if locked else "WHO IS HERE")
		for i in ts.size():
			var t: Dictionary = ts[i]
			var left = _graph_left(id, t)
			var sub: String = t.role + " · " + ((str(left) + " thing" + ("s" if left > 1 else "") + " to ask") if left else "nothing more to say")
			if not Data.T["CROWN"].has(t.id) and not S.done.has("mode_" + id):
				sub += " · Not the Crown’s: choose how to speak"
			_talk_button(t, sub, func(): talk(i))
		if S.assessed.has(id):
			_hint("You have sized up this scene" + (". The stakes show on each option." if S.assessed[id].ok else " and learned nothing."))
		else:
			var a = _actions()
			_button("Size up the situation (The Wire" + ("" if Game.perk("size") or Game.vperk("size_read") else ", 1 hour") + ")", assess, a)
		_hint("Words here are free but may cost an hour. What you learn or what stirs people up changes your next check." if Game.has_talked(id) else "More options will appear once you have said something to someone here.")
		_temp_line()
	# companions who could walk with you, and errands waiting here (the browser's blocks)
	if Bridge.has_js("recruitBlock"):
		_html_fragment(str(Bridge.call_js("recruitBlock", [id])))
	if Bridge.has_js("errandBlock"):
		_html_fragment(str(Bridge.call_js("errandBlock", [id])))
	var objs = Game.objects()
	if objs.size():
		_prompt("LOOK AROUND")
		for o in objs:
			var seen: bool = Game.is_done("gmet_" + id + "_x_" + str(o.id))
			_choice(str(o.name) + ("  (looked at)" if seen else ""), str(o.get("blurb", "")), [], false, func(): look(str(o.id)))
	_dice_bar()
	_prompt("WHAT DO YOU DO?")
	var list: Array = sc.choices.duplicate()
	if sc.get("extra") != null:
		var ex: Variant = Data.call_fn(sc.extra)
		if ex is Array:
			list.append_array(ex)
	var vis: Array = []
	for i in list.size():
		if not (locked and not Data.truthy(list[i].get("open"))):
			vis.append(i)
	if vis.is_empty():
		_hint("Your options will show up once you have said something to someone here.")
	var sized: bool = S.assessed.has(id) and S.assessed[id].ok
	for i in vis:
		var ch: Dictionary = list[i]
		var block: Variant = Data.call_fn(ch.need) if ch.get("need") != null else null
		var m = Game.modifiers(ch)
		var auto: bool = ch.get("auto") != null and Data.truthy(Data.call_fn(ch.auto))
		var tags: Array = []
		if auto:
			tags.append(["No roll", "go"])
		else:
			tags.append(_ck_tag(str(ch.skill), m, "scene"))
		if block:
			tags.append([str(block), "warn"])
		if sized:
			if auto:
				tags.append(["Outcome: " + _fx_summary(ch.ok), "go"])
			else:
				tags.append(["Win: " + _fx_summary(ch.ok), "go"])
				tags.append(["Lose: " + _fx_summary(ch.bad), "warn"])
		_choice(str(Data.val(ch.title)), str(Data.gv(ch, "hint")) if ch.get("hint") != null else "", tags, block != null, func(): resolve(ch, i))
	for b in ["bindRecruit", "bindErrands", "bindMemory"]:
		if Bridge.has_js(b) and b != "bindMemory":
			Bridge.call_js(b)
	_reveal_all()
	Game.snap("scene")
	if id == "redoubt" and not Game.is_done("rd_cut"):
		S.done.rd_cut = true
		_redoubt_cut()

## Lieutenant Ashworth comes from the dugout to the courier, and then he speaks (the browser's rdCut).
func _redoubt_cut():
	var open := func():
		if Game.cur_id() != "redoubt" or Game.has_talked("redoubt"):
			return
		var ts: Array = Game.talkers()
		for i in ts.size():
			if str(ts[i].id) == "ashworth":
				talk(i)
				return
	if world == null or not three_d or not world_view.visible or not world.figures.has("ashworth"):
		return
	world.cut_walk("ashworth", Vector2(-5.4, -6.0), 1.9, open)

func _talk_button(t: Dictionary, sub: String, cb: Callable):
	var p = _choice(str(t.name), sub, [], false, cb)
	var v: VBoxContainer = p.get_child(0)
	var row = HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_theme_constant_override("separation", 12)
	var port = _portrait(str(t.get("mood", "calm")), t.get("hue"), 56)
	port.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.remove_child(v)
	row.add_child(port)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(v)
	p.add_child(row)

func _temp_line():
	var t: Array = Game.S.temp
	if t.is_empty():
		return
	var c: Array = []
	for x in t:
		c.append(Game.chip(Data.T["SKILLS"][x.sk] + " " + ("+" if int(x.v) > 0 else "") + str(x.v) + " · " + str(x.label), "up" if int(x.v) > 0 else "down"))
	_chips(c)

func _ck_tag(sk: String, m: Dictionary, kind: String, extra := "") -> Array:
	var vn: String = m.get("vn") if m.get("vn") else Data.T["SKILLS"].get(sk, sk)
	return [("Red · " if kind == "red" else "") + vn + " · " + Game.diff_name(int(m.dc)) + " " + str(m.dc) + " · " + str(Game.odds(m)) + "%" + extra, "red" if kind == "red" else ""]

func _fx_summary(out: Variant) -> String:
	if not (out is Dictionary):
		return ""
	var p: PackedStringArray = []
	var fx: Variant = Data.g(out, "fx")
	if not (fx is Dictionary):
		fx = {}
	for k in ["hp", "st", "pw", "ra", "hrs", "notice", "trust", "coin", "duty"]:
		if fx.get(k):
			p.append(Data.T["NAMES"][k] + " " + ("+" if int(fx[k]) > 0 else "−") + str(abs(int(fx[k]))))
	if fx.get("wet"): p.append("powder soaked")
	if fx.get("crack"): p.append("seal cracked")
	if out.get("deliver") == true: p.append("copy delivered")
	elif out.get("deliver") == false: p.append("copy lost")
	for gi in out.get("give", []):
		if Data.T["ITEMS"].has(gi): p.append(Data.T["ITEMS"][gi]["name"])
	return ", ".join(p) if p.size() else "nothing much"

func _perception(sc: Dictionary, id: String):
	var p: Variant = sc.get("perception")
	if not (p is Dictionary):
		return
	var S = Game.S
	if not S.perc.has(id):
		var a = Game.d6()
		var b = Game.d6()
		var bon: int = Game.skill_bonus("wits") + Game.v_rank("wire") + (-1 if int(S.hp) <= 4 and not Game.vperk("no_wound_pen") else 0) + (-1 if int(S.st) <= 3 else 0) + (2 if Game.perk("perc") else 0)
		var ok = Game.ok_roll(a, b, bon, int(p.dc))
		S.perc[id] = { "ok": ok, "a": a, "b": b, "bon": bon, "tot": a + b + bon, "dc": p.dc }
		if ok:
			_chips(_xp(1))
	var r: Dictionary = S.perc[id]
	_roll({ "a": r.a, "b": r.b, "total": r.tot, "ok": r.ok, "crit": "" }, { "tot": r.bon, "dc": r.dc, "list": [], "vn": "Perception (The Wire)" }, "Perception (The Wire)")
	_prose(p.ok if r.ok else p.bad, COL.text, true)

func _arrival_voices(id: String):
	var S = Game.S
	if Game.is_done("arr_" + id):
		return
	S.done["arr_" + id] = true
	var sv: Variant = Data.T["SCENE_VOICE"].get(id)
	if not (sv is Dictionary):
		return
	if sv.get("trace") and not Game.muted_by("trace"):
		var tr: Array = sv.trace
		var i = 0 if int(S.trust) <= -1 else (2 if int(S.trust) >= 1 else 1)
		_voice("trace", tr[i] if i < tr.size() and tr[i] else tr[1])
	var shown = false
	if sv.get("argue"):
		shown = _argue({ "lines": sv.argue }, true)
	if not shown and sv.get("duty") and not Game.muted_by("duty"):
		_voice("duty", Data.val(sv.duty))

func _arg_list(a: Variant) -> Array:
	if a == null:
		return []
	if not (a is Array):
		return [a]
	if a.size() and a[0] is Array:
		return [{ "lines": a }]
	return a

func _argue(a: Variant, arrival: bool) -> bool:
	if not (a is Dictionary) or not (a.get("lines") is Array) or a.lines.is_empty():
		return false
	if a.get("show") != null and not Data.truthy(Data.call_fn(a.show)):
		return false
	for l in a.lines:
		if not Game.voice_on(l[0], null) or (arrival and Game.muted_by(l[0])):
			return false
	if a.get("min") is Dictionary:
		for v in a.min:
			if Game.voice_val(v) < int(a.min[v]):
				return false
	for l in a.lines:
		_voice(l[0], Data.val(l[1]))
	return true

func _banter(id: String, key: String):
	var list: Variant = Data.T["BANTER"].get(id)
	if not (list is Array):
		return
	for b in list:
		if b.get("on") != key:
			continue
		var lines: PackedStringArray = []
		for l in b.lines:
			if l[0]:
				lines.append("[b]" + _esc(_name_of(id, l[0])) + "[/b] " + _esc(l[1]))
			else:
				lines.append("[i][color=#%s]%s[/color][/i]" % [COL.dim.to_html(false), _esc(l[1])])
		_beat(_add(_rtl("\n".join(lines))), "\n".join(lines))

func _name_of(id: String, sid: String) -> String:
	var sc: Variant = Game.def(id)
	if sc:
		for t in sc.get("talk", []):
			if t.id == sid:
				return t.name
	return sid

func _manner(id: String, t: Dictionary):
	var arr: Variant = Data.T["MANNER"].get(id + ":" + str(t.id))
	if not (arr is Array) or arr.is_empty():
		return
	var k = "v_" + id + ":" + str(t.id)
	var n = int(Game.S.done.get(k, 0))
	Game.S.done[k] = n + 1
	var line: String = arr[n % arr.size()]
	_beat(_prose(line, COL.dim, true), line)

func assess():
	var S = Game.S
	var id = Game.cur_id()
	var sc: Dictionary = Game.def(id)
	var m = Game.modifiers({ "skill": "wits", "dc": 8, "v": "wire" })
	var here = 2 if S.perc.has(id) and S.perc[id].ok else 0
	var others = 0
	for k in S.perc:
		if k != id and S.perc[k].ok:
			others += 1
	var pb: int = here + min(2, others)
	var a = Game.d6()
	var b = Game.d6()
	var ok: bool = true if Game.vperk("size_read") else Game.ok_roll(a, b, int(m.tot) + pb, int(m.dc))
	S.assessed[id] = { "ok": ok }
	var chips: Array = [] if Game.perk("size") or Game.vperk("size_read") else _fx({ "hrs": 1 })
	if ok:
		chips.append_array(_xp(1))
	var e = Game.check_end()
	if e != "":
		return ending(e)
	_clear()
	_world("still")
	_eyebrow(sc.title)
	_title("You read the ground" if ok else "You cannot read it")
	var mods: Array = m.list.duplicate()
	if pb:
		mods.append("keen eyes (passed perception) +" + str(pb))
	_roll({ "a": a, "b": b, "total": a + b + int(m.tot) + pb, "ok": ok, "crit": "" }, { "tot": int(m.tot) + pb, "dc": m.dc, "list": mods, "vn": "Size up the situation (The Wire)" }, "Size up the situation (The Wire)")
	_prose("You take a slow breath and weigh the faces, the ground, the weather and the exits. For once the picture holds still. Each course of action now shows what it could win you and what it could cost." if ok else "You study the scene until the details blur. An hour goes by and you are no wiser, and the dispatch case is no lighter.")
	_chips(chips)
	_button("Back to the scene", scene)

# ---------------------------------------------------------------- Redoubt Nine memories

func _memory_prompt(id: String):
	var S = Game.S
	var M: Dictionary = Data.T["MEM"]
	if Game.past_n() >= M.frags.size() or not M.lead.has(id) or S.done.has("mtrig_" + id):
		return
	if int(S.idx) - int(S.past.last) < 2:
		return
	_voice("ringing", M.lead[id], true)
	var a = _actions()
	_button("Listen to it", func():
		S.done["mtrig_" + id] = true
		S.past.last = S.idx
		memory_screen(), a)
	_button("Push it down", func():
		S.done["mtrig_" + id] = "down"
		S.done["mdown"] = int(S.done.get("mdown", 0)) + 1
		var d: Array = M.down[int(S.done.mdown) % 2]
		Game.vq_push(d[0], d[1])
		scene(), a)

func memory_screen():
	Sound.play("redoubt", 0.55)
	Sound.music("memory")
	var S = Game.S
	var M: Dictionary = Data.T["MEM"]
	var n = Game.past_n()
	var F: Dictionary = M.frags[n]
	S.past.n = n + 1
	var chips = _xp(2 if Game.vperk("mem_xp") else 1)
	_clear()
	phase = "other"
	_eyebrow("Redoubt Nine · Memory %d of %d" % [n + 1, M.frags.size()])
	_title(F.title)
	for p in F.text:
		_beat(_prose(p, COL.text, true), p)
	for x in F.voices:
		if Game.voice_on(x[0], null):
			_voice(x[0], x[1])
	_chips(chips)
	var last: bool = n + 1 >= M.frags.size()
	var a = _actions()
	_button("What happened at the gun?" if last else "Back to the present", func(): memory_choice() if last else scene(), a)
	_stage(a)

func memory_choice():
	var M: Dictionary = Data.T["MEM"]
	_clear()
	_eyebrow("Redoubt Nine")
	_title("What happened at the gun?")
	_prose("The ringing is quiet for the first time since Redoubt Nine. It is waiting for you to say it, and whatever you say, you will have to keep saying.")
	for v in M.views:
		_choice(v.title, v.hint, [], false, func():
			var chips: Array = []
			Game.S.past.view = v.id
			_thought(v.thought, chips)
			Game.vq_push("duty", v.duty, "force")
			Game.vq_push("hat", v.hat, "force")
			_clear()
			_eyebrow("Redoubt Nine")
			_title("You say it")
			_prose(v.said)
			_drain()
			_chips(chips)
			var a = _actions()
			_button("Back to the present", scene, a)
			_stage(a))

# ================================================================ talking

func _who_at(ti: Variant) -> Variant:
	if Bridge.has_js("whoAt"):
		return Bridge.call_js("whoAt", [ti])
	if typeof(ti) == TYPE_STRING:
		for o in Data.T["OBJECTS"].get(Game.cur_id(), []):
			if str(o.id) == ti:
				return { "id": "x_" + str(o.id), "name": o.name, "role": o.get("blurb", "Something here"), "obj": true, "mood": "think", "hue": "0deg" }
		return null
	var ts = Game.talkers()
	return ts[ti] if int(ti) < ts.size() else null

## The node a conversation opens on (for tests and tools).
func conversation_hub(scene_id: String, who: String) -> String:
	var G: Variant = Data.graph(scene_id, who)
	return str(G.hub) if G is Dictionary else "hub"

func talk(ti: int):
	var id = Game.cur_id()
	var t: Dictionary = Game.talkers()[ti]
	if not Data.T["CROWN"].has(t.id) and not Game.S.done.has("mode_" + id):
		return mode_screen(ti)
	var G: Dictionary = Data.graph(id, t.id)
	graph_show(ti, G.hub, {})

func look(oid: String):
	var G: Dictionary = Data.graph(Game.cur_id(), "x_" + oid)
	graph_show(oid, G.hub, {})

func mode_screen(ti: int):
	var id = Game.cur_id()
	var t: Dictionary = Game.talkers()[ti]
	var sc: Dictionary = Game.def(id)
	phase = "other"
	_clear()
	_world("still")
	_eyebrow(sc.title + " · Talking")
	_speaker(t.name, t.role, t.mood, t.get("hue"))
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _box(Color("2a1414"), COL.bad, 1, 4))
	p.add_child(_rtl("This person does not wear the Crown’s cockade. Your orders were to speak to no one who does not."))
	_add(p)
	_prose("You can keep to the letter of it, or you can speak freely. The choice holds for everyone you meet at this stop.")
	_choice("By the book", "Free. Plain answers only.", [], false, func():
		Game.S.done["mode_" + id] = "book"
		graph_show(ti, Data.graph(id, t.id).hub, {}))
	_choice("Off the record", ("No Duty cost for you." if Game.perk("off") else "Duty −1, once per scene.") + " Unlocks the quiet things people only say off the record.", [], false, func():
		var note = go_off(id)
		graph_show(ti, Data.graph(id, t.id).hub, { "note": note }))
	_choice("Back to the scene", "", [], false, scene)

func go_off(id: String) -> String:
	var S = Game.S
	S.done["mode_" + id] = "off"
	S.done["cock_" + id] = true
	var cc2: Array = [] if Game.perk("off") else _fx({ "duty": -1 })
	Game.vq_drop_generic()
	Game.vq_push("duty", Game.pick_line("offd", Data.T["OFF_LINES"]["duty"]), "spec")
	Game.vq_push("hat", Game.pick_line("offh", Data.T["OFF_LINES"]["hat"]), "spec")
	return "You speak off the record, against your orders. " + ("It costs you nothing you can measure. " if Game.perk("off") else ("Duty −1. " if cc2.size() else "Your Duty is already as low as it goes. ")) + "People here may say more."

# The flow of a conversation (which lines show, which options are open, checks and their memory) is the
# dialogue runner's (addons/pt_dialogue, shared with the browser build through dialogue/*.pt). This file
# only draws what the runner gives it, with the game's own widgets.

var dlg: PTDialogueRunner
var dlg_host: PTGameHost
var _dlg_drawn := {}      # the view last drawn, so a view drawn during an action isn't drawn twice

func _dialogue() -> PTDialogueRunner:
	if dlg == null:
		dlg_host = PTGameHost.new(self)
		dlg = PTDialogueRunner.new(Data.dialogue, dlg_host)
	return dlg

## Point the runner at the person (or thing) `ti` in the current place. Returns their talker info, or null.
func _dlg_open(ti: Variant) -> Variant:
	var t: Variant = _who_at(ti)
	if t == null:
		return null
	var who := { "id": str(t.id), "name": str(t.name), "role": str(t.get("role", "")), "mood": t.get("mood", "calm"), "hue": t.get("hue", "") }
	if Data.truthy(t.get("obj")):
		who.obj = true
	if not _dialogue().open(Game.cur_id(), who):
		return null
	return t

func graph_show(ti: Variant, node_id: String, ctx: Dictionary):
	var t: Variant = _dlg_open(ti)
	if t == null or not dlg.G.nodes.has(node_id):
		return scene()
	_dlg_draw(ti, dlg.show(node_id, _dlg_ctx(ctx)))

func _graph_go(ti: Variant, node_id: String, prev: Dictionary):
	var t: Variant = _dlg_open(ti)
	if t == null or not dlg.G.nodes.has(node_id):
		return scene()
	_dlg_draw(ti, dlg.go(node_id, _dlg_ctx(prev)))

## ctx from the browser logic (mkRe, mkGo …): chips and a note pass straight through
func _dlg_ctx(ctx: Dictionary) -> Dictionary:
	var c := {}
	for k in ["chips", "note", "q", "you"]:
		if ctx.get(k) != null and str(ctx.get(k)) != "":
			c[k] = ctx[k]
	return c

func _dlg_choose(ti: Variant, index: int):
	if dlg == null or dlg.view.get("ended", true):
		return
	_dlg_draw(ti, dlg.choose(index))

## Hub topics still unasked, for the talk buttons in a scene.
func _graph_left(id: String, t: Dictionary) -> int:
	return _dialogue().topics_left(id, { "id": str(t.id), "name": str(t.get("name", "")) })

## Draw a view from the runner, the way the browser's graphShow draws one.
func _dlg_draw(ti: Variant, v: Dictionary):
	if v.get("ended", false):
		match str(v.get("reason", "")):
			"leave": scene()
			"action":
				# an action that went somewhere else: a fight, the road … (or, if it asked for nothing, the scene)
				if not _do_pending(false) and phase == "talk":
					scene()
			"missing": scene()
			_: ending(str(v.reason))
		return
	if is_same(v, _dlg_drawn) and phase == "talk":
		return
	_dlg_drawn = v
	var S = Game.S
	var id: String = dlg.scene_id
	var t: Dictionary = dlg.talker
	var obj: bool = v.obj
	var sc: Dictionary = Game.def(id)
	var node_id: String = v.node
	phase = "talk"
	cur_g = { "ti": ti, "node": node_id }
	Data.js.set_global("CURG", { "ti": ti, "nodeId": node_id, "tid": ti if typeof(ti) == TYPE_STRING else t.id })
	Sound.ambience("rain_in" if id in TOWN else "rain_out", 0.15)
	_clear()
	_world("still")
	if node_id == dlg.G.hub and not obj:
		world.focus("person", str(t.id))
	_eyebrow(sc.title + (" · Looking closer" if obj else " · Talking"))
	_speaker(t.name, t.role, v.mood, t.get("hue"), obj)
	for e in v.entries:
		match str(e.t):
			"you": _you(str(e.text))
			"roll": _roll(e.r, e.m)
			"say", "look":
				for line in e.lines:
					_beat(_prose(line, COL.text, obj), line)
			"voice":
				if str(e.get("beat", "")) != "":
					_beat(_prose(e.beat, COL.dim, true), str(e.beat))
				_voice(e.v, e.text, e.get("big", false), true, str(e.get("passive", "")))
			"argue":
				for l in e.lines: _voice(l.v, l.text)
			"beat": _beat(_prose(e.text, COL.dim, true), str(e.text))
			"banter":
				var lines: PackedStringArray = []
				for l in e.lines:
					if str(l.who) != "": lines.append("[b]" + _esc(l.who) + "[/b] " + _esc(l.text))
					else: lines.append("[i][color=#%s]%s[/color][/i]" % [COL.dim.to_html(false), _esc(l.text)])
				_beat(_add(_rtl("\n".join(lines))), "\n".join(lines))
			"html": _html_fragment(str(e.html))
			"thought":
				var th: Dictionary = Data.T["THOUGHTS"][e.id]
				_beat(_rtl("[b]New thought: " + _esc(th.name) + "[/b]\n[i]" + _esc(th.text) + "[/i]", 18, COL.brass), th.name)
			"thought_done":
				_eyebrow("Thought internalized")
				_thought_card(e.id, true)
			"chips": _chips(e.list)
			"note": _hint(str(e.text))
			"temp": _temp_line()
	var box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	_add(box)
	var keep = target
	target = box
	if v.choices.any(func(c): return c.has("check")):
		_dice_bar()
	_prompt(v.prompt.to_upper())
	for c in v.choices:
		var idx: int = c.index
		match str(c.kind):
			"ask":
				_choice(c.text, c.get("hint", ""), [[c.voice, ""]], false, func(): _dlg_choose(ti, idx), "v:" + c.v)
			"no":
				_choice(c.text, "", [[c.voice, ""]], false, func(): _dlg_choose(ti, idx), "v:" + c.v)
			_:
				var tags: Array = []
				if c.has("check"):
					var ck: Dictionary = c.check
					tags.append([("Red · " if ck.kind == "red" else "") + ck.voice + " · " + ck.difficulty + " " + str(ck.dc) + " · " + str(ck.odds) + "%" + (" · retry" if ck.retry else ""), "red" if ck.kind == "red" else ""])
				for tg in c.get("tags", []):
					tags.append([tg, "warn" if tg == "Off the record" else ("go" if tg.begins_with("Thought: ") else "")])
				var ctl: Control = _choice(c.text, str(c.get("hint", "")), tags, not c.enabled, func(): _dlg_choose(ti, idx))
				if c.has("check") and ctl:   # hover: every modifier, as in Disco Elysium
					var ck2: Dictionary = c.check
					ctl.tooltip_text = "%s (%s) · %s %d\nRoll 2d6 %s. You need %d or more.\n%s\n%s" % [ck2.voice, Data.T.SKILLS.get(ck2.skill, ck2.skill), ck2.difficulty, ck2.dc, Game.signed(ck2.tot), ck2.dc, "\n".join(PackedStringArray(ck2.mods)),
						"Red check: one chance." if ck2.kind == "red" else "White check: you can try again when your skill improves or you learn something new."]
	var acts = _actions()
	_button("Back to the scene", scene, acts)
	if not obj and not Data.T["CROWN"].has(t.id) and S.done.get("mode_" + id) == "book":
		_button("Go off the record" + ("" if Game.perk("off") else " (Duty −1)"), func(): graph_show(ti, node_id, { "note": go_off(id) }), acts)
	target = keep
	_stage(box)
	Game.snap("scene")

## Data logic can ask for a screen change (scene, ending, resolve, a fight...); carry it out.
## Returns false when nothing was asked for.
func _do_pending(default_scene: bool) -> bool:
	var p = Game.pending
	Game.pending = []
	if p.is_empty():
		if default_scene:
			scene()
		return false
	match p[0]:
		"scene": scene()
		"road": road([])
		"ending": ending(p[1])
		"resolve": resolve(p[1], p[2], p[3] if p.size() > 3 else {})
	return true

# ================================================================ acting on a scene

## pre: {} for a normal roll, {r, nm} for a thought's second try, or a fight result
## {ok, fled, extra, xp, strip} when a fight stood in for the roll.
func resolve(ch: Dictionary, idx: int, pre: Dictionary = {}):
	var S = Game.S
	var id = Game.cur_id()
	var sc: Dictionary = Game.def(id)
	if ch.get("fight") != null and pre.is_empty():
		Data.call_fn(ch.fight, [ch, idx])
		return
	var forced: bool = pre.has("ok") and not pre.has("r")
	var auto: bool = not forced and ch.get("auto") != null and Data.truthy(Data.call_fn(ch.auto))
	var ok = true
	var r: Dictionary = {}
	var m: Dictionary = {}
	if forced:
		m = Game.modifiers(ch)
		ok = Data.truthy(pre.ok)
		r = { "a": 0, "b": 0, "total": int(m.dc) + 4 if ok else int(m.dc) - 3, "ok": ok, "crit": "" }
	elif not auto:
		m = Game.modifiers(ch)
		r = pre.r if pre.has("r") else Game.roll_dice(m)
		ok = r.ok
		if not ok and pre.is_empty():
			var tu: Variant = Game.thought_retry(str(ch.skill))
			if tu:
				return _thr_gate(ch, idx, m, r, tu)
	var out: Dictionary = ch.ok if ok else ch.bad
	var fx: Variant = Data.g(out, "fx")
	if forced and fx is Dictionary:
		# the fight already cost health and powder; the outcome's own costs for those are dropped
		var strip: Array = pre.get("strip", ["hp", "pw"]) if pre.get("strip") is Array else ["hp", "pw"]
		var kept = {}
		for k in fx:
			if not strip.has(k):
				kept[k] = fx[k]
		fx = kept
	var chips = _fx(fx)
	if pre.get("nm"):
		chips.append(Game.chip("“" + pre.nm + "” spent", "info"))
	if not auto and S.temp.size():
		var labels: PackedStringArray = []
		for x in S.temp:
			labels.append(str(x.label))
		chips.append(Game.chip("Spent: " + ", ".join(labels)))
		S.temp = []
	var xp_gain: int = int(out.get("xp", 0)) + (int(pre.get("xp", 0)) if forced else 0) + (((2 if int(r.total) >= int(m.dc) + 4 else 1) + (1 if Game.perk("xp") else 0)) if not auto and ok else 0)
	if xp_gain:
		chips.append_array(_xp(xp_gain))
	if out.get("again"):
		S.errands = int(S.errands) + 1
	S.out[id] = { "i": idx, "ok": ok }
	if out.get("deliver") == true:
		chips.append(Game.chip("Copy reached the officer", "info"))
	elif out.get("deliver") == false:
		S.copies = max(0, int(S.copies) - 1)
		S.relay[id] = "lost"
		chips.append(Game.chip("Copy not delivered", "down"))
	for g in out.get("give", []):
		if Game.gain(g):
			chips.append(Game.chip(Data.T["ITEMS"][g].kind + ": " + Data.T["ITEMS"][g].name, "info"))
	for g in out.get("take", []):
		if Game.has(g):
			Game.lose(g)
			S.done["gave_" + g] = true
			chips.append(Game.chip("Handed over: " + Data.T["ITEMS"][g].name))
	var af: Variant = ch.get("after")
	if af == null and Data.T["AFTER"].has(id) and idx < Data.T["AFTER"][id].size():
		af = Data.T["AFTER"][id][idx]
	if af is Array and af.size():
		var line: Variant = af[0] if ok else (af[1] if af.size() > 1 and af[1] else af[0])
		if line:
			S.log.append({ "title": sc.title, "text": line })
	var fl: Variant = out.get("flags")
	if fl is Dictionary:
		if fl.get("read"):
			S.read = true; Game.gain("orders"); chips.append(Game.chip("The orders are read", "info"))
		if fl.get("broken"):
			S.sealBroken = true
		if fl.get("sold"):
			S.sold = true; chips.append(Game.chip("A summary of the orders sold", "down"))
	var cv = _choice_voice(id, idx, sc, ch)
	if cv is Dictionary:
		if cv.get("tally"):
			_tally(cv.tally, chips)
		var spec: Array = []
		if cv.get("duty"):
			spec.append(["duty", Game.ok_pick(cv.duty, ok)])
		if cv.get("hat") and Game.has("hat"):
			spec.append(["hat", Game.ok_pick(cv.hat, ok)])
		if spec.size():
			Game.vq_drop_generic()
			for x in spec:
				Game.vq_push(x[0], x[1], "spec")
		elif cv.get("tally"):
			_jsv("tallyVoices", cv.tally)
	Game.ledger_changed.emit()
	phase = "other"
	_clear()
	_world("still")
	_eyebrow(sc.title)
	if forced:
		_title("You won the fight" if ok else ("You got clear" if Data.truthy(pre.get("fled")) else "You were beaten"))
		_html_fragment(str(pre.get("html", "")))
	else:
		_title("You make the call" if auto else ("It holds" if ok else "It goes wrong"))
		if not auto:
			_roll(r, m)
	_prose(Data.gv(out, "text"))
	if forced and pre.get("extra") != null and str(Data.val(pre.extra)) != "":
		_prose(Data.val(pre.extra))
	_chips(chips)
	_drain()
	var a = _actions()
	_button("Continue", func():
		if Game.S.get("practice"):
			return title_screen()
		if out.get("end"):
			return ending(out.end)
		var e = Game.check_end()
		if e != "":
			return ending(e)
		if out.get("again"):
			return scene()
		if out.get("deliver") == true:
			return relay(id, advance)
		advance(), a)
	_stage(a)

func _choice_voice(id: String, idx: int, sc: Dictionary, ch: Dictionary) -> Variant:
	if ch.get("cv"):
		return ch.cv
	var base_choices: Array = sc.get("choices", []) if sc.get("choices") is Array else []
	if idx < base_choices.size():
		var sv: Variant = Data.T["SCENE_VOICE"].get(id)
		var cv: Variant = sv.get("choices")[idx] if sv is Dictionary and sv.get("choices") is Array and idx < sv.choices.size() else null
		if cv == null and Data.T["CHOICE_TALLY"].has(id):
			cv = { "tally": Data.T["CHOICE_TALLY"][id][idx] }
		return cv
	if ch.get("cv"):
		return ch.cv
	return { "tally": ch.get("tally", "merciful") }

func _thr_gate(ch: Dictionary, idx: int, m: Dictionary, r: Dictionary, tu: String):
	var nm: String = Data.T["THOUGHTS"][tu].name
	var sk: String = str(ch.skill)
	_clear()
	_eyebrow(Game.def(Game.cur_id()).title)
	_title("The roll goes against you")
	_roll(r, m)
	_prose("Then a thought you have carried long enough to own turns over: “" + nm + ".” You can try this once more, and the thought’s second try will be spent for good.")
	var a = _actions()
	_button("Try again · " + nm, func():
		Game.S.done["thr_" + tu] = true
		Game.S.done["thrsk_" + sk] = true
		resolve(ch, idx, { "r": Game.roll_dice(m), "nm": nm }), a)
	_button("Take the failure", func(): resolve(ch, idx, { "r": r }), a)

func _cont(c: Variant):
	if c is Callable:
		c.call()
	elif c != null:
		Data.call_fn(c)

func relay(id: String, cont: Variant):
	var S = Game.S
	if S.relay.has(id):
		return _cont(cont)
	var o: Variant = Data.T["OFF"].get(id)
	if not (o is Array):
		return _cont(cont)
	var know = "You have read what the paper says. You know what it will cost the people along the river." if S.read else "You do not know exactly what the paper says. You know only that it is meant for the men with maps, and not for the people on the road."
	var sc: Dictionary = Game.def(id)
	phase = "other"
	_clear()
	_eyebrow(sc.title)
	_speaker("The hand held out", "", "think" if S.read else "doubt", { "ford": "0deg", "oak": "0deg", "ridge": "200deg" }.get(id, "0deg"))
	_prose(o[0] + " holds out a hand for the cipher, " + o[1] + ". " + know + "\n\nYou can still decide how much of it to give.")
	var opts = [["Hand it over, complete", "Duty +1. The orders arrive as written."],
		["Hand over the requisitions, hold back the column coordinates", "Valley trust +1. The officer gets supplies and no map of the retreat."],
		["Say the copy was lost", "Duty −1, +1 hour. Nothing is delivered. Someone may ask questions."]]
	for i in 3:
		_choice(opts[i][0], opts[i][1], [], false, func(): _relay_pick(id, i, cont))

func _relay_pick(id: String, i: int, cont: Variant):
	var S = Game.S
	var chips: Array
	var text: String
	var sc: Dictionary = Game.def(id)
	if i < 2:
		if i == 0:
			S.full = int(S.full) + 1; S.relay[id] = "full"
		else:
			S.partial = int(S.partial) + 1; S.relay[id] = "partial"
		S.copies = max(0, int(S.copies) - 1)
		if not S.delivered.has(id):
			S.delivered.append(id)
		chips = _fx({ "duty": 1 } if i == 0 else { "trust": 1 })
		chips.append_array(_xp(3))
		text = "The paper changes hands and is read quickly. Whatever it says, it is out of your hand and into the machine’s, and the weight on your ribs is lighter." if i == 0 else "He thumbs the requisitions, frowns at the missing leaf, and decides not to ask. The columns will march without a full map of where they are going. You tell yourself that is not the same as lying."
	else:
		S.withheld = int(S.withheld) + 1; S.relay[id] = "withheld"
		chips = _fx({ "duty": -1, "hrs": 1 })
		text = "You say the copy went into the river. He looks at you for a long moment and you hold his eyes. “Pity,” he says at last. The case is still on your chest, cold against your ribs."
	var ar: Variant = Data.T["AFTER_RELAY"].get(id)
	if ar is Array and i < ar.size() and ar[i]:
		S.log.append({ "title": sc.title, "text": ar[i] })
	_tally("loyal" if i == 0 else "merciful", chips)
	var rv: Array = Data.T["RELAY_V"]["full" if i == 0 else ("partial" if i == 1 else "withheld")]
	Game.vq_drop_generic()
	Game.vq_push("duty", rv[0], "spec")
	Game.vq_push("hat", rv[1], "spec")
	_jsv("compEvent", "relay_" + ["full", "partial", "withheld"][i])
	Game.ledger_changed.emit()
	_clear()
	_eyebrow(sc.title)
	_title(["Handed over", "Half the truth", "Kept back"][i])
	_prose(text)
	_chips(chips)
	_drain()
	var a = _actions()
	_button("Continue", func():
		var e = Game.check_end()
		if e != "":
			return ending(e)
		_cont(cont), a)
	_stage(a)

func advance():
	if Bridge.has_js("advanceNow"):
		Bridge.call_js("advanceNow")
		return
	var S = Game.S
	S.temp = []
	_jsv("mullTick")
	var big = Game.is_main(Game.cur_id())
	S.idx = int(S.idx) + 1
	if int(S.idx) >= S.route.size():
		return ending("depot")
	march(big)

func march(big: bool):
	if Bridge.has_js("march"):
		Bridge.call_js("march", [big])
		return
	var S = Game.S
	var chips: Array = []
	if big:
		var cost: int = (2 if Game.has("map") else 3) - (1 if int(S.done.get("weir_short", 0)) > 0 else 0) - (2 if Game.is_done("vh_guide") else 0) - (1 if Game.vperk("march_hr") else 0)
		if int(S.done.get("weir_short", 0)) > 0:
			S.done.weir_short = int(S.done.weir_short) - 1
		S.done.vh_guide = false
		cost = max(1, cost)
		S.hrs = int(S.hrs) + cost
		chips.append(Game.chip("Hours +" + str(cost) + (" (trail map)" if Game.has("map") else ""), "down"))
		if int(S.ra) > 0:
			S.ra = int(S.ra) - 1; chips.append(Game.chip("Rations -1", "down"))
		else:
			S.st = int(S.st) - 2; Game.clamp_k("st"); chips.append(Game.chip("Stamina -2 (no food)", "down"))
		if int(S.notice) > 0:
			S.notice = int(S.notice) - 1; chips.append(Game.chip("Notice −1: the valley forgets a little", "up"))
		if Game.vperk("march_notice") and int(S.notice) > 0:
			S.notice = int(S.notice) - 1; chips.append(Game.chip("Notice −1: you kept low", "up"))
		if Game.perk("march"):
			chips.append(Game.chip("The march sits easier on you", "up"))
		else:
			S.st = int(S.st) - 1; Game.clamp_k("st"); chips.append(Game.chip("Stamina -1 (the march)", "down"))
	else:
		S.hrs = int(S.hrs) + 1
		chips.append(Game.chip("Hours +1", "down"))
	Game.ledger_changed.emit()
	var e = Game.check_end()
	if e != "":
		return ending(e)
	Sound.play("leg", 0.4)
	road(chips)

func _flavor_line() -> String:
	var T: Dictionary = Data.T
	var pool: Array = T["FLAVOR"] + T["FLAVOR_MORE"]
	if int(Game.S.hp) <= 6:
		pool += T["FLAVOR_PAIN"] + T["FLAVOR_PAIN"]
	if int(Game.S.st) <= 4:
		pool += T["FLAVOR_TIRED"] + T["FLAVOR_TIRED"]
	return pool[Game.rng.randi_range(0, pool.size() - 1)]

func road(chips: Array):
	var S = Game.S
	phase = "road"
	Sound.music("")
	Sound.ambience("rain_out", 0.35)
	var id = Game.cur_id()
	var sc: Variant = Game.def(id)
	_clear()
	_eyebrow(("The road to " + sc.title) if Game.is_main(id) else "Further along the road")
	_title("Between stops")
	_prose(_flavor_line())
	for i in range(int(S.idx), S.route.size()):
		if S.route[i] == "oak":
			_hint("Next stop: Oakhaven")
			break
		if Game.is_main(S.route[i]):
			break
	if Bridge.has_js("errandNote"):
		_html_fragment(str(Bridge.call_js("errandNote")))
	_chips(chips)
	_drain()
	var rv = Game.road_voice()
	if rv.size():
		_voice(rv[0], rv[1])
	if Bridge.has_js("compRoad"):
		_html_fragment(str(Bridge.call_js("compRoad")))
	_prompt("BEFORE YOU GO ON")
	var hard: bool = S.get("hard", false)
	var heal: int = (0 if hard else 1) + (1 if Game.perk("rest") else 0)
	var a = _actions()
	_button("Rest 3 hours (+%d stamina, +%d health)" % [2 if hard else 3, heal], func():
		S.hrs = int(S.hrs) + 3; S.st = int(S.st) + (2 if hard else 3); S.hp = int(S.hp) + heal
		_after_road_act(), a)
	_button("Eat a ration (+%d stamina)" % ((1 if hard else 2) + (1 if Game.perk("eat") else 0)), func():
		S.ra = int(S.ra) - 1; S.st = int(S.st) + (1 if hard else 2) + (1 if Game.perk("eat") else 0)
		_after_road_act(), a, int(S.ra) <= 0)
	_button("Dry the lock and powder (1 hour)", func():
		S.hrs = int(S.hrs) + 1; S.wet = false
		_after_road_act(), a, not S.wet)
	_button("Reread the orders" if S.read else ("Try the cipher again" if S.sealBroken else "Read the seal"), read_seal, a)
	if Bridge.has_js("ptCpBackOk") and Data.truthy(Bridge.call_js("ptCpBackOk")):
		_button("Turn back for Oakhaven, over Tanner’s Bridge (2 hours, Lisle may remember you)", func(): Bridge.call_js("ptCpBack"), a)
	if Bridge.has_js("backTargets"):
		var bt: Variant = Bridge.call_js("backTargets")
		_button("Go back to a place you have visited" if bt is Array and bt.size() else "Go back (nowhere behind you yet)", func(): Bridge.call_js("backMenu"), a, not (bt is Array and bt.size()))
	if Bridge.has_js("roadExtraBtns"):
		# the browser's buttons: data-a="valley", "dlog", horses, letters to read...
		var extra := Html.parse(str(Bridge.call_js("roadExtraBtns")))
		for b in Html.query(extra, "[data-a]"):
			var act := str(b.attrs["data-a"])
			_button(_el_text(b), func(): Bridge.call_js("roadExtraAct", [act]), a, b.attrs.has("disabled"))
	_choice("Go on", "", [], false, scene)
	Game.snap("road")

func _after_road_act():
	Game.clamp_k("st")
	Game.clamp_k("hp")
	Game.ledger_changed.emit()
	var e = Game.check_end()
	if e != "":
		return ending(e)
	road([])

func read_seal():
	Sound.play("lock", 0.45)
	var S = Game.S
	close_modal()
	if S.read:
		return show_orders()
	var m = Game.modifiers({ "skill": "wits", "dc": 9, "v": "cipher" })
	if Game.vperk("seal"):
		m.tot = int(m.tot) + 2
		m.list.append("Clerk’s eye +2")
	var broken: bool = S.sealBroken
	phase = "other"
	_clear()
	_eyebrow("The tin case")
	_title("Read the seal?")
	_prose(("The wax is already cracked, but the cipher is still a knot of figures and grouped letters. " if broken else "You would have to break the crimson wax. It cannot be mended, and any provost who sees the case will know. ") + "You would have to work the cipher line by line, which takes a steady head and about an hour. If you start, you roll and take what comes. You can still put it back.")
	_hint("Wits · %s %d · %d%%  —  %s" % [Game.diff_name(int(m.dc)), m.dc, Game.odds(m), " · ".join(PackedStringArray(m.list))])
	var SV: Dictionary = Data.T["SEAL_V"]
	if broken:
		if Game.voice_on("cipher", null) and SV.get("again"):
			_voice("cipher", SV.again)
	else:
		if not Game.muted_by("duty") and SV.get("duty"):
			_voice("duty", SV.duty)
		if Game.has("hat") and not Game.muted_by("hat") and SV.get("hat"):
			_voice("hat", SV.hat)
		if Game.voice_val("cipher") >= 2 and SV.get("cipher"):
			_voice("cipher", SV.cipher)
	var a = _actions()
	_button("Work the cipher" if broken else "Break the seal and read", func():
		var r = Game.roll_dice(m)
		S.sealBroken = true
		var chips: Array = []
		if not Game.vperk("seal"):
			S.hrs = int(S.hrs) + 1
			chips.append(Game.chip("Hours +1", "down"))
		if not broken:
			chips.append(Game.chip("Seal broken", "down"))
		if r.ok:
			S.read = true
			Game.gain("orders")
			chips.append(Game.chip("The orders are read", "info"))
			Game.vq_push("duty", SV.get("readDuty"))
			Game.vq_push("hat", SV.get("readHat"))
		Game.ledger_changed.emit()
		_clear()
		_eyebrow("The tin case")
		_title("The cipher gives way" if r.ok else "The figures swim")
		_roll(r, m)
		_prose("The groups fall into order one at a time, the way a drill does when you stop thinking about it. When you reach the last line you sit still for a while." if r.ok else "You work the groups until the candle gutters and the figures stop meaning anything. The wax is broken and you know nothing more than when you started. You can try again with a clearer head.")
		if r.ok:
			_doc(Data.T["ORDERS_TEXT"])
		_chips(chips)
		_drain()
		var a2 = _actions()
		_button("Back to the road", func():
			var e = Game.check_end()
			if e != "":
				return ending(e)
			road([]), a2)
		_stage(a2), a)
	_button("Back out", func(): road([]), a)
	_stage(a)

func _doc(text: String):
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", _box(Color("d9cba8"), Color("8a7650"), 1, 2, Vector4(20, 16, 20, 16)))
	p.add_child(_rtl("[font=res://assets/fonts/LiberationMono-Regular.ttf]" + _esc(text) + "[/font]", 15, Color("2b2416")))
	_add(p)

func show_orders():
	_clear()
	_eyebrow("The tin case")
	_title("The orders, as you decoded them")
	_doc(Data.T["ORDERS_TEXT"])
	_button("Back to the road", func(): road([]))

# ================================================================ endings

var last_ending := ""

func ending(kind: String):
	var S = Game.S
	last_ending = kind
	phase = "other"
	Sound.music("")
	var E: Variant = Data.T["ENDINGS"].get(kind)
	if not (E is Dictionary):
		E = { "title": "The road ends", "text": "" }
	if kind == "depot" or kind == "truth":
		if not S.delivered.has("malice"):
			S.delivered.append("malice")
	var tag: String = { "depot": "Duty done", "truth": "Duty reconsidered", "ashes": "Duty abandoned", "sold": "Duty sold", "arrest": "Duty questioned", "death": "The road wins", "late": "The war moves on", "gate": "Duty given away" }.get(kind, "")
	var tail: PackedStringArray = []
	if int(S.duty) >= 2: tail.append("You did what the Crown asked of you at nearly every door, and you wonder if anyone will ever ask the road what it thinks of that.")
	if int(S.duty) <= -2: tail.append("You carried the case, but you gave the Crown very little of yourself along the way, and everyone you met could tell.")
	if int(S.partial) > 0: tail.append("Not every officer got all of what you carried. Some of the people on the road may owe their lives to your hesitation, and some officers will hold it against you.")
	if int(S.withheld) > 0: tail.append("At least one copy never reached the hand waiting for it. Whether that was mercy or mutiny depends on who writes the report.")
	if S.sold and kind != "sold": tail.append("A strongbox at Marrow Cross holds a summary of the orders. You do not know whose hands it will reach.")
	if int(S.trust) >= 2: tail.append("In the valley, people will say a courier once stood with them.")
	elif int(S.trust) <= -2: tail.append("In the valley, the courier’s name is not spoken kindly.")
	if Bridge.has_js("endTailMore"):
		var more: Variant = Bridge.call_js("endTailMore", [kind])
		if more is Array:
			for x in more: tail.append(str(x))
	var legacy: Variant = Bridge.call_js("legacyOf", [kind]) if Bridge.has_js("legacyOf") else null
	if legacy is Dictionary:
		_save_legacy(legacy)
	if kind == "death":
		Game.vq_push("mud", "There. Down at last. I kept a place for you, all this way.", "force")
	elif Data.T["END_V"].has(kind):
		Game.vq_push("duty", Data.T["END_V"][kind][0])
		Game.vq_push("hat", Data.T["END_V"][kind][1])
	_clear()
	_eyebrow(tag)
	_title(str(E.title), true)
	_prose(str(Data.val(E.text)) + ("\n\n" + " ".join(tail) if tail.size() else ""))
	_drain()
	if Bridge.has_js("compEnd"):
		_html_fragment(str(Bridge.call_js("compEnd", [kind])))
	if legacy is Dictionary and Bridge.has_js("crownFileHtml"):
		_html_fragment(str(Bridge.call_js("crownFileHtml", [legacy])))
		_prompt("MALICE GAOL")
		_prose("Somewhere under Fort Malice, a cipher clerk is about to be blamed for what was in your case. Your courier’s record is saved for Malice Gaol. To carry this road into Malice Gaol in the browser, copy the code below and paste it on Malice Gaol’s title screen.")
		var code := TextEdit.new()
		code.text = legacy_code
		code.editable = false
		code.custom_minimum_size = Vector2(0, 70)
		code.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
		_add(code)
		var la = _actions()
		_button("Copy the courier record", func(): DisplayServer.clipboard_set(legacy_code), la)
	var c = Game.courier_type()
	_prompt("WHAT KIND OF COURIER YOU WERE")
	_add(_rtl("[b]" + _esc(c[0]) + "[/b]\n" + _esc(c[1])))
	_prompt("WHAT HAPPENED AT THE GUN")
	_prose(Game.past_end())
	if S.log.size():
		_prompt("WHAT YOU LEFT BEHIND")
		for e in S.log:
			_add(_rtl("[b]" + _esc(e.title) + "[/b]  " + _esc(e.text), 17))
	var rows = [["Copies delivered", "%d of 4" % S.delivered.size()],
		["Handed over in full / in part / kept back", "%d / %d / %d" % [S.full, S.partial, S.withheld]],
		["Hours on the road", "%d of %d" % [min(int(S.hrs), 99), Game.dline()]],
		["Duty to the Crown", Game.signed(S.duty)], ["Valley trust", Game.signed(S.trust)], ["Coin", str(S.coin)],
		["Level reached / optional errands done", "%d / %d" % [S.level, S.errands]], ["Seal", "Broken" if S.sealBroken else "Intact"]]
	if S.get("hard", false):
		rows.push_front(["Difficulty", "Hardcore"])
	var grid = GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 30)
	for r in rows:
		var l1 = Label.new(); l1.text = r[0]; l1.add_theme_color_override("font_color", COL.dim)
		var l2 = Label.new(); l2.text = r[1]
		grid.add_child(l1); grid.add_child(l2)
	_add(grid)
	var a = _actions()
	_button("Walk the road again", func(): cc = {}; title_screen(), a)
	_stage(a)

# ================================================================ panels (modal)

var legacy_code := ""
## The courier's record: user://legacy.json, the same record the browser keeps for Malice Gaol, and a
## code in the browser's format (PTL1: then base64 of the JSON) to paste into Malice Gaol.
func _save_legacy(L: Dictionary) -> void:
	var txt := JSON.stringify(_plain(L))
	var f := FileAccess.open("user://legacy.json", FileAccess.WRITE)
	if f:
		f.store_string(txt)
		f.close()
	legacy_code = "PTL1:" + Marshalls.utf8_to_base64(txt)

func _plain(v: Variant) -> Variant:
	if v is Dictionary:
		var o := {}
		for k in v:
			o[str(k)] = _plain(v[k])
		return o
	if v is Array:
		return v.map(func(x): return _plain(x))
	if v is float and v == floor(v) and abs(v) < 1e15:
		return int(v)
	return v

func _open_modal():
	modal_tag = ""
	for c in mpage.get_children():
		c.queue_free()
	target = mpage
	modal.visible = true
	mscroll.scroll_vertical = 0

func close_modal():
	modal.visible = false
	target = page
	if modal_tag == "dice":
		# the odds on the checks change with the dice in hand
		modal_tag = ""
		_rerender()

func _modal_close_row():
	var a = _actions()
	_button("Close", close_modal, a)

## Redraw whatever screen is under the panel after something in the panel changed.
func _rerender():
	var was_modal = modal.visible
	var keep = target
	target = page
	if phase == "scene":
		scene()
	elif phase == "talk" and not cur_g.is_empty():
		graph_show(cur_g.ti, cur_g.node, {})
	elif phase == "road":
		road([])
	target = mpage if was_modal else keep

func open_char():
	if phase == "title":
		return
	var S = Game.S
	var T: Dictionary = Data.T
	_open_modal()
	modal_tag = "char"
	_eyebrow("Character")
	_title("The courier")
	_hint("Level %d · XP %d of %d · %d skill point%s to spend" % [S.level, S.xp, T.XP_PER_POINT, S.points, "" if int(S.points) == 1 else "s"])
	for sk in T.SKILLS:
		var parts = Game.skill_parts(sk)
		var base = Game.skill_bonus(sk)
		var pb: PackedStringArray = []
		for p in parts:
			pb.append(str(p[0]) + " " + Game.signed(p[1]))
		var cap = Game.v_cap(sk)
		var head = HBoxContainer.new()
		head.add_child(_rtl("[b][color=#%s]%s %s[/color][/b]  [font_size=15][color=#%s]%s[/color][/font_size]\n[font_size=15][i]%s[/i][/font_size]" % [
			NAME_COL[sk].to_html(false), T.SKILL_INFO[sk][0].to_upper(), Game.signed(base), COL.dim.to_html(false), _esc(" · ".join(pb)), _esc(T.SKILL_INFO[sk][1])], 20))
		_add(head)
		var caprow = _actions()
		var cl = Label.new()
		cl.text = "Training cap %d" % cap
		cl.add_theme_color_override("font_color", COL.dim)
		caprow.add_child(cl)
		_button("Raise the cap to %d" % (cap + 1), func(): Game.train("cap:" + sk); open_char(); _rerender(), caprow, int(S.points) <= 0)
		for v in T.V_OF[sk]:
			var r = Game.v_rank(v)
			var pips = ""
			for q in max(cap, r):
				pips += "●" if q < r else "○"
			var perks: PackedStringArray = []
			var vp: Array = T.VPERK[v]
			for q in vp.size():
				var on = r > q
				perks.append("[color=#%s]%d. [b]%s[/b] %s[/color]" % [(COL.good if on else COL.dim).to_html(false), q + 1, _esc(vp[q][0]), _esc(vp[q][1])])
			var p = PanelContainer.new()
			var sb = _box(COL.panel, _voice_color(v), 0, 2, Vector4(14, 8, 12, 8))
			sb.border_width_left = 3
			p.add_theme_stylebox_override("panel", sb)
			var vb = VBoxContainer.new()
			var row = HBoxContainer.new()
			row.add_child(_rtl("[b]%s[/b]  %s  [color=#%s]%s[/color]\n[font_size=15][i]%s[/i][/font_size]" % [_esc(T.VOICES[v].name), Game.signed(Game.v_val(v)), COL.brass.to_html(false), pips, _esc(T.VOICES[v].info)], 18))
			var b = Button.new()
			b.text = "At the cap" if r >= cap else "Train +1"
			b.disabled = int(S.points) <= 0 or r >= cap
			b.pressed.connect(func(): Game.train("v:" + v); open_char(); _rerender())
			row.add_child(b)
			vb.add_child(row)
			vb.add_child(_rtl("[font_size=14]" + "\n".join(perks) + "[/font_size]", 14))
			p.add_child(vb)
			_add(p)
	_prompt("OTHER VOICES IN YOUR HEAD")
	for v in T.VOICES:
		if T.VOICES[v].get("sk"):
			continue
		if v == "hat" and not Game.has("hat") and not Game.is_done("hat_met"):
			continue
		_add(_rtl("[b]%s[/b]  [i]%s[/i]" % [_esc(Game.voice_head(v)), _esc(T.VOICES[v].info)], 16))
	_modal_close_row()

func open_thoughts():
	if phase == "title":
		return
	var S = Game.S
	_open_modal()
	modal_tag = "tin"
	_eyebrow("Tin Thoughts")
	_title("What you are turning over")
	_hint("A new thought sits loose until you pin it in a pigeonhole. A pinned thought is mulled for a few stops: its cost applies at once, its benefit and conclusion only once it sinks in.")
	if S.get("caseNote"):
		_hint(S.caseNote)
		S.caseNote = ""
	var n = Game.case_slots()
	for i in max(n, S.thoughts.size()):
		if i >= S.thoughts.size():
			_add(_rtl("[i]Pigeonhole %d · empty[/i]" % (i + 1), 16, COL.dim))
			continue
		var tid: String = S.thoughts[i]
		var mulling: bool = int(S.mull.get(tid, 0)) > 0
		_thought_card(tid, not mulling, func(v: VBoxContainer, m: int):
			v.add_child(_rtl("[i]" + ("Mulling: %d more stop%s. Only the cost applies so far." % [m, "s" if m > 1 else ""] if mulling else "Internalized.") + "[/i]", 15, COL.dim))
			var b = Button.new()
			b.text = "Set aside"
			b.pressed.connect(func(): Game.unpin_thought(tid); open_thoughts(); _rerender())
			v.add_child(b))
	if n < int(Data.T.MAX_HOLES):
		var a = _actions()
		_button("Cut a new pigeonhole (1 skill point)", func(): Game.cut_hole(); open_thoughts(), a, int(S.points) <= 0)
	_prompt("LOOSE PAPERS")
	if S.loose.is_empty():
		_hint("Nothing loose. Thoughts come from conversations that stay with you, from habits you keep, and from what the ringing brings back.")
	for tid in S.loose.duplicate():
		var d = int(Data.T.THOUGHTS[tid].get("mull", 2))
		_thought_card(tid, false, func(v: VBoxContainer, _m: int):
			if Game.case_free():
				var b = Button.new()
				b.text = "Pin it (%d stops to sink in)" % d
				b.pressed.connect(func(): Game.pin_thought(tid); open_thoughts(); _rerender())
				v.add_child(b)
			else:
				v.add_child(_rtl("[i]No empty pigeonhole. Set a pinned thought aside or cut a new pigeonhole first.[/i]", 15, COL.dim)))
	_modal_close_row()

func open_satchel(sel: String = ""):
	if phase == "title":
		return
	var S = Game.S
	var IT: Dictionary = Data.T.ITEMS
	_open_modal()
	modal_tag = "bag"
	_eyebrow("Satchel")
	_title("What you carry")
	for id in S.inv:
		if not IT.has(id):
			continue
		var it: Dictionary = IT[id]
		var worn = Data.truthy(S.worn.get(id))
		_choice(it.name + ("  (worn)" if worn else ""), str(Data.gv(it, "short")), [[it.kind, ""]], false, func(): open_item(id))
	_modal_close_row()

func open_item(id: String):
	var S = Game.S
	var it: Dictionary = Data.T.ITEMS[id]
	_open_modal()
	_eyebrow(it.kind)
	_title(it.name)
	var body = str(Data.gv(it, "body"))
	if it.kind == "Parcel":
		_prose(body)
	else:
		_doc(body)
	_drain()
	var a = _actions()
	if id == "case":
		_button("Reread the orders" if S.read else ("Try the cipher again" if S.sealBroken else "Read the seal"), read_seal, a, phase != "road")
	if it.get("equip"):
		_button((it.get("offLabel", "Take it off")) if S.worn.get(id) else it.get("wearLabel", "Wear it (Nerve +2, Wits −2)"), func():
			Game.toggle_wear(id); open_item(id); _rerender(), a)
	if it.get("use"):
		_button(str(it.use.get("label", "Use it")), func():
			var chips = Game.use_item(id)
			var e = Game.check_end()
			if e != "":
				close_modal(); return ending(e)
			_open_modal(); _eyebrow("Satchel"); _chips(chips)
			var a2 = _actions()
			_button("Back to satchel", func(): open_satchel(), a2)
			_button("Close", close_modal, a2)
			_rerender(), a)
	_button("Back to satchel", func(): open_satchel(), a)
	_button("Close", close_modal, a)

## Living dice: the "Dice in hand" button above choices that roll.
func _dice_bar() -> void:
	var ld: Variant = Game.S.get("ld")
	if not LivingDice.is_on(ld):
		return
	var h: Array = LivingDice.hand(ld)
	var a = _actions()
	_button("Dice in hand: %s [%s] · %s [%s]" % [h[0].name, _faces(h[0]), h[1].name, _faces(h[1])], open_dice, a)

func _faces(d: Dictionary) -> String:
	return " ".join(PackedStringArray(d.f.map(func(x): return str(int(x)))))

## The dice panel: each die as an unfolded cube (top 0; left 1, front 2, right 4, back 3; bottom 5).
func open_dice() -> void:
	var S = Game.S
	if not LivingDice.is_on(S.get("ld")):
		return
	var ld: Dictionary = S.ld
	_open_modal()
	modal_tag = "dice"
	_eyebrow("Living dice")
	_title("Dice in hand")
	var rules: PackedStringArray = []
	if ld.get("snow", false): rules.append("Snowball: higher faces land more often")
	if ld.get("lock", false): rules.append("Lock: pick a face to hold its pair still")
	if ld.get("blank", false): rules.append("Hard mode: blank dice")
	_hint("The face that lands gains a pip and the face across from it loses one." + ((" " + ". ".join(rules) + ".") if rules.size() else ""))
	var h: Array = ld.hand
	for di in ld.dice.size():
		var d: Dictionary = ld.dice[di]
		var held = "  (left hand)" if int(h[0]) == di else ("  (right hand)" if int(h[1]) == di else "")
		_add(_rtl("[b]%s[/b]%s  [color=#%s]thrown %d times[/color]\n[font_size=15][i]%s[/i][/font_size]" % [_esc(d.name), held, COL.dim.to_html(false), int(d.get("n", 0)), _esc(str(d.get("note", "")))], 18))
		var grid = GridContainer.new()
		grid.columns = 4
		grid.add_theme_constant_override("h_separation", 4)
		grid.add_theme_constant_override("v_separation", 4)
		var layout = [-1, 0, -1, -1, 1, 2, 4, 3, -1, 5, -1, -1]
		for fi in layout:
			if fi < 0:
				var sp = Control.new()
				sp.custom_minimum_size = Vector2(44, 34)
				grid.add_child(sp)
				continue
			var locked = d.k != "hang" and int(d.lock) == LivingDice.pair_of(fi)
			var b = _button(str(int(d.f[fi])) + (" •" if locked else ""), func():
				LivingDice.toggle_lock(d, fi)
				open_dice(), grid, not ld.get("lock", false) or d.k == "hang")
			b.custom_minimum_size = Vector2(44, 34)
			if locked:
				b.modulate = Color("ffe28a")
		_add(grid)
		if ld.dice.size() > 2:
			var ah = _actions()
			_button("Hold in left hand", func(): LivingDice.hold(ld, 0, di); open_dice(), ah, int(h[0]) == di)
			_button("Hold in right hand", func(): LivingDice.hold(ld, 1, di); open_dice(), ah, int(h[1]) == di)
	if dev:
		_prompt("DEV")
		var ad = _actions()
		_button("Add The Blank", func(): LivingDice.dev_add(ld, "blank"); open_dice(), ad)
		_button("Add the Hangman's Die", func(): LivingDice.dev_add(ld, "hang"); open_dice(), ad)
		_button("Reset every face", func(): LivingDice.dev_add(ld, "reset"); open_dice(), ad)
	var a = _actions()
	_button("Close", close_modal, a)

func open_journal():
	if phase == "title":
		return
	var S = Game.S
	_open_modal()
	modal_tag = "log"
	_eyebrow("Journal")
	_title("What you have learned")
	if S.learned.is_empty():
		_hint("You have not learned anything yet. Talk to people before you act.")
	var where = ""
	for l in S.learned:
		if l.where != where:
			where = l.where
			_prompt(str(where).to_upper())
		_add(_rtl("[b]" + _esc(l.from) + "[/b]: " + _esc(l.text), 17))
	_prompt("THE ROAD SO FAR")
	var names: PackedStringArray = []
	for i in min(int(S.seen), S.route.size()):
		names.append(str(Game.def(S.route[i]).title))
	_add(_rtl(_esc(" → ".join(names)) if names.size() else "[i]Not yet on the road.[/i]", 16))
	if S.log.size():
		_prompt("WHAT YOU LEFT BEHIND")
		for e in S.log:
			_add(_rtl("[b]" + _esc(e.title) + "[/b]  " + _esc(e.text), 16))
	_modal_close_row()

func open_menu():
	_open_modal()
	_eyebrow("Menu")
	_title("The Postal Trace")
	if phase != "title" and phase != "fight" and phase != "page":
		_prompt("SAVE")
		for i in range(1, Game.SAVE_SLOTS + 1):
			var d: Variant = Game.read_slot(i)
			_choice("Slot %d" % i, _slot_label(d) if d is Dictionary else "Empty", [], false, func():
				Game.save_slot(i)
				open_menu())
		_save_extras()
	_prompt("LOAD")
	_load_list()
	_load_extras()
	_sync_section()
	_prompt("3D PLACES")
	var a3 = _actions()
	_button("3D places: " + ("on" if three_d else "off"), func():
		three_d = not three_d
		close_modal()
		if not three_d:
			_world_off()
		elif phase == "scene":
			scene(), a3)
	_display_settings()
	_prompt("DEV MODE")
	_hint("Shows the temporary stat changes of each dialogue option before you choose it and the full modifier breakdown on every check, and gives you the place editor (Edit place, over the 3D view).")
	var ad = _actions()
	_button("Dev Mode: " + ("on" if dev else "off"), func():
		set_dev(not dev)
		open_menu(), ad)
	_prompt("SOUND")
	for k in ["master", "sfx", "amb", "music"]:
		var row = HBoxContainer.new()
		var l = Label.new()
		l.text = { "master": "Master", "sfx": "Effects and voices", "amb": "Rain and ambience", "music": "Music" }[k]
		l.custom_minimum_size = Vector2(130 if _narrow() else 220, 0)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(l)
		var s = HSlider.new()
		s.min_value = 0
		s.max_value = 1
		s.step = 0.05
		s.value = Sound.volume[k]
		s.custom_minimum_size = Vector2(170 if _narrow() else 260, 32 if big_buttons else 24)
		s.value_changed.connect(func(v): Sound.volume[k] = v)
		row.add_child(s)
		_add(row)
	var a = _actions()
	if phase != "title":
		_button("Quit to title", func(): close_modal(); title_screen(), a)
	_button("Close", close_modal, a)

const DEV_CFG := "user://settings.cfg"

# ---------------------------------------------------------------- text, colours, buttons

func _load_display() -> void:
	if COL0.is_empty():
		COL0 = COL.duplicate()
	var c = ConfigFile.new()
	c.load(DEV_CFG)
	layout_pref = str(c.get_value("display", "layout", "auto"))
	hh = layout_pref == "handheld" or (layout_pref == "auto" and handheld_device())
	world_shrink = 2 if hh else WORLD_SHRINK
	detail = str(c.get_value("display", "detail", "light" if hh else "full"))
	Engine.max_fps = 30 if detail == "light" else 0
	text_scale = float(c.get_value("display", "text", 0.9 if hh else 1.0))
	palette = str(c.get_value("display", "palette", "parchment"))
	big_pref = str(c.get_value("display", "buttons", "auto"))
	big_buttons = big_pref == "on" or (big_pref == "auto" and touch_device())
	COL = COL0.duplicate()
	for k in PALETTES.get(palette, {}):
		COL[k] = PALETTES[palette][k]

func _display_set(key: String, value: Variant) -> void:
	var c = ConfigFile.new()
	c.load(DEV_CFG)
	c.set_value("display", key, value)
	c.save(DEV_CFG)
	_load_display()
	_fit_window()
	if vring:
		vring.show_button = str(c.get_value("display", "voice_button", "auto"))
		vring._refresh()
	# put the new look on everything at once: the frame is built again and this screen drawn again
	_rebuild_frame()

func _rebuild_frame() -> void:
	var keep_phase = phase
	for ch in get_children():
		if ch == pad:
			continue
		remove_child(ch)
		ch.queue_free()
	world = null
	pad.set_mode("panel")
	_build_frame()
	_render_ledger()
	match keep_phase:
		"title": title_screen()
		"scene": scene()
		"road": road([])
		_:
			if Game.S.get("route", []).size():
				scene()
			else:
				title_screen()
	open_menu()

func _seg(label: String, opts: Array, cur: Variant, cb: Callable) -> void:
	var row = HFlowContainer.new()
	row.add_theme_constant_override("h_separation", 6)
	row.add_theme_constant_override("v_separation", 6)
	var l = Label.new()
	l.text = label
	l.custom_minimum_size = Vector2(110 if _narrow() else 150, 0)
	row.add_child(l)
	for o in opts:
		var b = _button(str(o[1]), func(): cb.call(o[0]), row)
		if str(o[0]) == str(cur):
			b.modulate = Color("ffe28a")
	_add(row)

func _display_settings() -> void:
	_prompt("TEXT AND BUTTONS")
	_seg("Text size", [[0.9, "Small"], [1.0, "Normal"], [1.15, "Large"], [1.3, "Larger"]], text_scale, func(v): _display_set("text", v))
	_seg("Colours", [["parchment", "Usual"], ["contrast", "High contrast"], ["soft", "Soft"]], palette, func(v): _display_set("palette", v))
	_seg("Buttons", [["auto", "Auto"], ["off", "Normal"], ["on", "Large"]], big_pref, func(v): _display_set("buttons", v))
	_seg("Voice button", [["auto", "Auto"], ["on", "Always"], ["off", "Never"]], vring.show_button if vring else "auto", func(v): _display_set("voice_button", v))
	_seg("Layout", [["auto", "Auto"], ["desktop", "Desktop"], ["handheld", "Handheld"]], layout_pref, func(v): _display_set("layout", v))
	_seg("Detail", [["full", "Full"], ["light", "Light"]], detail, func(v): _display_set("detail", v))
	_hint("Handheld: the layout for a 640×480 screen and a game pad (on by itself on a small screen). Light: 30 frames a second and fewer checks, for a slow handheld’s battery.")
	_hint("Auto: large buttons and the voice button come on by themselves on a touch screen. The voice button shows when one of your voices has something to say about where you are (the ring over you, or V).")
	var a = _actions()
	_button("Controls…", open_controls, a)

var _capture := ""     # the action waiting for a key

func open_controls() -> void:
	_open_modal()
	_eyebrow("Controls")
	_title("Keys")
	_hint("Click an action, then press the key you want for it. The arrow keys also walk, and a game pad's stick walks too. On a touch screen: tap to walk, tap twice to run, pinch to zoom, and twist two fingers to turn the view.")
	for a in Controls.ACTIONS:
		var name: String = a[0]
		var row = HBoxContainer.new()
		var l = Label.new()
		l.text = str(a[1])
		l.custom_minimum_size = Vector2(170 if _narrow() else 260, 0)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		row.add_child(l)
		var b = _button("Press a key…" if _capture == name else Controls.key_name(name), func():
			_capture = name
			open_controls(), row)
		b.custom_minimum_size.x = 160
		_add(row)
	_prompt("GAME PAD")
	for row in pad_help():
		var hr = HBoxContainer.new()
		var l1 = Label.new()
		l1.text = row[0]
		l1.custom_minimum_size = Vector2(110 if _narrow() else 160, 0)
		l1.add_theme_font_override("font", f_mono_b)
		l1.add_theme_font_size_override("font_size", fs(14))
		hr.add_child(l1)
		var l2 = Label.new()
		l2.text = row[1]
		l2.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		l2.add_theme_font_size_override("font_size", fs(15))
		hr.add_child(l2)
		_add(hr)
	var ap = _actions()
	_button("A and B: " + ("swapped" if pad.swap else "usual"), func():
		pad.set_swap(not pad.swap)
		open_controls(), ap)
	_hint("If A goes back and B picks, swap them.")
	var acts = _actions()
	_button("Reset to defaults", func():
		Controls.reset()
		_capture = ""
		open_controls(), acts)
	_button("Back", func():
		_capture = ""
		open_menu(), acts)

func _input(ev: InputEvent) -> void:
	if pad and pad.input(ev):
		get_viewport().set_input_as_handled()
		return
	if _capture != "" and ev is InputEventKey and ev.pressed and not ev.echo:
		get_viewport().set_input_as_handled()
		if ev.keycode != KEY_ESCAPE:
			Controls.set_key(_capture, ev.physical_keycode if ev.physical_keycode != 0 else ev.keycode)
		_capture = ""
		open_controls()

func _load_dev() -> void:
	var c = ConfigFile.new()
	if c.load(DEV_CFG) == OK:
		dev = bool(c.get_value("dev", "on", false))
	Data.js.set_global("DEV", dev)

## The browser's setDev: Dev Mode is kept between runs.
func set_dev(v: bool) -> void:
	dev = v
	Data.js.set_global("DEV", v)
	var c = ConfigFile.new()
	c.load(DEV_CFG)
	c.set_value("dev", "on", v)
	c.save(DEV_CFG)
	editor.set_available(v and world_view.visible and not hh)

func open_load():
	_open_modal()
	_eyebrow("Load game")
	_load_list()
	_load_extras()
	_sync_section()
	_modal_close_row()

func _load_list():
	var any = false
	for i in range(0, Game.SAVE_SLOTS + 1):
		var d: Variant = Game.read_slot(i)
		if not (d is Dictionary):
			continue
		any = true
		_choice(("Autosave" if i == 0 else "Slot %d" % i), _slot_label(d), [], false, func(): _load_and_go(i))
	if not any:
		_hint("No saved games yet.")

func _slot_label(d: Dictionary) -> String:
	return str(d.get("where", "")) + ((" · " + str(d.when)) if str(d.get("when", "")) != "" else "")

func _load_and_go(i: int):
	_resume(Game.load_slot(i))

## The browser's loadPack: carry on from where the save was made.
func _resume(c: Variant) -> bool:
	if not (c is Dictionary):
		return false
	close_modal()
	seen_lines.clear()
	_render_ledger()
	if Game.S.route.is_empty():
		feeling()
	elif c.get("kind") == "road":
		road([])
	elif c.get("kind") == "revisit" and c.get("rv") != null and Bridge.has_js("revisit"):
		Bridge.call_js("revisit", [c.rv])
	else:
		scene()
	return true

# ---------------------------------------------------------------- save files, save codes, sync folder

var _msg: Label

func _say(t: String):
	if is_instance_valid(_msg):
		_msg.text = t

func _file_dialog(mode: int, title: String, cb: Callable, name := "") -> void:
	var fd = FileDialog.new()
	fd.file_mode = mode
	fd.access = FileDialog.ACCESS_FILESYSTEM
	fd.use_native_dialog = true
	fd.title = title
	if mode != FileDialog.FILE_MODE_OPEN_DIR:
		fd.filters = PackedStringArray(["*.json ; Save files", "*.txt ; Save codes"])
	if Game.sync_dir != "":
		fd.current_dir = Game.sync_dir
	else:
		fd.current_dir = OS.get_system_dir(OS.SYSTEM_DIR_DOCUMENTS)
	if name != "":
		fd.current_file = name
	fd.size = Vector2i(820, 560)
	var done = func(path: String):
		fd.queue_free()
		cb.call(path)
	fd.file_selected.connect(done)
	fd.dir_selected.connect(done)
	fd.canceled.connect(fd.queue_free)
	add_child(fd)
	fd.popup_centered()

func _save_extras():
	_prompt("SAVE TO A FILE")
	_hint("A small file you can keep anywhere and open again under Load game, here or in the browser version.")
	var a = _actions()
	_button("Save to a file", func():
		_file_dialog(FileDialog.FILE_MODE_SAVE_FILE, "Save game", func(path):
			_say(("Saved as " + path.get_file() + ".") if Game.save_file(path) else "That file could not be written."), Game.file_name()), a)
	_button("Copy save code", func():
		DisplayServer.clipboard_set(Game.save_code())
		_say("Save code copied. Paste it under Load game, here or in the browser version."), a)
	_msg = _add(Label.new())
	_msg.add_theme_color_override("font_color", COL.dim)

func _load_extras():
	_prompt("LOAD FROM A FILE OR A SAVE CODE")
	_hint("A file of all saves puts each one back in its own slot. Save all saves makes that file, to carry every save to another device or to the browser version.")
	var code = TextEdit.new()
	code.placeholder_text = "Paste a save code here"
	code.custom_minimum_size = Vector2(0, 70)
	code.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	_add(code)
	var a = _actions()
	var fail = func(): _say("That save could not be read.")
	_button("Save all saves to one file", func():
		_file_dialog(FileDialog.FILE_MODE_SAVE_FILE, "Save all saves", func(path):
			var n = Game.save_all_file(path)
			_say(("Saved %d %s as %s." % [n, "save" if n == 1 else "saves", path.get_file()]) if n > 0 else "There are no saves yet, or that file could not be written."), "postal-trace-all-saves.json"), a)
	_button("Choose a save file", func():
		_file_dialog(FileDialog.FILE_MODE_OPEN_FILE, "Load game", func(path):
			var txt = FileAccess.get_file_as_string(path)
			var r: Variant = Game.load_all_text(txt)
			if r is Dictionary:
				# a file of all saves: each goes back in its own slot
				var note = ("1 save" if r.put == 1 else "%d saves" % r.put) + " put in their slots" + (("; %d %s already held a newer save and kept it" % [r.kept, "slot" if r.kept == 1 else "slots"]) if r.kept else "") + "."
				if phase == "title":
					title_screen()
					open_load()
				else:
					open_menu()
				_say(note)
				return
			if not _resume(Game.apply_pack(Game.read_pack(txt))): fail.call()), a)
	_button("Load code", func():
		var t = code.text if code.text.strip_edges() != "" else DisplayServer.clipboard_get()
		if not _resume(Game.apply_pack(Game.read_pack(t))): fail.call(), a)
	if not is_instance_valid(_msg) or not _msg.is_inside_tree():
		_msg = _add(Label.new())
		_msg.add_theme_color_override("font_color", COL.dim)

func _sync_section():
	_prompt("SYNC FOLDER")
	if Game.sync_dir == "":
		_hint("Pick a folder that Dropbox, Google Drive, OneDrive or iCloud keeps in step, and your slots and autosave go there too, so they follow you to your other computers. When both copies exist, the newer one loads.")
	else:
		_hint("Slots are also kept in " + Game.sync_dir + ". When both copies exist, the newer one loads.")
	var a = _actions()
	_button("Choose a sync folder" if Game.sync_dir == "" else "Change folder", func():
		_file_dialog(FileDialog.FILE_MODE_OPEN_DIR, "Sync folder", func(path):
			Game.set_sync_dir(path)
			open_menu()), a)
	if Game.sync_dir != "":
		_button("Stop syncing", func(): Game.set_sync_dir(""); open_menu(), a)

func _latest_slot() -> int:
	var best = -1
	var best_at = -1.0
	for i in range(0, Game.SAVE_SLOTS + 1):
		var d: Variant = Game.read_slot(i)
		if d is Dictionary and float(d.get("at", 0)) > best_at:
			best_at = float(d.at)
			best = i
	return best

func _where() -> String:
	var id = Game.cur_id()
	var sc: Variant = Game.def(id)
	return ("%s · hour %d" % [sc.title, Game.S.hrs]) if sc else "On the road"


func open_credits():
	_open_modal()
	_eyebrow("Credits")
	_title("The Postal Trace")
	_prose("Ported to Godot from the browser version. All writing, systems and audio come from the original game.")
	for grp in Data.T.get("CREDITS", []):
		_prompt(str(grp[0]).to_upper())
		for c in grp[1]:
			_add(_rtl("[b]" + _esc(c[0]) + "[/b] · " + _esc(c[1]) + ((" · " + _esc(c[2])) if c[2] else "") + ("\n[i]" + _esc(c[3]) + "[/i]" if c.size() > 3 and c[3] else ""), 15))
	_prompt("FONTS")
	_add(_rtl("Caladea (Apache 2.0) and Liberation Mono (SIL Open Font License 1.1). Licence texts are in assets/fonts.", 15))
	_modal_close_row()

# ================================================================ the 3D place behind the text

## Show the current place in 3D behind a side panel. mode "walk" lets you move; "still" keeps the view.
func _world(mode: String) -> void:
	if not three_d or world == null:
		return
	var base := Game.cur_id()
	# going back: the browser builds back_cross from the Cross-Pillars layout, and so on
	if not World.has_place(base) and base.begins_with("back_") and World.has_place(base.substr(5)):
		base = base.substr(5)
	var file: String = world.file if world.file.split("__")[0] == base and world.file != "" else base
	if not World.has_place(file):
		return
	# the 3D view fades up when it comes back after the text-only screens (not between one screen and the next)
	if not world_view.visible and Time.get_ticks_msec() / 1000.0 - _world_off_at > 0.25:
		world_view.modulate.a = 0.0
		if _world_tw and _world_tw.is_valid():
			_world_tw.kill()
		_world_tw = create_tween()
		_world_tw.tween_property(world_view, "modulate:a", 1.0, 0.45).set_trans(Tween.TRANS_SINE)
	world_view.visible = true
	editor.set_available(dev and not hh)   # the place editor needs a mouse
	_side(true)
	world.enter(file)
	world.input_locked = mode != "walk"
	if mode == "walk":
		world.refresh()

func _world_off() -> void:
	if world_view == null or not world_view.visible:
		return
	editor.set_available(false)
	world.leave()
	world_view.visible = false
	_world_off_at = Time.get_ticks_msec() / 1000.0
	_side(false)

## Phones and narrow windows put the story under the 3D view instead of beside it.
func _narrow() -> bool:
	var vs = get_viewport_rect().size
	return hh or vs.x < 900.0 or vs.y > vs.x * 1.1

var _side_on := false

func _side(on: bool) -> void:
	_side_on = on
	panel_bg.visible = on
	var vs = get_viewport_rect().size
	if hh:
		_side_hh(on, vs)
		return
	scroll.visible = true
	var narrow = on and _narrow()
	# narrow the column first, so the panel is not held open by the wide layout's minimum width
	margin.custom_minimum_size = Vector2((vs.x - 44 if narrow else SIDE_W - 20) if on else minf(780, vs.x - 52), 0)
	var low = roundf(vs.y * 0.52)
	for c in [scroll, panel_bg]:
		if on and narrow:
			c.anchor_left = 0.0; c.anchor_right = 1.0; c.anchor_top = 1.0; c.anchor_bottom = 1.0
			c.offset_left = 0; c.offset_right = 0; c.offset_top = -low; c.offset_bottom = 0
		elif on:
			c.anchor_left = 1.0; c.anchor_right = 1.0; c.anchor_top = 0.0; c.anchor_bottom = 1.0
			c.offset_left = -SIDE_W; c.offset_right = 0; c.offset_top = 0; c.offset_bottom = 0
		else:
			c.set_anchors_preset(Control.PRESET_FULL_RECT)
			c.offset_left = 0; c.offset_right = 0; c.offset_top = 0; c.offset_bottom = 0
	# on a narrow screen the 3D view takes the top of the window only, so the courier is not under the text
	world_view.set_anchors_preset(Control.PRESET_FULL_RECT)
	world_view.offset_bottom = -low if narrow else 0
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 14 if on else 24)

## Handheld: the text on the right, the place on the left; when walking, the place fills the screen.
func _side_hh(on: bool, vs: Vector2) -> void:
	var walk = on and pad and pad.mode == "walk"
	margin.custom_minimum_size = Vector2(HH_SIDE - 20 if on else minf(780, vs.x - 36), 0)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 10 if on else 16)
	margin.add_theme_constant_override("margin_top", 10 if on else 14)
	for c in [scroll, panel_bg]:
		if on:
			c.anchor_left = 1.0; c.anchor_right = 1.0; c.anchor_top = 0.0; c.anchor_bottom = 1.0
			c.offset_left = -HH_SIDE; c.offset_right = 0; c.offset_top = 0; c.offset_bottom = 0
		else:
			c.set_anchors_preset(Control.PRESET_FULL_RECT)
			c.offset_left = 0; c.offset_right = 0; c.offset_top = 0; c.offset_bottom = 0
	scroll.visible = not walk
	panel_bg.visible = on and not walk
	world_view.set_anchors_preset(Control.PRESET_FULL_RECT)
	world_view.offset_right = 0 if (walk or not on) else -HH_SIDE
	world_view.offset_bottom = 0
	_pad_bar()

func _apply_pad_mode() -> void:
	if hh and _side_on:
		_side(true)
	_pad_bar()

## Handhelds: guess from the screen (a 640×480 one), or the launcher says so (PT_HANDHELD=1, as the
## PortMaster script does), or the export has the "handheld" feature.
static func handheld_device() -> bool:
	if OS.get_environment("PT_HANDHELD") == "1" or OS.has_feature("handheld"):
		return true
	if DisplayServer.get_name() == "headless" or touch_device():
		return false
	var ss = DisplayServer.screen_get_size()
	return ss.x > 0 and ss.x <= 800 and ss.y <= 600

## What each pad button does (Menu > Controls).
func pad_help() -> Array:
	return [["D-pad", "Move between options; walk, when walking"], ["A", "Pick; talk to or look at what is marked, when walking"],
		["B", "Back or close; hold to run, when walking"], ["X", "Walk in the place / back to the text"],
		["Y", "Hear the waiting voice"], ["L1 / R1", "Scroll the text; turn the view, when walking"],
		["L2 / R2", "Mark the next thing to talk to or look at"], ["Select", "Character, Tin Thoughts, Satchel, Journal in turn"],
		["Select + L1/R1", "Zoom the view"], ["Start", "Menu"]]

var _bar_t := 0.0
func _process(dt: float) -> void:
	_bar_t -= dt
	if _bar_t <= 0.0:
		_bar_t = 0.12
		_pad_bar()

## The line of pad hints over the 3D view.
func _pad_bar() -> void:
	if pad_bar == null:
		return
	var show = pad != null and pad.used and world_view.visible and not modal.visible and world != null
	if not show:
		pad_bar.visible = false
		return
	var t := ""
	if pad.mode == "walk":
		var k: Variant = world.pad_target
		var what := "—"
		if k != null:
			what = ("talk to " if k.kind == "person" else ("go through: " if k.kind == "door" else "look at ")) + str(k.name)
		t = "A %s    L2/R2 next    hold B run    X text    Start menu" % what
	elif pad.can_walk():
		t = "X walk    Select pages    Start menu"
	pad_bar.text = t
	pad_bar.visible = t != ""
	var side = 0 if pad.mode == "walk" or not _side_on else (HH_SIDE if hh else (0 if _narrow() else SIDE_W))
	pad_bar.offset_right = -8 - side

## A pad was pressed for the first time: the hints come on.
func pad_hints() -> void:
	if beat_btn and is_instance_valid(beat_btn):
		beat_btn.text = "Continue  (A)"
	_pad_bar()

## The part of the window where the 3D view can be seen (not under the story panel).
func view_rect() -> Rect2:
	var r = world_view.get_global_rect()
	if _side_on and not _narrow():
		r.size.x -= SIDE_W
	return r

## How big the game draws itself. On a computer the window shows a 1280×800 layout, scaled to fit. On a
## phone or tablet (or a narrow window) the layout is sized in finger-sized points instead, so text and
## buttons stay readable rather than shrinking to fit the whole desktop layout on a small screen.
static func touch_device() -> bool:
	return DisplayServer.is_touchscreen_available() or OS.get_environment("PT_TOUCH") == "1"

func _fit_window() -> void:
	var win = get_window()
	var ws = Vector2(win.size)
	if ws.x <= 0 or ws.y <= 0:
		return
	var want = Vector2i(1280, 800)
	if hh:
		# 480 lines high, as wide as the screen's shape allows (640 on the RG35XX Plus, 853 on a 16:9 TV)
		want = Vector2i(int(round(480.0 * ws.x / ws.y)), 480)
	elif touch_device() or ws.x < ws.y:
		var s = maxf(1.0, DisplayServer.screen_get_dpi() / 150.0)
		var logical = ws / s
		# keep the desktop layout where there is room for it
		if logical.x >= 1100 and logical.y >= 700:
			want = Vector2i(1280, 800)
		else:
			want = Vector2i(int(logical.x), int(logical.y))
	if win.content_scale_size != want:
		win.content_scale_size = want

func _on_resized() -> void:
	_fit_window()
	if world_view and world_view.visible:
		_side(true)
	elif margin:
		_side(false)

func _on_world_interact(kind: String, id: String) -> void:
	if phase != "scene":
		return
	if kind == "person":
		var ts := Game.talkers()
		for i in ts.size():
			if str(ts[i].id) == id:
				talk(i)
				return
	elif kind == "thing":
		look(id)

# ================================================================ marked-up text from data logic

## Draw text built by data logic: paragraphs, voice lines, a fight summary, plain styled text.
func _markup(s: String, beats := true) -> void:
	for seg in Markup.parse(s):
		match seg[0]:
			"p":
				var c = _prose(seg[1])
				if beats:
					_beat(c, str(seg[1]))
			"v":
				_voice(seg[1], seg[2], false, beats)
			"t":
				_add(_rtl(seg[1]))

# ================================================================ fights

## Try a fight straight from the title screen, with a fresh Battery Gunner.
func practice_menu() -> void:
	phase = "other"
	_clear()
	_eyebrow("Practice")
	_title("Practice a fight")
	_hint("A fresh Battery Gunner, full powder. Nothing here touches your saved games.")
	_choice("The ambush at the ford", "The bearers of Lieutenant Hale, a coffin on a cart, and a rider in a greatcoat.", [], false, func(): _practice("bearers"))
	_choice("A hunting party on the road", "Provost riders with your description on a bill.", [], false, func(): _practice("hunt"))
	_button("Back", title_screen)

func _practice(kind: String):
	Game.begin_run({ "trait": "steady", "up": { "arms": 2, "nerve": 1, "wits": 1, "grit": 2 }, "arch": "gunner", "left": 0 })
	var S = Game.S
	S.practice = true
	S.route = ["cross", "bearers", "ford", "oak", "ridge", "malice"]
	S.idx = 1
	S.seen = 2
	S.hp = 7
	Game.ledger_changed.emit()
	if kind == "bearers":
		resolve(Data.scenes.bearers.choices[2], 2)
	else:
		S.notice = 5
		Bridge.call_js("nHuntFight", [func(_a): title_screen()])

# ================================================================ the browser logic's own screens

## Rule helpers that go through the browser logic, so companions' reactions and later
## additions run too. They return chips as the browser builds them (HTML spans).
func _jsc(name: String, args: Array) -> Array:
	var r: Variant = Bridge.call_js(name, args)
	return r if r is Array else []

func _fx(fx: Variant) -> Array:
	if Bridge.has_js("applyFx"):
		return _jsc("applyFx", [fx])
	return Game.apply_fx(fx)

func _xp(n: int) -> Array:
	if Bridge.has_js("addXp"):
		return _jsc("addXp", [n])
	return Game.add_xp(n)

func _tally(tag: String, chips: Variant = null) -> void:
	var c: Array = chips if chips is Array else []
	if Bridge.has_js("tallyAdd"):
		Bridge.call_js("tallyAdd", [tag, c])
	else:
		Game.tally_add(tag, c)

func _side_add(v: String, chips: Variant = null) -> void:
	var c: Array = chips if chips is Array else []
	if Bridge.has_js("sideAdd"):
		Bridge.call_js("sideAdd", [v, c])
	else:
		Game.side_add(v, c)

func _thought(tid: String, chips: Variant = null) -> bool:
	var c: Array = chips if chips is Array else []
	if Bridge.has_js("newThought"):
		return Data.truthy(Bridge.call_js("newThought", [tid, c]))
	return Game.new_thought(tid, c)

func _jsv(name: String, a: Variant = null, b: Variant = null) -> void:
	var args: Array = []
	if a != null: args.append(a)
	if b != null: args.append(b)
	Bridge.call_js(name, args)

## Draw a whole screen the browser logic built with show(html).
func show_html(h: String) -> void:
	phase = "page"
	_clear()
	Bridge.page = Html.parse(h)
	_render_children(Bridge.page)
	_reveal_all()
	_render_ledger()

## Draw an HTML piece from the browser logic into the current screen (it joins the page,
## so the logic can find and wire its buttons).
func _html_fragment(h: String) -> void:
	if h.strip_edges() == "":
		return
	var frag := Html.parse(h)
	for c in frag.children:
		c._parent = weakref(Bridge.page)
		Bridge.page.children.append(c)
	_render_children(frag)

func show_modal_html() -> void:
	_open_modal()
	_render_children(Bridge.modal_page)
	target = page

const SKIP_TAGS := ["script", "style", "svg", "canvas", "input", "select", "textarea", "img", "audio", "video"]

func _render_children(el: Html.Element) -> void:
	var buf := ""
	var last_el := false
	for c in el.children:
		if c.tag == "#text" or (c.tag in Html.INLINE and not c.has_class("chip") and c.tag != "img"):
			# pieces the browser set apart with CSS gaps (a styled span, or two spans in a row)
			if c.tag != "#text" and c.tag != "br" and (c.attrs.has("class") or last_el) and buf != "" and not buf.ends_with(" ") and not buf.ends_with("\n"):
				buf += "   "
			buf += _inline_bb(c)
			last_el = c.tag != "#text"
		else:
			_flush_bb(buf)
			buf = ""
			_render_el(c)
	_flush_bb(buf)

func _flush_bb(bb: String) -> void:
	if bb.strip_edges() == "":
		return
	for seg in Markup.parse_bb(bb):
		match seg[0]:
			"t":
				var line: String = seg[1]
				if line.strip_edges() != "":
					_beat(_add(_rtl(line)), line)
			"v":
				_voice(seg[1], Html.unescape(seg[2]), seg[3].find("big") >= 0)
			"i":
				_add(_portrait(seg[1], seg[2] if seg[2] != "" else null, 72))
			"r":
				var rr: Array = Bridge.rolls[seg[1]] if seg[1] < Bridge.rolls.size() else []
				if rr.size():
					_roll(rr[0], rr[1], rr[2], false)
			"p":
				_beat(_prose(seg[1]), str(seg[1]))

func _inline_bb(c: Html.Element) -> String:
	if c.tag == "#text":
		return _esc(c.text).replace("\n", " ")
	if c.tag == "br":
		return "\n"
	var inner := ""
	for x in c.children:
		inner += _inline_bb(x)
	match c.tag:
		"b", "strong": return "[b]" + inner + "[/b]"
		"i", "em": return "[i]" + inner + "[/i]"
		"small": return "[font_size=14]" + inner + "[/font_size]"
		"kbd", "code": return "[code]" + inner + "[/code]"
	if c.has_class("chip"):
		return "[color=#%s]%s[/color]" % [(COL.good if c.has_class("up") else (COL.bad if c.has_class("down") else COL.brass)).to_html(false), inner]
	if c.has_class("tag"):
		return "[color=#%s]‹%s›[/color]" % [(COL.good if c.has_class("go") else (COL.bad if c.has_class("warn") or c.has_class("red") else COL.dim)).to_html(false), inner]
	if c.has_class("fhurt") or c.has_class("neg") or c.has_class("bad"):
		return "[color=#%s]%s[/color]" % [COL.bad.to_html(false), inner]
	if c.has_class("fgood") or c.has_class("good") or c.has_class("ok"):
		return "[color=#%s]%s[/color]" % [COL.good.to_html(false), inner]
	if c.has_class("die"):
		return "[b] " + inner + " [/b]"
	return inner

func _el_text(el: Html.Element) -> String:
	return el.text_content().strip_edges()

func _render_el(el: Html.Element) -> void:
	var tag := el.tag
	if tag in SKIP_TAGS or el.attrs.has("hidden") or JsLite.truthy(el.props.get("hidden")):
		return
	var keep := target
	match tag:
		"h1", "h2":
			_title(_el_text(el), tag == "h1")
			return
		"h3", "h4":
			_add(_rtl("[b]" + _esc(_el_text(el)) + "[/b]", 20))
			return
		"button":
			_render_button(el)
			return
		"ul", "ol":
			for li in el.children:
				if li.tag == "li":
					var t := ""
					for x in li.children:
						t += _inline_bb(x) if (x.tag == "#text" or x.tag in Html.INLINE) else _esc(x.text_content())
					_add(_rtl("•  " + t.strip_edges(), 17))
			return
		"details":
			for c in el.children:
				if c.tag == "summary":
					_prompt(_el_text(c).to_upper())
				elif c.tag != "#text":
					_render_el(c)
			return
		"p":
			var t := ""
			for x in el.children:
				t += _inline_bb(x) if (x.tag == "#text" or x.tag in Html.INLINE) else _esc(x.text_content())
			_flush_bb(t)
			return
	if el.has_class("eyebrow"):
		_eyebrow(_el_text(el)); return
	if el.has_class("prompt"):
		_prompt(_el_text(el).to_upper()); return
	if el.has_class("hint") or el.has_class("fdesc") or el.has_class("nextstop") or el.has_class("role"):
		var t := ""
		for x in el.children:
			t += _inline_bb(x)
		_add(_rtl("[i]" + t.strip_edges() + "[/i]", 16, COL.dim)); return
	if el.has_class("chips"):
		var list: Array = []
		for c in Html.query(el, ".chip"):
			list.append({ "t": _el_text(c), "k": "up" if c.has_class("up") else ("down" if c.has_class("down") else ("info" if c.has_class("info") else "")) })
		_chips(list); return
	if el.has_class("doc"):
		_doc(el.text_content()); return
	if el.has_class("roll"):
		var p := PanelContainer.new()
		p.add_theme_stylebox_override("panel", _box(Color("14110d"), COL.line, 1, 4))
		var t := ""
		for x in el.children:
			t += (_inline_bb(x) if x.tag in Html.INLINE or x.tag == "#text" else _esc(x.text_content())) + "  "
		p.add_child(_rtl(t.strip_edges(), 16))
		_add(p); return
	if el.has_class("voice"):
		var vb := Html.query(el, "[data-vi]")
		var v: String = str(vb[0].attrs["data-vi"]) if vb.size() else ""
		var head := _el_text(Html.query(el, "b")[0]) if Html.query(el, "b").size() else ""
		var body := _el_text(el).substr(head.length()).strip_edges()
		if v != "" and Data.T.VOICES.has(v):
			_voice(v, body, el.has_class("big"))
		else:
			var p2 := PanelContainer.new()
			var sb := _box(COL.panel, COL.hat, 0, 2, Vector4(14, 8, 12, 8))
			sb.border_width_left = 3
			p2.add_theme_stylebox_override("panel", sb)
			p2.add_child(_rtl("[font_size=14][color=#%s][b]%s[/b][/color][/font_size]\n%s" % [COL.brass.to_html(false), _esc(head).to_upper(), _esc(body)], 18))
			_add(p2)
			_beat(p2, body)
		return
	var boxed := ["cockade", "thoughtcard", "courier", "fsum", "memq", "panel", "cpgate_box", "card", "arrive_box", "comp", "banter", "flog"]
	for b in boxed:
		if el.has_class(b):
			var p3 := PanelContainer.new()
			p3.add_theme_stylebox_override("panel", _box(Color("231d14") if b != "cockade" else Color("2a1414"), COL.brass if b != "cockade" else COL.bad, 1, 5))
			var v3 := VBoxContainer.new()
			v3.add_theme_constant_override("separation", 8)
			p3.add_child(v3)
			_add(p3)
			target = v3
			_render_children(el)
			target = keep
			return
	if el.has_class("actions") or el.has_class("foes") or el.has_class("talkbar") or el.has_class("lookbar") or el.has_class("archs") or el.has_class("fstat") or el.has_class("stepper"):
		var horizontal := el.has_class("actions") or el.has_class("fstat") or el.has_class("stepper")
		if horizontal:
			var f := _actions()
			target = f
			_render_children(el)
			target = keep
			return
	if el.has_class("speaker"):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 16)
		_add(row)
		var col: VBoxContainer = null
		for c in el.children:
			if c.tag == "#text" or c.tag in Html.INLINE:
				target = row
				_flush_bb(_inline_bb(c))
			else:
				if col == null:
					col = VBoxContainer.new()
					col.alignment = BoxContainer.ALIGNMENT_CENTER
					row.add_child(col)
				target = col
				_render_el(c)
		target = keep
		return
	_render_children(el)

func _render_button(el: Html.Element) -> void:
	var disabled := el.attrs.has("disabled")
	var cb := func(): el.fire("click")
	var tq := Html.query(el, ".t")
	var title := ""
	var hint := ""
	var tags: Array = []
	if tq.size():
		title = _el_text(tq[0])
		var hq := Html.query(el, ".h")
		hint = _el_text(hq[0]) if hq.size() else ""
	elif el.has_class("talkbtn") or el.has_class("lookbtn") or el.has_class("foe") or el.has_class("arch"):
		var bq := Html.query(el, "b")
		title = _el_text(bq[0]) if bq.size() else _el_text(el)
		var bits: PackedStringArray = []
		for q in Html.query(el, "i, em, span:not(.tag):not(.tags):not(.fpips)"):
			if q.tag != "span" or q.children.size() == 1:
				var tt := _el_text(q)
				if tt != "" and tt != title:
					bits.append(tt)
		hint = " · ".join(bits)
		var pips := Html.query(el, ".fpips i")
		if pips.size():
			var pp := ""
			for pi in pips:
				pp += "●" if pi.has_class("on") else "○"
			title += "   " + pp
	else:
		title = _el_text(el)
	for tg in Html.query(el, ".tag"):
		tags.append([_el_text(tg), "go" if tg.has_class("go") else ("warn" if tg.has_class("warn") else ("red" if tg.has_class("red") else ""))])
	title = RegEx.create_from_string("^\\d+\\.\\s+").sub(title, "")
	if el.has_class("choice") or el.has_class("talkbtn") or el.has_class("lookbtn") or el.has_class("foe") or el.has_class("arch") or el.has_class("voiceopt"):
		if el.has_class("sel") and el.has_class("foe"):
			title = "▶ " + title
		var c := _choice(title, hint, tags, disabled, cb, "", not el.has_class("foe"))
		el.widget = c
	else:
		var b := _button(title.replace("Space", "").strip_edges(), cb, target if target is HFlowContainer else null, disabled)
		el.widget = b

## talk() as the browser logic calls it (ti: a talker's index; last/note: see talk()).
func talk_js(ti: Variant, _last: Variant = null, note: Variant = null) -> void:
	if typeof(ti) == TYPE_STRING:
		return look(ti)
	var ts := Game.talkers()
	if int(ti) >= ts.size():
		return scene()
	var t: Dictionary = ts[int(ti)]
	var id := Game.cur_id()
	if note == null and not Data.T["CROWN"].has(t.id) and not Game.S.done.has("mode_" + id):
		return mode_screen(int(ti))
	var G: Variant = Data.graph(id, t.id)
	if G == null:
		return scene()
	graph_show(int(ti), G.hub, { "note": note } if note != null else {})

# ---------------------------------------------------------------- test hooks
func Game_begin() -> void:
	Game.begin_run({ "trait": "steady", "up": { "arms": 2, "nerve": 1, "wits": 1, "grit": 2 }, "arch": "gunner", "left": 0 })

func feeling_pick(i: int) -> void:
	feeling()
	choices[i][1].call()
