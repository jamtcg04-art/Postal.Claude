class_name Pad
extends Node
## Game pad control, built for handhelds with a d-pad and no sticks (the Anbernic RG35XX Plus), and the same
## on any pad on a computer. The browser build's pad code (padTick in index.html) uses the same buttons.
##
## Two modes:
##   "panel": the d-pad moves between options, A picks, B goes back, L1/R1 scroll the text.
##   "walk":  the d-pad walks the courier, A talks to or looks at the highlighted person or thing,
##            L2/R2 change what is highlighted, L1/R1 turn the view, hold B to run, tap B (or X) for the text.
## X switches between them where there is a place to walk in. Y hears the waiting voice. Start opens the menu,
## Select steps through Character, Tin Thoughts, Satchel and Journal. Select + L1/R1 zooms the view.

const CFG := "user://settings.cfg"
const REPEAT_DELAY := 0.36
const REPEAT_RATE := 0.11

## [action, pad buttons, pad axis (axis, sign) or null]
const ACTS := [
	["hh_up", [JOY_BUTTON_DPAD_UP], [JOY_AXIS_LEFT_Y, -1]],
	["hh_down", [JOY_BUTTON_DPAD_DOWN], [JOY_AXIS_LEFT_Y, 1]],
	["hh_left", [JOY_BUTTON_DPAD_LEFT], [JOY_AXIS_LEFT_X, -1]],
	["hh_right", [JOY_BUTTON_DPAD_RIGHT], [JOY_AXIS_LEFT_X, 1]],
	["hh_ok", [JOY_BUTTON_A], null],
	["hh_back", [JOY_BUTTON_B], null],
	["hh_walk", [JOY_BUTTON_X], null],
	["hh_voice", [JOY_BUTTON_Y], null],
	["hh_menu", [JOY_BUTTON_START, JOY_BUTTON_GUIDE], null],
	["hh_pages", [JOY_BUTTON_BACK], null],
	["hh_l1", [JOY_BUTTON_LEFT_SHOULDER], null],
	["hh_r1", [JOY_BUTTON_RIGHT_SHOULDER], null],
	["hh_l2", [], [JOY_AXIS_TRIGGER_LEFT, 1]],
	["hh_r2", [], [JOY_AXIS_TRIGGER_RIGHT, 1]],
]
const DIRS := { "hh_up": "ui_up", "hh_down": "ui_down", "hh_left": "ui_left", "hh_right": "ui_right" }

var main: Node                 # main.gd
var mode := "panel"            # "panel" or "walk"
var swap := false              # A and B the other way round (Menu > Controls)
var used := false              # a pad has been pressed this session (the hints show then)
var page_i := -1               # which page Select opened last
var _held: Dictionary = {}     # action -> seconds held
var _rep: Dictionary = {}      # direction action -> time to its next repeat
var _back_moved := false       # B was held while walking (a run), so letting go is not "back to the text"
var _sel_chord := false        # Select was used with L1/R1 (zoom), so letting go does not open a page
var _focus_t := 0.0
var _pick_at := -1             # where the picked option was in its list, and how long the list was,
var _pick_n := 0               # so a screen drawn again the same (the creator, Settings) keeps your place
var _pick_ms := 0

signal mode_changed(mode: String)

func _ready() -> void:
	setup()

## Add the pad actions. L2/R2 come in as trigger axes (Godot's pad mapping turns trigger buttons into axes).
func setup() -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	swap = bool(c.get_value("pad", "swap", false))
	for a in ACTS:
		var name: String = a[0]
		if not InputMap.has_action(name):
			InputMap.add_action(name, 0.5)
		InputMap.action_erase_events(name)
		var buttons: Array = a[1].duplicate()
		if swap and name == "hh_ok":
			buttons = [JOY_BUTTON_B]
		elif swap and name == "hh_back":
			buttons = [JOY_BUTTON_A]
		for b in buttons:
			var jb = InputEventJoypadButton.new()
			jb.button_index = b
			jb.device = -1
			InputMap.action_add_event(name, jb)
		if a[2] != null:
			var jm = InputEventJoypadMotion.new()
			jm.axis = a[2][0]
			jm.axis_value = float(a[2][1])
			jm.device = -1
			InputMap.action_add_event(name, jm)

func set_swap(v: bool) -> void:
	var c = ConfigFile.new()
	c.load(CFG)
	c.set_value("pad", "swap", v)
	c.save(CFG)
	setup()

func _action_of(ev: InputEvent) -> String:
	for a in ACTS:
		if ev.is_action(a[0]):
			return a[0]
	return ""

## Called from main.gd's _input. True when the event was a pad event (it is then used up here).
func input(ev: InputEvent) -> bool:
	if not (ev is InputEventJoypadButton or ev is InputEventJoypadMotion):
		return false
	var act = _action_of(ev)
	if act == "":
		# a stick or a button the game does not use: keep it away from the text panel's own focus moves
		return ev is InputEventJoypadButton
	var pressed = ev.is_action_pressed(act)
	var released = ev.is_action_released(act)
	if pressed and _held.has(act):
		return true            # an axis still past the line, or a repeat from the pad
	if pressed:
		_held[act] = 0.0
		if not used:
			used = true
			main.pad_hints()
		_press(act)
	elif released and _held.has(act):
		var t: float = _held[act]
		_held.erase(act)
		_rep.erase(act)
		_release(act, t)
	return true

func held(act: String) -> bool:
	return _held.has(act)

# ---------------------------------------------------------------- presses

func _press(act: String) -> void:
	var w: World = main.world
	if w and w.in_cut() and act in ["hh_ok", "hh_back", "hh_menu"]:
		w.cut_skip()
		return
	if main._capture != "":
		return
	match act:
		"hh_menu":
			if main.modal.visible:
				main.close_modal()
			elif main.phase != "title":
				main.open_menu()
			return
		"hh_pages":
			_sel_chord = false
			return
		"hh_voice":
			if main.vring and not main.modal.visible:
				main.vring.open_next()
			return
		"hh_walk":
			if mode == "walk":
				set_mode("panel")
			elif can_walk():
				set_mode("walk")
			return
	if held("hh_pages") and act in ["hh_l1", "hh_r1"]:
		_sel_chord = true
		if w:
			w.zoom = clampf(w.zoom * (0.82 if act == "hh_r1" else 1.22), 3.5, 14.0)
		return
	if mode == "walk":
		_press_walk(act)
	else:
		_press_panel(act)

func _release(act: String, t: float) -> void:
	if main._capture != "":
		return
	if act == "hh_pages" and not _sel_chord:
		_next_page()
	elif act == "hh_back" and mode == "walk" and not _back_moved and t < 0.35:
		set_mode("panel")
	if act == "hh_back":
		_back_moved = false

func _press_walk(act: String) -> void:
	var w: World = main.world
	match act:
		"hh_ok":
			if w and w.pad_target != null:
				w.approach(w.pad_target)
		"hh_l2":
			if w: w.pad_cycle(-1)
		"hh_r2":
			if w: w.pad_cycle(1)

func _press_panel(act: String) -> void:
	if DIRS.has(act):
		if _ensure_focus():
			_send(DIRS[act])
		_rep[act] = REPEAT_DELAY
	elif act == "hh_ok":
		if main.beat_btn != null and not main.modal.visible:
			main._next_beat()
		elif _ensure_focus():
			var all = _all_focusable(_box())
			_pick_at = all.find(main.get_viewport().gui_get_focus_owner())
			_pick_n = all.size()
			_pick_ms = Time.get_ticks_msec()
			_send("ui_accept")
	elif act == "hh_back":
		if main.modal.visible:
			main.close_modal()
		elif can_walk():
			set_mode("walk")
	elif act in ["hh_l1", "hh_r1", "hh_l2", "hh_r2"]:
		_scroll(-1 if act in ["hh_l1", "hh_l2"] else 1)

func _send(action: String) -> void:
	for p in [true, false]:
		var e = InputEventAction.new()
		e.action = action
		e.pressed = p
		Input.parse_input_event(e)

func _scroll(dir: int) -> void:
	var sc: ScrollContainer = main.mscroll if main.modal.visible else main.scroll
	sc.scroll_vertical += int(dir * sc.size.y * 0.7)

func _next_page() -> void:
	if not (main.phase in ["scene", "talk", "road"]):
		return
	var tags := ["char", "tin", "bag", "log"]
	if LivingDice.is_on(Game.S.get("ld")):
		tags.append("dice")
	var i := tags.find(main.modal_tag) if main.modal.visible else -1
	if i == tags.size() - 1:
		main.close_modal()
		return
	match tags[i + 1]:
		"char": main.open_char()
		"tin": main.open_thoughts()
		"bag": main.open_satchel()
		"log": main.open_journal()
		"dice": main.open_dice()

# ---------------------------------------------------------------- focus in the text panel

## The box the d-pad moves around in: the menu or page when one is open, otherwise the story panel.
func _box() -> Control:
	return main.mpage if main.modal.visible else main.page

func _focusable(c: Control) -> bool:
	if c.focus_mode != Control.FOCUS_ALL or not c.is_visible_in_tree():
		return false
	if c is BaseButton and c.disabled:
		return false
	return true

func _first_focusable(n: Node) -> Control:
	for ch in n.get_children():
		if ch is Control:
			if _focusable(ch):
				return ch
			var f = _first_focusable(ch)
			if f:
				return f
	return null

## True when something sensible already has focus (so the press can go through); otherwise focus the
## first option and use up the press.
func _ensure_focus() -> bool:
	var f = main.get_viewport().gui_get_focus_owner()
	var box = _box()
	if f and f.is_visible_in_tree() and box.is_ancestor_of(f):
		return true
	focus_first()
	return false

func _all_focusable(n: Node, out: Array = []) -> Array:
	for ch in n.get_children():
		if ch is Control:
			if _focusable(ch):
				out.append(ch)
			_all_focusable(ch, out)
	return out

func focus_first() -> void:
	var box = _box()
	# the same screen drawn again after a pick: stay on the option you picked
	if _pick_at >= 0 and Time.get_ticks_msec() - _pick_ms < 1500:
		var all = _all_focusable(box)
		var at = _pick_at
		_pick_at = -1
		if all.size() == _pick_n and at < all.size():
			all[at].grab_focus()
			return
	if not main.modal.visible:
		if main.beat_btn != null and is_instance_valid(main.beat_btn):
			main.beat_btn.grab_focus()
			return
		for c in main.choices:
			if not c[2] and is_instance_valid(c[0]) and c[0].is_visible_in_tree():
				c[0].grab_focus()
				return
	var f = _first_focusable(box)
	if f:
		f.grab_focus()

# ---------------------------------------------------------------- walking

## There is a place on screen to walk in.
func can_walk() -> bool:
	var w: World = main.world
	return w != null and main.three_d and main.world_view.visible and main.phase == "scene" and not main.modal.visible \
		and not w.input_locked and not w.in_cut() and not (main.editor and main.editor.on)

func set_mode(m: String) -> void:
	if m == mode:
		return
	mode = m
	var w: World = main.world
	if w:
		w.pad_on = m == "walk"
		if m != "walk":
			w.pad_mv = Vector2.ZERO
			w.pad_run = false
			w.pad_turn = 0.0
	if m == "panel":
		focus_first.call_deferred()
	mode_changed.emit(m)

func _process(dt: float) -> void:
	for a in _held:
		_held[a] += dt
	if mode == "walk" and not can_walk():
		set_mode("panel")
	var w: World = main.world
	if mode == "walk" and w:
		var mv = Vector2.ZERO
		if held("hh_up"): mv.y -= 1
		if held("hh_down"): mv.y += 1
		if held("hh_left"): mv.x -= 1
		if held("hh_right"): mv.x += 1
		w.pad_mv = mv
		w.pad_run = held("hh_back")
		if w.pad_run and mv != Vector2.ZERO:
			_back_moved = true
		w.pad_turn = 0.0 if held("hh_pages") else (1.0 if held("hh_l1") else 0.0) - (1.0 if held("hh_r1") else 0.0)
		return
	# held directions repeat in the panel, as a keyboard's arrows do
	for a in DIRS:
		if _rep.has(a) and held(a):
			_rep[a] -= dt
			if _rep[a] <= 0.0:
				_rep[a] = REPEAT_RATE
				if _ensure_focus():
					_send(DIRS[a])
	# after a pad press, keep something focused when a new screen has been drawn
	if used:
		_focus_t -= dt
		if _focus_t <= 0.0:
			_focus_t = 0.15
			var f = main.get_viewport().gui_get_focus_owner()
			if f == null or not f.is_visible_in_tree() or not _box().is_ancestor_of(f):
				focus_first()
