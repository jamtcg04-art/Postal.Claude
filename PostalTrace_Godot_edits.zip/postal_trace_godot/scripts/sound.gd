## Sound: one-shot effects, a looping ambience bed and music, from res://assets.
extends Node

var volume := { "master": 1.0, "sfx": 0.8, "amb": 0.6, "music": 0.6 }
var _amb: AudioStreamPlayer
var _music: AudioStreamPlayer
var _amb_key := ""
var _music_key := ""
var _pool: Array = []
var _cache: Dictionary = {}

const SFX_VOL := { "road": 0.5, "duty": 0.45, "hat": 0.45, "pass": 0.35, "fail": 0.35, "redpass": 0.5, "redfail": 0.5,
	"thought": 0.55, "lock": 0.45, "blip": 0.25, "ringing": 0.5, "redoubt": 0.55, "leg": 0.4 }

func _ready() -> void:
	_amb = AudioStreamPlayer.new()
	_music = AudioStreamPlayer.new()
	add_child(_amb)
	add_child(_music)
	for i in 6:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_pool.append(p)

func _stream(path: String) -> AudioStream:
	if _cache.has(path):
		return _cache[path]
	var s: AudioStream = null
	if ResourceLoader.exists(path):
		s = load(path)
	_cache[path] = s
	return s

func play(key: String, vol: float = -1.0) -> void:
	var s := _stream("res://assets/sfx/" + key + ".mp3")
	if s == null:
		return
	var v: float = vol if vol >= 0.0 else float(SFX_VOL.get(key, 0.4))
	for p in _pool:
		if not p.playing:
			p.stream = s
			p.volume_db = linear_to_db(max(0.0001, v * volume["sfx"] * volume["master"]))
			p.play()
			return

## The voices each have a short sting the first time they speak on a screen.
func voice(v: String) -> void:
	if ResourceLoader.exists("res://assets/sfx/v_" + v + ".mp3"):
		play("v_" + v, 0.35)
	elif v == "duty" or v == "hat":
		play(v)

func ambience(key: String, vol: float = 0.35) -> void:
	if key == _amb_key:
		return
	_amb_key = key
	_amb.stop()
	if key == "":
		return
	var s := _stream("res://assets/amb/" + key + ".mp3")
	if s == null:
		return
	if s is AudioStreamMP3:
		(s as AudioStreamMP3).loop = true
	_amb.stream = s
	_amb.volume_db = linear_to_db(max(0.0001, vol * volume["amb"] * volume["master"]))
	_amb.play()

func music(key: String) -> void:
	if key == _music_key:
		return
	_music_key = key
	_music.stop()
	if key == "":
		return
	var s := _stream("res://assets/music/" + key + ".mp3")
	if s == null:
		return
	if s is AudioStreamMP3:
		(s as AudioStreamMP3).loop = true
	_music.stream = s
	_music.volume_db = linear_to_db(max(0.0001, 0.6 * volume["music"] * volume["master"]))
	_music.play()
