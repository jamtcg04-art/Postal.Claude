## Figure: a person in the world, built on the one rigged body (assets/3d/people/person.glb).
##
## dress() takes the browser version's outfit description (coat colour, what they wear,
## hat, weapon, or a soldier's uniform body) and shows and colours the right pieces.
## play() runs one of the 39 movements from the rig: idle, talk, arms, walk, jog, sit...
class_name Figure
extends Node3D

const PERSON := "res://assets/3d/people/person.glb"
const BLOB := preload("res://shaders/blob.gdshader")
const RG_SKIN := Color(0.62, 0.5, 0.42)
const RG_BOOT := Color(0.1, 0.09, 0.08)
const RG_HAT := Color(0.12, 0.11, 0.1)
const RG_IRON := Color(0.36, 0.37, 0.4)

var body: Node3D
var anim: AnimationPlayer
var current = ""
var meshes: Dictionary = {}       # node name -> MeshInstance3D
var look: Dictionary = {}

func _init() -> void:
	if not ResourceLoader.exists(PERSON):
		return
	body = load(PERSON).instantiate()
	add_child(body)
	for mi in body.find_children("*", "MeshInstance3D", true, false):
		meshes[str(mi.name)] = mi
		mi.visible = false
	anim = body.find_child("AnimationPlayer", true, false)
	var blob = MeshInstance3D.new()
	blob.name = "Blob"
	var q = PlaneMesh.new()
	q.size = Vector2(0.95, 0.95)
	blob.mesh = q
	blob.position.y = 0.03
	var bm = ShaderMaterial.new()
	bm.shader = BLOB
	blob.material_override = bm
	blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(blob)

static func _c(a: Variant, fallback: Color) -> Color:
	if a is Array and a.size() >= 3:
		return Color(float(a[0]), float(a[1]), float(a[2]))
	return fallback

func _mat(c: Color, tex: Texture2D = null) -> ShaderMaterial:
	return PlaceBuilder.psx(tex, c)

func _show_part(nm: String, c: Color) -> void:
	var mi: MeshInstance3D = meshes.get("part_" + nm)
	if mi == null:
		return
	mi.visible = true
	mi.set_surface_override_material(0, _mat(c))

## o: the outfit, as the game describes it (see data/places/*.json, "look").
func dress(o: Dictionary) -> void:
	look = o
	if body == null:
		return
	for k in meshes:
		meshes[k].visible = false
	var dress: Dictionary = PlaceBuilder.models().get("dress", {})
	var wpn_cols: Dictionary = dress.get("RG_WPN", {})
	var dim = float(o.get("dim", 1.0))
	var head: bool = o.get("head", true) != false
	var more: Array = []
	if o.get("body"):
		var bk = str(o.body)
		var mi: MeshInstance3D = meshes.get("Body_" + bk)
		var info: Dictionary = PlaceBuilder.models().get("rig", {}).get("bodies", {}).get(bk, {})
		if mi:
			mi.visible = true
			var tex_of = str(info.get("texOf", bk))
			var tex = PlaceBuilder.texture("rig_%s_%s" % [tex_of, str(o.get("tex", ""))])
			if tex == null:
				var names: Array = info.get("tex", [])
				if names.size():
					tex = PlaceBuilder.texture("rig_%s_%s" % [tex_of, names[0]])
			var drop: Array = o.get("drop", []) if o.get("drop") is Array else []
			var gcol: Dictionary = o.get("gcol", {}) if o.get("gcol") is Dictionary else {}
			var groups: Array = info.get("groups", [])
			for s in min(groups.size(), mi.mesh.get_surface_count()):
				var g: Array = groups[s]
				var gname = str(g[0])
				var hidden = drop.has(gname) or (not head and (gname == "head" or gname == "Shako material"))
				if hidden:
					mi.set_surface_override_material(s, _hidden())
				elif g[2] and tex:
					mi.set_surface_override_material(s, _mat(Color(dim, dim, dim), tex))
				else:
					var c = _c(gcol.get(gname, g[1]), _c(o.get("c"), Color(0.3, 0.3, 0.3)))
					mi.set_surface_override_material(s, _mat(c * dim))
		more = (o.get("more", []) if o.get("more") is Array else []).filter(func(m): return head or not ["hat", "cap", "capband"].has(str(m[0])))
		if o.get("hat") and head:
			more.append([o.hat, o.get("hatc", [RG_HAT.r, RG_HAT.g, RG_HAT.b])])
		if o.get("wpn"):
			more.append([o.wpn, wpn_cols.get(o.wpn, [0.3, 0.3, 0.3])])
			more.append([str(o.wpn) + "_m", [RG_IRON.r, RG_IRON.g, RG_IRON.b]])
		for m in more:
			_show_part(str(m[0]), _c(m[1], Color(0.3, 0.3, 0.3)) * dim)
	else:
		var fig: MeshInstance3D = meshes.get("Figure")
		var coat = _c(o.get("c"), Color(0.3, 0.28, 0.26))
		var cols = [coat, _c(o.get("br"), Color(coat.r * 0.62 + 0.03, coat.g * 0.62 + 0.03, coat.b * 0.62 + 0.03)), RG_SKIN, RG_BOOT, RG_HAT,
			_c(o.get("wc"), Color(min(1.0, coat.r * 1.25 + 0.1), min(1.0, coat.g * 1.25 + 0.1), min(1.0, coat.b * 1.25 + 0.1))), Color(0.3, 0.3, 0.3), RG_SKIN, coat, coat]
		var fit: Variant = o.get("fit")
		if fit is Dictionary and fit.get("cols") is Dictionary:
			for k in fit.cols:
				cols[int(k)] = _c(fit.cols[k], cols[int(k)])
		if fig:
			fig.visible = true
			var slots: Array = PlaceBuilder.models().get("rig", {}).get("plain", [])
			for s in min(slots.size(), fig.mesh.get_surface_count()):
				var idx = int(str(slots[s]).substr(4))
				if idx == 7 and not head:
					fig.set_surface_override_material(s, _hidden())
				else:
					fig.set_surface_override_material(s, _mat(cols[idx] * dim))
		if fit is Dictionary and fit.get("parts") is Array:
			for q in fit.parts:
				_show_part(str(q[0]), _c(q[1], coat) * dim)
		elif o.get("skirt") != false:
			_show_part("skirt", coat * 0.92 * dim)
		if o.get("hat"):
			_show_part(str(o.hat), _c(o.get("hatc"), RG_HAT) * dim)
		if o.get("wpn"):
			_show_part(str(o.wpn), _c(wpn_cols.get(o.wpn), Color(0.3, 0.3, 0.3)) * dim)
			_show_part(str(o.wpn) + "_m", RG_IRON * dim)
		for nm in (o.get("parts", []) if o.get("parts") is Array else []):
			_show_part(str(nm), _c(wpn_cols.get(nm), Color(0.3, 0.3, 0.3)) * dim)
	scale = Vector3.ONE * 0.94 * float(o.get("s", 1.0))
	_set_stoop(float(o.get("stoop", 0.0)) if o.get("stoop") != null else 0.0)

## Old people stoop: the browser's wRigStoop, run after the animation each frame.
class Stoop extends SkeletonModifier3D:
	var k := 1.0
	var bones: Array = []      # [bone index, turn about its own x axis]
	func _process_modification() -> void:
		var sk = get_skeleton()
		if sk == null:
			return
		for b in bones:
			var j: int = b[0]
			if j < 0:
				continue
			sk.set_bone_pose_rotation(j, sk.get_bone_pose_rotation(j) * Quaternion(Vector3.RIGHT, float(b[1]) * k))

const STOOP_SIGN := 1.0
const ARM_FIX := 1.0
var _stoop: Stoop

func _set_stoop(k: float) -> void:
	if body == null:
		return
	if k <= 0.0:
		if _stoop:
			_stoop.active = false
		return
	if _stoop == null:
		var sk: Skeleton3D = body.find_children("*", "Skeleton3D", true, false)[0] if body.find_children("*", "Skeleton3D", true, false).size() else null
		if sk == null:
			return
		var joints: Array = PlaceBuilder.models().get("rig", {}).get("joints", [])
		_stoop = Stoop.new()
		# bend the back forward a little at each joint of the spine, the neck back up so the head still
		# looks ahead, and the arms back so they still hang straight down
		for q in [[1, STOOP_SIGN * 0.16], [2, STOOP_SIGN * 0.2], [3, STOOP_SIGN * 0.14], [4, -STOOP_SIGN * 0.3], [7, ARM_FIX * 0.5], [11, ARM_FIX * 0.5]]:
			var name = str(joints[q[0]]) if q[0] < joints.size() else ""
			_stoop.bones.append([sk.find_bone(name), q[1]])
		sk.add_child(_stoop)
	_stoop.k = k
	_stoop.active = true

static var _hide_mat: ShaderMaterial
func _hidden() -> ShaderMaterial:
	if _hide_mat == null:
		_hide_mat = PlaceBuilder.psx(null, Color(1, 1, 1), true, Vector2.ZERO, -1.0)
	return _hide_mat

## Play a movement by name; loops for the standing and walking ones.
func play(name: String, speed := 1.0) -> void:
	if anim == null:
		return
	if not anim.has_animation(name):
		name = "idle"
	if current != name:
		current = name
		var a = anim.get_animation(name)
		a.loop_mode = Animation.LOOP_NONE if name in ["death", "hitc", "hith", "knock", "pickup", "interact", "consume", "pshoot", "preload", "punch", "jab", "hook", "slash", "throw"] else Animation.LOOP_LINEAR
		anim.play(name, 0.16)
		if name != "walk":
			anim.seek(randf() * a.length * 0.5)
	anim.speed_scale = speed

## The default outfit for the courier: a soldier's kit in the courier's colours, the case on his chest.
static func courier_look() -> Dictionary:
	return { "body": "soldier_g", "tex": "courier", "head": true, "hat": "hat", "drop": ["Shako material", "Havresac 01", "Sabre briquet Material"],
		"more": [["case", [0.12, 0.12, 0.13]]], "c": [0.22, 0.25, 0.31] }
