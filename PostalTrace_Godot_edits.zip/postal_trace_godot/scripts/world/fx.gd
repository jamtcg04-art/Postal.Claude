class_name PlaceFX
extends Node3D
## The small living touches the browser build draws every frame (its W.FX table and the
## flickering props): chimney smoke, the swinging lantern and the window glint at Cross-Pillars,
## the tethered horses breathing and tossing their heads, fire props flickering, and the night
## fog banks drifting round the Quarter Cut's yard. Numbers are the browser's.

var file = ""
var t = 0.0
var anim: Array = []          # {node, b, pos, off, kind, ph, x}
var puffs: Array = []
var last_emit = -1.0
var lantern: Node3D
var glint: Node3D
var banks: Array = []
var _mats: Dictionary = {}

const CHIM = [Vector3(-8.48, 6.1, -4.98), Vector3(-8.48, 6.1, -2.98)]
const LANT = Vector3(1.0, 2.55, -8.25)
const WIN = Vector3(-5.95, 1.7, 3.6)
const HTOSS = -0.12
const WOOD = Color(0.24, 0.18, 0.13)
const IRON = Color(0.13, 0.12, 0.12)

static func attach(place: Node3D, file_name: String) -> PlaceFX:
	var fx = PlaceFX.new()
	fx.name = "FX"
	fx.file = file_name
	place.add_child(fx)
	fx._setup(place)
	return fx

func _mat(c: Color, lit := false, a := 1.0) -> ShaderMaterial:
	return PlaceBuilder.psx(null, c, lit, Vector2.ZERO, a)

## The browser's wCyl(r0, r1, y0, y1, seg): a cylinder between two heights.
func _cyl(r0: float, r1: float, y0: float, y1: float, seg: int, m: Material, parent: Node3D) -> MeshInstance3D:
	var c = CylinderMesh.new()
	c.bottom_radius = r0
	c.top_radius = r1
	c.height = absf(y1 - y0)
	c.radial_segments = seg
	c.rings = 1
	var mi = MeshInstance3D.new()
	mi.mesh = c
	mi.position.y = (y0 + y1) / 2.0
	mi.material_override = m
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi

var place: Node3D
var _hidden: Array = []         # Rect2s of ground freed by things the story took away
var mare: Node3D

func _setup(p: Node3D) -> void:
	place = p
	var props = place.get_node_or_null("Props")
	if props:
		for n in props.get_children():
			if not n is Node3D or not n.has_meta("model"):
				continue
			var m = str(n.get_meta("model"))
			if m == "fire" or m == "flame":
				_animate(n, "flick", 0.0)
			elif m.begins_with("cp_horse"):
				_animate(n, "horse", 0.0 if m == "cp_horse_grey" else 3.1)
	if file == "cross":
		_build_lantern()
		_stable_mare()
	if file == "market__yard":
		_build_banks()
	if file == "market":
		_market_setup()
	apply_state()

func _animate(n: Node3D, kind: String, ph: float) -> void:
	var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
	var m = str(n.get_meta("model"))
	if not sizes.has(m):
		return
	var sz: Dictionary = sizes[m]
	var mn: Array = sz.mn
	var s3: Array = sz.sz
	var off = Vector3(-(float(mn[0]) + float(s3[0]) / 2.0), -float(mn[1]), -(float(mn[2]) + float(s3[2]) / 2.0))
	var b: Basis = n.transform.basis
	var pos: Vector3 = n.transform.origin - b * off
	anim.append({node = n, b = b, pos = pos, off = off, kind = kind, ph = ph, x = pos.x})

## On the way back, Karrow's mare stands in the lane by the livery once you have brought her
## out of the back stall (the browser adds her to the layout only then).
## Where a prop stands in the layout (its footprint's centre), as the browser places it.
static func spot(n: Node3D) -> Vector3:
	var sizes: Dictionary = PlaceBuilder.models().get("sizes", {})
	var m = str(n.get_meta("model", ""))
	if not sizes.has(m):
		return n.position
	var mn: Array = sizes[m].mn
	var s3: Array = sizes[m].sz
	var off = Vector3(-(float(mn[0]) + float(s3[0]) / 2.0), -float(mn[1]), -(float(mn[2]) + float(s3[2]) / 2.0))
	return n.transform.origin - n.transform.basis * off

func _stable_mare() -> void:
	var it = {m = "cp_horse", x = -1.5, z = 3.2, h = 1.9, r = -PI / 2 + 0.3}
	mare = PlaceBuilder._prop(it, PlaceBuilder.models().get("sizes", {}))
	mare.name = "KarrowsMare"
	var props = place.get_node_or_null("Props")
	(props if props else place).add_child(mare)
	_animate(mare, "horse", 5.2)

func _cross_state() -> String:
	var id = Game.cur_id()
	if id.begins_with("back_") and Game.jsf("crossState") != null:
		return str(Data.call_fn(Game.jsf("crossState")))
	return "plain"

## Show or hide what the story decides at Cross-Pillars: the crew's horses and their rail while
## Vane holds the road (or lies dead), only the ones nobody has taken, and Karrow's mare once
## she is out. Runs on entering and whenever the place refreshes.
func apply_state() -> void:
	if file != "cross":
		return
	var d: Dictionary = Game.S.get("done", {})
	var back = Game.cur_id().begins_with("back_")
	var crew = not (_cross_state() in ["held", "burned"])
	var gone = str(d.get("hz_crew", ""))
	var show = {
		"grey": crew and gone != "grey",
		"black": crew and gone != "black" and not Data.truthy(d.get("hz_spoils")),
		"rail": crew,
		"mare": back and Data.truthy(d.get("stable")),
	}
	var area = { "grey": Rect2(7.5, -8.3, 2.2, 1.1), "black": Rect2(7.5, -6.55, 2.2, 1.1), "rail": Rect2(7.0, -7.9, 0.6, 2.0) }
	_hidden.clear()
	var props = place.get_node_or_null("Props")
	if props:
		for n in props.get_children():
			if not n is Node3D or not n.has_meta("model"):
				continue
			var m = str(n.get_meta("model"))
			var o = spot(n)
			var key = ""
			if n == mare:
				key = "mare"
			elif m == "cp_horse_grey" and absf(o.z + 7.75) < 1.2:
				key = "grey"
			elif m == "cp_horse" and absf(o.z + 6.0) < 1.2 and o.x > 6.0:
				key = "black"
			elif m == "fence" and absf(o.x - 7.3) < 0.6 and absf(o.z + 6.9) < 1.0:
				key = "rail"
			if key == "" or n.get_meta("ed_del", false):
				continue
			n.visible = show[key]
			if not show[key] and area.has(key):
				_hidden.append(area[key])
	_mare_solids(show.mare)
	# once the tavern has burned there is no door into the taproom
	var things = place.get_node_or_null("Things")
	if things:
		for m in things.get_children():
			if str(m.get_meta("kind", "")) == "door" and str(m.get_meta("to", "")) == "taproom":
				m.visible = not (back and _cross_state() == "burned")

func _mare_solids(on: bool) -> void:
	var solid = place.get_node_or_null("Solid")
	if solid == null:
		return
	for c in solid.get_children():
		if str(c.name).begins_with("MarePost"):
			solid.remove_child(c)
			c.queue_free()
	if not on:
		return
	var ry = -PI / 2 + 0.3
	for k in range(-2, 3):
		var m = Marker3D.new()
		m.name = "MarePost%d" % (k + 2)
		m.position = Vector3(-1.5 + k * 0.37 * sin(ry), 0, 3.2 + k * 0.37 * cos(ry))
		m.set_meta("r", 0.33)
		solid.add_child(m)

## Whether a solid at (x, z) belonged to something the story has taken away.
func cleared(x: float, z: float) -> bool:
	for r in _hidden:
		if r.has_point(Vector2(x, z)):
			return true
	return false

func _build_lantern() -> void:
	_cyl(0.07, 0.06, 0, 2.75, 5, _mat(WOOD, true), _at(Vector3(LANT.x, 0, LANT.z - 0.75)))
	var beam = _at(Vector3(LANT.x, 2.68, LANT.z - 0.78))
	beam.rotation.x = PI / 2
	_cyl(0.05, 0.05, 0, 0.8, 4, _mat(WOOD, true), beam)
	lantern = _at(Vector3(LANT.x, 2.66, LANT.z))
	_cyl(0.012, 0.012, -0.24, 0, 4, _mat(Color(0.15, 0.13, 0.11), true), lantern)
	_cyl(0.11, 0.03, -0.32, -0.24, 6, _mat(IRON, true), lantern)
	_cyl(0.085, 0.085, -0.6, -0.32, 6, _mat(Color(1.0, 0.78, 0.38)), lantern)
	_cyl(0.11, 0.11, -0.66, -0.6, 6, _mat(IRON, true), lantern)
	var glow = PlaceBuilder._light({x = LANT.x, z = LANT.z + 0.2, flat = true, w = 4.2, c = [0.42, 0.3, 0.13], flick = true}, 90)
	if glow:
		add_child(glow)
	glint = _at(WIN)
	_cyl(0.07, 0.02, -0.06, 0.06, 4, _mat(Color(1, 0.97, 0.85)), glint)
	glint.visible = false

func _at(p: Vector3) -> Node3D:
	var n = Node3D.new()
	n.position = p
	add_child(n)
	return n

func _inside_yard(x: float, z: float) -> bool:
	return x > 21.4 and x < 32.2 and z > -14.2 and z < 0.2

func _build_banks() -> void:
	var rng = RandomNumberGenerator.new()
	rng.seed = 127
	var k = 0
	while banks.size() < 26 and k < 400:
		k += 1
		var x = 12 + rng.randf() * 30
		var z = -27 + rng.randf() * 40
		if _inside_yard(x, z):
			continue
		var a = 0.22 + rng.randf() * 0.2
		var n = _at(Vector3(x, 0, z))
		_cyl(1, 0.85, 0, 0.5, 9, _mat(Color(0.32, 0.33, 0.36), false, snappedf(a, 0.05)), n)
		banks.append({n = n, x = x, z = z, r = 1.6 + rng.randf() * 2.2, ph = rng.randf() * TAU, sp = 0.12 + rng.randf() * 0.18})

func _process(dt: float) -> void:
	dt = minf(dt, 0.1)
	t += dt
	for a in anim:
		if not a.node.visible:
			continue
		if a.kind == "flick":
			_pose(a, 0.0, 0.0, 0.85 + 0.25 * absf(sin(t * 1000.0 / 90.0 + a.x)))
		else:
			_horse(a)
	if file == "cross":
		_smoke()
		_lantern_swing()
	if banks.size():
		_drift(dt)
	if file == "market":
		_market(dt)

func _pose(a: Dictionary, rx: float, dy: float, ysc: float) -> void:
	var b: Basis = a.b
	if ysc != 1.0:
		b = Basis(b.x, b.y * ysc, b.z)
	if rx != 0.0:
		b = b * Basis(Vector3(1, 0, 0), Vector3(0, cos(rx), sin(rx)), Vector3(0, -sin(rx), cos(rx)))
	var n: Node3D = a.node
	n.transform = Transform3D(b, a.pos + Vector3(0, dy, 0)) * Transform3D(Basis(), a.off)

## A tethered horse breathes, tosses its head now and then, and shifts its weight.
func _horse(a: Dictionary) -> void:
	var ph: float = a.ph
	var per = 6.5 + ph * 0.7
	var c = fmod(t + ph * 2.3, per)
	var rx = 0.012 * sin(t * 1.3 + ph)
	var y = 0.0
	if c < 1.0:
		var s = sin(PI * c)
		rx += HTOSS * s * (1 + 0.35 * sin(c * 18))
		y += 0.03 * s
	elif c > per * 0.55 and c < per * 0.55 + 0.45:
		y += 0.035 * absf(sin((c - per * 0.55) * 21))
	_pose(a, rx, y + 1.05 * maxf(0.0, -rx), 1.0)

## The tavern chimney: grey smoke leaning off with the wind.
func _smoke() -> void:
	if t - last_emit > 0.42:
		last_emit = t
		for i in CHIM.size():
			if i > 0 and randf() < 0.5:
				continue
			var p = _at(CHIM[i] + Vector3((randf() - 0.5) * 0.15, 0, (randf() - 0.5) * 0.15))
			var mi = _cyl(0.5, 0.36, -0.28, 0.3, 7, _mat(Color(0.42, 0.42, 0.45)), p)
			puffs.append({n = p, mi = mi, o = p.position, b = t, life = 3.6 + randf() * 1.2, s = 0.7 + randf() * 0.5})
	var keep: Array = []
	for p in puffs:
		var a = (t - p.b) / p.life
		if a >= 1.0:
			p.n.queue_free()
			continue
		keep.append(p)
		var r = (0.2 + 0.6 * a) * p.s * ((1 - a) / 0.3 if a > 0.7 else 1.0)
		var g = snappedf(0.42 - 0.14 * a, 0.02)
		p.mi.material_override = _mat(Color(g, g, g + 0.03))
		var n: Node3D = p.n
		n.position = p.o + Vector3(a * 1.1, a * 2.6, -a * 0.4)
		n.rotation = Vector3(0, a * 2 + p.s, 0)
		n.scale = Vector3(maxf(r, 0.001), maxf(r * 0.8, 0.001), maxf(r, 0.001))
	puffs = keep

func _lantern_swing() -> void:
	if lantern:
		lantern.rotation = Vector3(0.16 * sin(t * 1.7) + 0.06 * sin(t * 0.43 + 1), 0, 0.04 * sin(t * 1.1))
	if glint:
		# Dace's piece at the tavern window: a glint of the barrel now and then while Vane holds the road
		var c = fmod(t, 8.5)
		glint.visible = _road_held() and (c < 0.1 or (c > 0.26 and c < 0.34))
		glint.rotation.y = t

var _held_t = -9.0
var _held = true
func _road_held() -> bool:
	if t - _held_t < 1.0:
		return _held
	_held_t = t
	_held = true
	var id = Game.cur_id()
	if id.begins_with("back_") and Game.jsf("crossState") != null:
		var st = str(Data.call_fn(Game.jsf("crossState")))
		_held = not (st in ["dead", "held", "burned"])
	return _held

## Low banks of night fog drift through the lanes, never into the yard itself.
func _drift(dt: float) -> void:
	for b in banks:
		b.x += b.sp * dt
		if b.x > 44:
			b.x = 10
		var n: Node3D = b.n
		n.visible = not _inside_yard(b.x, b.z)
		var br = b.r * (1 + 0.12 * sin(t * 0.4 + b.ph))
		n.position = Vector3(b.x, 0.05 + 0.15 * sin(t * 0.3 + b.ph), b.z)
		n.rotation.y = b.ph
		n.scale = Vector3(br, 0.9 + 0.3 * sin(t * 0.25 + b.ph), br)

# ================================================================ Linden on its feet
# Townsfolk walk the streets between the places people go; come close and they slow, look at you,
# and sometimes say something, then go on about their business. Goodwife Marl walks her stalls.
# (The browser's mkWalkers and Marl's walk, with its numbers.)

var walkers: Array = []
var spots: Array = []
var marl: Dictionary = {}
var say_label: Label3D
const MARL_STOPS = [[7.9, 30.6, 0.0], [5.0, 27.6, -1.4], [7.6, 19.6, PI], [4.6, 22.2, -1.2], [9.4, 28.4, 1.4]]

func _world() -> Node:
	return place.get_parent() if place else null

func _market_setup() -> void:
	var data: Variant = Data.js.globals.vars.get("MK_WALKERS")
	var holder = place.get_node_or_null("Bystanders")
	if data is Array and holder:
		for k in data.size():
			var w: Dictionary = Game._plain(data[k])
			var m = Marker3D.new()
			m.name = "Walker_%d" % k
			m.set_meta("kind", "extra")
			m.set_meta("walker", true)
			holder.add_child(m)
			walkers.append({ k = k, w = w, node = m, route = [], goal = null, pause = randf() * 3.0, stop_t = 0.0, seen_t = -99.0, speak = false, held = null, block_t = 0.0, was_goal = null, placed = false, want = "idle", holds = false })
	say_label = Label3D.new()
	say_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	say_label.no_depth_test = true
	say_label.fixed_size = true
	say_label.pixel_size = 0.0022
	say_label.font_size = 24
	say_label.outline_size = 8
	say_label.width = 420
	say_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	say_label.modulate = Color(0.85, 0.85, 0.8)
	say_label.visible = false
	add_child(say_label)
	var ph = place.get_node_or_null("People")
	if ph:
		for n in ph.get_children():
			if str(n.get_meta("id", "")) == "marl":
				marl = { node = n, st = "", t = 0.0 }

## A walker's look: their coat from their hue, and the clothes the browser's code gives them.
func _walker_look(e: Dictionary) -> void:
	var w: Dictionary = e.w
	var n: Node3D = e.node
	var hue = float(w.get("hue", 0))
	var hh = hue + 4.2
	var coat = [0.5 + 0.5 * cos(hh), 0.5 + 0.5 * cos(hh - 2.1), 0.5 + 0.5 * cos(hh + 2.1)].map(func(v): return 0.14 + v * 0.18)
	var id = "walker%d" % e.k
	var h = int(Bridge.call_js("wRigHash", [id + JsLite.num_str(hue) + JsLite.num_str(roundf(n.position.x * 10.0))]))
	var p = { "id": id, "hue": hue, "walkAI": true }
	if w.get("old"): p["rgOld"] = true
	if w.get("female"): p["rgFemale"] = true
	if w.get("item"): p["rgItem"] = w.item
	if w.get("carry"): p["carry"] = true
	var o = { "c": coat, "head": true, "hat": null if h % 4 == 0 else "hat" }
	var f: Variant = PlaceEdits.fit_for(p, coat, h, false, "market")
	if f is Dictionary:
		o["fit"] = f
		if f.get("s") != null: o["s"] = f.s
		if f.get("stoop"): o["stoop"] = f.stoop
		if f.has("hat"):
			o["hat"] = f.hat
			o["hatc"] = f.get("hatc")
		e.holds = bool(f.get("holds", false))
	var idle = ["idle", "arms", "idle", "talk", "idle", "arms", "idle"][h % 7]
	if e.holds and idle in ["arms", "talk"]:
		idle = "idle"
	e.want = idle
	n.set_meta("look", { "want": idle, "o": o })

func _fig(n: Node3D) -> Figure:
	for c in n.get_children():
		if c is Figure and not c.is_queued_for_deletion():
			return c
	return null

func _market(dt: float) -> void:
	var W = _world()
	if W == null or not W.active or W.place != place:
		return
	var frozen: bool = W.editing
	if walkers.size():
		if spots.is_empty():
			# the walkable town: every open spot on a 2m lattice inside the streets, well clear of walls and stalls
			for x in range(-24, 27, 2):
				for z in range(-38, 41, 2):
					if not W._blocked(float(x), float(z), 1.1):
						spots.append(Vector2(x, z))
			if spots.size() < 10:
				for e in walkers:
					e.node.visible = false
				walkers.clear()
				return
			for e in walkers:
				var s0: Vector2 = spots[int(floor((e.k + 0.5) / walkers.size() * spots.size()))]
				e.node.position = Vector3(s0.x, 0, s0.y)
				e.node.rotation.y = randf() * TAU
				_walker_look(e)
			W.refresh()
		if not frozen:
			for e in walkers:
				_walk_one(W, e, dt)
	if not marl.is_empty() and not frozen:
		_marl(W, dt)

func _walk_one(W: Node, e: Dictionary, dt: float) -> void:
	var n: Node3D = e.node
	var pl: Vector3 = W.pl
	var d = Vector2(pl.x - n.position.x, pl.z - n.position.z).length()
	var fig = _fig(n)
	if d < 1.9 and e.stop_t == 0.0 and t - e.seen_t > 20.0:
		e.stop_t = t
		e.seen_t = t
		e.speak = randf() < 0.65 and not walkers.any(func(o): return o != e and o.stop_t > 0.0)
		e.held = e.goal
		e.goal = null
		n.rotation.y = atan2(pl.x - n.position.x, pl.z - n.position.z)
		if fig: fig.play("yes" if randf() < 0.5 else "talk")
		if e.speak:
			var lines: Variant = Bridge.call_js("mkWalkLines", [e.w])
			if lines is Array and lines.size():
				var l: Variant = lines[randi() % lines.size()]
				say_label.text = str(l.get("text", "")) if l is Dictionary else str(l)
				say_label.visible = true
				e["saying"] = true
	if e.stop_t > 0.0:
		var want = atan2(pl.x - n.position.x, pl.z - n.position.z)
		n.rotation.y += wrapf(want - n.rotation.y, -PI, PI) * minf(1.0, dt * 4.0)
		if e.get("saying"):
			say_label.position = n.global_position + Vector3(0, 2.3, 0)
		if t - e.stop_t > 2.6 or d > 3.2:
			e.stop_t = 0.0
			if e.get("saying"):
				say_label.visible = false
				e["saying"] = false
			e.goal = e.held
			e.held = null
			if e.goal == null:
				_leg(e)
		elif fig and t - e.stop_t > 1.2:
			fig.play(e.want)
		return
	# a person standing in the way: wait for them to pass, rather than walk through
	if e.goal != null and d < 0.8:
		e.block_t += dt
		if e.block_t < 1.5:
			e.was_goal = e.goal
			e.goal = null
	if e.goal == null and e.was_goal != null and d > 1.0:
		e.goal = e.was_goal
		e.was_goal = null
		e.block_t = 0.0
	if e.goal == null and e.was_goal == null:
		e.pause -= dt
		if e.pause <= 0.0:
			e.pause = 2.0
			_next(W, e)
	if e.goal != null:
		var g: Vector2 = e.goal
		var gv = Vector2(g.x - n.position.x, g.y - n.position.z)
		var sp = float(e.w.get("sp", 1.2))
		var st = sp * dt
		if gv.length() <= st or gv.length() < 0.02:
			n.position = Vector3(g.x, 0, g.y)
			e.goal = null
			_leg(e)
		else:
			n.position += Vector3(gv.x, 0, gv.y).normalized() * st
			n.rotation.y = atan2(gv.x, gv.y)
		if fig: fig.play("walk", clampf(sp / 1.45, 0.6, 2.1))
	elif fig:
		fig.play(e.want)

## A destination 8 to 30 metres away, walked by the same paths you would take.
func _next(W: Node, e: Dictionary) -> void:
	var n: Node3D = e.node
	var at = Vector2(n.position.x, n.position.z)
	for i in 6:
		var s: Vector2 = spots[randi() % spots.size()]
		var dd = s.distance_to(at)
		if dd < 8.0 or dd > 30.0:
			continue
		var r: Array = W._path(at, s + Vector2(randf() - 0.5, randf() - 0.5))
		if r.size():
			e.route = r.duplicate()
			break
	_leg(e)

func _leg(e: Dictionary) -> void:
	if e.route.is_empty():
		e.goal = null
		e.pause = 1.5 + randf() * 5.0
		return
	e.goal = e.route.pop_front()

## Goodwife Marl leaves her board now and then, goes up or down Fountain Street to one of her other
## stalls, stands at it a while, and comes back. If you come close, or speak to her, she stops.
func _marl(W: Node, dt: float) -> void:
	var n: Node3D = marl.node
	if not is_instance_valid(n) or not n.visible:
		return
	if marl.st == "":
		marl.home = [n.position.x, n.position.z, n.rotation.y, n.get_meta("ax") if n.has_meta("ax") else null, n.get_meta("az") if n.has_meta("az") else null]
		marl.st = "home"
		marl.t = t + 6.0 + randf() * 8.0
		marl.stops = MARL_STOPS.filter(func(q): return not W._blocked(q[0], q[1], 0.35))
	var fig = _fig(n)
	var pl: Vector3 = W.pl
	var near = Vector2(pl.x - n.position.x, pl.z - n.position.z).length() < 1.8
	var talking = W.input_locked or (W.hover is Dictionary and W.hover.get("node") == n)
	if marl.st != "home":
		# the blocker that keeps you out of her place only stands while she is in it
		var hx = float(marl.home[0]); var hz = float(marl.home[1])
		W.solids = W.solids.filter(func(s): return not (s.has("r") and absf(float(s.r) - 0.35) < 1e-3 and ((absf(s.x - hx) < 0.05 and absf(s.z - hz) < 0.05) or Vector2(s.x - n.position.x, s.z - n.position.z).length() < 0.4)))
	if near or talking:
		if fig and marl.st == "walk": fig.play("idle")
		return
	if marl.st == "home" or marl.st == "stop":
		if t < marl.t:
			return
		if marl.st == "home" and marl.stops.size():
			marl.q = marl.stops[randi() % marl.stops.size()]
			_marl_go(W, Vector2(marl.q[0], marl.q[1]), "stop")
		elif marl.st == "stop":
			_marl_go(W, Vector2(marl.home[0], marl.home[1]), "home")
		else:
			marl.t = t + 10.0
		return
	if marl.st == "walk":
		if marl.route.is_empty():
			marl.st = marl.then
			return
		var w: Vector2 = marl.route[0]
		var dv = Vector2(w.x - n.position.x, w.y - n.position.z)
		var st = 1.15 * dt
		n.rotation.y = atan2(dv.x, dv.y)
		if dv.length() <= st:
			n.position = Vector3(w.x, n.position.y, w.y)
			marl.route.pop_front()
		else:
			n.position += Vector3(dv.x, 0, dv.y).normalized() * st
		_marl_ax(W, n, n.position.x + sin(n.rotation.y), n.position.z + cos(n.rotation.y))
		if fig: fig.play("walk", clampf(1.15 / 1.45, 0.6, 2.1))
		if marl.route.is_empty():
			marl.st = marl.then
			if marl.st == "stop":
				n.rotation.y = float(marl.q[2])
				marl.t = t + 5.0 + randf() * 4.0
			else:
				n.rotation.y = float(marl.home[2])
				_marl_ax(W, n, marl.home[3], marl.home[4])
				marl.t = t + 14.0 + randf() * 12.0
				W._read_solids()
				W.solids.append({ "x": n.position.x, "z": n.position.z, "r": 0.35 })
			if fig: fig.play("idle")

func _marl_go(W: Node, to: Vector2, then: String) -> void:
	var n: Node3D = marl.node
	var r: Array = W._path(Vector2(n.position.x, n.position.z), to)
	marl.route = r.duplicate() if r.size() else [to]
	marl.then = then
	marl.st = "walk"

## Where you stand to talk to her goes with her.
func _marl_ax(W: Node, n: Node3D, ax: Variant, az: Variant) -> void:
	if ax == null:
		n.remove_meta("ax"); n.remove_meta("az")
	else:
		n.set_meta("ax", ax); n.set_meta("az", az)
	for k in W.picks:
		if k.node == n:
			k.ax = ax
			k.az = az
