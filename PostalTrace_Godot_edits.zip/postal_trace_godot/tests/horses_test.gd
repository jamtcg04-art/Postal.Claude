extends SceneTree
## The horses at Cross-Pillars follow the story as in the browser: Karrow's mare stands in the
## lane on the way back once she is out of the stall, and the crew's horses go when taken.
##   godot --headless --path . -s res://tests/horses_test.gd
var w
var f := 0
var results: Array = []
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func node_vis(model: String, x: float, z: float) -> bool:
	for n in w.place.get_node("Props").get_children():
		var o = w.fx.spot(n)
		if str(n.get_meta("model", "")) == model and absf(o.x - x) < 1.2 and absf(o.z - z) < 1.2:
			return n.visible
	return false
func blocked_at(x: float, z: float) -> bool:
	return w._blocked(x, z, 0.1)
func visit(route_id: String, done: Dictionary) -> void:
	var G = root.get_node("Game")
	G.begin_run({ "trait": "steady" })
	G.S.route = [route_id]; G.S.idx = 0
	for k in done: G.S.done[k] = done[k]
	if w.place:
		w.place.queue_free(); w.place = null
	w.file = ""
	w.enter("cross")
func _process(_d: float) -> bool:
	f += 1
	if f == 2:
		w = load("res://scripts/world/world.gd").new()
		root.add_child(w)
		return false
	if f < 4:
		return false
	visit("cross", {})
	check("first visit: no mare in the lane", not w.fx.mare.visible)
	check("first visit: both crew horses at the rail", node_vis("cp_horse_grey", 8.6, -7.75) and node_vis("cp_horse", 8.6, -6.0))
	check("the horses move (breathing, tossing)", w.fx.anim.filter(func(a): return a.kind == "horse").size() == 3)
	visit("back_cross", { "stable": true })
	check("going back with the mare out: she stands in the lane", w.fx.mare.visible and not (w.fx.mare is MeshInstance3D))
	check("and she is in the way", blocked_at(-1.5, 3.2))
	visit("back_cross", {})
	check("going back without her: the lane is empty", not w.fx.mare.visible and not blocked_at(-1.5, 3.2))
	visit("cross", { "hz_crew": "grey" })
	check("the grey taken: gone from the rail", not node_vis("cp_horse_grey", 8.6, -7.75) and node_vis("cp_horse", 8.6, -6.0))
	check("and its ground is free", not blocked_at(8.6, -7.75))
	visit("cross", { "hz_spoils": true })
	check("the black taken as spoils: gone", not node_vis("cp_horse", 8.6, -6.0))
	w.place.queue_free(); w.place = null; w.file = ""
	w.enter("market__yard")
	check("fires flicker", w.fx.anim.filter(func(a): return a.kind == "flick").size() > 0)
	check("fog drifts round the yard", w.fx.banks.size() == 26)
	for r in results: print(r)
	print("HORSES: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
	return true
