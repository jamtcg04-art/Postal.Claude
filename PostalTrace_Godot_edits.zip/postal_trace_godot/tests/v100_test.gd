extends SceneTree
## The opening at Redoubt Nine (the lieutenant walks out to you, then speaks), the signal hut at
## Hob's Cutting, going round a meeting, the pace note, and the courier's record for Malice Gaol.
##   godot --headless --path . -s res://tests/v100_test.gd
var main
var G
var f := 0
var results: Array = []
var t0 := 0
func check(name: String, ok: bool, note := "") -> void:
	results.append(("PASS " if ok else "FAIL ") + name + ("  " + note if note != "" else ""))
func texts(n: Node, out: Array) -> Array:
	if n is Button: out.append(n.text)
	elif n is RichTextLabel: out.append(n.get_parsed_text())
	elif n is Label: out.append(n.text)
	elif n is TextEdit: out.append(n.text)
	for c in n.get_children(): texts(c, out)
	return out
func page_text() -> String:
	return "\n".join(PackedStringArray(texts(main.page, [])))
func press(label: String) -> bool:
	for b in _buttons(main.page, []):
		if label in b.text and not b.disabled:
			b.pressed.emit()
			return true
	return false
func _buttons(n: Node, out: Array) -> Array:
	if n is Button: out.append(n)
	for c in n.get_children(): _buttons(c, out)
	return out
func choose(label: String) -> bool:
	for c in main.choices:
		var tx := "\n".join(PackedStringArray(texts(c[0], [])))
		if label in tx and not c[2]:
			c[1].call()
			return true
	return false
func Bridge_call(n: String, a: Array) -> Variant:
	return root.get_node("Bridge").call_js(n, a)
func _initialize():
	main = load("res://scenes/main.tscn").instantiate(); root.add_child(main)
func _process(_d):
	f += 1
	if f > 900:
		for r in results: print(r)
		print('V100: gave up at frame ', f)
		return true
	if f == 3:
		G = root.get_node("Game")
		main.Game_begin()
		main.intro(0)
		check("the opening is three pages of clay now", (G.T("INTRO_PAGES") as Array).size() == 3)
		main.intro(2)
		press("Take the first step")
		return false
	if f == 5:
		check("the road starts at Redoubt Nine, then the signal hut", G.S.route.slice(0, 3) == ["redoubt", "wirehut", "cross"], str(G.S.route.slice(0, 4)))
		var tx := page_text()
		check("Redoubt Nine is a place with people in it", "Redoubt Nine" in tx and "Lieutenant Ashworth" in tx and "Orderly Fenn" in tx)
		check("and you are standing in it in 3D", main.world.file == "redoubt" and main.world_view.visible)
		check("the lieutenant's scene is under way", main.world.in_cut())
		if not main.world.figures.has("ashworth"): return false
		var m: Node3D = main.world.figures["ashworth"].get_parent()
		check("he starts by the dugout", Vector2(m.position.x, m.position.z).distance_to(Vector2(-5.4, -6.0)) < 0.2)
		return false
	if f > 5 and f < 420 and main.world.in_cut():
		main.world._process(0.05)
		return false
	if f > 5 and f < 425 and t0 == 0:
		t0 = f
		var m: Node3D = main.world.figures["ashworth"].get_parent()
		check("he walks over to you", Vector2(m.position.x, m.position.z).distance_to(Vector2(1.3, 3.7)) < 0.1, str(m.position))
		var tx := page_text()
		check("and then he speaks", "TALKING" in tx.to_upper() and "Ashworth" in tx, tx.substr(0, 120))
		return false
	if t0 > 0 and f == t0 + 2:
		# through the conversation to the handover
		var ok = choose("I will take it")
		check("you take the case from him", ok)
		return false
	if t0 > 0 and f == t0 + 3:
		choose("Look around you")
		return false
	if t0 > 0 and f == t0 + 4:
		var tx := page_text()
		check("the scene's choices are how you leave", "relieved, and ashamed of it" in tx and "Go numb" in tx, tx.substr(0, 200))
		var hrs = int(G.S.hrs)
		choose("relieved, and ashamed of it")
		check("relieved: Duty +1", int(G.S.duty) == 1)
		check("the Cockade speaks for the first time", G.S.vq.any(func(q): return "clears its throat" in str(q)) or "clears its throat" in page_text())
		return false
	if t0 > 0 and f == t0 + 5:
		press("Continue")
		return false
	if t0 > 0 and f == t0 + 6:
		var tx := page_text()
		check("leaving the redoubt starts the clock and costs nothing", int(G.S.hrs) == 0 and "The clock starts" in tx, str(G.S.hrs) + " " + tx.substr(0, 300))
		check("the road shows the pace", "72 hours left" in tx and "stops to Fort Malice" in tx)
		choose("Go on")
		return false
	if t0 > 0 and f == t0 + 7:
		var tx := page_text()
		check("the signal hut at Hob's Cutting", G.S.route[G.S.idx] == "wirehut" and "Linesman Quill" in tx)
		check("the Wire's passive check is rolled there", G.S.perc.has("wirehut"))
		check("in 3D too", main.world.file == "wirehut")
		G.S.talked["wirehut:linesman"] = true
		main.scene()
		return false
	if t0 > 0 and f == t0 + 8:
		var ws = int(G.S.done.get("weir_short", 0))
		G.on_roll = func(m, r): r.a = 6; r.b = 6; r.ok = true; r.total = 12 + int(m.tot)
		var ok = choose("splice the river line")
		check("you can help splice the line", ok)
		return false
	if t0 > 0 and f == t0 + 9:
		check("splicing marks the pole road (two long marches an hour shorter)", int(G.S.done.get("weir_short", 0)) == 2 and G.S.done.get("wh_spliced") == true, str(G.S.done.get("weir_short")))
		check("and leaves a Tin Thought", G.S.loose.has("pole_road"))
		G.on_roll = Callable()
		press("Continue")
		return false
	if t0 > 0 and f == t0 + 10:
		choose("Go on")
		return false
	if t0 > 0 and f == t0 + 11:
		# on to the first road meeting after Cross-Pillars: the road offers to go round it
		G.S.idx = 3; G.S.seen = 3
		var nxt: String = G.S.route[3]
		main.road([])
		var tx := page_text()
		check("the road offers to go round a meeting", "by the back lanes" in tx, nxt)
		var n0: int = G.S.route.size()
		press("by the back lanes")
		check("going round takes it off the road", G.S.route.size() == n0 - 1 and G.S.skipped.has(nxt))
		return false
	if t0 > 0 and f == t0 + 12:
		# the sky-fire: the first night on the road, once
		G.S.hrs = 15
		G.S.idx = 4
		var ws = int(G.S.done.get("weir_short", 0))
		set_meta("ws", ws)
		Bridge_call("roadHook", [false, []])
		var tx := page_text()
		check("the sky-fire comes on the first night", "sky burned" in tx and G.S.done.get("storm_seen") == true, tx.substr(0, 120))
		check("and the voices argue about it", "The Cockade" in tx or "Cockade" in tx or "It is the rain" in tx)
		choose("Walk on by the light of it")
		return false
	if t0 > 0 and f == t0 + 13:
		check("walking by its light shortens the next march", int(G.S.done.get("weir_short", 0)) == int(get_meta("ws")) + 1)
		var hooked = Bridge_call("roadHook", [false, []])
		check("it only happens once", not G.S.done.has("storm_twice") and not ("sky burned" in page_text() and hooked == true))
		G.S.done["gseen_wirehut_linesman_cut"] = true
		G.S.inv.append("wirecopy")
		G.S.done["storm_heard"] = true
		return false
	if t0 > 0 and f == t0 + 14:
		var keep: int = G.S.idx
		G.S.idx = 0
		main.talk(1)
		check("Orderly Fenn has a conversation of his own", "Fenn" in page_text() and "TALKING" in page_text().to_upper())
		G.S.idx = keep
		G.S.out["mill"] = { "i": 0, "ok": true }
		G.S.done["cp_report"] = true
		G.S.fights = [{ "t": "The hunting party", "foe": "The provost’s riders", "res": "won", "crown": true }]
		main.ending("depot")
		return false
	if t0 > 0 and f == t0 + 15:
		var tx := page_text()
		check("the ending shows what the Crown heard", "WHAT THE CROWN HEARD" in tx.to_upper() and "reached the Provost-Marshal" in tx, "")
		check("and that the courier fought the provost's men", "against the Crown’s own provost men" in tx)
		check("and offers the record to Malice Gaol", "MALICE GAOL" in tx and main.legacy_code.begins_with("PTL1:"))
		var j = JSON.parse_string(FileAccess.get_file_as_string("user://legacy.json"))
		check("the record is saved for Malice Gaol", j is Dictionary and j.ending == "depot" and j.allegiance in ["crown", "torn", "valley"] and j.reports.size() >= 3, str(j.get("allegiance") if j is Dictionary else j))
		var back = JSON.parse_string(Marshalls.base64_to_utf8(main.legacy_code.substr(5)))
		check("its code reads back as the same record", back is Dictionary and back.ending == "depot")
		check("the record carries the linesman's copy and the sky-fire for Malice", j.clues.cut == true and j.clues.copy == true and j.storm.heard == true and j.relay is Dictionary)
		check("the Third Battery and the skipped meeting reach the ending", "went round 1 place" in tx)
		for r in results: print(r)
		print("V100: %d/%d" % [results.filter(func(r): return r.begins_with("PASS")).size(), results.size()])
		return true
	return false
