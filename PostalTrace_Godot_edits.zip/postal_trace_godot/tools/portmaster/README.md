# The Postal Trace on a handheld (PortMaster)

Built for the Anbernic RG35XX Plus running muOS; any PortMaster firmware on an arm64 handheld should work.

## Install (muOS)

1. Open PortMaster once on the handheld (Applications > PortMaster) with Wi-Fi on, so it sets itself up.
2. Copy `postaltrace.zip` (do not unzip it) to the SD card's `MUOS/PortMaster/autoinstall/` folder.
3. Open PortMaster again. It installs the game, which then shows under Ports as "The Postal Trace".
4. The first start downloads PortMaster's Godot 4.3 and Weston runtimes, so keep Wi-Fi on the first time.

KNULLI: the autoinstall folder is `/userdata/system/.local/share/PortMaster/autoinstall/`.

Saves and settings stay in the port's folder (`postaltrace/conf/`). Save files and save codes move between
this, the desktop build and the browser build (Menu > Save to a file / Copy save code).

## Controls

| Button | In the text | Walking in a place |
|--|--|--|
| D-pad | move between options | walk |
| A | pick | talk to / look at what is marked |
| B | back, close a page | hold to run; tap for the text |
| X | walk in the place | back to the text |
| Y | hear the waiting voice | hear the waiting voice |
| L1 / R1 | scroll the text | turn the view |
| L2 / R2 | scroll the text | mark the next person or thing |
| Select | Character, Tin Thoughts, Satchel, Journal (and the dice, with living dice) in turn | same |
| Select + L1/R1 | | zoom |
| Start | menu | menu |
| Select + Start | quit (PortMaster) | |

If A goes back and B picks, Menu > Controls… > "A and B: swapped".
Menu > Detail: Light (the default here) runs at 30 frames a second to save the battery.
If the 3D is too slow, Menu > 3D places: off plays the whole game from the text.

## RG35XX 2024 and other handhelds without Wi-Fi

The game is the same on the RG35XX 2024 (same chip, memory and screen as the Plus), but PortMaster cannot fetch its
runtimes there. Before the first start, download `godot_4.3.squashfs` and `weston_pkg_0.2.squashfs` from
https://portmaster.games/runtimes.html on a computer and copy them to the SD card's `MUOS/PortMaster/libs/` folder.
(Or install PortMaster with Install.Full.PortMaster.sh, which brings every runtime.)

## Building the zip

From the project folder, with Godot 4.3 on your PATH: `tools/portmaster/package.sh` (writes `build/postaltrace.zip`).
The pack must be exported by Godot **4.3**, to match PortMaster's godot_4.3 runtime.
