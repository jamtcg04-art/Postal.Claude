#!/bin/bash
# Export the game pack and put together the PortMaster zip: build/postaltrace.zip
set -e
cd "$(dirname "$0")/../.."
GODOT=${GODOT:-godot}
mkdir -p build/pm/postaltrace
"$GODOT" --headless --export-pack "Handheld (Linux ARM64, PortMaster)" build/pm/postaltrace/postaltrace.pck
cp "tools/portmaster/The Postal Trace.sh" build/pm/
chmod +x "build/pm/The Postal Trace.sh"
cp tools/portmaster/postaltrace.gptk tools/portmaster/port.json tools/portmaster/gameinfo.xml tools/portmaster/README.md build/pm/postaltrace/
[ -f tools/portmaster/screenshot.png ] && cp tools/portmaster/screenshot.png build/pm/postaltrace/
rm -f build/postaltrace.zip
(cd build/pm && zip -qr ../postaltrace.zip "The Postal Trace.sh" postaltrace)
echo "build/postaltrace.zip"
