# Publishing the browser build

These three files go into the Postal Trace artifact (3cd3e7dd-c8a8-44df-917b-406d3703caf0).
Everything else it needs (sounds, music, the 3D packs in assets/) is already there.

| File here | Served as |
|---|---|
| index.html | index.html (replaces the game) |
| gaol.html | gaol.html (Malice Gaol, new second page) |
| assets/gaol3d.js | assets/gaol3d.js (Malice Gaol's 3D, new) |

From a new chat or Claude Code with these files attached, ask Claude to publish them to that artifact
with publish_files in patch mode (the other files stay). If the artifact is shared publicly, set it to
"Only you" first, publish, then share again.

Both pages share one site, so Malice Gaol can read the courier's record (localStorage key pt_legacy)
that The Postal Trace writes at every ending. Before a road is finished, Malice Gaol's title screen is
locked, with a box to paste a courier record code (the Godot build gives one at its endings).
Existing Malice Gaol saves from the separate artifact do not carry over (different site); its old
artifact (492fd528) can stay up or be retired.
