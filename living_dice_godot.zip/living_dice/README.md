# Living dice for the Godot build

Drop the `living_dice` folder into the project (for example `res://living_dice/`). Both scripts use `class_name`, so `LivingDice` and `DiceRing` are available everywhere without an autoload.

The rules and data shape match the browser build exactly. The state lives in the run state as `ld` (the browser's `S.ld`), so the shared save file carries it either way. If `ld` is missing or `null`, living dice are off and everything plays as before.

## The Postal Trace

1. **Character screen.** Below "Which road?", add a "The dice" section: *Ordinary dice* / *Living dice*. With Living on, show three toggles: *Snowball rule*, *Lock rule* and *Hard mode: blank dice*. On "Begin the road":
   `state.ld = LivingDice.postal_start({"on": on, "snow": snow, "lock": lock, "blank": blank})`
2. **Odds on check tags.** Where the odds percentage is worked out:
   `if LivingDice.is_on(state.ld): return LivingDice.odds(state.ld, {"tot": m.tot, "dc": m.dc})`
3. **Rolling a check.** Where 2d6 is thrown for a skill check:
   `if LivingDice.is_on(state.ld): r = LivingDice.roll(state.ld, {"tot": m.tot, "dc": m.dc}, state.hp)`
   Then apply `r.fx` (`st`, `xp`, `hp`) and show the chips. Show `LivingDice.verdict(r, normal_text)` as the verdict, and `r.note` under the roll. `r.a` and `r.b` are the face values shown on the two dice.
4. **Dice bar.** On any screen whose choices include a check, put a "Dice in hand" button above the choices. It opens a panel with each die drawn as an unfolded cube (net order: top 0; left 1, front 2, right 4, back 3; bottom 5). With the lock rule on, tapping a face calls `LivingDice.toggle_lock(die, face_index)`. With more than two dice, "Hold in left/right hand" calls `LivingDice.hold(ld, side, die_index)`. Refresh the check odds afterwards.
5. **Dev mode only:** in the dice panel, add the buttons *Add The Blank*, *Add the Hangman's Die* and *Reset every face*, which call `LivingDice.dev_add(ld, "blank" | "hang" | "reset")`.

Other uses of plain d6 stay as they are: the Wire perception check, fights and the assessment roll.

## Malice Gaol

1. **Character screen ("What the Crown made of you").** Add the same dice section. On "Go on":
   `state.ld = LivingDice.gaol_start({...})`
2. **Odds, rolls and the dice bar:** the same as Postal steps 2 to 4. In dialogue, the bar is how the player switches dice before choosing a check.
3. **Jory Lamb** joins the yard's people list only while `LivingDice.is_on(state.ld)`. His dialogue (text in the browser build's `NPC.jory`) offers:
   - *Show me the game* → the ring screen: pick one of your dice, then a small stake (1 tobacco) or a big stake (3). Call `DiceRing.play(ld, die_index, stake, day)` and add `.tob` to Tobacco. Disable both stakes once `DiceRing.won_today(ld, day) >= 6`.
   - *Who's trading dice?* → `DiceRing.offers(ld, day)` gives three trade offers. `DiceRing.price(your_die, t)` is the tobacco you pay (positive) or get back (negative). `DiceRing.trade(ld, die_index, t, day)` makes the swap and returns the tobacco change.
   - *What's that in your cheek?* (until you own it) → buy the Hangman's Die with `DiceRing.buy_hangman(ld)` (−5 tobacco), or throw Jory for it with `DiceRing.throw_for_hangman(ld)`.
   - *Got anything stranger?* (until you own it) → buy The Blank with `DiceRing.buy_blank(ld)` (−1 tobacco).
