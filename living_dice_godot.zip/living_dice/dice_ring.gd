## Jory Lamb's dice ring on the yard step (Malice Gaol, only with living dice on).
## Pure logic over the same S.ld dictionary as LivingDice; the game shows the screens
## and applies the tobacco changes it returns. Rules match the browser build.
class_name DiceRing
extends RefCounted

const DAILY_CAP := 6   # Jory stops paying out after 6 tobacco to one prisoner in a day

const TRADE := [
	{"n": "A debtor’s worn die", "f": [2, 2, 3, 4, 5, 5], "who": "a debtor from the common side", "note": "Rubbed smooth in a nervous palm. The ones and sixes have worn toward the middle."},
	{"n": "A deserter’s lucky die", "f": [1, 3, 3, 4, 4, 7], "who": "a deserter on the circle", "note": "Carried out of Redoubt Nine. Somebody notched the six into a seven with a nail."},
	{"n": "A forger’s cut die", "f": [0, 2, 3, 4, 5, 8], "who": "one of Tobit’s old customers", "note": "Shaved and re-inked by somebody with very steady hands. A big face, and a bad one."},
	{"n": "A chorister’s dull die", "f": [3, 3, 3, 4, 4, 4], "who": "a boy from the chapel detail", "note": "Thrown so carefully for so long that it hardly does anything any more. Safe as a hymn."},
	{"n": "A drowned man’s die", "f": [-2, 1, 3, 4, 6, 9], "who": "a river-clan prisoner", "note": "Pulled out of the Tanner along with its owner. It has seen a great deal of luck, both ways."},
	{"n": "A turnkey’s confiscated die", "f": [1, 2, 4, 4, 5, 6], "who": "a runner who should not have it", "note": "Taken off a man on the Row and sold back down it. A little better than honest."},
]

static func house(ld: Dictionary) -> Dictionary:
	if not ld.has("house"):
		ld["house"] = LivingDice.make_die("Jory’s house die", LivingDice.STD)
	return ld["house"]

static func won_today(ld: Dictionary, day: int) -> int:
	return int(ld.get("won", {}).get(str(day), 0))

## One round: your die `di` against the house die. Returns {res: win/lose/tie, me, him, tob, note}.
## tob is the change to apply to Tobacco.
static func play(ld: Dictionary, di: int, stake: int, day: int) -> Dictionary:
	var d: Dictionary = ld["dice"][di]
	var H := house(ld)
	var me := LivingDice.throw_die(ld, d)
	var him := LivingDice.throw_die(ld, H)
	if not ld.has("won"):
		ld["won"] = {}
	var res := "tie"
	var tob := 0
	if me["v"] > him["v"]:
		res = "win"
		tob = mini(stake, DAILY_CAP - won_today(ld, day))
		ld["won"][str(day)] = won_today(ld, day) + tob
	elif me["v"] < him["v"]:
		res = "lose"
		tob = -stake
	return {"res": res, "me": me["v"], "him": him["v"], "tob": tob,
		"note": LivingDice.note(d, me["g"]) + " · " + LivingDice.note(H, him["g"])}

## The three inmates trading today (indexes into TRADE), minus any already taken.
static func offers(ld: Dictionary, day: int) -> Array:
	var s: int = int(ld.get("seed", 0)) + day * 5
	var out := []
	var k := 0
	while out.size() < 3 and k < 12:
		var t := (s + k * 2) % TRADE.size()
		if not out.has(t):
			out.append(t)
		k += 1
	var taken: Dictionary = ld.get("taken", {})
	return out.filter(func(t): return not taken.has("%d:%d" % [day, t]))

## Tobacco you pay (positive) or receive (negative) to swap `mine` for TRADE[t].
static func price(mine: Dictionary, t: int) -> int:
	var diff := 0
	for v in TRADE[t]["f"]:
		diff += int(v)
	for v in mine["f"]:
		diff -= int(v)
	return clampi(int(round(diff / 3.0)), -4, 6)

## Swap your die `di` for TRADE[t]. Returns the tobacco change (negative of price).
static func trade(ld: Dictionary, di: int, t: int, day: int) -> int:
	var p := price(ld["dice"][di], t)
	if not ld.has("taken"):
		ld["taken"] = {}
	ld["taken"]["%d:%d" % [day, t]] = true
	var T: Dictionary = TRADE[t]
	ld["dice"][di] = LivingDice.make_die(T["n"], T["f"], "bone", "%s Traded from %s on day %d." % [T["note"], T["who"], day])
	return -p

static func buy_hangman(ld: Dictionary) -> int:
	if ld.get("hangGot", false):
		return 0
	ld["dice"].append(LivingDice.hangman_die())
	ld["hangGot"] = true
	return -5

static func buy_blank(ld: Dictionary) -> int:
	if ld.get("blankGot", false):
		return 0
	ld["dice"].append(LivingDice.blank_die())
	ld["blankGot"] = true
	return -1

static func _remove(ld: Dictionary, di: int) -> void:
	ld["dice"].remove_at(di)
	var h: Array = ld["hand"]
	for s in 2:
		if int(h[s]) > di:
			h[s] = int(h[s]) - 1
	LivingDice.hand(ld)   # repairs any hand that pointed at the removed die

## Throw your left-hand die against the house for the Hangman's Die.
## Lose and Jory keeps the die you threw (he gives a chipped spare if you would drop under two).
static func throw_for_hangman(ld: Dictionary) -> Dictionary:
	if ld.get("hangGot", false):
		return {"win": false, "already": true}
	var di: int = ld["hand"][0]
	var d: Dictionary = ld["dice"][di]
	var H := house(ld)
	var me := LivingDice.throw_die(ld, d)
	var him := LivingDice.throw_die(ld, H)
	var win: bool = me["v"] > him["v"]
	if win:
		ld["dice"].append(LivingDice.hangman_die())
		ld["hangGot"] = true
	else:
		_remove(ld, di)
		if ld["dice"].size() < 2:
			ld["dice"].append(LivingDice.make_die("Chipped bone", LivingDice.STD, "bone", "Jory’s spare, given back so that you can still play. A corner is missing."))
		LivingDice.hand(ld)
	return {"win": win, "me": me["v"], "him": him["v"], "lost": "" if win else d["name"],
		"note": LivingDice.note(d, me["g"]) + " · " + LivingDice.note(H, him["g"])}
