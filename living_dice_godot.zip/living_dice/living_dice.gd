## Living dice for The Postal Trace and Malice Gaol (Godot 4).
## Same rules and the same save shape as the browser build, so a shared save
## file carries S.ld across unchanged.
##
## Off: two ordinary d6. On: each throw, the face that lands gains 1 and the
## face opposite it (index 5 - i) loses 1. Options: snowball (higher faces land
## more often), lock (hold one pair of faces still), blank (hard mode: every face
## starts at 1). Special kinds: "hang" (snowballs always, opposite loses 2) and
## "blank" (only fails outright on 0 or less).
##
## The state is a plain Dictionary, the same as the browser's S.ld:
## { on, snow, lock, blank, dice: [ {name, f:[6 ints], k, lock, n, note} ], hand: [i, j], ... }
class_name LivingDice
extends RefCounted

const STD := [1, 2, 3, 4, 5, 6]
const HANG_FACES := [6, 7, 8, 8, 7, 6]
const BLANK_FACES := [1, 1, 1, 1, 1, 1]

static func make_die(name: String, faces: Array, kind: String = "bone", note: String = "") -> Dictionary:
	return {"name": name, "f": faces.duplicate(), "k": kind, "lock": -1, "n": 0, "note": note}

static func hangman_die() -> Dictionary:
	return make_die("The Hangman’s Die", HANG_FACES, "hang", "Every face starts at six or better and it always runs hot toward its best face, but the face across from each throw loses 2. Lean on it long enough and every face goes below zero.")

static func blank_die() -> Dictionary:
	return make_die("The Blank", BLANK_FACES, "blank", "A die with every pip filed off but one, on every face. It starts as the worst die there is and becomes whatever you throw it into. It only fails outright on 0 or less.")

## Build the state from the character screen options. `dice` is the starting pair.
static func setup(opts: Dictionary, dice: Array) -> Dictionary:
	if opts.get("blank", false):
		for d in dice:
			d["f"] = BLANK_FACES.duplicate()
			d["k"] = "blank"
			d["name"] = str(d["name"]) + " (blank)"
	return {"on": true, "snow": opts.get("snow", false), "lock": opts.get("lock", false), "blank": opts.get("blank", false),
		"dice": dice, "hand": [0, 1], "seed": randi() % 1000}

static func postal_start(opts: Dictionary) -> Variant:
	if not opts.get("on", false):
		return null
	return setup(opts, [
		make_die("Left die", STD, "bone", "One of the pair of bone dice from the third battery’s mess tin. Nobody else wanted them."),
		make_die("Right die", STD, "bone", "Its twin. The two have never agreed about anything.")])

static func gaol_start(opts: Dictionary) -> Variant:
	if not opts.get("on", false):
		return null
	return setup(opts, [
		make_die("Drain bone", STD, "bone", "Fished out of the drain grate in Cell Nine on your first night. The last man here left it behind."),
		make_die("Shelf bone", STD, "bone", "Wedged under the plank shelf, its twin. Somebody scratched a gallows into the one.")])

static func is_on(ld) -> bool:
	return ld is Dictionary and ld.get("on", false)

static func hand(ld: Dictionary) -> Array:
	var dice: Array = ld["dice"]
	var h: Array = ld["hand"]
	if int(h[0]) < 0 or int(h[0]) >= dice.size():
		h[0] = 0
	if int(h[1]) < 0 or int(h[1]) >= dice.size() or int(h[1]) == int(h[0]):
		h[1] = 1 if int(h[0]) == 0 else 0
	return [dice[int(h[0])], dice[int(h[1])]]

## Put die `di` in hand `side` (0 left, 1 right), swapping if it is already in the other hand.
static func hold(ld: Dictionary, side: int, di: int) -> void:
	var h: Array = ld["hand"]
	var other := 1 - side
	if int(h[other]) == di:
		h[other] = h[side]
	h[side] = di

static func pair_of(i: int) -> int:
	return mini(i, 5 - i)

## Lock rule: toggle the pair holding face i still. One pair per die. Hangman's die cannot be locked.
static func toggle_lock(d: Dictionary, i: int) -> void:
	if d["k"] == "hang":
		return
	var p := pair_of(i)
	d["lock"] = -1 if int(d["lock"]) == p else p

static func snowballs(ld: Dictionary, d: Dictionary) -> bool:
	return d["k"] == "hang" or ld.get("snow", false)

static func weights(ld: Dictionary, d: Dictionary) -> Array:
	var sn := snowballs(ld, d)
	var w := []
	for v in d["f"]:
		w.append(maxf(0.2, 1.0 + 0.15 * float(v)) if sn else 1.0)
	return w

static func _sum(a: Array) -> float:
	var t := 0.0
	for x in a:
		t += float(x)
	return t

static func pick_face(ld: Dictionary, d: Dictionary) -> int:
	var w := weights(ld, d)
	var t := randf() * _sum(w)
	for i in 6:
		t -= w[i]
		if t <= 0.0:
			return i
	return 5

## Apply one throw that landed on face i. Returns what moved, for the roll note.
static func age(d: Dictionary, i: int) -> Dictionary:
	var o := 5 - i
	var g := {"i": i, "o": o, "a0": d["f"][i], "b0": d["f"][o], "locked": false}
	d["n"] = int(d.get("n", 0)) + 1
	if d["k"] != "hang" and int(d["lock"]) == pair_of(i):
		g["locked"] = true
		return g
	d["f"][i] = int(d["f"][i]) + 1
	d["f"][o] = int(d["f"][o]) - (2 if d["k"] == "hang" else 1)
	return g

static func throw_die(ld: Dictionary, d: Dictionary) -> Dictionary:
	var i := pick_face(ld, d)
	var v: int = d["f"][i]
	return {"v": v, "g": age(d, i)}

static func floor_of(d: Dictionary) -> int:
	return 0 if d["k"] == "blank" else 1

## Double six (6 or more on both) always succeeds; both at or under their floor always fails.
static func passes(a: int, b: int, tot: int, dc: int, fa: int = 1, fb: int = 1) -> bool:
	if a >= 6 and b >= 6:
		return true
	if a <= fa and b <= fb:
		return false
	return a + b + tot >= dc

## Percent chance for the check tag. m = {tot, dc}
static func odds(ld: Dictionary, m: Dictionary) -> int:
	var h := hand(ld)
	var wa := weights(ld, h[0])
	var wb := weights(ld, h[1])
	var p := 0.0
	for i in 6:
		for j in 6:
			if passes(h[0]["f"][i], h[1]["f"][j], m["tot"], m["dc"], floor_of(h[0]), floor_of(h[1])):
				p += wa[i] * wb[j]
	return int(round(p / (_sum(wa) * _sum(wb)) * 100.0))

static func note(d: Dictionary, g: Dictionary) -> String:
	if g["locked"]:
		return "%s: landed on a locked pair, nothing moves" % d["name"]
	return "%s: %d → %d, the face opposite %d → %d" % [d["name"], g["a0"], d["f"][g["i"]], g["b0"], d["f"][g["o"]]]

## Roll a check with the dice in hand. Same fields as the browser roll:
## {a, b, total, ok, crit: "hi"/"lo"/"", sup: "super"/"cata"/"", note, fx}
## fx is what the game should apply: super = Stamina +1 and 5 XP; catastrophe =
## Health -1, or Stamina -1 if Health is 2 or less (it never kills by itself).
static func roll(ld: Dictionary, m: Dictionary, hp: int) -> Dictionary:
	var h := hand(ld)
	var A := throw_die(ld, h[0])
	var B := throw_die(ld, h[1])
	var a: int = A["v"]
	var b: int = B["v"]
	var total: int = a + b + int(m["tot"])
	var fa := floor_of(h[0])
	var fb := floor_of(h[1])
	var ok := passes(a, b, m["tot"], m["dc"], fa, fb)
	var margin: int = total - int(m["dc"])
	var crit := "hi" if (a >= 6 and b >= 6) else ("lo" if (a <= fa and b <= fb) else "")
	var sup := ""
	var fx := {}
	if ok and margin >= 7:
		sup = "super"
		fx = {"st": 1, "xp": 5}
	elif not ok and (margin <= -7 or (a < 0 and b < 0)):
		sup = "cata"
		fx = {"hp": -1} if hp > 2 else {"st": -1}
	return {"a": a, "b": b, "total": total, "ok": ok, "crit": crit, "sup": sup, "fx": fx,
		"note": note(h[0], A["g"]) + " · " + note(h[1], B["g"])}

static func verdict(r: Dictionary, normal: String) -> String:
	match r.get("sup", ""):
		"super": return "Overwhelming success"
		"cata": return "Catastrophe"
	return normal

## Dev mode, Postal only for now.
static func dev_add(ld: Dictionary, which: String) -> void:
	match which:
		"blank": ld["dice"].append(blank_die())
		"hang": ld["dice"].append(hangman_die())
		"reset":
			for d in ld["dice"]:
				d["f"] = HANG_FACES.duplicate() if d["k"] == "hang" else (BLANK_FACES.duplicate() if d["k"] == "blank" else STD.duplicate())
				d["n"] = 0
				d["lock"] = -1
